# Hja²Ops - AI Multi-Agent Platform

## Overview

Hja²Ops is a sophisticated AI multi-agent platform that enables users to interact with specialized AI assistants through a modern web interface. The platform provides a comprehensive chat system, user management, credit-based billing, and administrative controls. Built as a full-stack application, it offers real-time AI conversations with token tracking, transaction management, and scalable architecture designed for future expansion into courses, community features, and content creation tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark theme
- **State Management**: TanStack Query for server state and caching
- **Routing**: Wouter for lightweight client-side routing
- **Authentication**: Session-based authentication with Replit Auth integration

### Backend Architecture
- **Runtime**: Node.js with Express server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with proper error handling and middleware
- **Session Management**: Express sessions with PostgreSQL storage
- **Authentication**: OpenID Connect via Replit Auth with Passport.js

### Database Design
- **Primary Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle migrations and schema definitions
- **Core Tables**:
  - `users`: User profiles, roles, plans, and credits
  - `agents`: AI agent configurations and metadata
  - `chats`: Conversation history and message storage
  - `transactions`: Payment and credit transaction records
  - `sessions`: Authentication session storage

### AI Integration
- **Primary Model**: OpenAI GPT-5 for chat completions
- **Token Management**: Automatic token counting and usage tracking
- **Multi-Agent System**: Configurable AI agents with specialized prompts
- **Fallback Strategy**: Prepared for multiple AI providers (Groq, HuggingFace)

### Security & Authentication
- **Authentication Method**: Replit OpenID Connect integration
- **Session Storage**: Secure PostgreSQL-backed sessions
- **Role-Based Access**: User, admin role management
- **API Security**: Authenticated endpoints with proper middleware

### Credit & Billing System
- **Credit Model**: Token-based usage tracking with credit deduction
- **Payment Integration**: Prepared for Mercado Pago integration
- **Plan Management**: Tiered plans (free, basic, pro, premium)
- **Transaction Tracking**: Complete audit trail for all transactions

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit Auth OpenID Connect provider
- **Session Storage**: PostgreSQL via connect-pg-simple

### AI Services
- **Primary AI**: OpenAI API (GPT-5 model)
- **Future Integrations**: Groq, HuggingFace APIs for fallback support

### Frontend Libraries
- **UI Components**: Radix UI component primitives
- **Styling**: Tailwind CSS framework
- **State Management**: TanStack Query for API state
- **Date Utilities**: date-fns for date formatting
- **Form Handling**: React Hook Form with Zod validation

### Development Tools
- **Build System**: Vite with TypeScript support
- **Code Quality**: ESLint, TypeScript strict mode
- **Database Tools**: Drizzle Kit for migrations and schema management
- **Development**: Hot module replacement via Vite

### Payment Processing
- **Payment Gateway**: Mercado Pago (configured but not yet implemented)
- **Mock Transactions**: Current implementation includes demo transaction flow

### Monitoring & Analytics
- **Error Handling**: Comprehensive error boundaries and API error handling
- **Logging**: Server-side request logging and error tracking
- **Performance**: Query optimization and caching strategies

## Recent Changes

### Courses Module Implementation (Janeiro 2024)
- **Complete Course System**: Implemented full-featured course module with Netflix-style interface, gamification, and token-based progression
- **Course Components**: Created CourseCard (Netflix-style), CoursePlayer (video player with sidebar), UnlockCourseModal (purchase confirmation)
- **Gamification System**: Token-based course unlocking, lesson completion rewards, progress tracking with visual indicators
- **Course Structure**: Comprehensive course data model with lessons, attachments, progress tracking, and multiple access levels (free/premium/unlocked)
- **Player Experience**: Full-featured video player with lesson navigation, progress tracking, attachments download, and completion system
- **Mock Data**: Rich course content including 6 complete courses with multiple lessons, instructor info, ratings, and student counts

### Dashboard Implementation (Janeiro 2024)
- Implemented comprehensive MainDashboard layout with sidebar navigation, header with search/notifications, and modular content sections
- Created modular dashboard sections for Home, Courses, Community, Resources, Tokens, Chat, and Settings with proper navigation
- Enhanced Sidebar.tsx with credits widget, user status, and dynamic navigation between sections
- Integrated HajaVersoDashboard.tsx as main entry point with proper routing in App.tsx replacing default landing behavior

### Design System Implementation (Janeiro 2024)
- **Complete UI Component Library**: Implemented comprehensive design system with Button, Input/Textarea, Card, Tabs, Badge, and Modal components using cyberpunk styling
- **Tailwind Configuration**: Extended with custom color tokens, shadow utilities, and hairline borders (0.2px) following the cyberpunk aesthetic (#000000, #00BFFF, #FF6A00)
- **Glass Morphism Effects**: Added glass utilities with backdrop-blur, neon glow effects, and subtle animations for enhanced visual hierarchy
- **Accessibility Features**: Implemented focus management, keyboard navigation, proper contrast ratios, and ARIA labels across all components
- **Design Documentation**: Created comprehensive README with usage guidelines, color system, component patterns, and accessibility standards