import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        primary: {
          DEFAULT: "var(--primary)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          foreground: "var(--secondary-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          foreground: "var(--accent-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
        // Hja²Ops cores específicas
        "hja-black": "#000000",
        "hja-blue": "#00f3ff", 
        "hja-orange": "#ff6b00",
        "hja-gray": "#c5d1db",
        
        // Hja²Ops Design System 2025
        hja: {
          // Backgrounds
          bg: "#000000",           // Preto absoluto
          surface: "#0A141B",      // Surface principal
          surfaceAlt: "#001A23",   // Surface alternativa
          
          // Primary colors  
          primary: "#00BFFF",      // Azul caneta luminoso (glow)
          accent: "#FF6A00",       // Laranja (alertas/CTA)
          
          // Text colors
          textBase: "#C5D1DB",     // Texto base "fumaça"
          textMuted: "#7A8C99",    // Texto secundário
          
          // Semantic colors
          success: "#00FF88",
          warning: "#FFB800", 
          danger: "#FF4444",
        }
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        inter: ["Inter", "system-ui", "sans-serif"],
        outfit: ["Outfit", "system-ui", "sans-serif"],
        orbitron: ["Orbitron", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)"],
        mono: ["var(--font-mono)"],
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        "glow-pulse": {
          "0%, 100%": { 
            boxShadow: "0 0 5px #00f3ff, 0 0 10px #00f3ff, 0 0 15px #00f3ff",
            opacity: "1"
          },
          "50%": { 
            boxShadow: "0 0 10px #00f3ff, 0 0 20px #00f3ff, 0 0 30px #00f3ff",
            opacity: "0.8"
          },
        },
        "neon-glow": {
          "0%": { textShadow: "0 0 5px #00f3ff" },
          "50%": { textShadow: "0 0 10px #00f3ff, 0 0 20px #00f3ff" },
          "100%": { textShadow: "0 0 5px #00f3ff" },
        },
        "glitch": {
          "0%": { transform: "translateX(0)" },
          "20%": { transform: "translateX(-2px)" },
          "40%": { transform: "translateX(2px)" },
          "60%": { transform: "translateX(-2px)" },
          "80%": { transform: "translateX(2px)" },
          "100%": { transform: "translateX(0)" },
        },
        "typing": {
          "0%": { width: "0" },
          "100%": { width: "100%" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "glow-pulse": "glow-pulse 2s infinite",
        "neon-glow": "neon-glow 2s infinite alternate",
        "glitch": "glitch 0.3s infinite",
        "typing": "typing 3.5s steps(40, end)",
      },
      boxShadow: {
        "glow-blue": "0 0 20px rgba(0, 243, 255, 0.5)",
        "glow-orange": "0 0 20px rgba(255, 107, 0, 0.5)",
        "glow-blue-strong": "0 0 30px rgba(0, 243, 255, 0.8)",
        'neon': '0 0 20px rgba(0, 191, 255, 0.3), 0 0 40px rgba(0, 191, 255, 0.1)',
        'neon-strong': '0 0 30px rgba(0, 191, 255, 0.5), 0 0 60px rgba(0, 191, 255, 0.2)',
        'neon-accent': '0 0 20px rgba(255, 106, 0, 0.3), 0 0 40px rgba(255, 106, 0, 0.1)',
        'glass': '0 8px 32px rgba(0, 0, 0, 0.3)',
      },
      
      borderWidth: {
        'hairline': '0.2px',
      },
      backgroundImage: {
        "glass-gradient": "linear-gradient(135deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05))",
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"), 
    require("@tailwindcss/typography"),
    function({ addUtilities }: any) {
      const newUtilities = {
        '.border-hairline': {
          borderWidth: '0.2px',
          borderColor: 'rgba(197, 209, 219, 0.2)',
        },
        '.smoke-text': {
          color: '#C5D1DB',
        },
        '.smoke-text-muted': {
          color: '#7A8C99',
        },
        '.glass': {
          backgroundColor: 'rgba(10, 20, 27, 0.6)',
          backdropFilter: 'blur(20px)',
          borderColor: 'rgba(0, 191, 255, 0.2)',
        },
        '.glass-strong': {
          backgroundColor: 'rgba(10, 20, 27, 0.8)',
          backdropFilter: 'blur(40px)',
          borderColor: 'rgba(0, 191, 255, 0.3)',
        },
        '.glow': {
          boxShadow: '0 0 20px rgba(0, 191, 255, 0.3), 0 0 40px rgba(0, 191, 255, 0.1)',
          borderColor: 'rgba(0, 191, 255, 0.4)',
        },
        '.glow-accent': {
          boxShadow: '0 0 20px rgba(255, 106, 0, 0.3), 0 0 40px rgba(255, 106, 0, 0.1)',
          borderColor: 'rgba(255, 106, 0, 0.4)',
        },
        '.focus-visible-custom': {
          '&:focus-visible': {
            outline: '2px solid rgba(0, 191, 255, 0.5)',
            outlineOffset: '2px',
          },
        },
      }
      addUtilities(newUtilities)
    }
  ],
} satisfies Config;
