import { MercadoPagoConfig, Preference, Payment } from 'mercadopago';

// In development, these can be demo/test values
const MP_ACCESS_TOKEN = process.env.MP_ACCESS_TOKEN || 'TEST-demo_token_for_development';

if (process.env.NODE_ENV === 'production' && !process.env.MP_ACCESS_TOKEN) {
  throw new Error('MP_ACCESS_TOKEN must be set in production');
}

// Initialize Mercado Pago client
const client = new MercadoPagoConfig({
  accessToken: MP_ACCESS_TOKEN,
  options: {
    timeout: 5000,
    idempotencyKey: 'abc'
  }
});

export const preference = new Preference(client);
export const payment = new Payment(client);

export interface CreatePaymentData {
  title: string;
  quantity: number;
  unit_price: number;
  userId: string;
  planId?: string;
  creditsAmount?: number;
}

export async function createCheckoutSession(data: CreatePaymentData) {
  try {
    // In development mode, return a mock checkout URL
    if (process.env.NODE_ENV === 'development' && MP_ACCESS_TOKEN.startsWith('TEST-demo')) {
      return {
        init_point: `/checkout/demo?amount=${data.unit_price}&title=${encodeURIComponent(data.title)}`,
        id: 'demo-preference-' + Date.now()
      };
    }

    const hostUrl = process.env.REPLIT_DOMAINS?.split(',')[0] || 'http://localhost:5000';
    
    const preferenceData = {
      items: [
        {
          id: data.planId || 'credits',
          title: data.title,
          quantity: data.quantity,
          unit_price: data.unit_price,
          currency_id: 'BRL'
        }
      ],
      back_urls: {
        success: `${hostUrl}/checkout/success`,
        failure: `${hostUrl}/checkout/failure`,
        pending: `${hostUrl}/checkout/pending`
      },
      auto_return: 'approved',
      external_reference: JSON.stringify({
        userId: data.userId,
        planId: data.planId,
        creditsAmount: data.creditsAmount,
        type: data.planId ? 'plan' : 'credits'
      }),
      notification_url: `${hostUrl}/api/webhook/mercadopago`,
      statement_descriptor: 'HjaOps Credits'
    };

    const response = await preference.create({ body: preferenceData });
    return response;
  } catch (error) {
    console.error('Error creating Mercado Pago preference:', error);
    throw new Error('Failed to create checkout session');
  }
}

export async function getPaymentInfo(paymentId: string) {
  try {
    // In development mode, return mock payment info
    if (process.env.NODE_ENV === 'development' && MP_ACCESS_TOKEN.startsWith('TEST-demo')) {
      return {
        id: paymentId,
        status: 'approved',
        external_reference: JSON.stringify({
          userId: 'demo_user_001',
          planId: null,
          creditsAmount: 100,
          type: 'credits'
        })
      };
    }

    const response = await payment.get({ id: paymentId });
    return response;
  } catch (error) {
    console.error('Error getting payment info:', error);
    throw new Error('Failed to get payment information');
  }
}