import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { db } from "./db";
import { 
  users, 
  chats, 
  transactions, 
  plans,
  monitoring, 
  notifications,
  techTrends,
  affiliateProducts,
  affiliateMetrics,
  posts,
  postReads
} from "@shared/schema";
import { eq, gte, lte, desc, asc, sum, count, avg, sql } from 'drizzle-orm';
import { generateChatResponse, estimateTokens } from "./services/openai";
import { orchestrator } from "./services/orchestrator";
import { handleChat, getAgents, getModels, getChatHistory, getUserCredits } from "./controllers/chatController";
import { seedDatabase } from "./seed";
import { 
  insertAgentSchema, 
  insertChatSchema, 
  insertTransactionSchema, 
  insertPlanSchema, 
  insertAffiliateProductSchema,
  insertAffiliateMetricsSchema,
  insertPostSchema,
  insertPostReadSchema,
  insertCapsuleSchema,
  insertReactionSchema,
  insertCommentSchema,
  type Message 
} from "@shared/schema";
import { z } from "zod";
import { checkCredits, addCredits } from "./middleware/credits.js";
import { createCheckoutSession, getPaymentInfo } from "./lib/mercadopago.js";
import { checkPostAccess, unlockPostWithCredits, formatPostContent, type PaywallRequest } from "./middleware/paywall";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Agent routes (new orchestrator)
  app.get('/api/agents', getAgents);

  // Agent routes (legacy)
  app.get('/api/agents/legacy', async (req, res) => {
    try {
      const agents = await storage.getActiveAgents();
      res.json(agents);
    } catch (error) {
      console.error("Error fetching agents:", error);
      res.status(500).json({ message: "Failed to fetch agents" });
    }
  });

  app.get('/api/agents/all', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const agents = await storage.getAgents();
      res.json(agents);
    } catch (error) {
      console.error("Error fetching all agents:", error);
      res.status(500).json({ message: "Failed to fetch agents" });
    }
  });

  app.post('/api/agents', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertAgentSchema.parse(req.body);
      const agent = await storage.createAgent(validatedData);
      res.json(agent);
    } catch (error) {
      console.error("Error creating agent:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid agent data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create agent" });
    }
  });

  app.put('/api/agents/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const validatedData = insertAgentSchema.partial().parse(req.body);
      const agent = await storage.updateAgent(id, validatedData);
      res.json(agent);
    } catch (error) {
      console.error("Error updating agent:", error);
      res.status(500).json({ message: "Failed to update agent" });
    }
  });

  app.delete('/api/agents/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      await storage.deleteAgent(id);
      res.json({ message: "Agent deleted successfully" });
    } catch (error) {
      console.error("Error deleting agent:", error);
      res.status(500).json({ message: "Failed to delete agent" });
    }
  });

  // New AI Orchestrator Chat Routes
  app.post('/api/chat', isAuthenticated, checkCredits(1), handleChat);
  app.get('/api/chat/history', isAuthenticated, getChatHistory);
  app.get('/api/credits', isAuthenticated, getUserCredits);
  app.get('/api/models', getModels);

  // Checkout and Payment routes
  app.post('/api/checkout/session', isAuthenticated, async (req: any, res) => {
    try {
      const { planId, creditsAmount } = req.body;
      const userId = req.user.claims.sub;

      let title: string;
      let unitPrice: number;
      let creditsToAdd: number;

      if (planId) {
        // Buying a plan
        const plan = await storage.getPlan(planId);
        if (!plan) {
          return res.status(404).json({ message: "Plan not found" });
        }
        title = `Plano ${plan.name} - Hja²Ops`;
        unitPrice = parseFloat(plan.price) / 100; // Convert from cents
        creditsToAdd = plan.creditsIncluded;
      } else if (creditsAmount) {
        // Buying credits directly
        title = `${creditsAmount} Créditos - Hja²Ops`;
        unitPrice = creditsAmount * 0.10; // R$ 0.10 per credit
        creditsToAdd = creditsAmount;
      } else {
        return res.status(400).json({ message: "Either planId or creditsAmount is required" });
      }

      // Create transaction record
      const transaction = await storage.createTransaction({
        userId,
        planId: planId || null,
        type: planId ? 'plan' : 'credits',
        amount: (unitPrice * 100).toString(), // Convert to cents
        creditsAdded: creditsToAdd,
        provider: 'mercadopago',
        status: 'pending'
      });

      // Create Mercado Pago preference
      const preference = await createCheckoutSession({
        title,
        quantity: 1,
        unit_price: unitPrice,
        userId,
        planId,
        creditsAmount
      });

      res.json({
        checkoutUrl: preference.init_point,
        transactionId: transaction.id
      });
    } catch (error) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ message: "Failed to create checkout session" });
    }
  });

  // Mercado Pago Webhook
  app.post('/api/webhook/mercadopago', async (req, res) => {
    try {
      const { type, data } = req.body;

      if (type === 'payment') {
        const paymentId = data.id;
        
        // Get payment info from Mercado Pago
        const paymentInfo = await getPaymentInfo(paymentId);
        
        if (paymentInfo.status === 'approved') {
          // Parse external reference to get transaction info
          const externalRef = JSON.parse(paymentInfo.external_reference || '{}');
          const { userId, creditsAmount, planId } = externalRef;

          // Find and update the transaction
          const [transaction] = await db
            .select()
            .from(transactions)
            .where(eq(transactions.userId, userId))
            .where(eq(transactions.status, 'pending'))
            .orderBy(desc(transactions.createdAt))
            .limit(1);

          if (transaction) {
            // Update transaction status
            await storage.updateTransaction(transaction.id, {
              status: 'completed',
              providerPaymentId: paymentId,
              metadata: paymentInfo
            });

            // Add credits to user
            await addCredits(userId, transaction.creditsAdded);

            // Update user plan if buying a plan
            if (planId) {
              const plan = await storage.getPlan(planId);
              if (plan) {
                await db
                  .update(users)
                  .set({ plan: plan.name })
                  .where(eq(users.id, userId));
              }
            }
          }
        } else if (paymentInfo.status === 'rejected' || paymentInfo.status === 'cancelled') {
          // Handle failed payment
          const externalRef = JSON.parse(paymentInfo.external_reference || '{}');
          const { userId } = externalRef;

          const [transaction] = await db
            .select()
            .from(transactions)
            .where(eq(transactions.userId, userId))
            .where(eq(transactions.status, 'pending'))
            .orderBy(desc(transactions.createdAt))
            .limit(1);

          if (transaction) {
            await storage.updateTransaction(transaction.id, {
              status: 'failed',
              providerPaymentId: paymentId,
              metadata: paymentInfo
            });
          }
        }
      }

      res.status(200).json({ message: 'Webhook processed successfully' });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(500).json({ message: "Webhook processing failed" });
    }
  });

  // Plans routes
  app.get('/api/plans', async (req, res) => {
    try {
      const plans = await storage.getActivePlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching plans:", error);
      res.status(500).json({ message: "Failed to fetch plans" });
    }
  });

  app.post('/api/plans', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertPlanSchema.parse(req.body);
      const plan = await storage.createPlan(validatedData);
      res.json(plan);
    } catch (error) {
      console.error("Error creating plan:", error);
      res.status(500).json({ message: "Failed to create plan" });
    }
  });

  // Transaction routes
  app.get('/api/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get('/api/admin/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const allTransactions = await db
        .select()
        .from(transactions)
        .orderBy(desc(transactions.createdAt))
        .limit(100);

      res.json(allTransactions);
    } catch (error) {
      console.error("Error fetching admin transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Chat routes (legacy)
  app.get('/api/chats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const chats = await storage.getChats(userId);
      res.json(chats);
    } catch (error) {
      console.error("Error fetching chats:", error);
      res.status(500).json({ message: "Failed to fetch chats" });
    }
  });

  app.get('/api/chats/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const chat = await storage.getChat(id);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }

      // Verify user owns this chat
      if (chat.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(chat);
    } catch (error) {
      console.error("Error fetching chat:", error);
      res.status(500).json({ message: "Failed to fetch chat" });
    }
  });

  app.post('/api/chats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertChatSchema.parse({
        ...req.body,
        userId,
      });

      const chat = await storage.createChat(validatedData);
      res.json(chat);
    } catch (error) {
      console.error("Error creating chat:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid chat data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create chat" });
    }
  });

  app.post('/api/chats/:id/messages', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { content } = req.body;
      const userId = req.user.claims.sub;

      if (!content || typeof content !== 'string') {
        return res.status(400).json({ message: "Message content is required" });
      }

      // Get chat and verify ownership
      const chat = await storage.getChat(id);
      if (!chat || chat.userId !== userId) {
        return res.status(404).json({ message: "Chat not found" });
      }

      // Get agent
      const agent = await storage.getAgent(chat.agentId);
      if (!agent) {
        return res.status(404).json({ message: "Agent not found" });
      }

      // Get user for credit check
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Estimate tokens for the new message
      const estimatedTokens = estimateTokens(content) + 100; // Add buffer for response
      
      if ((user.credits || 0) < estimatedTokens) {
        return res.status(402).json({ 
          message: "Insufficient credits",
          required: estimatedTokens,
          available: user.credits || 0 
        });
      }

      // Create user message
      const userMessage: Message = {
        role: 'user',
        content,
        timestamp: new Date().toISOString()
      };

      // Get current messages and add user message
      const currentMessages = (chat.messages as Message[]) || [];
      const messagesWithUser = [...currentMessages, userMessage];

      // Generate AI response
      const aiResponse = await generateChatResponse(
        messagesWithUser,
        agent.promptBase,
        agent.defaultModel || 'gpt-5'
      );

      // Create assistant message
      const assistantMessage: Message = {
        role: 'assistant',
        content: aiResponse.content,
        timestamp: new Date().toISOString(),
        tokensUsed: aiResponse.tokensUsed
      };

      // Update chat with both messages
      const updatedMessages = [...messagesWithUser, assistantMessage];
      const totalTokensUsed = (chat.tokensUsed || 0) + aiResponse.tokensUsed;

      const updatedChat = await storage.updateChat(id, {
        messages: updatedMessages,
        tokensUsed: totalTokensUsed,
        title: chat.title || content.substring(0, 50) + (content.length > 50 ? '...' : '')
      });

      // Deduct credits
      await storage.deductCredits(userId, aiResponse.tokensUsed);

      res.json({
        message: assistantMessage,
        tokensUsed: aiResponse.tokensUsed,
        chat: updatedChat
      });

    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  // Transaction routes
  app.get('/api/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post('/api/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertTransactionSchema.parse({
        ...req.body,
        userId,
      });

      const transaction = await storage.createTransaction(validatedData);
      
      // If this is a completed credit purchase, add credits to user
      if (validatedData.type === 'credits' && validatedData.status === 'completed' && validatedData.creditsAdded) {
        const user = await storage.getUser(userId);
        if (user) {
          await storage.updateUserCredits(userId, (user.credits || 0) + validatedData.creditsAdded);
        }
      }

      res.json(transaction);
    } catch (error) {
      console.error("Error creating transaction:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  // User Dashboard API
  app.get('/api/user/dashboard', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Mock dashboard data (replace with real data)
      const dashboardData = {
        credits: user.credits || 85,
        maxCredits: user.maxCredits || 200,
        plan: user.plan || 'Pro',
        
        // Recent chats
        recentChats: [
          { id: '1', agentName: 'Roteirista AI', lastMessage: 'Script criado com sucesso!', time: '2h atrás' },
          { id: '2', agentName: 'Vibe Code', lastMessage: 'Código otimizado e documentado.', time: '5h atrás' },
          { id: '3', agentName: 'Viral Maker', lastMessage: 'Estratégia de viral content pronta.', time: '1d atrás' },
        ],

        // HVC recommendations
        recommendations: [
          { type: 'upgrade', message: 'Considere fazer upgrade para Pro - você está usando 85% dos créditos', priority: 'high' },
          { type: 'usage', message: 'Ótimo uso do Roteirista AI! Continue explorando.', priority: 'low' },
          { type: 'alert', message: 'Novo modelo GPT-5 disponível com melhor performance', priority: 'medium' },
        ],

        // Chat history
        chats: [
          {
            id: '1',
            title: 'Estratégia de Conteúdo Viral',
            agentId: 'roteirista',
            agentName: 'Roteirista AI',
            agentColor: '#00f3ff',
            messageCount: 15,
            tokensUsed: 245,
            lastMessage: 'Script para TikTok criado com sucesso! Use os hooks sugeridos.',
            lastActivity: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            status: 'completed'
          }
        ],

        // Transactions
        transactions: [
          {
            id: 'tx_001',
            type: 'plan_upgrade',
            description: 'Upgrade para Plano Pro',
            amount: 49.90,
            credits: 500,
            status: 'completed',
            date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
            paymentMethod: 'PIX'
          }
        ],

        // Gamification
        progress: {
          level: 7,
          xp: 2450,
          xpToNextLevel: 3000,
          totalXp: 8950,
          rank: 'Explorador Avançado',
          streak: 12,
          totalChats: 127,
          tokensEarned: 240
        },

        badges: [
          {
            id: 'welcome',
            name: 'Bem-vindo',
            description: 'Completou o primeiro chat',
            icon: '👋',
            category: 'basic',
            unlocked: true,
            unlockedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
            rarity: 'common'
          }
        ]
      };

      res.json(dashboardData);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Admin HVC Core routes
  app.get('/api/admin/overview', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { hvcCore } = await import('./services/hvcCore');
      const [platformStatus, providerMetrics] = await Promise.all([
        hvcCore.getPlatformStatus(),
        hvcCore.getProviderMetrics()
      ]);

      res.json({
        platformStatus,
        providerMetrics,
        lastUpdated: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error fetching admin overview:", error);
      res.status(500).json({ message: "Failed to fetch overview data" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { hvcCore } = await import('./services/hvcCore');
      const tokenAnalysis = await hvcCore.analyzeTokenConsumption();
      
      // Get all users with consumption data
      const allUsers = await db.select().from(users).limit(100);
      
      const usersWithAnalysis = allUsers.map(u => {
        const analysis = tokenAnalysis.find(t => t.userId === u.id);
        return {
          ...u,
          tokenAnalysis: analysis || {
            tokensUsed: 0,
            tokensRemaining: u.credits || 0,
            projectedDays: 999,
            riskLevel: 'low'
          }
        };
      });

      res.json({
        users: usersWithAnalysis,
        totalUsers: allUsers.length,
        riskSummary: {
          high: tokenAnalysis.filter(t => t.riskLevel === 'high').length,
          medium: tokenAnalysis.filter(t => t.riskLevel === 'medium').length,
          low: tokenAnalysis.filter(t => t.riskLevel === 'low').length
        }
      });
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Failed to fetch users data" });
    }
  });

  app.get('/api/admin/chats', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const recentChats = await db
        .select()
        .from(chats)
        .orderBy(desc(chats.createdAt))
        .limit(20);

      // Get agent usage metrics
      const agentMetrics = await db
        .select({
          agentId: chats.agentId,
          totalChats: count(chats.id),
          totalTokens: sum(chats.tokensUsed)
        })
        .from(chats)
        .groupBy(chats.agentId);

      res.json({
        recentChats,
        agentMetrics,
        totalChats: recentChats.length
      });
    } catch (error) {
      console.error("Error fetching admin chats:", error);
      res.status(500).json({ message: "Failed to fetch chats data" });
    }
  });

  app.get('/api/admin/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const recentTransactions = await db
        .select()
        .from(transactions)
        .orderBy(desc(transactions.createdAt))
        .limit(50);

      // Revenue metrics
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const [todayRevenue, monthRevenue] = await Promise.all([
        db.select({ total: sum(transactions.amount) })
          .from(transactions)
          .where(gte(transactions.createdAt, today)),
        db.select({ total: sum(transactions.amount) })
          .from(transactions)
          .where(gte(transactions.createdAt, new Date(today.getFullYear(), today.getMonth(), 1)))
      ]);

      res.json({
        recentTransactions,
        revenue: {
          today: Number(todayRevenue[0]?.total || 0),
          month: Number(monthRevenue[0]?.total || 0)
        },
        transactionCount: recentTransactions.length
      });
    } catch (error) {
      console.error("Error fetching admin transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions data" });
    }
  });

  app.get('/api/admin/alerts', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const recentAlerts = await db
        .select()
        .from(notifications)
        .orderBy(desc(notifications.createdAt))
        .limit(20);

      const { hvcCore } = await import('./services/hvcCore');
      const newAlerts = await hvcCore.suggestUpgrades();

      // Get recent monitoring errors
      const recentErrors = await db
        .select()
        .from(monitoring)
        .where(eq(monitoring.success, false))
        .orderBy(desc(monitoring.timestamp))
        .limit(10);

      res.json({
        notifications: recentAlerts,
        suggestedAlerts: newAlerts,
        recentErrors,
        errorCount: recentErrors.length
      });
    } catch (error) {
      console.error("Error fetching admin alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts data" });
    }
  });

  app.post('/api/admin/give-credits', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { userId, credits, reason } = req.body;
      
      // Add credits to user
      await db.update(users)
        .set({ 
          credits: sql`${users.credits} + ${credits}`,
          updatedAt: new Date()
        })
        .where(eq(users.id, userId));

      // Log the action
      const { hvcCore } = await import('./services/hvcCore');
      await hvcCore.logMetric('admin_credit_grant', {
        adminId: req.user.claims.sub,
        targetUserId: userId,
        creditsAdded: credits,
        reason
      });

      res.json({ success: true, message: `${credits} créditos adicionados ao usuário` });
    } catch (error) {
      console.error("Error giving credits:", error);
      res.status(500).json({ message: "Failed to add credits" });
    }
  });

  // Admin routes
  app.get('/api/admin/users-old', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // This would typically be implemented with pagination
      // For now, returning basic user info
      res.json({ message: "Admin endpoint - implement user listing" });
    } catch (error) {
      console.error("Error fetching admin users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Return basic stats - would implement proper analytics
      res.json({
        totalUsers: 1247,
        activeChats: 89,
        tokensToday: 125400,
        revenue: 2847
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Test routes for terminal testing (demo purposes)
  app.post('/user', async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Create or get demo user
      const demoUser = await storage.upsertUser({
        id: "demo_user_001",
        email: email,
        firstName: "Demo",
        lastName: "User",
        role: "user",
        plan: "free",
        credits: 20
      });

      res.json({
        message: "Demo user created/updated",
        user: demoUser
      });
    } catch (error) {
      console.error("Error creating demo user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.post('/chat', async (req, res) => {
    try {
      const { userId, agentId, messages } = req.body;
      
      if (!userId || !agentId || !messages) {
        return res.status(400).json({ 
          message: "Missing required fields: userId, agentId, messages" 
        });
      }

      // Process chat through orchestrator
      const result = await orchestrator.processChat({
        userId,
        agentId,
        messages
      });

      if (result.success) {
        res.json({
          message: "Chat processed successfully",
          response: result.response,
          tokensUsed: result.tokensUsed,
          creditsDeducted: result.creditsDeducted
        });
      } else {
        res.status(400).json({
          message: result.error || "Chat processing failed"
        });
      }
    } catch (error) {
      console.error("Error processing chat:", error);
      res.status(500).json({ message: "Failed to process chat" });
    }
  });

  // Help routes
  app.post('/api/help/generate-tip', async (req, res) => {
    try {
      const { context } = req.body;
      
      if (!context) {
        return res.status(400).json({ message: "Context is required" });
      }

      // Generate AI-powered contextual tip
      const tipPrompt = `Generate a helpful tip for users in the "${context}" context of an AI Multi-Agent Platform. 
      
      The platform has:
      - 3 AI agents: Roteirista (content creation), Vibe Code (technical development), Agente Viral (marketing)
      - Chat interface for AI interactions
      - Credit-based token system
      - Analytics dashboard
      - Professional SaaS interface
      
      Generate a JSON response with:
      {
        "title": "Concise tip title",
        "content": "Detailed explanation (2-3 sentences in Portuguese)",
        "context": "${context}",
        "actionable": ["Action step 1", "Action step 2"]
      }
      
      Make it specific, actionable, and relevant to the ${context} context.`;

      const aiResponse = await generateChatResponse(tipPrompt, [] as Message[]);
      
      try {
        const tipData = JSON.parse(aiResponse.content);
        res.json(tipData);
      } catch (parseError) {
        // Fallback if AI doesn't return valid JSON
        res.json({
          title: "Dica Contextual",
          content: aiResponse.content.substring(0, 200) + "...",
          context: context,
          actionable: ["Explore as funcionalidades disponíveis", "Experimente diferentes agentes"]
        });
      }
    } catch (error) {
      console.error("Error generating AI tip:", error);
      res.status(500).json({ message: "Failed to generate tip" });
    }
  });

  // Seed database endpoint
  app.post('/api/seed', async (req, res) => {
    try {
      const result = await seedDatabase();
      if (result.success) {
        res.json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error("Error seeding database:", error);
      res.status(500).json({ message: "Failed to seed database" });
    }
  });

  // Admin Dashboard Routes
  app.get('/api/admin/usage', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      // Mock usage data - replace with real analytics
      const usageData = {
        tokensToday: 47200,
        mostUsedModel: 'groq',
        monthlyRevenue: 12400,
        systemStatus: 'stable',
        recentActivities: [
          {
            user: 'Carlos Silva',
            action: 'usou',
            agent: 'Agente Viral',
            tokens: 12,
            timestamp: new Date()
          }
        ],
        tokenConsumption: [1200, 800, 1800, 2400, 3200, 2800, 2100],
        alerts: [
          {
            level: 'high',
            title: 'Usuário com Uso Anômalo',
            message: 'João Silva consumiu 5x mais tokens que a média',
            time: '2 min atrás'
          }
        ]
      };
      
      res.json(usageData);
    } catch (error) {
      console.error("Error fetching usage data:", error);
      res.status(500).json({ message: "Failed to fetch usage data" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/admin/credits', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { userId, amount, description } = req.body;
      
      if (!userId || typeof amount !== 'number') {
        return res.status(400).json({ message: "userId and amount are required" });
      }
      
      const targetUser = await storage.getUser(userId);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update user credits
      const newCredits = Math.max(0, targetUser.credits + amount);
      await storage.updateUserCredits(userId, newCredits);
      
      // Create transaction record
      const transaction = {
        userId,
        type: 'adjustment' as const,
        amount: 0,
        creditsAdded: amount,
        description: description || `Admin credit adjustment: ${amount > 0 ? '+' : ''}${amount}`,
        paymentIntentId: null
      };
      
      await storage.createTransaction(transaction);
      
      res.json({ message: "Credits updated successfully", newCredits });
    } catch (error) {
      console.error("Error updating credits:", error);
      res.status(500).json({ message: "Failed to update credits" });
    }
  });

  // HajaVerso Community & Courses Routes
  
  // Courses Routes
  app.get('/api/courses', async (req, res) => {
    try {
      // Mock courses data
      const courses = [
        {
          id: '1',
          title: 'Criação de Vídeos Virais com IA',
          description: 'Aprenda a criar conteúdo viral usando ferramentas de IA e técnicas avançadas de storytelling.',
          thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=225&fit=crop',
          instructor: 'Carlos Mentor',
          duration: '4h 30m',
          lessons: 24,
          students: 1247,
          rating: 4.8,
          level: 'intermediario',
          price: 197,
          tags: ['Vídeo', 'IA', 'Marketing'],
          progress: 65,
          isEnrolled: true,
          isPremium: false
        }
      ];
      
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  // Community Posts Routes
  app.get('/api/community/posts', async (req, res) => {
    try {
      // Mock community posts
      const posts = [
        {
          id: '1',
          author: {
            id: '1',
            name: 'Ana Designer',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=40&h=40&fit=crop&crop=face',
            badge: 'vip',
            level: 24
          },
          title: 'Como criar thumbnails que convertem 10x mais',
          content: 'Pessoal, depois de testar mais de 200 thumbnails diferentes, descobri 3 técnicas que aumentaram meu CTR de 2% para 20%. Vou compartilhar tudo aqui...',
          tags: ['design', 'thumbnails', 'youtube'],
          likes: 47,
          comments: 12,
          isLiked: false,
          isStarred: true,
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
          category: 'design'
        }
      ];
      
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.post('/api/community/posts', isAuthenticated, async (req: any, res) => {
    try {
      const { title, content, tags, category } = req.body;
      
      if (!title || !content) {
        return res.status(400).json({ message: "Title and content are required" });
      }
      
      // Mock post creation
      const newPost = {
        id: Date.now().toString(),
        author: {
          id: req.user.claims.sub,
          name: req.user.claims.name || 'User',
          avatar: req.user.claims.picture || '',
          badge: 'pro',
          level: 15
        },
        title,
        content,
        tags: tags ? tags.split(',').map((tag: string) => tag.trim()) : [],
        likes: 0,
        comments: 0,
        isLiked: false,
        isStarred: false,
        createdAt: new Date(),
        category: category || 'geral'
      };
      
      res.status(201).json(newPost);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  // Resources Routes
  app.get('/api/resources', async (req, res) => {
    try {
      // Mock resources data
      const resources = [
        {
          id: '1',
          title: 'Pack Transições Cinematográficas',
          description: '50 transições profissionais para dar um acabamento de cinema aos seus vídeos.',
          type: 'pack',
          category: 'video',
          thumbnail: 'https://images.unsplash.com/photo-1489598843681-ba1966d2c0e0?w=300&h=200&fit=crop',
          downloads: 2847,
          rating: 4.9,
          price: 0,
          isPremium: false,
          isUnlocked: true,
          tokensRequired: 15,
          fileSize: '2.3 GB',
          format: 'MP4, MOV',
          tags: ['transições', 'cinema', 'premium']
        }
      ];
      
      res.json(resources);
    } catch (error) {
      console.error("Error fetching resources:", error);
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  // Tokens & Gamification Routes
  app.get('/api/tokens/history', isAuthenticated, async (req: any, res) => {
    try {
      // Mock token history
      const history = [
        {
          id: '1',
          action: 'Aula Concluída',
          tokens: 10,
          type: 'earned',
          timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
          description: 'Criação de Vídeos Virais - Aula 3'
        }
      ];
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching token history:", error);
      res.status(500).json({ message: "Failed to fetch token history" });
    }
  });

  app.get('/api/achievements', isAuthenticated, async (req: any, res) => {
    try {
      // Mock achievements data
      const achievements = [
        {
          id: '1',
          title: 'Primeira Aula',
          description: 'Assista sua primeira aula completa',
          tokens: 10,
          isCompleted: true,
          progress: 1,
          maxProgress: 1,
          category: 'cursos'
        }
      ];
      
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  // HVC Core - Token Management System Routes
  
  // Token Overview & Analytics
  app.get('/api/hvc/overview', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Business logic: Calculate real-time metrics
      const overview = {
        currentBalance: 2847,
        dailyUsage: 156,
        monthlyUsage: 4680,
        daysRemaining: Math.floor(2847 / 156), // Auto-calculate based on usage
        estimatedMonthlyCost: 247.50,
        conversionRate: 8.5,
        profitMargin: 87.2, // Target: 80%+ margin
        totalUsers: 1543,
        premiumUsers: 127,
        systemHealth: 98.2,
        realTimeCost: 67.45,
        apiErrors: 12,
        avgResponseTime: 450,
        activeUsers: 234,
        tokensPerSecond: 12.3
      };

      // Apply business rules
      if (overview.profitMargin < 80) {
        overview.alerts = [{
          type: 'warning',
          message: 'Margin below target. Consider price adjustments.',
          action: 'REVIEW_PRICING'
        }];
      }

      res.json(overview);
    } catch (error) {
      console.error("Error fetching HVC overview:", error);
      res.status(500).json({ message: "Failed to fetch overview" });
    }
  });

  // AI Forecast System
  app.get('/api/hvc/forecast', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { period = '30d' } = req.query;
      
      // Mock AI predictions with business logic
      const predictions = [
        {
          id: '1',
          type: 'shortage',
          title: 'Escassez de Tokens Prevista',
          description: 'Com o uso atual de 156 tokens/dia, você ficará sem tokens em 18 dias.',
          probability: 95,
          impact: 'high',
          daysUntil: 18,
          action: 'Comprar 2.000 tokens agora',
          estimatedCost: 300.00
        },
        {
          id: '2',
          type: 'upgrade',
          title: 'Upgrade Recomendado',
          description: 'Usuários excedendo 80% do plano atual. Sugerir upgrade automático.',
          probability: 78,
          impact: 'medium',
          daysUntil: 5,
          action: 'Implementar upgrade automático',
          estimatedSavings: 89.50
        },
        {
          id: '3',
          type: 'optimization',
          title: 'Oportunidade de Otimização',
          description: 'Migrar 40% do tráfego para modelos Groq reduziria custos em 60%.',
          probability: 85,
          impact: 'high',
          daysUntil: 0,
          action: 'Ativar distribuição inteligente',
          estimatedSavings: 156.30
        }
      ];

      // Business rule: Auto-trigger actions when probability > 90%
      predictions.forEach(prediction => {
        if (prediction.probability > 90) {
          prediction.autoTrigger = true;
        }
      });

      res.json({ predictions, period, accuracy: 98.5 });
    } catch (error) {
      console.error("Error fetching HVC forecast:", error);
      res.status(500).json({ message: "Failed to fetch forecast" });
    }
  });

  // Smart Distribution Controls
  app.get('/api/hvc/distribution', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const modelProviders = [
        {
          id: 'groq',
          name: 'Groq (Llama 3)',
          cost: 0.001, // R$ 0.001 per 1k tokens
          performance: 85,
          latency: 120,
          reliability: 98,
          isActive: true,
          usage: 45,
          costToday: 23.40
        },
        {
          id: 'openai',
          name: 'OpenAI GPT-4o',
          cost: 0.030, // 30x more expensive than Groq
          performance: 98,
          latency: 800,
          reliability: 99,
          isActive: true,
          usage: 25,
          costToday: 89.50
        },
        {
          id: 'huggingface',
          name: 'HuggingFace Mixtral',
          cost: 0.002,
          performance: 80,
          latency: 200,
          reliability: 95,
          isActive: true,
          usage: 20,
          costToday: 12.80
        }
      ];

      const userTiers = [
        {
          id: 'free',
          name: 'Usuários Gratuitos',
          users: 1416, // totalUsers - premiumUsers
          tokensPerDay: 50,
          allowedModels: ['groq', 'huggingface'], // Only cheap models
          priority: 3,
          costPerUser: 0.05
        },
        {
          id: 'basic',
          name: 'Plano Básico',
          users: 76, // 60% of premium
          tokensPerDay: 200,
          allowedModels: ['groq', 'huggingface', 'openai'],
          priority: 2,
          costPerUser: 0.30
        },
        {
          id: 'pro',
          name: 'Plano Pro',
          users: 38, // 30% of premium
          tokensPerDay: 500,
          allowedModels: ['groq', 'huggingface', 'openai'],
          priority: 1,
          costPerUser: 0.60
        },
        {
          id: 'enterprise',
          name: 'Enterprise',
          users: 13, // 10% of premium
          tokensPerDay: 2000,
          allowedModels: ['groq', 'huggingface', 'openai'],
          priority: 0,
          costPerUser: 2.00
        }
      ];

      // Business logic: Calculate distribution rules
      const distributionRules = [
        {
          id: '1',
          title: 'Fallback Inteligente',
          description: 'Se OpenAI > R$100/dia, redirecionar para Groq',
          isActive: true,
          impact: 'high',
          triggered: modelProviders.find(p => p.id === 'openai')?.costToday > 100
        },
        {
          id: '2',
          title: 'Limite de Custo por Usuário',
          description: 'Pausar usuários que excedem 10x o uso médio',
          isActive: true,
          impact: 'high',
          triggered: false
        }
      ];

      res.json({ modelProviders, userTiers, distributionRules, autoDistribution: true });
    } catch (error) {
      console.error("Error fetching distribution data:", error);
      res.status(500).json({ message: "Failed to fetch distribution data" });
    }
  });

  app.post('/api/hvc/distribution/toggle-provider', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { providerId, isActive } = req.body;
      
      // Business logic: Prevent disabling all providers
      if (!isActive) {
        // Check if this would leave less than 2 active providers
        // Implementation would check database for current provider states
      }

      console.log(`Provider ${providerId} set to ${isActive ? 'active' : 'inactive'}`);
      
      res.json({ message: "Provider status updated", providerId, isActive });
    } catch (error) {
      console.error("Error toggling provider:", error);
      res.status(500).json({ message: "Failed to toggle provider" });
    }
  });

  // Rewards & Gamification System
  app.get('/api/hvc/rewards', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const rewards = [
        {
          id: '1',
          title: 'Onboarding Completo',
          description: 'Usuário finaliza tutorial e configuração inicial',
          tokens: 5,
          type: 'onboarding',
          isActive: true,
          triggers: 2847,
          conversions: 2401,
          totalTokensGiven: 12005,
          conversionRate: (2401 / 2847) * 100,
          cost: 12005 * 0.15 // tokens * cost per token
        },
        {
          id: '2',
          title: 'Primeiro Amigo',
          description: 'Indica um amigo que se cadastra na plataforma',
          tokens: 10,
          type: 'referral',
          isActive: true,
          triggers: 456,
          conversions: 423,
          totalTokensGiven: 4230,
          conversionRate: (423 / 456) * 100,
          cost: 4230 * 0.15
        }
      ];

      // Business logic: Calculate ROI for each reward
      rewards.forEach(reward => {
        // Assume each conversion brings R$30 average value
        const revenue = reward.conversions * 30;
        reward.roi = ((revenue - reward.cost) / reward.cost) * 100;
      });

      const gamificationStats = {
        totalTokensDistributed: rewards.reduce((sum, r) => sum + r.totalTokensGiven, 0),
        totalCost: rewards.reduce((sum, r) => sum + r.cost, 0),
        averageROI: rewards.reduce((sum, r) => sum + r.roi, 0) / rewards.length,
        activeRewards: rewards.filter(r => r.isActive).length,
        totalRewards: rewards.length
      };

      res.json({ rewards, stats: gamificationStats });
    } catch (error) {
      console.error("Error fetching rewards data:", error);
      res.status(500).json({ message: "Failed to fetch rewards data" });
    }
  });

  app.post('/api/hvc/rewards/toggle', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { rewardId, isActive } = req.body;
      
      console.log(`Reward ${rewardId} set to ${isActive ? 'active' : 'inactive'}`);
      
      res.json({ message: "Reward status updated", rewardId, isActive });
    } catch (error) {
      console.error("Error toggling reward:", error);
      res.status(500).json({ message: "Failed to toggle reward" });
    }
  });

  // Admin Controls & Emergency Actions
  app.post('/api/hvc/emergency', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { action } = req.body;
      
      // Business logic: Emergency protocols
      switch (action) {
        case 'STOP_ALL_AGENTS':
          console.log('EMERGENCY: Stopping all AI agents');
          // Would disable all AI model endpoints
          break;
        case 'ECONOMY_MODE':
          console.log('EMERGENCY: Activating economy mode');
          // Would switch all traffic to cheapest providers only
          break;
        case 'PAUSE_REGISTRATIONS':
          console.log('EMERGENCY: Pausing new user registrations');
          break;
        case 'SYSTEM_RESET':
          console.log('EMERGENCY: Initiating system reset');
          break;
        default:
          return res.status(400).json({ message: "Invalid emergency action" });
      }
      
      res.json({ message: `Emergency action ${action} executed`, timestamp: new Date() });
    } catch (error) {
      console.error("Error executing emergency action:", error);
      res.status(500).json({ message: "Failed to execute emergency action" });
    }
  });

  app.post('/api/hvc/pricing/update', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { plan, newPrice } = req.body;
      
      // Business logic: Price validation
      const minPrices = {
        'Básico': 19.90,
        'Pro': 39.90,
        'Enterprise': 99.90
      };

      if (newPrice < minPrices[plan as keyof typeof minPrices]) {
        return res.status(400).json({ 
          message: `Price too low for ${plan}. Minimum: R$ ${minPrices[plan as keyof typeof minPrices]}` 
        });
      }

      console.log(`Updating ${plan} price to R$ ${newPrice}`);
      
      res.json({ message: "Price updated successfully", plan, newPrice });
    } catch (error) {
      console.error("Error updating price:", error);
      res.status(500).json({ message: "Failed to update price" });
    }
  });

  // Token Charts & Analytics Data
  app.get('/api/hvc/charts', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { period = '30d' } = req.query;
      
      // Generate realistic mock data based on business patterns
      const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
      
      const tokenUsageData = Array.from({length: days}, (_, i) => {
        // Simulate weekend dips and workday peaks
        const isWeekend = (i % 7 === 0 || i % 7 === 6);
        const baseUsage = isWeekend ? 800 : 2400;
        const randomVariation = Math.random() * 800;
        return Math.floor(baseUsage + randomVariation);
      });

      const costData = tokenUsageData.map(usage => ({
        usage,
        cost: usage * 0.03, // Average cost per token
        margin: 85 + Math.random() * 10 // 85-95% margin
      }));

      const providerDistribution = {
        'Groq': 45, // Cheapest, highest usage
        'OpenAI': 25, // Most expensive, limited usage
        'HuggingFace': 20,
        'Claude': 10
      };

      res.json({
        tokenUsage: tokenUsageData,
        costAnalysis: costData,
        providerDistribution,
        period,
        insights: [
          {
            type: 'optimization',
            title: 'Economia Detectada',
            description: 'Migração para Groq resultou em 45% de economia',
            savings: 156.30
          },
          {
            type: 'prediction',
            title: 'Pico de Uso Previsto',
            description: 'Esperado entre 14h-16h baseado no histórico',
            confidence: 92
          }
        ]
      });
    } catch (error) {
      console.error("Error fetching charts data:", error);
      res.status(500).json({ message: "Failed to fetch charts data" });
    }
  });

  // TechWatch System Routes
  
  // Real-time system metrics
  app.get('/api/techwatch/metrics', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Real-time system health metrics
      const metrics = {
        systemHealth: 98.5,
        lastScan: new Date(),
        activeIncidents: 1,
        todayErrors: 12,
        avgLatency: 450,
        costToday: 67.45,
        tokenUsage: 24671,
        fallbackRate: 3.2,
        providers: [
          {
            id: 'groq',
            name: 'Groq (Llama 3)',
            status: 'operational',
            uptime: 99.8,
            latency: 120,
            errors: 2,
            requests: 12847,
            cost: 23.40
          },
          {
            id: 'openai',
            name: 'OpenAI GPT-4o',
            status: 'degraded',
            uptime: 97.2,
            latency: 850,
            errors: 8,
            requests: 6234,
            cost: 89.50
          },
          {
            id: 'huggingface',
            name: 'HuggingFace',
            status: 'operational',
            uptime: 99.1,
            latency: 200,
            errors: 1,
            requests: 8956,
            cost: 12.80
          }
        ]
      };

      res.json(metrics);
    } catch (error) {
      console.error("Error fetching TechWatch metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // TechWatch AI news feed
  app.get('/api/techwatch/feed', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Mock AI news feed with realistic updates
      const techWatchItems = [
        {
          id: '1',
          title: 'OpenAI GPT-4o Preço Reduzido em 25%',
          type: 'price_change',
          source: 'OpenAI Official',
          provider: 'openai',
          impact: 'high',
          description: 'OpenAI anunciou redução de preços do GPT-4o de $0.03/1k tokens para $0.0225/1k tokens, efetivo imediatamente.',
          recommendation: 'Reavaliar distribuição de tráfego. Considerar aumentar quota de GPT-4o para usuários Pro.',
          actionRequired: true,
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          url: 'https://openai.com/pricing',
          tags: ['pricing', 'gpt-4o', 'cost-optimization']
        },
        {
          id: '2',
          title: 'Groq Llama 3.1 405B Disponível',
          type: 'model_update',
          source: 'Groq Blog',
          provider: 'groq',
          impact: 'medium',
          description: 'Nova versão do Llama 3.1 405B com melhor performance em raciocínio e código. Latência mantida em ~100ms.',
          recommendation: 'Testar modelo em sandbox. Performance pode superar GPT-4o em alguns casos específicos.',
          actionRequired: false,
          timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
          tags: ['llama', 'performance', 'reasoning']
        },
        {
          id: '3',
          title: 'Claude 3.5 Sonnet Instabilidade Relatada',
          type: 'outage',
          source: 'Anthropic Status',
          provider: 'anthropic',
          impact: 'medium',
          description: 'Usuários reportam timeouts intermitentes (15-20% das requests) nas últimas 2 horas.',
          recommendation: 'Ativar fallback automático para Claude. Monitorar próximas 4 horas.',
          actionRequired: true,
          timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
          url: 'https://status.anthropic.com',
          tags: ['outage', 'reliability', 'fallback']
        }
      ];

      res.json({
        items: techWatchItems,
        lastScan: new Date(),
        totalItems: techWatchItems.length,
        actionRequired: techWatchItems.filter(item => item.actionRequired).length,
        accuracy: 98.5
      });
    } catch (error) {
      console.error("Error fetching TechWatch feed:", error);
      res.status(500).json({ message: "Failed to fetch TechWatch feed" });
    }
  });

  // Alerts and actions system
  app.get('/api/techwatch/alerts', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const alerts = [
        {
          id: '1',
          title: 'OpenAI Latência Crítica',
          description: 'P95 latência excedeu 4s por 15 minutos consecutivos. Impactando 23% dos usuários.',
          severity: 'critical',
          type: 'performance',
          timestamp: new Date(Date.now() - 10 * 60 * 1000),
          isActive: true,
          autoResolved: false,
          affectedUsers: 57,
          actions: [
            {
              id: 'fallback-openai',
              label: 'Ativar Fallback',
              description: 'Redirecionar tráfego OpenAI para Groq',
              estimatedImpact: 'Redução 80% latência',
              executionTime: '30s'
            }
          ]
        },
        {
          id: '2',
          title: 'Custo Diário Excedido',
          description: 'Gasto atual R$ 67.45 ultrapassou meta de R$ 65/dia.',
          severity: 'warning',
          type: 'cost',
          timestamp: new Date(Date.now() - 25 * 60 * 1000),
          isActive: true,
          autoResolved: false,
          actions: [
            {
              id: 'economy-mode',
              label: 'Modo Economia',
              description: 'Priorizar modelos baratos (Groq/HF)',
              estimatedImpact: 'Economia 60%',
              executionTime: '15s'
            }
          ]
        }
      ];

      const automationRules = [
        {
          id: '1',
          name: 'Fallback Automático',
          description: 'Se erros > 10% por 10min → ativar fallback',
          isActive: true,
          triggeredCount: 3,
          lastTriggered: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
        },
        {
          id: '2',
          name: 'Controle de Custo',
          description: 'Se custo > meta diária → ativar economia',
          isActive: true,
          triggeredCount: 7,
          lastTriggered: new Date(Date.now() - 1 * 60 * 60 * 1000)
        }
      ];

      res.json({
        alerts,
        automationRules,
        activeAlerts: alerts.filter(a => a.isActive).length,
        criticalAlerts: alerts.filter(a => a.severity === 'critical' && a.isActive).length
      });
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post('/api/techwatch/actions/execute', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { actionId, alertId } = req.body;
      
      console.log(`Executing TechWatch action: ${actionId} for alert: ${alertId}`);
      
      // Business logic for different actions
      let result = { message: 'Action executed successfully', timestamp: new Date() };
      
      switch (actionId) {
        case 'fallback-openai':
          console.log('Activating fallback from OpenAI to Groq');
          result.message = 'Fallback ativado: tráfego redirecionado para Groq';
          break;
        case 'economy-mode':
          console.log('Activating economy mode');
          result.message = 'Modo economia ativado: priorizando modelos baratos';
          break;
        case 'global-fallback':
          console.log('Activating global fallback');
          result.message = 'Fallback global ativado para todos os provedores instáveis';
          break;
        default:
          result.message = `Ação ${actionId} executada com sucesso`;
      }
      
      res.json(result);
    } catch (error) {
      console.error("Error executing action:", error);
      res.status(500).json({ message: "Failed to execute action" });
    }
  });

  // Economy dashboard data
  app.get('/api/techwatch/economy', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const economyData = {
        monthlyRevenue: 12847.50,
        monthlyCosts: 1652.30,
        profitMargin: 87.2,
        cac: 23.50, // Customer Acquisition Cost
        ltv: 247.80, // Lifetime Value
        ltvToCac: 10.5,
        conversionRate: 8.7,
        churnRate: 2.3,
        arpu: 34.20, // Average Revenue Per User
        mrr: 8945.60, // Monthly Recurring Revenue
        growth: 23.8,
        planMetrics: [
          {
            plan: 'Gratuito',
            users: 1416,
            revenue: 0,
            cost: 142.40,
            margin: -100,
            conversionRate: 4.2
          },
          {
            plan: 'Básico',
            users: 76,
            revenue: 2272.40,
            cost: 91.20,
            margin: 96.0,
            conversionRate: 12.5
          },
          {
            plan: 'Pro',
            users: 38,
            revenue: 2276.20,
            cost: 68.40,
            margin: 97.0,
            conversionRate: 8.3
          },
          {
            plan: 'Enterprise',
            users: 13,
            revenue: 1948.70,
            cost: 78.20,
            margin: 96.0,
            conversionRate: 0
          }
        ]
      };

      res.json(economyData);
    } catch (error) {
      console.error("Error fetching economy data:", error);
      res.status(500).json({ message: "Failed to fetch economy data" });
    }
  });

  // Monetization & Payment Routes
  
  // Get user credits and usage
  app.get('/api/credits/balance', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Mock credit data - in production, this would come from database
      const creditData = {
        balance: user.credits || 247,
        totalEarned: 325,
        totalSpent: 78,
        dailyUsage: [
          { date: '2024-01-15', credits: 5.2 },
          { date: '2024-01-16', credits: 8.1 },
          { date: '2024-01-17', credits: 3.4 },
          { date: '2024-01-18', credits: 12.3 },
          { date: '2024-01-19', credits: 6.7 },
          { date: '2024-01-20', credits: 9.1 },
          { date: '2024-01-21', credits: 4.8 }
        ],
        recentUsage: [
          {
            id: '1',
            agentId: 'roteiro',
            agentName: 'Roteirista IA',
            model: 'gpt-4o',
            credits: 2.5,
            timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
            details: 'Roteiro publicitário 30s'
          },
          {
            id: '2',
            agentId: 'code',
            agentName: 'Vibe Code', 
            model: 'groq',
            credits: 0.8,
            timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
            details: 'Componente React para dashboard'
          }
        ]
      };

      res.json(creditData);
    } catch (error) {
      console.error("Error fetching credit balance:", error);
      res.status(500).json({ message: "Failed to fetch credit balance" });
    }
  });

  // Get available credit packages and plans
  app.get('/api/credits/packages', async (req, res) => {
    try {
      // Mock product data - in production, this would come from database/config
      const packages = {
        creditPackages: [
          {
            id: 'credits_50',
            name: 'Starter',
            credits: 50,
            price: 19.90,
            description: 'Perfeito para testar nossos agentes',
            features: ['Todos os agentes disponíveis', 'Suporte por email', 'Histórico de 30 dias']
          },
          {
            id: 'credits_200',
            name: 'Popular',
            credits: 200,
            price: 69.90,
            originalPrice: 79.60,
            popular: true,
            bonus: 20,
            description: 'Ideal para uso regular',
            features: ['Todos os agentes disponíveis', 'Suporte prioritário', 'Histórico de 90 dias', '+20 créditos bônus']
          },
          {
            id: 'credits_500',
            name: 'Professional',
            credits: 500,
            price: 149.90,
            originalPrice: 199.00,
            bonus: 100,
            description: 'Para criadores profissionais',
            features: ['Todos os agentes disponíveis', 'Modelos premium', 'Suporte via WhatsApp', 'Histórico ilimitado', '+100 créditos bônus']
          },
          {
            id: 'credits_1000',
            name: 'Enterprise',
            credits: 1000,
            price: 249.90,
            originalPrice: 399.00,
            bonus: 300,
            description: 'Para equipes e agências',
            features: ['Todos os agentes disponíveis', 'Modelos premium', 'Suporte dedicado', 'API access', 'Relatórios avançados', '+300 créditos bônus']
          }
        ],
        plans: [
          {
            id: 'basic_monthly',
            name: 'Basic',
            price: 39.90,
            credits: 200,
            interval: 'monthly',
            features: ['200 créditos/mês', 'Todos os agentes', 'Suporte por email', 'Histórico 30 dias']
          },
          {
            id: 'pro_monthly',
            name: 'Pro',
            price: 89.90,
            credits: 500,
            interval: 'monthly',
            popular: true,
            features: ['500 créditos/mês', 'Todos os agentes', 'Modelos premium', 'Suporte WhatsApp', 'Histórico 90 dias']
          },
          {
            id: 'premium_monthly',
            name: 'Premium',
            price: 179.90,
            credits: 1000,
            interval: 'monthly',
            features: ['1000 créditos/mês', 'Todos os agentes', 'Modelos premium', 'Suporte dedicado', 'API access']
          }
        ]
      };

      res.json(packages);
    } catch (error) {
      console.error("Error fetching packages:", error);
      res.status(500).json({ message: "Failed to fetch packages" });
    }
  });

  // Create payment intent for MercadoPago
  app.post('/api/payment/create-intent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { productType, productId, promoCode } = req.body;

      // Validate input
      if (!productType || !productId) {
        return res.status(400).json({ message: "Product type and ID are required" });
      }

      // Get product details (mock data)
      let productData;
      if (productType === 'credits') {
        const packages = [
          { id: 'credits_50', name: 'Starter', credits: 50, price: 19.90 },
          { id: 'credits_200', name: 'Popular', credits: 200, price: 69.90 },
          { id: 'credits_500', name: 'Professional', credits: 500, price: 149.90 },
          { id: 'credits_1000', name: 'Enterprise', credits: 1000, price: 249.90 }
        ];
        productData = packages.find(p => p.id === productId);
      } else if (productType === 'plan') {
        const plans = [
          { id: 'basic_monthly', name: 'Basic', credits: 200, price: 39.90 },
          { id: 'pro_monthly', name: 'Pro', credits: 500, price: 89.90 },
          { id: 'premium_monthly', name: 'Premium', credits: 1000, price: 179.90 }
        ];
        productData = plans.find(p => p.id === productId);
      }

      if (!productData) {
        return res.status(404).json({ message: "Product not found" });
      }

      // Apply promo code discount
      let finalPrice = productData.price;
      if (promoCode === 'WELCOME10') {
        finalPrice = productData.price * 0.9;
      }

      // Create payment intent
      const paymentIntent = {
        id: `intent_${Date.now()}`,
        userId,
        productType,
        productId,
        amount: finalPrice,
        credits: productData.credits,
        promoCode,
        status: 'created',
        createdAt: new Date()
      };

      console.log('Payment intent created:', paymentIntent);

      res.json({
        paymentIntent,
        redirectUrl: `/payment/checkout/${paymentIntent.id}`,
        message: 'Payment intent created successfully'
      });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Failed to create payment intent" });
    }
  });

  // Apply promo code
  app.post('/api/credits/apply-promo', isAuthenticated, async (req: any, res) => {
    try {
      const { code, productId } = req.body;

      // Mock promo codes
      const promoCodes = {
        'WELCOME10': { type: 'percentage', value: 10, description: '10% de desconto' },
        'FIRST20': { type: 'percentage', value: 20, description: '20% de desconto primeira compra' },
        'BONUS50': { type: 'credits', value: 50, description: '+50 créditos bônus' }
      };

      const promo = promoCodes[code.toUpperCase()];
      
      if (!promo) {
        return res.status(404).json({ message: "Código promocional inválido" });
      }

      res.json({
        valid: true,
        promo: {
          code: code.toUpperCase(),
          ...promo
        },
        message: `Código aplicado! ${promo.description}`
      });
    } catch (error) {
      console.error("Error applying promo code:", error);
      res.status(500).json({ message: "Failed to apply promo code" });
    }
  });

  // Webhook endpoint for MercadoPago
  app.post('/api/webhooks/mercadopago', async (req, res) => {
    try {
      const webhookData = req.body;
      console.log('MercadoPago webhook received:', webhookData);

      // In production, validate webhook signature here
      
      if (webhookData.type === 'payment') {
        const paymentId = webhookData.data.id;
        
        // Process payment status
        setTimeout(async () => {
          try {
            // Mock payment processing
            console.log(`Processing payment ${paymentId}...`);
            
            // In production, fetch actual payment details from MercadoPago
            // and update user credits accordingly
            
          } catch (error) {
            console.error('Error processing payment webhook:', error);
          }
        }, 1000);
      }

      res.status(200).json({ received: true });
    } catch (error) {
      console.error("Webhook processing error:", error);
      res.status(500).json({ message: "Webhook processing failed" });
    }
  });

  // Get user transaction history
  app.get('/api/credits/transactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Mock transaction data
      const transactions = [
        {
          id: '1',
          type: 'credit_purchase',
          amount: 69.90,
          credits: 200,
          status: 'approved',
          paymentMethod: 'mercadopago',
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          description: 'Pacote Popular - 200 créditos',
          invoice: 'INV-2024-001'
        },
        {
          id: '2',
          type: 'bonus',
          amount: 0,
          credits: 20,
          status: 'approved',
          paymentMethod: 'bonus',
          timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          description: 'Bônus pacote Popular'
        },
        {
          id: '3',
          type: 'bonus',
          amount: 0,
          credits: 5,
          status: 'approved',
          paymentMethod: 'bonus',
          timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          description: 'Bônus de boas-vindas'
        }
      ];

      res.json({ transactions });
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Model Routing & Analytics Routes
  
  // Get routing analytics
  app.get('/api/routing/analytics', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const timeRange = req.query.timeRange || '24h';
      
      // Mock routing analytics data
      const analytics = {
        timeRange,
        totalRequests: 1247,
        routingDecisions: {
          'primary_selection': 892,
          'fallback_1': 186,
          'fallback_2': 98,
          'premium_override': 71
        },
        fallbackActivations: 284,
        costSavings: 156.78,
        abTestsRunning: 2,
        providerHealth: {
          groq: 'healthy',
          huggingface: 'degraded',
          replit: 'healthy',
          openai: 'healthy'
        },
        topCostSavingRecommendations: [
          {
            agentType: 'roteirista',
            currentCostPerRequest: 0.045,
            targetCostPerRequest: 0.032,
            recommendations: [
              {
                action: 'switch_model',
                modelId: 'groq-llama-3.1-8b',
                expectedSaving: 28.9,
                impact: 'medium',
                description: 'Usar Groq Llama 3.1 8B para 80% dos requests'
              }
            ]
          }
        ]
      };

      res.json(analytics);
    } catch (error) {
      console.error("Error fetching routing analytics:", error);
      res.status(500).json({ message: "Failed to fetch routing analytics" });
    }
  });

  // Get provider health metrics
  app.get('/api/routing/providers/health', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Mock provider health data
      const providerHealth = {
        groq: {
          status: 'healthy',
          latency: 1200,
          errorRate: 2.1,
          uptime: 99.8,
          requestsPerMinute: 45,
          lastHealthCheck: new Date()
        },
        huggingface: {
          status: 'degraded',
          latency: 3200,
          errorRate: 8.5,
          uptime: 97.2,
          requestsPerMinute: 12,
          lastHealthCheck: new Date()
        },
        replit: {
          status: 'healthy',
          latency: 800,
          errorRate: 1.2,
          uptime: 99.9,
          requestsPerMinute: 38,
          lastHealthCheck: new Date()
        },
        openai: {
          status: 'healthy',
          latency: 4500,
          errorRate: 0.8,
          uptime: 99.5,
          requestsPerMinute: 8,
          lastHealthCheck: new Date()
        }
      };

      res.json(providerHealth);
    } catch (error) {
      console.error("Error fetching provider health:", error);
      res.status(500).json({ message: "Failed to fetch provider health" });
    }
  });

  // Get A/B tests
  app.get('/api/routing/ab-tests', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Mock A/B test data
      const abTests = [
        {
          id: 'test-1',
          name: 'Groq vs OpenAI para Roteirista',
          description: 'Comparando qualidade vs custo',
          agentType: 'roteirista',
          controlModelId: 'groq-llama-3.1-70b',
          experimentModelId: 'openai-gpt-4o',
          trafficSplit: 20,
          status: 'running',
          progress: 68,
          significant: false,
          startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          estimatedCompletion: '3 dias',
          results: {
            totalRequests: 342,
            controlPerformance: {
              requests: 274,
              avgCost: 0.045,
              avgLatency: 1200,
              successRate: 96.7,
              satisfaction: 4.2
            },
            experimentPerformance: {
              requests: 68,
              avgCost: 0.125,
              avgLatency: 4500,
              successRate: 98.5,
              satisfaction: 4.7
            }
          }
        },
        {
          id: 'test-2',
          name: 'DeepSeek R1 Performance Test',
          description: 'Testando novo modelo para análise de dados',
          agentType: 'data-analyst',
          controlModelId: 'groq-llama-3.1-70b',
          experimentModelId: 'groq-deepseek-r1',
          trafficSplit: 30,
          status: 'completed',
          progress: 100,
          significant: true,
          winner: 'experiment',
          startDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
          endDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          results: {
            totalRequests: 1205,
            controlPerformance: {
              requests: 845,
              avgCost: 0.052,
              avgLatency: 1450,
              successRate: 94.2,
              satisfaction: 3.8
            },
            experimentPerformance: {
              requests: 360,
              avgCost: 0.068,
              avgLatency: 2200,
              successRate: 97.8,
              satisfaction: 4.5
            },
            statisticalSignificance: true,
            winner: 'experiment'
          }
        }
      ];

      res.json({ abTests });
    } catch (error) {
      console.error("Error fetching A/B tests:", error);
      res.status(500).json({ message: "Failed to fetch A/B tests" });
    }
  });

  // Create new A/B test
  app.post('/api/routing/ab-tests', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { name, description, agentType, controlModelId, experimentModelId, trafficSplit, duration } = req.body;

      // Validação básica
      if (!name || !agentType || !controlModelId || !experimentModelId) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const newTest = {
        id: `test_${Date.now()}`,
        name,
        description: description || '',
        agentType,
        controlModelId,
        experimentModelId,
        trafficSplit: trafficSplit || 20,
        status: 'running',
        progress: 0,
        significant: false,
        startDate: new Date(),
        endDate: new Date(Date.now() + (duration || 7) * 24 * 60 * 60 * 1000),
        active: true
      };

      console.log('Created A/B test:', newTest);

      res.json({ 
        success: true, 
        test: newTest,
        message: 'A/B test created successfully'
      });
    } catch (error) {
      console.error("Error creating A/B test:", error);
      res.status(500).json({ message: "Failed to create A/B test" });
    }
  });

  // Update routing configuration
  app.put('/api/routing/config/:agentType', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { agentType } = req.params;
      const { primaryModel, fallbacks, premiumOverride, conditions } = req.body;

      console.log(`Updating routing config for ${agentType}:`, {
        primaryModel,
        fallbacks,
        premiumOverride,
        conditions
      });

      res.json({ 
        success: true,
        message: `Routing configuration updated for ${agentType}`
      });
    } catch (error) {
      console.error("Error updating routing config:", error);
      res.status(500).json({ message: "Failed to update routing config" });
    }
  });

  // Force provider failure (for testing)
  app.post('/api/routing/providers/:provider/force-failure', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { provider } = req.params;
      const { duration = 60000 } = req.body; // Default 1 minute

      console.log(`Forcing failure for provider ${provider} for ${duration}ms`);

      res.json({ 
        success: true,
        message: `Provider ${provider} marked as failed for ${duration}ms`
      });
    } catch (error) {
      console.error("Error forcing provider failure:", error);
      res.status(500).json({ message: "Failed to force provider failure" });
    }
  });

  // ===================================
  // AFFILIATE ROUTES
  // ===================================
  
  // Public routes for affiliate products
  app.get('/api/affiliate/products', async (req, res) => {
    try {
      const products = await storage.getActiveAffiliateProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching affiliate products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.get('/api/affiliate/products/featured', async (req, res) => {
    try {
      const products = await storage.getFeaturedAffiliateProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching featured products:", error);
      res.status(500).json({ message: "Failed to fetch featured products" });
    }
  });

  app.get('/api/affiliate/products/category/:category', async (req, res) => {
    try {
      const { category } = req.params;
      const products = await storage.getAffiliateProductsByCategory(category);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ message: "Failed to fetch products by category" });
    }
  });

  // Impression tracking route
  app.post('/api/affiliate/impression/:id', async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user?.claims?.sub;
      const sessionId = req.sessionID;
      const userAgent = req.get('User-Agent');
      const ipAddress = req.ip;
      const referrer = req.get('Referer');

      // Verify product exists
      const product = await storage.getAffiliateProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      // Record impression metric
      await storage.createAffiliateMetric({
        productId: id,
        userId,
        sessionId,
        eventType: 'impression',
        userAgent,
        ipAddress,
        referrer,
        tokensAwarded: 0,
        metadata: {
          timestamp: new Date().toISOString(),
          productTitle: product.title
        }
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error tracking impression:", error);
      res.status(500).json({ message: "Failed to track impression" });
    }
  });

  // Click tracking route with gamification
  app.post('/api/affiliate/click/:id', async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user?.claims?.sub;
      const sessionId = req.sessionID;
      const userAgent = req.get('User-Agent');
      const ipAddress = req.ip;
      const referrer = req.get('Referer');

      // Verify product exists
      const product = await storage.getAffiliateProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      let tokensAwarded = 0;
      let message = "Click tracked successfully";
      
      // Gamification: Award tokens for authenticated users
      if (userId) {
        const canEarn = await storage.canEarnTokensForProduct(userId, id);
        if (canEarn) {
          const awarded = await storage.awardTokensForAffiliateClick(userId, id, 1);
          if (awarded) {
            tokensAwarded = 1;
            message = "Click tracked and 1 Haja® token awarded! 🎉";
          }
        } else {
          message = "Click tracked (daily token limit reached for this product)";
        }
      }

      // Record click metric with token info
      await storage.createAffiliateMetric({
        productId: id,
        userId,
        sessionId,
        eventType: 'click',
        userAgent,
        ipAddress,
        referrer,
        tokensAwarded,
        metadata: {
          timestamp: new Date().toISOString(),
          productTitle: product.title,
          tokensAwarded
        }
      });

      res.json({ 
        success: true, 
        redirectUrl: product.affiliateLink,
        tokensAwarded,
        message
      });
    } catch (error) {
      console.error("Error tracking affiliate click:", error);
      res.status(500).json({ message: "Failed to track click" });
    }
  });

  // User affiliate stats route
  app.get('/api/affiliate/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getAffiliateUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching affiliate stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Admin affiliate stats route
  app.get('/api/admin/affiliate/stats', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      // Get all affiliate metrics
      const allMetrics = await storage.getAffiliateMetrics();
      const totalClicks = allMetrics.filter(m => m.eventType === 'click').length;
      
      // Count unique users who clicked
      const uniqueUserIds = new Set(allMetrics.filter(m => m.userId).map(m => m.userId));
      const totalUsers = uniqueUserIds.size;
      
      // Sum tokens awarded
      const tokensAwarded = allMetrics.reduce((sum, m) => sum + (m.tokensAwarded ?? 0), 0);
      
      // Calculate CTR and conversion metrics
      const totalImpressions = allMetrics.filter(m => m.eventType === 'impression').length;
      const ctr = totalImpressions > 0 ? (totalClicks / totalImpressions) * 100 : 0;
      const totalConversions = allMetrics.reduce((sum, m) => sum + (m.conversions ?? 0), 0);
      const conversionRate = totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0;
      
      // Get top products by clicks
      const productClickCounts = await storage.getTopClickedProducts(5);
      const topProducts = productClickCounts.map(p => ({
        productId: p.productId,
        title: p.title,
        clicks: p.clicks,
        tokensAwarded: allMetrics
          .filter(m => m.productId === p.productId && (m.tokensAwarded ?? 0) > 0)
          .reduce((sum, m) => sum + (m.tokensAwarded ?? 0), 0)
      }));
      
      // Generate daily stats for last 7 days
      const today = new Date();
      const dailyStats = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayMetrics = allMetrics.filter(m => {
          const metricDate = new Date(m.createdAt!).toISOString().split('T')[0];
          return metricDate === dateStr;
        });
        
        dailyStats.push({
          date: dateStr,
          clicks: dayMetrics.filter(m => m.eventType === 'click').length,
          tokens: dayMetrics.reduce((sum, m) => sum + (m.tokensAwarded ?? 0), 0)
        });
      }

      const stats = {
        totalClicks,
        totalImpressions,
        totalUsers,
        tokensAwarded,
        totalConversions,
        ctr,
        conversionRate,
        topProducts,
        dailyStats
      };

      res.json(stats);
    } catch (error) {
      console.error("Error fetching affiliate stats:", error);
      res.status(500).json({ message: "Failed to fetch affiliate stats" });
    }
  });

  // Admin routes for affiliate management
  app.get('/api/admin/affiliate/products', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const products = await storage.getAffiliateProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching admin affiliate products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  app.post('/api/admin/affiliate/product', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const productData = insertAffiliateProductSchema.parse(req.body);
      const product = await storage.createAffiliateProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      console.error("Error creating affiliate product:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.patch('/api/admin/affiliate/product/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const updates = req.body;
      
      const product = await storage.updateAffiliateProduct(id, updates);
      res.json(product);
    } catch (error) {
      console.error("Error updating affiliate product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete('/api/admin/affiliate/product/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      await storage.deleteAffiliateProduct(id);
      res.json({ success: true, message: "Product deleted successfully" });
    } catch (error) {
      console.error("Error deleting affiliate product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  app.get('/api/admin/affiliate/metrics', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const [summary, topProducts] = await Promise.all([
        storage.getAffiliateMetricsSummary(),
        storage.getTopClickedProducts(10)
      ]);

      res.json({
        summary,
        topProducts
      });
    } catch (error) {
      console.error("Error fetching affiliate metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // ===================================
  // BLOG ROUTES
  // ===================================
  
  // Public blog routes
  app.get('/api/blog/posts', async (req, res) => {
    try {
      const posts = await storage.getPublishedPosts();
      // Only return basic info for listing
      const postsPreview = posts.map(post => ({
        id: post.id,
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        coverImage: post.coverImage,
        requiredLevel: post.requiredLevel,
        views: post.views,
        readTime: post.readTime,
        publishedAt: post.publishedAt,
        tags: post.tags
      }));
      res.json(postsPreview);
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.get('/api/blog/post/:slug', checkPostAccess, async (req: PaywallRequest, res) => {
    try {
      const post = req.post!;
      const hasAccess = req.hasAccess!;
      const accessType = req.accessType!;

      // Increment view count
      await storage.incrementPostViews(post.id);

      // Format content based on access level
      const formattedPost = formatPostContent(post, hasAccess);

      res.json({
        ...formattedPost,
        accessType,
        requiresUnlock: !hasAccess && post.requiredLevel === "token-5",
        loginRequired: !hasAccess && req.accessType === "login-required"
      });
    } catch (error) {
      console.error("Error fetching blog post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  // Unlock post with credits
  app.post('/api/blog/post/:slug/unlock', isAuthenticated, checkPostAccess, unlockPostWithCredits, async (req: PaywallRequest, res) => {
    try {
      const post = req.post!;
      const formattedPost = formatPostContent(post, true);

      res.json({
        ...formattedPost,
        unlocked: true,
        message: "Post unlocked successfully"
      });
    } catch (error) {
      console.error("Error unlocking post:", error);
      res.status(500).json({ message: "Failed to unlock post" });
    }
  });

  // Admin blog routes
  app.get('/api/admin/blog/posts', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const posts = await storage.getPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching admin blog posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  app.post('/api/admin/blog/post', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const postData = insertPostSchema.parse({
        ...req.body,
        authorId: req.user.claims.sub
      });
      
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      console.error("Error creating blog post:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.patch('/api/admin/blog/post/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const updates = req.body;
      
      const post = await storage.updatePost(id, updates);
      res.json(post);
    } catch (error) {
      console.error("Error updating blog post:", error);
      res.status(500).json({ message: "Failed to update post" });
    }
  });

  app.delete('/api/admin/blog/post/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      await storage.deletePost(id);
      res.json({ success: true, message: "Post deleted successfully" });
    } catch (error) {
      console.error("Error deleting blog post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  app.get('/api/admin/blog/metrics', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const [readStats, allReads] = await Promise.all([
        storage.getPostReadStats(),
        storage.getPostReads()
      ]);

      // Calculate top earning posts
      const postEarnings = allReads
        .filter(read => read.creditsUsed > 0)
        .reduce((acc, read) => {
          if (!acc[read.postId]) {
            acc[read.postId] = {
              postId: read.postId,
              totalCredits: 0,
              totalReads: 0
            };
          }
          acc[read.postId].totalCredits += read.creditsUsed;
          acc[read.postId].totalReads += 1;
          return acc;
        }, {} as Record<string, any>);

      const topEarningPosts = Object.values(postEarnings)
        .sort((a: any, b: any) => b.totalCredits - a.totalCredits)
        .slice(0, 10);

      res.json({
        readStats,
        topEarningPosts,
        totalRevenueFromReads: allReads.reduce((sum, read) => sum + (read.creditsUsed || 0), 0)
      });
    } catch (error) {
      console.error("Error fetching blog metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // Blog/Newsletter routes with paywall
  

  // Generate URL-friendly slug
  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/--+/g, '-')
      .trim();
  };

  // Get all published posts (public endpoint)
  app.get('/api/posts', async (req, res) => {
    try {
      const posts = await storage.getPublishedPosts();
      res.json(posts);
    } catch (error) {
      console.error("Error fetching posts:", error);
      res.status(500).json({ message: "Failed to fetch posts" });
    }
  });

  // Get single post with paywall logic
  app.get('/api/posts/:slug', async (req: any, res: any) => {
    try {
      const { slug } = req.params;
      const userId = req.user?.claims?.sub;
      
      const post = await storage.getPostBySlug(slug);
      if (!post || !post.published) {
        return res.status(404).json({ message: "Post not found" });
      }

      // Increment view count
      await storage.incrementPostViews(post.id);

      // Basic access check
      let hasAccess = false;
      let accessType = 'none';
      
      if (post.requiredLevel === 'free') {
        hasAccess = true;
        accessType = 'free';
      } else if (userId) {
        const user = await storage.getUser(userId);
        if (user) {
          const hasRead = await storage.hasUserReadPost(userId, post.id);
          if (hasRead) {
            hasAccess = true;
            accessType = 'already_read';
          } else {
            const userPlan = user.plan || 'free';
            const planHierarchy = ['free', 'pro', 'vip'];
            const requiredIndex = planHierarchy.indexOf(post.requiredLevel);
            const userIndex = planHierarchy.indexOf(userPlan);
            
            if (userIndex >= requiredIndex) {
              hasAccess = true;
              accessType = 'plan';
            }
          }
        }
      }
      
      if (hasAccess) {
        // Return full content
        res.json({
          ...post,
          locked: false,
          accessType: accessType
        });
      } else {
        // Return limited content with paywall
        res.json({
          ...post,
          content: post.excerpt, // Only show excerpt
          locked: true,
          requiredLevel: post.requiredLevel,
          tokenCost: post.tokenCost || 0,
          accessType: 'none'
        });
      }
    } catch (error) {
      console.error("Error fetching post:", error);
      res.status(500).json({ message: "Failed to fetch post" });
    }
  });

  // Unlock post with tokens (requires authentication)
  app.post('/api/posts/:id/unlock', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const post = await storage.getPost(id);
      if (!post || !post.published) {
        return res.status(404).json({ message: "Post not found" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user already has access
      const hasRead = await storage.hasUserReadPost(userId, id);
      if (hasRead) {
        return res.json({ success: true, message: "Already unlocked" });
      }

      // Check if user has enough tokens
      const tokenCost = post.tokenCost || 0;
      if (tokenCost > 0 && (user.credits || 0) < tokenCost) {
        return res.status(402).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.credits || 0 
        });
      }

      // Deduct tokens and create read record
      if (tokenCost > 0) {
        await storage.deductCredits(userId, tokenCost);
        
        // Create transaction record
        await storage.createTransaction({
          userId,
          type: 'debit',
          amount: tokenCost.toString(),
          description: `Unlocked post: ${post.title}`,
          status: 'completed'
        });
      }

      // Record the read
      await storage.createPostRead({
        postId: id,
        userId,
        sessionId: req.sessionID,
        accessType: tokenCost > 0 ? 'token' : 'plan',
        creditsUsed: tokenCost
      });

      // Update post paid reads count
      await storage.updatePost(id, { 
        paidReads: (post.paidReads || 0) + 1 
      });

      res.json({ 
        success: true, 
        message: "Post unlocked successfully",
        tokensUsed: tokenCost
      });
    } catch (error) {
      console.error("Error unlocking post:", error);
      res.status(500).json({ message: "Failed to unlock post" });
    }
  });

  // Admin: Create new post
  app.post('/api/admin/posts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const postData = {
        ...req.body,
        authorId: userId,
        slug: generateSlug(req.body.title)
      };

      const post = await storage.createPost(postData);
      res.json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  // Affiliate Products API
  
  // Get active affiliate products (public endpoint)
  app.get('/api/affiliate/products', async (req: any, res: any) => {
    try {
      const products = await storage.getActiveAffiliateProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching affiliate products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Record impression when product is viewed
  app.post('/api/affiliate/products/:id/impression', async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const userId = req.user?.claims?.sub;
      const sessionId = req.sessionID;
      
      await storage.recordAffiliateImpression({
        productId: id,
        userId: userId || null,
        sessionId
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error recording impression:", error);
      res.status(500).json({ message: "Failed to record impression" });
    }
  });

  // Record click and handle gamification (requires authentication)
  app.post('/api/affiliate/products/:id/click', isAuthenticated, async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const sessionId = req.sessionID;
      const userAgent = req.headers['user-agent'];
      const referrer = req.headers.referer;
      const ipAddress = req.ip;
      
      const product = await storage.getAffiliateProduct(id);
      if (!product || !product.active) {
        return res.status(404).json({ message: "Product not found" });
      }

      // Check daily click limit for gamification
      const canEarnTokens = await storage.checkDailyClickLimit(userId, id);
      let tokensAwarded = 0;
      
      if (canEarnTokens) {
        tokensAwarded = 1; // Award 1 Haja® token per click (daily limit per product)
        
        // Add tokens to user account
        const user = await storage.getUser(userId);
        if (user) {
          await storage.updateUserCredits(userId, (user.credits || 0) + tokensAwarded);
          
          // Create transaction record
          await storage.createTransaction({
            userId,
            type: 'credit',
            amount: '0', // No monetary value, just tokens
            creditsAdded: tokensAwarded,
            description: `🎯 +1 Haja® token por clique em produto: ${product.title}`,
            status: 'completed'
          });
        }
      }

      // Record the click
      await storage.recordAffiliateClick({
        productId: id,
        userId,
        sessionId,
        userAgent,
        referrer,
        ipAddress,
        tokensAwarded
      });

      res.json({ 
        success: true,
        tokensAwarded,
        affiliateUrl: product.affiliateUrl,
        message: tokensAwarded > 0 ? `🎉 +1 Haja® token ganho!` : 'Clique registrado'
      });
    } catch (error) {
      console.error("Error recording click:", error);
      res.status(500).json({ message: "Failed to record click" });
    }
  });

  // Admin: Get all affiliate products
  app.get('/api/admin/affiliate/products', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const products = await storage.getAllAffiliateProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching admin products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Admin: Create affiliate product
  app.post('/api/admin/affiliate/products', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const product = await storage.createAffiliateProduct(req.body);
      res.json(product);
    } catch (error) {
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  // Admin: Update affiliate product
  app.patch('/api/admin/affiliate/products/:id', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const product = await storage.updateAffiliateProduct(id, req.body);
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  // Admin: Delete affiliate product
  app.delete('/api/admin/affiliate/products/:id', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      await storage.deleteAffiliateProduct(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Admin: Get affiliate metrics
  app.get('/api/admin/affiliate/metrics', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { productId } = req.query;
      const metrics = await storage.getAffiliateMetrics(productId as string);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching metrics:", error);
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // CapS'ula (Social Feed) API
  
  // Get capsules feed with pagination and sorting
  app.get('/api/capsules', async (req: any, res: any) => {
    try {
      const { limit = 20, offset = 0, sort = 'recent' } = req.query;
      const sortBy = sort === 'popular' ? 'popular' : 'recent';
      
      const capsules = await storage.getCapsules(
        parseInt(limit as string), 
        parseInt(offset as string), 
        sortBy
      );
      
      res.json(capsules);
    } catch (error) {
      console.error("Error fetching capsules:", error);
      res.status(500).json({ message: "Failed to fetch capsules" });
    }
  });

  // Create new capsule (requires authentication)
  app.post('/api/capsules', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const capsuleData = insertCapsuleSchema.parse({
        ...req.body,
        userId
      });
      
      const capsule = await storage.createCapsule(capsuleData);
      res.status(201).json(capsule);
    } catch (error) {
      console.error("Error creating capsule:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to create capsule" });
    }
  });

  // Add reaction to capsule (requires authentication)
  app.post('/api/capsules/:id/react', isAuthenticated, async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const { type } = req.body;
      
      const reactionData = insertReactionSchema.parse({
        capsuleId: id,
        userId,
        type
      });
      
      const reaction = await storage.addReaction(reactionData);
      res.json(reaction);
    } catch (error) {
      console.error("Error adding reaction:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to add reaction" });
    }
  });

  // Add comment to capsule (requires authentication)
  app.post('/api/capsules/:id/comment', isAuthenticated, async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const { text } = req.body;
      
      const commentData = insertCommentSchema.parse({
        capsuleId: id,
        userId,
        text
      });
      
      const comment = await storage.addComment(commentData);
      res.json(comment);
    } catch (error) {
      console.error("Error adding comment:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors[0].message });
      }
      res.status(500).json({ message: "Failed to add comment" });
    }
  });

  // Get comments for a capsule
  app.get('/api/capsules/:id/comments', async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const { limit = 20, offset = 0 } = req.query;
      
      const comments = await storage.getComments(
        id, 
        parseInt(limit as string), 
        parseInt(offset as string)
      );
      
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Get user's reactions for a capsule (requires authentication)
  app.get('/api/capsules/:id/reactions/me', isAuthenticated, async (req: any, res: any) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const reactions = await storage.getReactionsByUser(id, userId);
      res.json(reactions);
    } catch (error) {
      console.error("Error fetching user reactions:", error);
      res.status(500).json({ message: "Failed to fetch reactions" });
    }
  });

  // Admin: Toggle pin capsule (admin only)
  app.patch('/api/admin/capsules/:id/pin', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const { isPinned } = req.body;
      
      const capsule = await storage.togglePinCapsule(id, isPinned);
      res.json(capsule);
    } catch (error) {
      console.error("Error toggling pin:", error);
      res.status(500).json({ message: "Failed to toggle pin" });
    }
  });

  // Admin: Delete capsule (admin only)
  app.delete('/api/admin/capsules/:id', isAuthenticated, async (req: any, res: any) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      await storage.deleteCapsule(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting capsule:", error);
      res.status(500).json({ message: "Failed to delete capsule" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
