import { storage } from "../storage";

export interface TokenUsageMetrics {
  userId: string;
  agentId: string;
  model: string;
  tokensUsed: number;
  cost: number;
  timestamp: Date;
  taskType: string;
}

export interface TokenAnalytics {
  totalTokensToday: number;
  totalCostToday: number;
  avgTokensPerTask: number;
  peakHours: number[];
  topUsers: Array<{ userId: string; tokens: number; cost: number }>;
  topAgents: Array<{ agentId: string; tokens: number; usage: number }>;
  modelPerformance: Array<{ model: string; avgTokens: number; successRate: number; avgLatency: number }>;
  predictions: {
    weeklyTokens: number;
    monthlyCost: number;
    expectedPeaks: Array<{ hour: number; day: string; expectedTokens: number }>;
  };
}

export interface UserCreditAnalysis {
  userId: string;
  currentCredits: number;
  avgDailyUsage: number;
  daysRemaining: number;
  churnRisk: "low" | "medium" | "high";
  suggestedAction: string;
}

export class TokenIntelligenceLayer {
  private tokenHistory: TokenUsageMetrics[] = [];
  
  // Registra uso de tokens
  async recordTokenUsage(usage: TokenUsageMetrics): Promise<void> {
    this.tokenHistory.push(usage);
    
    // Salvaria no Firebase/banco de dados real
    console.log(`🔍 Token Intelligence: ${usage.userId} usou ${usage.tokensUsed} tokens (${usage.model})`);
    
    // Verifica se precisa gerar alertas
    await this.checkForAlerts(usage);
  }

  // Analisa padrões de uso
  async getTokenAnalytics(): Promise<TokenAnalytics> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayUsage = this.tokenHistory.filter(h => h.timestamp >= today);
    
    // Dados mockados com base na especificação
    return {
      totalTokensToday: 1240,
      totalCostToday: 24.80,
      avgTokensPerTask: 186,
      peakHours: [10, 14, 20], // 10h, 14h, 20h
      topUsers: [
        { userId: "user001", tokens: 450, cost: 9.00 },
        { userId: "admin001", tokens: 320, cost: 6.40 },
        { userId: "user002", tokens: 280, cost: 5.60 }
      ],
      topAgents: [
        { agentId: "roteirista", tokens: 680, usage: 15 },
        { agentId: "agente-viral", tokens: 340, usage: 8 },
        { agentId: "branding", tokens: 220, usage: 5 }
      ],
      modelPerformance: [
        { model: "groq/llama-3.1-70b", avgTokens: 195, successRate: 0.94, avgLatency: 1.8 },
        { model: "huggingface/mistral-7b", avgTokens: 165, successRate: 0.88, avgLatency: 3.2 },
        { model: "replit/replit-code-v1-3b", avgTokens: 140, successRate: 0.96, avgLatency: 1.2 }
      ],
      predictions: {
        weeklyTokens: 8680,
        monthlyCost: 380,
        expectedPeaks: [
          { hour: 14, day: "Friday", expectedTokens: 2000 },
          { hour: 20, day: "Sunday", expectedTokens: 1500 },
          { hour: 10, day: "Monday", expectedTokens: 1800 }
        ]
      }
    };
  }

  // Analisa risco de churn dos usuários
  async analyzeUserCredits(): Promise<UserCreditAnalysis[]> {
    // Mock de dados baseado no Firebase seed
    return [
      {
        userId: "user001",
        currentCredits: 45,
        avgDailyUsage: 15,
        daysRemaining: 3,
        churnRisk: "high",
        suggestedAction: "Enviar oferta de upgrade para plano Pro"
      },
      {
        userId: "admin001", 
        currentCredits: 500,
        avgDailyUsage: 25,
        daysRemaining: 20,
        churnRisk: "low",
        suggestedAction: "Usuário saudável - ofertar features premium"
      }
    ];
  }

  // Previsões automáticas
  async generatePredictions(): Promise<any> {
    const analytics = await this.getTokenAnalytics();
    
    return {
      weekendPeak: {
        message: "Na sexta vamos ter pico de 2.000 tokens → subir limite no Groq",
        action: "increase_groq_limits",
        confidence: 0.87,
        expectedTime: "2025-09-06T14:00:00Z"
      },
      userUpgrade: {
        message: "Usuário user001 vai estourar o plano atual → sugerir upgrade",
        action: "suggest_upgrade",
        userId: "user001",
        confidence: 0.92
      },
      costOptimization: {
        message: "Modelo Groq tem melhor custo/performance → definir como padrão",
        action: "update_default_model",
        model: "groq/llama-3.1-70b",
        expectedSavings: "R$ 85/mês"
      }
    };
  }

  // Sistema de recompensas dinâmicas
  async calculateDynamicRewards(userId: string, action: string): Promise<number> {
    const bonuses = {
      "new_user": 50,           // Novos usuários
      "referral": 25,           // Convite aceito
      "feedback": 10,           // Feedback positivo
      "community_post": 15,     // Post na comunidade
      "daily_login": 5,         // Login diário
      "first_viral": 100        // Primeiro conteúdo viral
    };

    return bonuses[action] || 0;
  }

  // Verifica condições para alertas automáticos
  private async checkForAlerts(usage: TokenUsageMetrics): Promise<void> {
    try {
      const user = await storage.getUser(usage.userId);
      if (!user) return;

      // Alerta de créditos baixos (<10%)
      if (user.credits && user.credits < 50) { // Menos de 10% de 500 créditos
        await this.generateAlert({
          type: "lowCredits",
          severity: "medium",
          userId: usage.userId,
          message: `Usuário ${usage.userId} tem apenas ${user.credits} créditos restantes`,
          suggestedAction: "upsell_plan"
        });
      }

      // Detecção de uso anômalo (>500 tokens em uma sessão)
      if (usage.tokensUsed > 500) {
        await this.generateAlert({
          type: "anomalousUsage",
          severity: "high", 
          userId: usage.userId,
          message: `Uso anômalo detectado: ${usage.tokensUsed} tokens em uma sessão`,
          suggestedAction: "investigate_user"
        });
      }

      // Custo de IA subindo (mock)
      const currentCost = usage.cost;
      if (currentCost > 1.0) { // > R$ 1,00 por request
        await this.generateAlert({
          type: "highCost",
          severity: "medium",
          message: `Custo elevado detectado: R$ ${currentCost.toFixed(2)} por request`,
          suggestedAction: "activate_fallback_model"
        });
      }

    } catch (error) {
      console.error("Erro ao verificar alertas:", error);
    }
  }

  // Gera alerta automático
  private async generateAlert(alert: any): Promise<void> {
    console.log(`🚨 HVC Alert [${alert.severity.toUpperCase()}]: ${alert.message}`);
    
    // Aqui integraria com sistema de notificações
    // WhatsApp, email, Discord, push notifications
    
    // Salva alerta no Firebase/banco
    const alertData = {
      ...alert,
      id: `alert_${Date.now()}`,
      timestamp: new Date().toISOString(),
      resolved: false
    };
    
    // Mock de salvamento
    console.log("💾 Alerta salvo:", alertData);
  }

  // Dashboard de métricas em tempo real
  async getDashboardMetrics() {
    const analytics = await this.getTokenAnalytics();
    const predictions = await this.generatePredictions();
    const userAnalysis = await this.analyzeUserCredits();
    
    return {
      usage: {
        today: `${analytics.totalTokensToday}/5.000`,
        prediction: `${predictions.weekendPeak?.message}`,
        monthlyForecast: `R$ ${analytics.predictions.monthlyCost}`
      },
      performance: analytics.modelPerformance,
      alerts: await this.getActiveAlerts(),
      recommendations: [
        predictions.costOptimization,
        predictions.userUpgrade
      ],
      highRiskUsers: userAnalysis.filter(u => u.churnRisk === "high")
    };
  }

  private async getActiveAlerts() {
    // Mock de alertas ativos
    return [
      {
        level: "medium",
        message: "HF com latência alta",
        type: "performance"
      },
      {
        level: "high", 
        message: "Usuário user001 com uso anômalo",
        type: "usage"
      }
    ];
  }
}

// Instância singleton
export const tokenIntelligence = new TokenIntelligenceLayer();