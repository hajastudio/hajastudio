import OpenAI from "openai";

export interface TechTrend {
  nome: string;
  tipo: "modelo" | "api" | "ferramenta" | "vulnerabilidade" | "preco";
  descricao: string;
  impacto: "baixo" | "medio" | "alto" | "critico";
  link: string;
  dataDeteccao: Date;
  relevanciaHja: number; // 0-1
}

export interface SystemHealth {
  model: string;
  status: "operational" | "degraded" | "down";
  latency: number;
  successRate: number;
  lastChecked: Date;
  errorRate: number;
}

export interface AutoAction {
  trigger: string;
  action: string;
  executed: boolean;
  timestamp: Date;
  result?: string;
}

export class TechWatchLayer {
  private openai: OpenAI;
  private healthChecks: SystemHealth[] = [];
  private autoActions: AutoAction[] = [];
  
  constructor() {
    this.openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY || 'demo-key'
    });
  }

  // Scan diário de novidades em IA via LLM
  async scanAITrends(): Promise<TechTrend[]> {
    try {
      const prompt = `Analise as principais novidades em IA dos últimos 7 dias e retorne em JSON:
      
      Procure por:
      - Novos modelos de linguagem (Llama, Claude, Gemini, etc)
      - APIs gratuitas ou com preços reduzidos  
      - Vulnerabilidades de segurança
      - Ferramentas emergentes (Text-to-Video, Audio, 3D)
      - Mudanças de pricing das principais APIs
      
      Formato JSON:
      {
        "trends": [
          {
            "nome": "string",
            "tipo": "modelo|api|ferramenta|vulnerabilidade|preco", 
            "descricao": "string",
            "impacto": "baixo|medio|alto|critico",
            "link": "string",
            "relevanciaHja": 0.0-1.0
          }
        ]
      }`;

      // Mock response baseado no que está no Firebase seed
      return [
        {
          nome: "Llama-4 Launch",
          tipo: "modelo",
          descricao: "Meta lança Llama-4 com 50% mais eficiência e menor custo por token",
          impacto: "alto",
          link: "https://ai.meta.com/llama-4",
          dataDeteccao: new Date(),
          relevanciaHja: 0.9
        },
        {
          nome: "OpenAI Price Drop",
          tipo: "preco",
          descricao: "OpenAI reduz preços em 20% para GPT-4",
          impacto: "medio",
          link: "https://openai.com/pricing",
          dataDeteccao: new Date(),
          relevanciaHja: 0.7
        },
        {
          nome: "Groq API Scaling",
          tipo: "api",
          descricao: "Groq aumenta rate limits e adiciona novos endpoints",
          impacto: "medio", 
          link: "https://groq.com/docs/updates",
          dataDeteccao: new Date(),
          relevanciaHja: 0.8
        },
        {
          nome: "Veo 2.0 Text-to-Video",
          tipo: "ferramenta",
          descricao: "Google lança Veo 2.0 para geração de vídeos realistas",
          impacto: "alto",
          link: "https://deepmind.google/veo",
          dataDeteccao: new Date(),
          relevanciaHja: 0.6
        }
      ];

    } catch (error) {
      console.error("Erro ao fazer scan de tendências:", error);
      return [];
    }
  }

  // Monitora saúde interna da plataforma
  async monitorSystemHealth(): Promise<SystemHealth[]> {
    const models = [
      "groq/llama-3.1-70b",
      "huggingface/mistral-7b", 
      "replit/replit-code-v1-3b",
      "openai/gpt-5"
    ];

    const healthData: SystemHealth[] = [];

    for (const model of models) {
      const health = await this.checkModelHealth(model);
      healthData.push(health);
      
      // Verifica se precisa de ação automática
      await this.checkForAutoActions(health);
    }

    this.healthChecks = healthData;
    return healthData;
  }

  // Verifica saúde de um modelo específico
  private async checkModelHealth(model: string): Promise<SystemHealth> {
    // Mock de health check baseado no que esperamos
    const mockData = {
      "groq/llama-3.1-70b": { status: "operational", latency: 1.8, successRate: 0.94, errorRate: 0.06 },
      "huggingface/mistral-7b": { status: "degraded", latency: 3.2, successRate: 0.88, errorRate: 0.12 },
      "replit/replit-code-v1-3b": { status: "operational", latency: 1.2, successRate: 0.96, errorRate: 0.04 },
      "openai/gpt-5": { status: "operational", latency: 2.1, successRate: 0.97, errorRate: 0.03 }
    };

    const data = mockData[model] || { status: "down", latency: 0, successRate: 0, errorRate: 1 };

    return {
      model,
      status: data.status as "operational" | "degraded" | "down",
      latency: data.latency,
      successRate: data.successRate,
      lastChecked: new Date(),
      errorRate: data.errorRate
    };
  }

  // Sistema de ações automáticas
  private async checkForAutoActions(health: SystemHealth): Promise<void> {
    const actions = [];

    // Se Groq falhar → ativa Hugging Face
    if (health.model.includes("groq") && health.status === "down") {
      actions.push({
        trigger: "groq_down",
        action: "activate_huggingface_fallback",
        executed: false,
        timestamp: new Date()
      });
    }

    // Se Replit ficar lento → troca para fallback  
    if (health.model.includes("replit") && health.latency > 5.0) {
      actions.push({
        trigger: "replit_slow",
        action: "switch_to_fallback_model",
        executed: false,
        timestamp: new Date()
      });
    }

    // Se taxa de erro alta → desativa temporariamente
    if (health.errorRate > 0.15) {
      actions.push({
        trigger: "high_error_rate", 
        action: "disable_model_temporarily",
        executed: false,
        timestamp: new Date()
      });
    }

    // Se custo disparar → muda modelo padrão
    if (health.model.includes("openai") && health.successRate < 0.85) {
      actions.push({
        trigger: "cost_spike",
        action: "change_default_model",
        executed: false,
        timestamp: new Date()
      });
    }

    // Executa as ações
    for (const action of actions) {
      await this.executeAutoAction(action);
      this.autoActions.push(action);
    }
  }

  // Executa ação automática
  private async executeAutoAction(action: AutoAction): Promise<void> {
    console.log(`🤖 HVC Auto-Action: ${action.action} (trigger: ${action.trigger})`);
    
    try {
      switch (action.action) {
        case "activate_huggingface_fallback":
          // Ativaria fallback no sistema de roteamento
          action.result = "HuggingFace ativado como fallback";
          break;
          
        case "switch_to_fallback_model":
          // Trocaria modelo padrão temporariamente
          action.result = "Modelo padrão alterado para backup";
          break;
          
        case "disable_model_temporarily":
          // Desativaria modelo com alta taxa de erro
          action.result = "Modelo desativado por 30 minutos";
          break;
          
        case "change_default_model":
          // Mudaria modelo padrão para mais econômico
          action.result = "Modelo padrão alterado para Groq";
          break;
      }
      
      action.executed = true;
      
      // Notificaria admin via WhatsApp/email/Discord
      await this.notifyAdmin(action);
      
    } catch (error) {
      action.result = `Erro: ${error.message}`;
      console.error(`Erro ao executar ação automática:`, error);
    }
  }

  // Sistema de notificações automáticas
  private async notifyAdmin(action: AutoAction): Promise<void> {
    const notification = {
      type: "auto_action",
      message: `HVC Core executou: ${action.action}`,
      details: action.result,
      timestamp: action.timestamp,
      priority: this.getActionPriority(action.trigger)
    };

    console.log(`📱 Notificação Admin:`, notification);
    
    // Aqui integraria com:
    // - WhatsApp Business API
    // - SendGrid para email
    // - Discord webhook
    // - Push notifications
    
    // Mock de integração
    if (notification.priority === "high") {
      console.log("🚨 Enviando notificação urgente via WhatsApp e email");
    } else {
      console.log("📧 Enviando notificação via email");
    }
  }

  private getActionPriority(trigger: string): "low" | "medium" | "high" {
    const highPriority = ["groq_down", "cost_spike"];
    const mediumPriority = ["replit_slow", "high_error_rate"];
    
    if (highPriority.includes(trigger)) return "high";
    if (mediumPriority.includes(trigger)) return "medium";
    return "low";
  }

  // Relatório de vigilância técnica
  async getTechWatchReport() {
    const trends = await this.scanAITrends();
    const health = await this.monitorSystemHealth();
    
    return {
      aiTrends: {
        count: trends.length,
        highImpact: trends.filter(t => t.impacto === "alto" || t.impacto === "critico"),
        newModels: trends.filter(t => t.tipo === "modelo"),
        priceChanges: trends.filter(t => t.tipo === "preco")
      },
      systemHealth: {
        operational: health.filter(h => h.status === "operational").length,
        degraded: health.filter(h => h.status === "degraded").length,
        down: health.filter(h => h.status === "down").length,
        avgLatency: health.reduce((sum, h) => sum + h.latency, 0) / health.length,
        avgSuccessRate: health.reduce((sum, h) => sum + h.successRate, 0) / health.length
      },
      autoActions: {
        total: this.autoActions.length,
        executed: this.autoActions.filter(a => a.executed).length,
        recent: this.autoActions.slice(-5) // Últimas 5 ações
      },
      recommendations: this.generateTechRecommendations(trends, health)
    };
  }

  // Gera recomendações automáticas
  private generateTechRecommendations(trends: TechTrend[], health: SystemHealth[]) {
    const recommendations = [];

    // Recomendações baseadas em tendências
    const newModels = trends.filter(t => t.tipo === "modelo" && t.relevanciaHja > 0.8);
    if (newModels.length > 0) {
      recommendations.push({
        type: "integration",
        message: `Avaliar integração do ${newModels[0].nome} - alta relevância`,
        priority: "high",
        action: "evaluate_new_model"
      });
    }

    // Recomendações baseadas em performance
    const degradedModels = health.filter(h => h.status === "degraded");
    if (degradedModels.length > 0) {
      recommendations.push({
        type: "performance", 
        message: `${degradedModels[0].model} com performance degradada - investigar`,
        priority: "medium",
        action: "investigate_model_performance"
      });
    }

    // Recomendações de custo
    const priceDrops = trends.filter(t => t.tipo === "preco" && t.impacto === "alto");
    if (priceDrops.length > 0) {
      recommendations.push({
        type: "cost_optimization",
        message: `Aproveitar redução de preços: ${priceDrops[0].nome}`,
        priority: "medium", 
        action: "update_pricing_strategy"
      });
    }

    return recommendations;
  }

  // Startup do sistema de vigilância
  async startTechWatch(): Promise<void> {
    console.log("🔍 Iniciando TechWatch Layer...");
    
    // Scan inicial
    await this.scanAITrends();
    await this.monitorSystemHealth();
    
    // Configura intervals automáticos
    setInterval(async () => {
      await this.monitorSystemHealth();
    }, 5 * 60 * 1000); // A cada 5 minutos

    setInterval(async () => {
      await this.scanAITrends();
    }, 24 * 60 * 60 * 1000); // A cada 24 horas
    
    console.log("✅ TechWatch Layer ativo");
  }
}

// Instância singleton
export const techWatch = new TechWatchLayer();