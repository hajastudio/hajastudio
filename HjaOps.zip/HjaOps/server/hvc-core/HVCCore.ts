import { tokenIntelligence } from './TokenIntelligence';
import { techWatch } from './TechWatch';

export interface HVCCoreConfig {
  providers: {
    groq: { apiKey: string; endpoint: string; priority: number };
    huggingface: { apiKey: string; endpoint: string; priority: number };
    replit: { apiKey: string; endpoint: string; priority: number };
    openai: { apiKey: string; endpoint: string; priority: number };
  };
  pricing: {
    defaultMarkup: number; // margem padrão (ex: 5x custo real)
    minMargin: number; // margem mínima (ex: 80%)
  };
  monitoring: {
    maxLatency: number; // ms
    minSuccessRate: number; // %
    alertThresholds: {
      lowCredits: number;
      highUsage: number;
      apiFailure: number;
    };
  };
}

export class HVCCore {
  private config: HVCCoreConfig;
  private isActive: boolean = false;

  constructor(config: HVCCoreConfig) {
    this.config = config;
  }

  // 🚀 Inicializa o HVC Core
  async start(): Promise<void> {
    console.log("🧠 Iniciando HVC Core (Haja Verso Conductor)...");
    
    try {
      // Inicia sistema de vigilância técnica
      await techWatch.startTechWatch();
      
      // Configura monitoramento de tokens
      await this.initializeTokenMonitoring();
      
      // Inicia algoritmos de precificação dinâmica
      await this.initializePricingEngine();
      
      // Configura alertas automáticos
      await this.setupAutomaticAlerts();
      
      this.isActive = true;
      console.log("✅ HVC Core ativo e monitorando plataforma 24/7");
      
      // Relatório inicial
      await this.generateSystemReport();
      
    } catch (error) {
      console.error("❌ Erro ao inicializar HVC Core:", error);
      throw error;
    }
  }

  // 🎯 Processa chat através do orquestrador inteligente
  async processChat(userId: string, agentId: string, message: string, chatId?: string): Promise<any> {
    try {
      // 1. Verifica créditos do usuário
      const userCredits = await this.getUserCredits(userId);
      if (userCredits < 1) {
        throw new Error("Insufficient credits");
      }

      // 2. Busca configuração do agente
      const agent = await this.getAgent(agentId);
      if (!agent || !agent.active) {
        throw new Error("Agent not available");
      }

      // 3. Seleciona melhor modelo baseado em performance/custo
      const optimalModel = await this.selectOptimalModel(agent.defaultModel, userId);

      // 4. Constrói prompt otimizado
      const fullPrompt = this.buildOptimizedPrompt(agent.prompt, message, userId);

      // 5. Faz chamada com fallback automático
      const response = await this.makeAIRequest(optimalModel, fullPrompt, userId);

      // 6. Calcula custo real e créditos a cobrar
      const pricing = this.calculatePricing(response.tokens, optimalModel, userId);

      // 7. Processa resposta e salva chat
      const chatResult = await this.processChatResponse({
        userId,
        agentId,
        message,
        response: response.message,
        chatId,
        tokens: response.tokens,
        model: optimalModel,
        cost: pricing.realCost,
        creditsCharged: pricing.creditsToCharge
      });

      // 8. Atualiza analytics em tempo real
      await tokenIntelligence.recordTokenUsage({
        userId,
        agentId,
        model: optimalModel,
        tokensUsed: response.tokens,
        cost: pricing.realCost,
        timestamp: new Date(),
        taskType: "chat"
      });

      return {
        success: true,
        chatId: chatResult.chatId,
        message: response.message,
        usage: {
          tokens: response.tokens,
          creditsCharged: pricing.creditsToCharge,
          cost: pricing.realCost,
          model: optimalModel
        }
      };

    } catch (error) {
      console.error("🚨 HVC Core erro no chat:", error);
      throw error;
    }
  }

  // 🤖 Seletor inteligente de modelo
  private async selectOptimalModel(preferredModel: string, userId: string): Promise<string> {
    // Busca métricas de performance dos modelos
    const healthReport = await techWatch.getTechWatchReport();
    
    // Analisa histórico do usuário
    const userAnalytics = await tokenIntelligence.analyzeUserCredits();
    const userPreferences = userAnalytics.find(u => u.userId === userId);
    
    // Algoritmo de seleção baseado em:
    // 1. Performance atual (latência, taxa de sucesso)
    // 2. Custo vs créditos restantes do usuário
    // 3. Preferências históricas
    // 4. Carga atual dos provedores
    
    const modelScores = {
      "groq/llama-3.1-70b": this.calculateModelScore("groq", healthReport, userPreferences),
      "huggingface/mistral-7b": this.calculateModelScore("huggingface", healthReport, userPreferences),
      "replit/replit-code-v1-3b": this.calculateModelScore("replit", healthReport, userPreferences),
      "openai/gpt-5": this.calculateModelScore("openai", healthReport, userPreferences)
    };
    
    // Retorna modelo com maior score (ou fallback)
    const bestModel = Object.entries(modelScores)
      .sort(([,a], [,b]) => b - a)[0][0];
    
    return bestModel || preferredModel;
  }

  private calculateModelScore(provider: string, healthReport: any, userPrefs: any): number {
    const health = healthReport.systemHealth;
    const providerHealth = health.find((h: any) => h.model.includes(provider));
    
    if (!providerHealth || providerHealth.status === "down") return 0;
    
    let score = 100;
    
    // Penaliza por latência alta
    score -= (providerHealth.avgLatency > 3.0) ? 30 : 0;
    
    // Penaliza por taxa de sucesso baixa
    score -= (providerHealth.avgSuccessRate < 0.9) ? 40 : 0;
    
    // Bonus por custo-benefício
    const costEfficiency = this.getCostEfficiency(provider);
    score += costEfficiency * 20;
    
    // Bonus por preferência do usuário
    if (userPrefs?.churnRisk === "high" && costEfficiency > 0.8) {
      score += 15; // Prefere modelos mais baratos para usuários em risco
    }
    
    return Math.max(0, score);
  }

  private getCostEfficiency(provider: string): number {
    const costMap = {
      "groq": 0.9,        // Mais eficiente
      "huggingface": 0.8,
      "replit": 0.7,
      "openai": 0.4       // Mais caro
    };
    return costMap[provider] || 0.5;
  }

  // 💰 Engine de precificação dinâmica
  private calculatePricing(tokens: number, model: string, userId: string): any {
    // Custo real por modelo (por 1000 tokens)
    const realCosts = {
      "groq/llama-3.1-70b": 0.045,
      "huggingface/mistral-7b": 0.032,
      "replit/replit-code-v1-3b": 0.028,
      "openai/gpt-5": 0.180
    };
    
    const baseCost = realCosts[model] || 0.05;
    const realCost = (tokens / 1000) * baseCost;
    
    // Markup dinâmico baseado em:
    // 1. Margem mínima de 80%
    // 2. Tipo de usuário (free vs premium)
    // 3. Horário (picos vs baixo uso)
    // 4. Disponibilidade do modelo
    
    let markup = this.config.pricing.defaultMarkup; // 5x por padrão
    
    // Ajustes dinâmicos
    const hour = new Date().getHours();
    const isPeakHour = hour >= 9 && hour <= 18;
    
    if (isPeakHour) markup *= 1.2; // 20% mais caro no horário comercial
    
    // Desconto para usuários premium
    const userPlan = this.getUserPlan(userId);
    if (userPlan === "premium") markup *= 0.8;
    if (userPlan === "pro") markup *= 0.9;
    
    const chargedPrice = realCost * markup;
    const creditsToCharge = Math.ceil(tokens / 100); // 1 crédito = ~100 tokens
    
    // Garantia de margem mínima
    const margin = (chargedPrice - realCost) / chargedPrice;
    if (margin < this.config.pricing.minMargin) {
      const adjustedPrice = realCost / (1 - this.config.pricing.minMargin);
      return {
        realCost,
        chargedPrice: adjustedPrice,
        creditsToCharge: Math.ceil(adjustedPrice * 100),
        margin: this.config.pricing.minMargin
      };
    }
    
    return {
      realCost,
      chargedPrice,
      creditsToCharge,
      margin
    };
  }

  // 📊 Gerador de relatórios automático
  async generateSystemReport(): Promise<any> {
    const analytics = await tokenIntelligence.getDashboardMetrics();
    const techReport = await techWatch.getTechWatchReport();
    
    const report = {
      timestamp: new Date().toISOString(),
      status: this.isActive ? "OPERATIONAL" : "INACTIVE",
      
      // Métricas de uso
      usage: analytics.usage,
      
      // Performance dos modelos  
      modelPerformance: analytics.performance,
      
      // Alertas ativos
      activeAlerts: analytics.alerts,
      
      // Recomendações automáticas
      recommendations: [
        ...analytics.recommendations,
        ...techReport.recommendations
      ],
      
      // Previsões
      predictions: analytics.usage,
      
      // Saúde técnica
      systemHealth: {
        operational: techReport.systemHealth.operational,
        degraded: techReport.systemHealth.degraded,
        down: techReport.systemHealth.down,
        avgLatency: techReport.systemHealth.avgLatency,
        avgSuccessRate: techReport.systemHealth.avgSuccessRate
      },
      
      // Novidades em IA
      aiTrends: {
        newModels: techReport.aiTrends.newModels,
        priceChanges: techReport.aiTrends.priceChanges,
        highImpact: techReport.aiTrends.highImpact
      }
    };
    
    console.log("📊 HVC Core System Report:", {
      status: report.status,
      activeAlerts: report.activeAlerts.length,
      recommendations: report.recommendations.length,
      systemHealth: `${report.systemHealth.operational} operational, ${report.systemHealth.degraded} degraded`
    });
    
    return report;
  }

  // Métodos auxiliares (mock - implementar com Firebase)
  private async getUserCredits(userId: string): Promise<number> { return 50; }
  private async getAgent(agentId: string): Promise<any> { return { active: true, defaultModel: "groq/llama-3.1-70b", prompt: "Test" }; }
  private async makeAIRequest(model: string, prompt: string, userId: string): Promise<any> { return { message: "Test response", tokens: 150 }; }
  private async processChatResponse(data: any): Promise<any> { return { chatId: "chat123" }; }
  private getUserPlan(userId: string): string { return "free"; }
  private buildOptimizedPrompt(agentPrompt: string, userMessage: string, userId: string): string { return `${agentPrompt}\n\nUser: ${userMessage}`; }
  
  private async initializeTokenMonitoring(): Promise<void> { console.log("🔍 Token monitoring iniciado"); }
  private async initializePricingEngine(): Promise<void> { console.log("💰 Pricing engine iniciado"); }
  private async setupAutomaticAlerts(): Promise<void> { console.log("🚨 Sistema de alertas configurado"); }
}

// Instância singleton exportada
export const hvcCore = new HVCCore({
  providers: {
    groq: { apiKey: process.env.GROQ_API_KEY || "", endpoint: "https://api.groq.com/openai/v1", priority: 1 },
    huggingface: { apiKey: process.env.HF_API_KEY || "", endpoint: "https://api-inference.huggingface.co", priority: 2 },
    replit: { apiKey: process.env.REPLIT_API_KEY || "", endpoint: "https://api.replit.com/v1", priority: 3 },
    openai: { apiKey: process.env.OPENAI_API_KEY || "", endpoint: "https://api.openai.com/v1", priority: 4 }
  },
  pricing: {
    defaultMarkup: 5.0,  // 5x custo real
    minMargin: 0.8       // 80% margem mínima
  },
  monitoring: {
    maxLatency: 5000,
    minSuccessRate: 0.85,
    alertThresholds: {
      lowCredits: 10,
      highUsage: 1000,
      apiFailure: 5
    }
  }
});