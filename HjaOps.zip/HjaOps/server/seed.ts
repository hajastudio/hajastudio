import { db } from "./db";
import { users, agents, plans } from "@shared/schema";
import type { InsertAgent, UpsertUser, InsertPlan } from "@shared/schema";
import { eq } from "drizzle-orm";
import { seedAffiliateData } from "./seed-affiliate";

const demoUser: UpsertUser = {
  id: "demo_user_001", 
  email: "demo@haja.app",
  firstName: "Demo",
  lastName: "User",
  role: "user",
  plan: "free",
  credits: 20
};

const initialAgents: InsertAgent[] = [
  {
    name: "Roteirista 🎬",
    description: "Especialista em roteiros criativos, storytelling e narrativas envolventes para vídeos, filmes e conteúdo audiovisual.",
    promptBase: "Você é um roteirista experiente e criativo. Sua especialidade é criar roteiros envolventes, desenvolvendo narrativas cativantes, personagens interessantes e diálogos naturais. Você domina diferentes formatos: vídeos curtos, filmes, séries, documentários e conteúdo para redes sociais. Sempre pense na estrutura narrativa, no arco dramático e no impacto emocional do conteúdo.",
    defaultModel: "gpt-5",
    tags: ["roteiro", "storytelling", "criatividade", "narrativa"],
    active: true
  },
  {
    name: "Vibe Code 💻",
    description: "Desenvolvedor especialista em programação, arquitetura de software e soluções técnicas inovadoras.",
    promptBase: "Você é um desenvolvedor sênior com vasta experiência em múltiplas linguagens de programação, arquitetura de software e boas práticas de desenvolvimento. Você ajuda com código limpo, soluções escaláveis, debugging, otimização de performance e tecnologias modernas. Sempre explique o código de forma didática e sugira melhorias quando possível.",
    defaultModel: "gpt-5", 
    tags: ["programação", "código", "desenvolvimento", "tecnologia"],
    active: true
  },
  {
    name: "Agente Viral 🚀",
    description: "Especialista em criar conteúdo viral, tendências e estratégias para maximizar o alcance nas redes sociais.",
    promptBase: "Você é um especialista em marketing viral e criação de conteúdo que gera engajamento massivo. Você entende profundamente as dinâmicas das redes sociais, algoritmos, tendências e psicologia do compartilhamento. Sua missão é criar ideias, hooks, títulos e estratégias que fazem o conteúdo explodir nas redes sociais.",
    defaultModel: "gpt-5",
    tags: ["viral", "marketing", "redes sociais", "engajamento"],
    active: true
  },
  {
    name: "Branding & Social 📣",
    description: "Consultor em branding, identidade visual e estratégias de presença digital para marcas e criadores.",
    promptBase: "Você é um consultor especializado em branding, identidade visual e estratégias de presença digital. Você ajuda a definir a personalidade da marca, tom de voz, posicionamento no mercado, estratégias de conteúdo e construção de uma presença digital forte e consistente. Sempre considere a identidade única da marca e seu público-alvo.",
    defaultModel: "gpt-5",
    tags: ["branding", "identidade", "marketing", "design"],
    active: true
  },
  {
    name: "Analista YouTube 📊",
    description: "Especialista em análise de dados do YouTube, otimização de canal, SEO e estratégias de crescimento.",
    promptBase: "Você é um analista especializado em YouTube, com expertise em métricas, algoritmo, SEO, otimização de thumbnails, títulos e estratégias de crescimento de canal. Você analisa dados de performance, sugere melhorias baseadas em analytics e desenvolve estratégias data-driven para maximizar visualizações, retenção e crescimento do canal.",
    defaultModel: "gpt-5",
    tags: ["youtube", "analytics", "seo", "crescimento"],
    active: true
  }
];

const initialPlans: InsertPlan[] = [
  {
    name: 'Básico',
    price: '1990', // R$ 19.90 in cents
    creditsIncluded: 500,
    perks: [
      'Acesso a todos os agentes',
      'Chat ilimitado',
      'Suporte por email',
      '500 créditos mensais'
    ],
    isActive: true
  },
  {
    name: 'Pro',
    price: '4990', // R$ 49.90 in cents
    creditsIncluded: 1500,
    perks: [
      'Tudo do Básico',
      'Acesso prioritário',
      'Modelos premium (GPT-4)',
      '1500 créditos mensais',
      'Suporte prioritário'
    ],
    isActive: true
  },
  {
    name: 'Premium',
    price: '9990', // R$ 99.90 in cents
    creditsIncluded: 3500,
    perks: [
      'Tudo do Pro',
      'Créditos ilimitados*',
      'Acesso antecipado a novos recursos',
      'Consultoria personalizada',
      'API access'
    ],
    isActive: true
  }
];

export async function seedDatabase() {
  try {
    console.log("🌱 Starting database seed...");

    // Create demo user
    console.log("👤 Creating demo user...");
    await db.insert(users).values(demoUser).onConflictDoUpdate({
      target: users.id,
      set: demoUser
    });
    console.log("✅ Demo user created: demo@haja.app");

    // Create initial agents
    console.log("🤖 Creating initial agents...");
    for (const agent of initialAgents) {
      await db.insert(agents).values(agent).onConflictDoNothing();
      console.log(`✅ Agent created: ${agent.name}`);
    }

    // Create initial plans
    console.log("💳 Creating initial plans...");
    const existingPlans = await db.select().from(plans).limit(1);
    if (existingPlans.length === 0) {
      for (const plan of initialPlans) {
        await db.insert(plans).values(plan);
        console.log(`✅ Plan created: ${plan.name}`);
      }
    } else {
      console.log("💳 Plans already exist");
    }

    // Give bonus credits to users with low credits
    console.log("🎁 Checking for users needing bonus credits...");
    const lowCreditUsers = await db
      .select()
      .from(users)
      .where(eq(users.credits, 0));

    if (lowCreditUsers.length > 0) {
      for (const user of lowCreditUsers) {
        await db
          .update(users)
          .set({ credits: 100 })
          .where(eq(users.id, user.id));
        console.log(`✅ Bonus credits given to: ${user.email}`);
      }
    } else {
      console.log("🎁 No users need bonus credits");
    }

    console.log("🎉 Database seed completed successfully!");
    
    // Seed affiliate and blog data
    await seedAffiliateData();
    
    return {
      success: true,
      message: "Database seeded successfully",
      data: {
        demoUser,
        agents: initialAgents
      }
    };
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    return {
      success: false,
      message: "Error seeding database",
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

// If running directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase().then(result => {
    console.log(result);
    process.exit(result.success ? 0 : 1);
  });
}