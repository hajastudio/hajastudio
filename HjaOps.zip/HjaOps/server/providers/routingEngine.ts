import type { 
  RouteDecision, 
  RoutingRule, 
  ProviderSLA, 
  ABTestConfig, 
  UserTier, 
  AgentType,
  Provider,
  ModelConfig,
  RoutingCondition
} from '../../client/src/types/routing';

import { 
  MODEL_REGISTRY, 
  PROVIDER_COSTS, 
  FALLBACK_CONFIG, 
  getModelById, 
  calculateRequestCost 
} from './modelConfig';

import { 
  AGENT_ROUTING_MATRIX, 
  PROVIDER_SLA_TARGETS, 
  USER_TIER_POLICIES 
} from '../../client/src/types/routing';

interface RoutingContext {
  userId: string;
  agentType: AgentType;
  userTier: UserTier;
  requestId: string;
  inputTokens: number;
  maxOutputTokens?: number;
  priority?: 'low' | 'normal' | 'high';
  metadata?: Record<string, any>;
}

interface ProviderHealth {
  provider: Provider;
  isHealthy: boolean;
  avgLatency: number;
  errorRate: number;
  queueLength: number;
  lastFailure?: Date;
  consecutiveFailures: number;
}

export class RoutingEngine {
  private providerHealth: Map<Provider, ProviderHealth> = new Map();
  private abTests: Map<string, ABTestConfig> = new Map();
  private requestMetrics: Map<string, any> = new Map();
  private circuitBreakers: Map<Provider, boolean> = new Map();

  constructor() {
    this.initializeProviderHealth();
    this.startHealthMonitoring();
  }

  /**
   * Método principal para determinar qual modelo usar
   */
  async route(context: RoutingContext): Promise<RouteDecision> {
    const startTime = Date.now();
    
    try {
      // 1. Verificar se o usuário está em um A/B test
      const abTestResult = this.checkABTest(context);
      if (abTestResult) {
        return abTestResult;
      }

      // 2. Obter regra de roteamento para o agente
      const routingRule = AGENT_ROUTING_MATRIX[context.agentType];
      if (!routingRule) {
        throw new Error(`No routing rule found for agent: ${context.agentType}`);
      }

      // 3. Verificar política do tier do usuário
      const tierPolicy = USER_TIER_POLICIES[context.userTier];
      
      // 4. Tentar modelo primário
      const primaryDecision = await this.tryModel(
        routingRule.primary.modelId, 
        context, 
        routingRule.primary.conditions,
        tierPolicy
      );

      if (primaryDecision.success) {
        return this.createRouteDecision(
          primaryDecision.model!, 
          'primary_selection',
          context,
          undefined,
          abTestResult?.abTestGroup
        );
      }

      // 5. Verificar override premium
      if (routingRule.premiumOverride && this.canUsePremium(context.userTier, routingRule.premiumOverride.minTier)) {
        const premiumDecision = await this.tryModel(
          routingRule.premiumOverride.modelId,
          context,
          [],
          tierPolicy
        );

        if (premiumDecision.success) {
          return this.createRouteDecision(
            premiumDecision.model!,
            'premium_override',
            context,
            undefined,
            abTestResult?.abTestGroup
          );
        }
      }

      // 6. Tentar fallbacks em ordem de prioridade
      const fallbackChain: string[] = [];
      const sortedFallbacks = routingRule.fallbacks.sort((a, b) => a.priority - b.priority);

      for (const fallback of sortedFallbacks) {
        fallbackChain.push(fallback.modelId);
        
        const fallbackDecision = await this.tryModel(
          fallback.modelId,
          context,
          fallback.conditions,
          tierPolicy
        );

        if (fallbackDecision.success) {
          return this.createRouteDecision(
            fallbackDecision.model!,
            `fallback_${fallback.priority}`,
            context,
            fallbackChain,
            abTestResult?.abTestGroup
          );
        }
      }

      // 7. Fallback de emergência - modelo mais simples disponível
      const emergencyModel = this.getEmergencyFallback(context.userTier);
      if (emergencyModel) {
        return this.createRouteDecision(
          emergencyModel,
          'emergency_fallback',
          context,
          fallbackChain,
          abTestResult?.abTestGroup
        );
      }

      throw new Error('No available models for routing');

    } catch (error) {
      console.error('Routing engine error:', error);
      throw error;
    } finally {
      const routingTime = Date.now() - startTime;
      this.recordMetric('routing_time', routingTime, context);
    }
  }

  /**
   * Tenta usar um modelo específico verificando todas as condições
   */
  private async tryModel(
    modelId: string, 
    context: RoutingContext, 
    conditions: RoutingCondition[] = [],
    tierPolicy: any
  ): Promise<{ success: boolean; model?: ModelConfig; reason?: string }> {
    
    const model = getModelById(modelId);
    if (!model) {
      return { success: false, reason: 'model_not_found' };
    }

    // Verificar se o provider está saudável
    const providerHealth = this.providerHealth.get(model.provider);
    if (!providerHealth?.isHealthy || this.circuitBreakers.get(model.provider)) {
      return { success: false, reason: 'provider_unhealthy' };
    }

    // Verificar restrições do modelo
    if (model.restrictions) {
      if (model.restrictions.minTier) {
        if (!this.canUseTier(context.userTier, model.restrictions.minTier)) {
          return { success: false, reason: 'insufficient_tier' };
        }
      }

      if (model.restrictions.maxRequestsPerHour) {
        const userHourlyUsage = await this.getUserHourlyUsage(context.userId, model.provider);
        if (userHourlyUsage >= model.restrictions.maxRequestsPerHour) {
          return { success: false, reason: 'rate_limit_exceeded' };
        }
      }
    }

    // Verificar política do tier do usuário
    if (!tierPolicy.allowedProviders.includes(model.provider)) {
      return { success: false, reason: 'provider_not_allowed' };
    }

    // Calcular custo estimado
    const estimatedCost = calculateRequestCost(
      modelId, 
      context.inputTokens, 
      context.maxOutputTokens || 1000
    );

    // Verificar limite de custo do tier
    if (estimatedCost > tierPolicy.maxCostPerRequest) {
      return { success: false, reason: 'cost_exceeds_tier_limit' };
    }

    // Verificar condições específicas da regra
    for (const condition of conditions) {
      if (!this.evaluateCondition(condition, {
        cost: estimatedCost,
        latency: providerHealth.avgLatency,
        errorRate: providerHealth.errorRate,
        userTier: context.userTier,
        queueLength: providerHealth.queueLength
      })) {
        return { success: false, reason: `condition_failed_${condition.type}` };
      }
    }

    return { success: true, model };
  }

  /**
   * Avalia uma condição de roteamento
   */
  private evaluateCondition(condition: RoutingCondition, metrics: any): boolean {
    const value = this.getMetricValue(condition.type, metrics);
    
    switch (condition.operator) {
      case 'gt': return value > condition.value;
      case 'gte': return value >= condition.value;
      case 'lt': return value < condition.value;
      case 'lte': return value <= condition.value;
      case 'eq': return value === condition.value;
      default: return false;
    }
  }

  private getMetricValue(type: string, metrics: any): number {
    switch (type) {
      case 'cost_cap': return metrics.cost;
      case 'latency_cap': return metrics.latency;
      case 'error_rate': return metrics.errorRate;
      case 'queue_length': return metrics.queueLength;
      default: return 0;
    }
  }

  /**
   * Verifica se o usuário está participando de um A/B test
   */
  private checkABTest(context: RoutingContext): RouteDecision | null {
    const activeTests = Array.from(this.abTests.values()).filter(
      test => test.active && 
              test.agentType === context.agentType &&
              new Date() >= test.startDate &&
              new Date() <= test.endDate
    );

    if (activeTests.length === 0) return null;

    // Usar hash do userId para determinismo
    const userHash = this.hashUserId(context.userId);
    const test = activeTests[0]; // Usar o primeiro teste ativo

    const isInExperiment = (userHash % 100) < test.trafficSplit;
    const modelId = isInExperiment ? test.experimentModelId : test.controlModelId;
    const model = getModelById(modelId);

    if (!model) return null;

    return this.createRouteDecision(
      model,
      `ab_test_${isInExperiment ? 'experiment' : 'control'}`,
      context,
      undefined,
      isInExperiment ? 'experiment' : 'control'
    );
  }

  /**
   * Cria a decisão final de roteamento
   */
  private createRouteDecision(
    model: ModelConfig,
    reason: string,
    context: RoutingContext,
    fallbackChain?: string[],
    abTestGroup?: 'control' | 'experiment'
  ): RouteDecision {
    const estimatedCost = calculateRequestCost(
      model.modelName,
      context.inputTokens,
      context.maxOutputTokens || 1000
    );

    const estimatedLatency = model.avgLatencyMs;

    return {
      selectedModel: model,
      reason,
      fallbackChain,
      abTestGroup,
      estimatedCost,
      estimatedLatency,
      metadata: {
        userId: context.userId,
        agentType: context.agentType,
        userTier: context.userTier,
        requestId: context.requestId,
        timestamp: new Date()
      }
    };
  }

  /**
   * Obtém modelo de fallback de emergência
   */
  private getEmergencyFallback(userTier: UserTier): ModelConfig | null {
    const tierPolicy = USER_TIER_POLICIES[userTier];
    
    // Procurar o modelo mais barato e disponível
    const availableModels = Object.values(MODEL_REGISTRY)
      .filter(model => tierPolicy.allowedProviders.includes(model.provider))
      .filter(model => {
        const health = this.providerHealth.get(model.provider);
        return health?.isHealthy && !this.circuitBreakers.get(model.provider);
      })
      .sort((a, b) => a.costPerToken - b.costPerToken);

    return availableModels[0] || null;
  }

  /**
   * Inicializa o monitoramento de saúde dos providers
   */
  private initializeProviderHealth(): void {
    Object.keys(PROVIDER_SLA_TARGETS).forEach(provider => {
      this.providerHealth.set(provider as Provider, {
        provider: provider as Provider,
        isHealthy: true,
        avgLatency: 1000,
        errorRate: 0,
        queueLength: 0,
        consecutiveFailures: 0
      });
    });
  }

  /**
   * Inicia monitoramento contínuo de saúde
   */
  private startHealthMonitoring(): void {
    setInterval(() => {
      this.updateProviderHealth();
    }, FALLBACK_CONFIG.healthCheckIntervalMs);
  }

  private async updateProviderHealth(): Promise<void> {
    // Implementação simulada - em produção, faria health checks reais
    for (const [provider, health] of this.providerHealth.entries()) {
      // Simular métricas baseadas em dados históricos
      const recentMetrics = await this.getRecentMetrics(provider);
      
      health.avgLatency = recentMetrics.avgLatency;
      health.errorRate = recentMetrics.errorRate;
      health.queueLength = recentMetrics.queueLength;

      // Determinar se está saudável
      const slaTarget = PROVIDER_SLA_TARGETS[provider];
      health.isHealthy = 
        health.avgLatency <= slaTarget.maxLatencyMs &&
        health.errorRate <= slaTarget.maxErrorRate / 100 &&
        health.consecutiveFailures < FALLBACK_CONFIG.triggers.consecutiveFailures;

      // Circuit breaker logic
      if (health.consecutiveFailures >= FALLBACK_CONFIG.circuitBreakerThreshold) {
        this.circuitBreakers.set(provider, true);
        
        // Reset circuit breaker after timeout
        setTimeout(() => {
          this.circuitBreakers.set(provider, false);
          health.consecutiveFailures = 0;
        }, FALLBACK_CONFIG.circuitBreakerTimeoutMs);
      }
    }
  }

  private async getRecentMetrics(provider: Provider) {
    // Mock implementation - em produção, consultaria métricas reais
    return {
      avgLatency: Math.random() * 3000 + 500,
      errorRate: Math.random() * 0.05,
      queueLength: Math.floor(Math.random() * 50)
    };
  }

  private async getUserHourlyUsage(userId: string, provider: Provider): Promise<number> {
    // Mock implementation - em produção, consultaria banco de dados
    return Math.floor(Math.random() * 20);
  }

  private canUseTier(userTier: UserTier, requiredTier: UserTier): boolean {
    const tierHierarchy = ['free', 'basic', 'pro', 'premium', 'enterprise'];
    const userIndex = tierHierarchy.indexOf(userTier);
    const requiredIndex = tierHierarchy.indexOf(requiredTier);
    return userIndex >= requiredIndex;
  }

  private canUsePremium(userTier: UserTier, minTier: UserTier): boolean {
    return this.canUseTier(userTier, minTier);
  }

  private hashUserId(userId: string): number {
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      const char = userId.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return Math.abs(hash);
  }

  private recordMetric(type: string, value: number, context: RoutingContext): void {
    // Mock implementation - em produção, enviaria para sistema de métricas
    console.log(`Metric recorded: ${type} = ${value}`, context);
  }

  /**
   * API pública para adicionar A/B tests
   */
  public addABTest(test: ABTestConfig): void {
    this.abTests.set(test.id, test);
  }

  /**
   * API pública para obter métricas de roteamento
   */
  public async getRoutingMetrics(timeRange: string) {
    // Mock implementation
    return {
      totalRequests: 1250,
      successfulRoutes: 1198,
      fallbackActivations: 52,
      avgRoutingTime: 12,
      costSavings: 156.78,
      providerDistribution: {
        groq: 0.45,
        huggingface: 0.25,
        replit: 0.20,
        openai: 0.10
      }
    };
  }

  /**
   * Força fallback para um provider específico
   */
  public forceProviderFailure(provider: Provider, duration: number = 60000): void {
    this.circuitBreakers.set(provider, true);
    
    const health = this.providerHealth.get(provider);
    if (health) {
      health.isHealthy = false;
      health.consecutiveFailures = 10;
    }

    setTimeout(() => {
      this.circuitBreakers.set(provider, false);
      if (health) {
        health.isHealthy = true;
        health.consecutiveFailures = 0;
      }
    }, duration);
  }
}

// Singleton instance
export const routingEngine = new RoutingEngine();