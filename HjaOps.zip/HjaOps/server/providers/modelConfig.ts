import type { ModelConfig, Provider } from '../../client/src/types/routing';

// Configuração detalhada de todos os modelos disponíveis
export const MODEL_REGISTRY: Record<string, ModelConfig> = {
  // Groq Models
  'groq-llama-3.1-70b': {
    provider: 'groq',
    modelName: 'llama-3.1-70b-versatile',
    displayName: 'Llama 3.1 70B (Groq)',
    costPerToken: 0.00008, // $0.08 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 1500,
    qualityScore: 9,
    contextWindow: 128000,
    capabilities: ['reasoning', 'creative-writing', 'code', 'analysis'],
    restrictions: {
      maxRequestsPerHour: 100
    }
  },
  'groq-llama-3.1-8b': {
    provider: 'groq',
    modelName: 'llama-3.1-8b-instant',
    displayName: 'Llama 3.1 8B (Groq)',
    costPerToken: 0.00002, // $0.02 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 800,
    qualityScore: 7,
    contextWindow: 128000,
    capabilities: ['reasoning', 'creative-writing', 'code'],
    restrictions: {
      maxRequestsPerHour: 200
    }
  },
  'groq-deepseek-r1': {
    provider: 'groq',
    modelName: 'deepseek-r1-distill-llama-70b',
    displayName: 'DeepSeek R1 70B (Groq)',
    costPerToken: 0.00012, // $0.12 per 1K tokens
    maxTokens: 8192,
    avgLatencyMs: 2200,
    qualityScore: 9.5,
    contextWindow: 128000,
    capabilities: ['reasoning', 'math', 'analysis', 'research'],
    restrictions: {
      minTier: 'basic',
      maxRequestsPerHour: 50
    }
  },
  'groq-mixtral-8x7b': {
    provider: 'groq',
    modelName: 'mixtral-8x7b-32768',
    displayName: 'Mixtral 8x7B (Groq)',
    costPerToken: 0.00006, // $0.06 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 1200,
    qualityScore: 8,
    contextWindow: 32768,
    capabilities: ['reasoning', 'multilingual', 'code'],
    restrictions: {
      maxRequestsPerHour: 120
    }
  },

  // HuggingFace Models
  'huggingface-mistral-7b': {
    provider: 'huggingface',
    modelName: 'mistralai/Mistral-7B-Instruct-v0.2',
    displayName: 'Mistral 7B Instruct',
    costPerToken: 0.00003, // $0.03 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 2500,
    qualityScore: 7.5,
    contextWindow: 32768,
    capabilities: ['reasoning', 'creative-writing', 'multilingual'],
    restrictions: {
      maxRequestsPerHour: 150
    }
  },
  'huggingface-codellama-7b': {
    provider: 'huggingface',
    modelName: 'codellama/CodeLlama-7b-Instruct-hf',
    displayName: 'CodeLlama 7B Instruct',
    costPerToken: 0.00004, // $0.04 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 3000,
    qualityScore: 8,
    contextWindow: 16384,
    capabilities: ['code', 'debugging', 'code-explanation'],
    restrictions: {
      maxRequestsPerHour: 100
    }
  },
  'huggingface-zephyr-7b': {
    provider: 'huggingface',
    modelName: 'HuggingFaceH4/zephyr-7b-beta',
    displayName: 'Zephyr 7B Beta',
    costPerToken: 0.00002, // $0.02 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 2800,
    qualityScore: 7,
    contextWindow: 32768,
    capabilities: ['conversation', 'reasoning', 'creative-writing'],
    restrictions: {
      maxRequestsPerHour: 200
    }
  },

  // Replit Models
  'replit-code-v1.5': {
    provider: 'replit',
    modelName: 'replit-code-v1_5-3b',
    displayName: 'Replit Code v1.5',
    costPerToken: 0.00001, // $0.01 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 1000,
    qualityScore: 8.5,
    contextWindow: 16384,
    capabilities: ['code', 'debugging', 'code-completion', 'refactoring'],
    restrictions: {
      maxRequestsPerHour: 300
    }
  },
  'replit-chat-v1': {
    provider: 'replit',
    modelName: 'replit-chat-v1-3b',
    displayName: 'Replit Chat v1',
    costPerToken: 0.00001, // $0.01 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 900,
    qualityScore: 7,
    contextWindow: 8192,
    capabilities: ['conversation', 'code-help', 'debugging'],
    restrictions: {
      maxRequestsPerHour: 400
    }
  },

  // OpenAI Models (Premium)
  'openai-gpt-4o': {
    provider: 'openai',
    modelName: 'gpt-4o',
    displayName: 'GPT-4o',
    costPerToken: 0.0025, // $2.50 per 1K tokens (input)
    maxTokens: 4096,
    avgLatencyMs: 5000,
    qualityScore: 10,
    contextWindow: 128000,
    capabilities: ['reasoning', 'creative-writing', 'code', 'analysis', 'vision', 'math'],
    restrictions: {
      minTier: 'pro',
      maxRequestsPerHour: 50,
      requiresApproval: false
    }
  },
  'openai-gpt-4o-mini': {
    provider: 'openai',
    modelName: 'gpt-4o-mini',
    displayName: 'GPT-4o Mini',
    costPerToken: 0.00015, // $0.15 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 3000,
    qualityScore: 8.5,
    contextWindow: 128000,
    capabilities: ['reasoning', 'creative-writing', 'code', 'analysis'],
    restrictions: {
      minTier: 'basic',
      maxRequestsPerHour: 100
    }
  },
  'openai-gpt-3.5-turbo': {
    provider: 'openai',
    modelName: 'gpt-3.5-turbo',
    displayName: 'GPT-3.5 Turbo',
    costPerToken: 0.0005, // $0.50 per 1K tokens
    maxTokens: 4096,
    avgLatencyMs: 2000,
    qualityScore: 7.5,
    contextWindow: 16384,
    capabilities: ['conversation', 'reasoning', 'creative-writing', 'code'],
    restrictions: {
      maxRequestsPerHour: 200
    }
  }
};

// Configuração de custos por provider
export const PROVIDER_COSTS: Record<Provider, {
  baseRequestCost: number; // custo fixo por request em centavos USD
  tokenMultiplier: number; // multiplicador de custo por token
  latencyPenalty: number; // penalidade por latência alta
}> = {
  groq: {
    baseRequestCost: 0.001,
    tokenMultiplier: 1.0,
    latencyPenalty: 0.00001 // por ms acima de 2s
  },
  huggingface: {
    baseRequestCost: 0.002,
    tokenMultiplier: 0.8,
    latencyPenalty: 0.000015 // por ms acima de 3s
  },
  replit: {
    baseRequestCost: 0.0005,
    tokenMultiplier: 0.5,
    latencyPenalty: 0.000005 // por ms acima de 1s
  },
  openai: {
    baseRequestCost: 0.01,
    tokenMultiplier: 2.5,
    latencyPenalty: 0.00002 // por ms acima de 4s
  }
};

// Configuração de qualidade por tipo de tarefa
export const TASK_QUALITY_WEIGHTS: Record<string, Record<string, number>> = {
  'creative-writing': {
    creativity: 0.4,
    coherence: 0.3,
    style: 0.2,
    accuracy: 0.1
  },
  'code': {
    correctness: 0.4,
    efficiency: 0.25,
    readability: 0.2,
    completeness: 0.15
  },
  'analysis': {
    accuracy: 0.35,
    depth: 0.3,
    clarity: 0.2,
    insights: 0.15
  },
  'reasoning': {
    logic: 0.4,
    completeness: 0.25,
    clarity: 0.2,
    efficiency: 0.15
  },
  'conversation': {
    naturalness: 0.3,
    helpfulness: 0.3,
    engagement: 0.2,
    accuracy: 0.2
  }
};

// Configuração de fallback automático
export const FALLBACK_CONFIG = {
  maxRetries: 3,
  retryDelayMs: 1000,
  circuitBreakerThreshold: 10, // falhas consecutivas
  circuitBreakerTimeoutMs: 60000, // 1 minuto
  healthCheckIntervalMs: 30000, // 30 segundos
  
  // Condições para ativar fallback
  triggers: {
    latencyThreshold: 10000, // 10 segundos
    errorRateThreshold: 0.15, // 15%
    consecutiveFailures: 5,
    queueLengthThreshold: 100
  },

  // Estratégias de fallback
  strategies: {
    'cost-optimized': {
      priority: ['cost', 'availability', 'latency', 'quality'],
      description: 'Prioriza custo baixo'
    },
    'latency-optimized': {
      priority: ['latency', 'availability', 'quality', 'cost'],
      description: 'Prioriza velocidade'
    },
    'quality-optimized': {
      priority: ['quality', 'availability', 'latency', 'cost'],
      description: 'Prioriza qualidade'
    },
    'balanced': {
      priority: ['availability', 'quality', 'latency', 'cost'],
      description: 'Balanceado entre métricas'
    }
  }
};

// Métricas de benchmark por modelo
export const MODEL_BENCHMARKS: Record<string, {
  averageResponseTime: number;
  tokensPerSecond: number;
  qualityMetrics: {
    coherence: number; // 0-1
    creativity: number; // 0-1
    factualAccuracy: number; // 0-1
    codeCorrectness?: number; // 0-1
  };
  userSatisfaction: number; // 0-1
  costEffectiveness: number; // quality/cost ratio
  lastUpdated: Date;
}> = {
  'groq-llama-3.1-70b': {
    averageResponseTime: 1500,
    tokensPerSecond: 150,
    qualityMetrics: {
      coherence: 0.92,
      creativity: 0.88,
      factualAccuracy: 0.89
    },
    userSatisfaction: 0.91,
    costEffectiveness: 11.4, // quality/cost
    lastUpdated: new Date()
  },
  'groq-llama-3.1-8b': {
    averageResponseTime: 800,
    tokensPerSecond: 200,
    qualityMetrics: {
      coherence: 0.85,
      creativity: 0.82,
      factualAccuracy: 0.83
    },
    userSatisfaction: 0.84,
    costEffectiveness: 42.0, // muito cost-effective
    lastUpdated: new Date()
  },
  'openai-gpt-4o': {
    averageResponseTime: 5000,
    tokensPerSecond: 50,
    qualityMetrics: {
      coherence: 0.96,
      creativity: 0.94,
      factualAccuracy: 0.95
    },
    userSatisfaction: 0.95,
    costEffectiveness: 3.8, // caro mas alta qualidade
    lastUpdated: new Date()
  },
  'replit-code-v1.5': {
    averageResponseTime: 1000,
    tokensPerSecond: 180,
    qualityMetrics: {
      coherence: 0.88,
      creativity: 0.75,
      factualAccuracy: 0.90,
      codeCorrectness: 0.92
    },
    userSatisfaction: 0.89,
    costEffectiveness: 89.0, // excelente para código
    lastUpdated: new Date()
  }
};

export function getModelById(modelId: string): ModelConfig | null {
  return MODEL_REGISTRY[modelId] || null;
}

export function getModelsByProvider(provider: Provider): ModelConfig[] {
  return Object.values(MODEL_REGISTRY).filter(model => model.provider === provider);
}

export function getAvailableModelsForTier(userTier: string): ModelConfig[] {
  return Object.values(MODEL_REGISTRY).filter(model => {
    if (!model.restrictions?.minTier) return true;
    
    const tierHierarchy = ['free', 'basic', 'pro', 'premium', 'enterprise'];
    const userTierIndex = tierHierarchy.indexOf(userTier);
    const modelTierIndex = tierHierarchy.indexOf(model.restrictions.minTier);
    
    return userTierIndex >= modelTierIndex;
  });
}

export function calculateRequestCost(
  modelId: string, 
  inputTokens: number, 
  outputTokens: number = 0
): number {
  const model = getModelById(modelId);
  if (!model) return 0;

  const providerConfig = PROVIDER_COSTS[model.provider];
  const tokenCost = (inputTokens + outputTokens) * model.costPerToken * providerConfig.tokenMultiplier;
  
  return providerConfig.baseRequestCost + tokenCost;
}