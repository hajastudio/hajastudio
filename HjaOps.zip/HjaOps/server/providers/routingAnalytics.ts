import type { 
  Provider, 
  AgentType, 
  UserTier, 
  RouteDecision, 
  ProviderMetrics, 
  RoutingAnalytics 
} from '../../client/src/types/routing';

interface RoutingEvent {
  timestamp: Date;
  userId: string;
  agentType: AgentType;
  userTier: UserTier;
  selectedModel: string;
  provider: Provider;
  reason: string;
  estimatedCost: number;
  actualCost?: number;
  latency?: number;
  success: boolean;
  fallbackUsed: boolean;
  abTestGroup?: 'control' | 'experiment';
  satisfaction?: number; // 1-5 user rating
}

interface CostSavingEvent {
  timestamp: Date;
  agentType: AgentType;
  originalModel: string;
  selectedModel: string;
  costSaved: number;
  reason: string;
}

export class RoutingAnalytics {
  private events: RoutingEvent[] = [];
  private costSavings: CostSavingEvent[] = [];
  private providerMetrics: Map<Provider, ProviderMetrics> = new Map();
  private maxEvents = 10000; // Limite de eventos em memória

  constructor() {
    this.initializeMetrics();
    this.startPeriodicAggregation();
  }

  /**
   * Registra uma decisão de roteamento
   */
  recordRoutingDecision(decision: RouteDecision, success: boolean = true): void {
    const event: RoutingEvent = {
      timestamp: new Date(),
      userId: decision.metadata.userId,
      agentType: decision.metadata.agentType,
      userTier: decision.metadata.userTier,
      selectedModel: decision.selectedModel.modelName,
      provider: decision.selectedModel.provider,
      reason: decision.reason,
      estimatedCost: decision.estimatedCost,
      latency: decision.estimatedLatency,
      success,
      fallbackUsed: decision.reason.includes('fallback'),
      abTestGroup: decision.abTestGroup
    };

    this.events.push(event);
    this.trimEvents();
    this.updateProviderMetrics(event);
  }

  /**
   * Registra economia de custo por decisão de roteamento
   */
  recordCostSaving(
    agentType: AgentType, 
    originalModel: string, 
    selectedModel: string, 
    costSaved: number, 
    reason: string
  ): void {
    const saving: CostSavingEvent = {
      timestamp: new Date(),
      agentType,
      originalModel,
      selectedModel,
      costSaved,
      reason
    };

    this.costSavings.push(saving);
  }

  /**
   * Atualiza latência e custo real após execução
   */
  updateActualMetrics(requestId: string, actualCost: number, actualLatency: number): void {
    const event = this.events.find(e => 
      // Buscar por timestamp próximo já que não temos requestId no evento
      Math.abs(e.timestamp.getTime() - Date.now()) < 60000
    );

    if (event) {
      event.actualCost = actualCost;
      event.latency = actualLatency;
    }
  }

  /**
   * Registra satisfação do usuário (1-5)
   */
  recordUserSatisfaction(userId: string, agentType: AgentType, rating: number): void {
    const recentEvent = this.events
      .filter(e => e.userId === userId && e.agentType === agentType)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];

    if (recentEvent) {
      recentEvent.satisfaction = rating;
    }
  }

  /**
   * Obtém métricas de analytics consolidadas
   */
  getAnalytics(timeRange: '1h' | '6h' | '24h' | '7d' = '24h'): RoutingAnalytics {
    const cutoff = this.getTimeRangeCutoff(timeRange);
    const relevantEvents = this.events.filter(e => e.timestamp >= cutoff);
    const relevantSavings = this.costSavings.filter(s => s.timestamp >= cutoff);

    // Contadores básicos
    const totalRequests = relevantEvents.length;
    const successfulRequests = relevantEvents.filter(e => e.success).length;
    const fallbackActivations = relevantEvents.filter(e => e.fallbackUsed).length;

    // Distribuição por decisão de roteamento
    const routingDecisions = relevantEvents.reduce((acc, event) => {
      acc[event.reason] = (acc[event.reason] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Economia total
    const totalCostSavings = relevantSavings.reduce((sum, saving) => sum + saving.costSaved, 0);

    // A/B tests ativos
    const abTestsRunning = new Set(
      relevantEvents
        .filter(e => e.abTestGroup)
        .map(e => `${e.agentType}-${e.abTestGroup}`)
    ).size;

    // Saúde dos providers
    const providerHealth = {} as Record<Provider, 'healthy' | 'degraded' | 'unhealthy'>;
    for (const [provider, metrics] of this.providerMetrics.entries()) {
      const errorRate = metrics.metrics.errorRate;
      const avgLatency = metrics.metrics.avgLatency;
      
      if (errorRate > 0.1 || avgLatency > 8000) {
        providerHealth[provider] = 'unhealthy';
      } else if (errorRate > 0.05 || avgLatency > 4000) {
        providerHealth[provider] = 'degraded';
      } else {
        providerHealth[provider] = 'healthy';
      }
    }

    // Top recomendações de economia
    const topCostSavingRecommendations = this.generateCostOptimizations(relevantEvents);

    return {
      timeRange,
      totalRequests,
      routingDecisions,
      fallbackActivations,
      costSavings: totalCostSavings,
      abTestsRunning,
      providerHealth,
      topCostSavingRecommendations
    };
  }

  /**
   * Obtém métricas por provider
   */
  getProviderMetrics(provider: Provider, timeRange: '1h' | '6h' | '24h' | '7d' = '24h'): ProviderMetrics | null {
    return this.providerMetrics.get(provider) || null;
  }

  /**
   * Obtém análise de performance por agente
   */
  getAgentPerformance(agentType: AgentType, timeRange: '1h' | '6h' | '24h' | '7d' = '24h') {
    const cutoff = this.getTimeRangeCutoff(timeRange);
    const agentEvents = this.events.filter(
      e => e.agentType === agentType && e.timestamp >= cutoff
    );

    if (agentEvents.length === 0) {
      return null;
    }

    const totalRequests = agentEvents.length;
    const successRate = agentEvents.filter(e => e.success).length / totalRequests;
    const avgCost = agentEvents.reduce((sum, e) => sum + (e.actualCost || e.estimatedCost), 0) / totalRequests;
    const avgLatency = agentEvents.reduce((sum, e) => sum + (e.latency || 0), 0) / totalRequests;
    const avgSatisfaction = agentEvents
      .filter(e => e.satisfaction)
      .reduce((sum, e, _, arr) => sum + (e.satisfaction! / arr.length), 0);

    // Distribuição por provider
    const providerDistribution = agentEvents.reduce((acc, event) => {
      acc[event.provider] = (acc[event.provider] || 0) + 1;
      return acc;
    }, {} as Record<Provider, number>);

    // Modelo mais usado
    const modelUsage = agentEvents.reduce((acc, event) => {
      acc[event.selectedModel] = (acc[event.selectedModel] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const mostUsedModel = Object.entries(modelUsage)
      .sort(([,a], [,b]) => b - a)[0]?.[0];

    return {
      agentType,
      timeRange,
      totalRequests,
      successRate,
      avgCost,
      avgLatency,
      avgSatisfaction,
      providerDistribution,
      mostUsedModel,
      fallbackRate: agentEvents.filter(e => e.fallbackUsed).length / totalRequests
    };
  }

  /**
   * Exporta dados para análise externa
   */
  exportData(format: 'json' | 'csv' = 'json', timeRange: '1h' | '6h' | '24h' | '7d' = '24h') {
    const cutoff = this.getTimeRangeCutoff(timeRange);
    const relevantEvents = this.events.filter(e => e.timestamp >= cutoff);

    if (format === 'json') {
      return {
        events: relevantEvents,
        costSavings: this.costSavings.filter(s => s.timestamp >= cutoff),
        analytics: this.getAnalytics(timeRange)
      };
    }

    // CSV export (simplified)
    const csvHeader = 'timestamp,userId,agentType,userTier,model,provider,cost,latency,success,fallback,satisfaction\n';
    const csvData = relevantEvents.map(e => 
      `${e.timestamp.toISOString()},${e.userId},${e.agentType},${e.userTier},${e.selectedModel},${e.provider},${e.actualCost || e.estimatedCost},${e.latency || 0},${e.success},${e.fallbackUsed},${e.satisfaction || ''}`
    ).join('\n');

    return csvHeader + csvData;
  }

  private initializeMetrics(): void {
    const providers: Provider[] = ['groq', 'huggingface', 'replit', 'openai'];
    
    providers.forEach(provider => {
      this.providerMetrics.set(provider, {
        provider,
        timeWindow: '24h',
        metrics: {
          totalRequests: 0,
          successfulRequests: 0,
          failedRequests: 0,
          avgLatency: 0,
          p95Latency: 0,
          p99Latency: 0,
          avgCost: 0,
          totalCost: 0,
          errorRate: 0,
          satisfactionScore: 0
        },
        lastUpdated: new Date()
      });
    });
  }

  private updateProviderMetrics(event: RoutingEvent): void {
    const metrics = this.providerMetrics.get(event.provider);
    if (!metrics) return;

    metrics.metrics.totalRequests++;
    
    if (event.success) {
      metrics.metrics.successfulRequests++;
    } else {
      metrics.metrics.failedRequests++;
    }

    metrics.metrics.errorRate = metrics.metrics.failedRequests / metrics.metrics.totalRequests;
    
    // Atualizar médias (simplificado)
    if (event.latency) {
      metrics.metrics.avgLatency = (metrics.metrics.avgLatency + event.latency) / 2;
    }
    
    const cost = event.actualCost || event.estimatedCost;
    metrics.metrics.totalCost += cost;
    metrics.metrics.avgCost = metrics.metrics.totalCost / metrics.metrics.totalRequests;
    
    if (event.satisfaction) {
      const currentSat = metrics.metrics.satisfactionScore || 0;
      metrics.metrics.satisfactionScore = (currentSat + event.satisfaction) / 2;
    }

    metrics.lastUpdated = new Date();
  }

  private generateCostOptimizations(events: RoutingEvent[]) {
    const agentCosts = events.reduce((acc, event) => {
      const agent = event.agentType;
      if (!acc[agent]) {
        acc[agent] = { totalCost: 0, requests: 0, models: {} as Record<string, number> };
      }
      
      acc[agent].totalCost += event.actualCost || event.estimatedCost;
      acc[agent].requests++;
      acc[agent].models[event.selectedModel] = (acc[agent].models[event.selectedModel] || 0) + 1;
      
      return acc;
    }, {} as Record<AgentType, any>);

    return Object.entries(agentCosts).map(([agent, data]) => ({
      agentType: agent as AgentType,
      currentCostPerRequest: data.totalCost / data.requests,
      targetCostPerRequest: (data.totalCost / data.requests) * 0.7, // 30% reduction target
      recommendations: [
        {
          action: 'switch_model' as const,
          modelId: 'groq-llama-3.1-8b',
          expectedSaving: 25,
          impact: 'medium' as const,
          description: `Migrar 60% dos requests para modelo mais econômico`
        },
        {
          action: 'implement_caching' as const,
          expectedSaving: 15,
          impact: 'low' as const,
          description: `Cache de respostas similares por 1 hora`
        }
      ]
    })).slice(0, 5); // Top 5 optimizations
  }

  private getTimeRangeCutoff(timeRange: string): Date {
    const now = new Date();
    const cutoffs = {
      '1h': 60 * 60 * 1000,
      '6h': 6 * 60 * 60 * 1000,
      '24h': 24 * 60 * 60 * 1000,
      '7d': 7 * 24 * 60 * 60 * 1000
    };
    
    return new Date(now.getTime() - (cutoffs[timeRange as keyof typeof cutoffs] || cutoffs['24h']));
  }

  private trimEvents(): void {
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(-this.maxEvents);
    }
  }

  private startPeriodicAggregation(): void {
    // Agregação a cada 5 minutos
    setInterval(() => {
      this.aggregateMetrics();
    }, 5 * 60 * 1000);
  }

  private aggregateMetrics(): void {
    // Aqui seria implementada agregação para métricas P95, P99, etc.
    // Por simplicidade, está omitida na implementação mock
    console.log('Aggregating routing metrics...');
  }
}

// Singleton instance
export const routingAnalytics = new RoutingAnalytics();