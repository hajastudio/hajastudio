import { storage } from "./storage";
import type { InsertAffiliateProduct, InsertPost } from "@shared/schema";

export async function seedAffiliateData() {
  console.log("Seeding affiliate products...");

  // Sample affiliate products data
  const affiliateProducts: InsertAffiliateProduct[] = [
    {
      title: "Smartphone Samsung Galaxy A54 5G 128GB",
      description: "Smartphone com tela de 6.4 polegadas, câmera tripla de 50MP, processador Exynos 1380 e bateria de 5000mAh. Ideal para fotos incríveis e performance superior.",
      imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400",
      affiliateLink: "https://mercadolivre.com.br/samsung-galaxy-a54",
      price: "149999", // R$ 1499.99
      originalPrice: "179999", // R$ 1799.99
      category: "Smartphones",
      commission: 5, // 5%
      active: true,
      featured: true,
      tags: ["Samsung", "5G", "Android", "Câmera", "128GB"]
    },
    {
      title: "Notebook Gamer ASUS TUF Gaming F15",
      description: "Notebook gamer com processador Intel Core i5, 16GB RAM, SSD 512GB, GeForce RTX 3050 e tela 15.6' Full HD. Perfeito para jogos e trabalho.",
      imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
      affiliateLink: "https://mercadolivre.com.br/asus-tuf-gaming-f15",
      price: "349999", // R$ 3499.99
      category: "Notebooks",
      commission: 3,
      active: true,
      featured: true,
      tags: ["ASUS", "Gaming", "Intel", "RTX 3050", "SSD"]
    },
    {
      title: "Fone de Ouvido Sony WH-1000XM4",
      description: "Fone de ouvido premium com cancelamento de ruído ativo, 30h de bateria, Hi-Res Audio e conexão Bluetooth 5.0. Conforto e qualidade sonora excepcionais.",
      imageUrl: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=400",
      affiliateLink: "https://mercadolivre.com.br/sony-wh-1000xm4",
      price: "119999", // R$ 1199.99
      originalPrice: "149999", // R$ 1499.99
      category: "Áudio",
      commission: 8,
      active: true,
      featured: false,
      tags: ["Sony", "Bluetooth", "Noise Cancelling", "Hi-Res", "Premium"]
    },
    {
      title: "Monitor Gamer LG UltraGear 27GL650F 27'",
      description: "Monitor gamer IPS 27' Full HD com 144Hz, 1ms, FreeSync Premium, HDR10 e ajuste de altura. Visual fluido e cores vibrantes para gaming.",
      imageUrl: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400",
      affiliateLink: "https://mercadolivre.com.br/lg-ultragear-27gl650f",
      price: "89999", // R$ 899.99
      category: "Monitores",
      commission: 4,
      active: true,
      featured: false,
      tags: ["LG", "Gaming", "144Hz", "IPS", "FreeSync"]
    },
    {
      title: "Teclado Mecânico Logitech G Pro X",
      description: "Teclado mecânico compacto para gamers com switches GX Blue, RGB LIGHTSYNC, cabo removível e design TKL. Performance profissional e durabilidade.",
      imageUrl: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400",
      affiliateLink: "https://mercadolivre.com.br/logitech-g-pro-x",
      price: "59999", // R$ 599.99
      category: "Periféricos",
      commission: 10,
      active: true,
      featured: false,
      tags: ["Logitech", "Mecânico", "RGB", "Gaming", "TKL"]
    },
    {
      title: "Tablet iPad Air 5ª Geração 64GB Wi-Fi",
      description: "iPad Air com chip M1, tela Liquid Retina de 10.9', compatibilidade com Apple Pencil (2ª geração) e Magic Keyboard. Potência e versatilidade.",
      imageUrl: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400",
      affiliateLink: "https://mercadolivre.com.br/ipad-air-5-geracao",
      price: "399999", // R$ 3999.99
      category: "Tablets",
      commission: 2,
      active: true,
      featured: true,
      tags: ["Apple", "iPad", "M1", "Liquid Retina", "64GB"]
    },
    {
      title: "Câmera Digital Canon EOS Rebel T100",
      description: "Câmera DSLR entry-level com sensor de 18MP, gravação Full HD, Wi-Fi integrado e modo Scene Intelligent Auto. Ideal para iniciantes na fotografia.",
      imageUrl: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
      affiliateLink: "https://mercadolivre.com.br/canon-eos-rebel-t100",
      price: "199999", // R$ 1999.99
      category: "Câmeras",
      commission: 6,
      active: true,
      featured: false,
      tags: ["Canon", "DSLR", "18MP", "Wi-Fi", "Full HD"]
    },
    {
      title: "Smart TV Samsung 55' 4K UHD",
      description: "Smart TV LED 55' com resolução 4K UHD, HDR, Tizen OS, controle remoto único e design sem bordas. Entretenimento em alta definição.",
      imageUrl: "https://images.unsplash.com/photo-1593784991095-a205069470b6?w=400",
      affiliateLink: "https://mercadolivre.com.br/samsung-smart-tv-55-4k",
      price: "249999", // R$ 2499.99
      originalPrice: "299999", // R$ 2999.99
      category: "TVs",
      commission: 3,
      active: true,
      featured: false,
      tags: ["Samsung", "Smart TV", "4K", "HDR", "55 polegadas"]
    }
  ];

  // Blog posts with different access levels
  const blogPosts: InsertPost[] = [
    {
      title: "10 Prompts Essenciais para Maximizar sua Produtividade com IA",
      slug: "prompts-essenciais-produtividade-ia",
      content: "A Inteligência Artificial está revolucionando a forma como trabalhamos. Aprenda os 10 prompts mais eficazes para turbinar sua produtividade diária.",
      excerpt: "A Inteligência Artificial está revolucionando a forma como trabalhamos e vivemos. Neste guia completo, você descobrirá os prompts mais eficazes para turbinar sua produtividade diária.",
      coverImage: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800",
      authorId: "admin-user-id",
      tags: ["IA", "Produtividade", "Prompts", "Automação", "Eficiência"],
      requiredLevel: "free",
      published: true,
      readTime: 8,
      seoTitle: "10 Prompts de IA para Aumentar Produtividade | Guia Completo 2024",
      seoDescription: "Descubra os 10 prompts essenciais de IA para maximizar sua produtividade. Guia prático com técnicas comprovadas para uso profissional.",
      publishedAt: new Date('2024-01-15'),
      views: 1250
    },
    {
      title: "Como Criar um Sistema de IA Multi-Agentes: Arquitetura Avançada",
      slug: "sistema-ia-multi-agentes-arquitetura",
      content: "Os sistemas multi-agentes representam o futuro da inteligência artificial. Aprenda a criar sua própria arquitetura neste guia técnico avançado.",
      excerpt: "Os sistemas multi-agentes representam o futuro da inteligência artificial, permitindo que diferentes AIs trabalhem em conjunto para resolver problemas complexos.",
      coverImage: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800",
      authorId: "admin-user-id",
      tags: ["IA", "Sistemas Multi-Agentes", "Arquitetura", "Python", "Programação Avançada"],
      requiredLevel: "pro",
      published: true,
      readTime: 25,
      seoTitle: "Sistemas Multi-Agentes: Guia Completo de Arquitetura e Implementação",
      seoDescription: "Aprenda a criar sistemas de IA multi-agentes com arquiteturas avançadas, protocolos de comunicação e implementações práticas.",
      publishedAt: new Date('2024-01-20'),
      views: 890
    },
    {
      title: "Estratégias Secretas de Prompt Engineering para GPT-5",
      slug: "estrategias-secretas-prompt-engineering-gpt5",
      content: "Descubra técnicas avançadas e pouco conhecidas para maximizar o potencial do GPT-5, incluindo métodos de manipulação de contexto e estratégias que apenas 5% dos usuários conhecem.",
      excerpt: "Descubra técnicas avançadas e pouco conhecidas para maximizar o potencial do GPT-5, incluindo métodos de manipulação de contexto, técnicas de few-shot learning aprimoradas.",
      coverImage: "https://images.unsplash.com/photo-1676299081847-824916de030a?w=800",
      authorId: "admin-user-id",
      tags: ["GPT-5", "Prompt Engineering", "IA Avançada", "Otimização", "Técnicas Secretas"],
      requiredLevel: "token-5",
      published: true,
      readTime: 18,
      seoTitle: "Prompt Engineering Avançado para GPT-5: Técnicas Secretas Reveladas",
      seoDescription: "Domine técnicas avançadas de prompt engineering para GPT-5. Estratégias secretas para maximizar performance e obter resultados superiores.",
      publishedAt: new Date('2024-01-25'),
      views: 2340
    }
  ];

  try {
    // Insert affiliate products
    for (const productData of affiliateProducts) {
      await storage.createAffiliateProduct(productData);
    }

    console.log(`✅ Created ${affiliateProducts.length} affiliate products`);

    // Insert blog posts
    for (const postData of blogPosts) {
      await storage.createPost(postData);
    }

    console.log(`✅ Created ${blogPosts.length} blog posts`);

    console.log("🎉 Affiliate and blog data seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding affiliate data:", error);
    throw error;
  }
}