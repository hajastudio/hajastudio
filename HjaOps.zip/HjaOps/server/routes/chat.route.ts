import express from "express";
import { orchestrator } from "../services/orchestrator";
import { checkCredits } from "../middleware/credits.middleware";

const router = express.Router();

// Mock user para demo
const DEMO_USER = {
  id: "demo-user-123",
  email: "demo@haja.app", 
  credits: 50,
  plan: "pro"
};

/**
 * POST /chat
 * Body esperado:
 * {
 *   "message": "texto da mensagem",
 *   "agentId": "roteirista"
 * }
 */
router.post("/", async (req, res) => {
  try {
    const { message, agentId } = req.body;
    
    if (!message || !agentId) {
      return res.status(400).json({
        success: false,
        error: "message e agentId são obrigatórios"
      });
    }

    console.log(`🤖 Processando chat: agente=${agentId}, mensagem="${message.substring(0, 50)}..."`);
    
    const chatRequest = {
      agentId,
      messages: [{ role: 'user' as const, content: message }],
      userId: DEMO_USER.id
    };

    const response = await hvcOrchestrator.processChat(chatRequest);
    
    // Simulação de gasto de créditos
    const creditsUsed = Math.max(1, Math.floor(response.tokensUsed / 100));
    
    return res.json({
      success: true,
      data: {
        response: response.content,
        tokensUsed: response.tokensUsed,
        model: response.model,
        provider: response.provider,
        cost: response.cost,
        creditsUsed,
        processingTime: response.processingTime
      }
    });

  } catch (error: any) {
    console.error("❌ Erro no /chat:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Erro desconhecido"
    });
  }
});

export default router;