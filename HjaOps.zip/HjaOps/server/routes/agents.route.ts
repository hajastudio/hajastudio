import express from "express";
import { PrismaClient } from "@prisma/client";

const router = express.Router();
const prisma = new PrismaClient();

/**
 * GET /agents
 * Lista todos os agentes ativos
 */
router.get("/", async (req, res) => {
  try {
    const agents = await prisma.agent.findMany({ 
      where: { active: true },
      orderBy: { name: 'asc' }
    });
    
    return res.json({
      success: true,
      agents: agents
    });
    
  } catch (error: any) {
    console.error("❌ Erro ao buscar agentes:", error);
    return res.status(500).json({
      success: false,
      error: "Erro ao buscar agentes"
    });
  }
});

/**
 * GET /agents/:id
 * Busca um agente específico
 */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    const agent = await prisma.agent.findUnique({
      where: { id }
    });
    
    if (!agent) {
      return res.status(404).json({
        success: false,
        error: "Agente não encontrado"
      });
    }
    
    return res.json({
      success: true,
      agent: agent
    });
    
  } catch (error: any) {
    console.error("❌ Erro ao buscar agente:", error);
    return res.status(500).json({
      success: false,
      error: "Erro ao buscar agente"
    });
  }
});

export default router;