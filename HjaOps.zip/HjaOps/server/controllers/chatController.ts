import { Request, Response } from 'express';
import { AIOrchestrator } from '../services/aiOrchestrator';
import { ConsumptionLogger } from '../services/consumptionLogger';
import { storage } from '../storage';
import { ChatMessage } from '../services/aiProviders';

// Initialize services
const aiOrchestrator = new AIOrchestrator();
const consumptionLogger = new ConsumptionLogger();

interface ChatRequest {
  messages: ChatMessage[];
  agentId: string;
  modelId?: string;
}

interface ChatResponse {
  success: boolean;
  message?: string;
  provider?: string;
  model?: string;
  tokensUsed?: number;
  cost?: number;
  latency?: number;
  creditsRemaining?: number;
  error?: string;
}

export async function handleChat(req: Request, res: Response): Promise<void> {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      res.status(401).json({ error: 'User not authenticated' });
      return;
    }

    const { messages, agentId, modelId }: ChatRequest = req.body;

    // Validate request
    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: 'Messages array is required' });
      return;
    }

    if (!agentId) {
      res.status(400).json({ error: 'Agent ID is required' });
      return;
    }

    // Get user data to check credits
    const user = await storage.getUser(userId);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    // Check if user has enough credits
    const requiredCredits = 1; // 1 credit per chat
    if (user.credits < requiredCredits) {
      res.status(402).json({ 
        error: 'Insufficient credits',
        creditsRequired: requiredCredits,
        creditsAvailable: user.credits
      });
      return;
    }

    console.log(`[ChatController] User ${userId} starting chat with agent ${agentId}`);

    // Orchestrate AI response
    const result = await aiOrchestrator.orchestrate(messages, agentId, modelId);

    if (result.success && result.response) {
      // Debit credits atomically
      const updatedCredits = user.credits - requiredCredits;
      await storage.updateUserCredits(userId, updatedCredits);

      // Log consumption
      await consumptionLogger.logConsumption(
        userId,
        agentId,
        result,
        user.plan || 'free',
        req.sessionID
      );

      const response: ChatResponse = {
        success: true,
        message: result.response.content,
        provider: result.provider,
        model: result.model,
        tokensUsed: result.tokensUsed,
        cost: result.cost,
        latency: result.latency,
        creditsRemaining: updatedCredits
      };

      res.json(response);
    } else {
      // Log failed attempt
      await consumptionLogger.logConsumption(
        userId,
        agentId,
        result,
        user.plan || 'free',
        req.sessionID
      );

      res.status(503).json({
        success: false,
        error: result.error || 'AI service unavailable',
        fallbacksUsed: result.fallbacksUsed
      });
    }

  } catch (error) {
    console.error('[ChatController] Error handling chat:', error);
    res.status(500).json({ 
      success: false,
      error: 'Internal server error' 
    });
  }
}

export async function getAgents(req: Request, res: Response): Promise<void> {
  try {
    // For now, return static agents data
    // In production, this would come from Firestore
    const agents = [
      {
        id: 'roteirista',
        name: 'Roteirista AI',
        description: 'Especialista em criação de roteiros e narrativas envolventes',
        category: 'Criação',
        defaultModel: 'llama-3.1-70b-versatile',
        specialty: ['Roteiros', 'Narrativa', 'Storytelling'],
        personality: 'Criativo e estruturado',
        systemPrompt: 'Você é um roteirista profissional especializado em criar narrativas envolventes...'
      },
      {
        id: 'vibecode',
        name: 'VibeCode',
        description: 'Desenvolvedor especializado em código limpo e arquitetura',
        category: 'Desenvolvimento',
        defaultModel: 'replit-code-v1_5-3b',
        specialty: ['TypeScript', 'React', 'Node.js'],
        personality: 'Preciso e didático',
        systemPrompt: 'Você é um desenvolvedor sênior especializado em boas práticas...'
      },
      {
        id: 'analista-youtube',
        name: 'Analista YouTube',
        description: 'Especialista em estratégias de crescimento no YouTube',
        category: 'Marketing',
        defaultModel: 'llama-3.1-70b-versatile',
        specialty: ['SEO YouTube', 'Thumbnails', 'Engagement'],
        personality: 'Estratégico e orientado a dados',
        systemPrompt: 'Você é um especialista em crescimento no YouTube...'
      },
      {
        id: 'branding-social',
        name: 'Branding Social',
        description: 'Consultor de marca e estratégias de redes sociais',
        category: 'Branding',
        defaultModel: 'llama-3.1-70b-versatile',
        specialty: ['Identidade Visual', 'Redes Sociais', 'Posicionamento'],
        personality: 'Criativo e estratégico',
        systemPrompt: 'Você é um consultor de branding especializado em redes sociais...'
      },
      {
        id: 'viral-maker',
        name: 'Viral Maker',
        description: 'Especialista em conteúdo viral e tendências',
        category: 'Conteúdo',
        defaultModel: 'llama-3.1-70b-versatile',
        specialty: ['Trends', 'Viral Content', 'Engagement'],
        personality: 'Energético e antenado',
        systemPrompt: 'Você é um especialista em criar conteúdo viral...'
      }
    ];

    res.json({ agents });
  } catch (error) {
    console.error('[ChatController] Error getting agents:', error);
    res.status(500).json({ error: 'Failed to fetch agents' });
  }
}

export async function getModels(req: Request, res: Response): Promise<void> {
  try {
    // Get provider status
    const providerStatus = aiOrchestrator.getProviderStatus();
    
    const models = [
      {
        id: 'llama-3.1-70b-versatile',
        name: 'Llama 3.1 70B',
        provider: 'groq',
        category: 'general',
        description: 'Modelo versátil para tarefas gerais',
        costPer1KTokens: 0.10,
        maxTokens: 4096,
        available: providerStatus.groq
      },
      {
        id: 'deepseek-r1',
        name: 'DeepSeek R1',
        provider: 'groq',
        category: 'reasoning',
        description: 'Especializado em raciocínio complexo',
        costPer1KTokens: 0.12,
        maxTokens: 8192,
        available: providerStatus.groq
      },
      {
        id: 'mistralai/Mistral-7B-Instruct-v0.3',
        name: 'Mistral 7B Instruct',
        provider: 'huggingface',
        category: 'general',
        description: 'Modelo eficiente para instruções',
        costPer1KTokens: 0.05,
        maxTokens: 2048,
        available: providerStatus.huggingface
      },
      {
        id: 'replit-code-v1_5-3b',
        name: 'Replit Code v1.5',
        provider: 'replit',
        category: 'code',
        description: 'Especializado em programação',
        costPer1KTokens: 0.08,
        maxTokens: 2048,
        available: providerStatus.replit
      }
    ];

    res.json({ 
      models,
      providerStatus
    });
  } catch (error) {
    console.error('[ChatController] Error getting models:', error);
    res.status(500).json({ error: 'Failed to fetch models' });
  }
}

export async function getChatHistory(req: Request, res: Response): Promise<void> {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      res.status(401).json({ error: 'User not authenticated' });
      return;
    }

    // For now, return empty history
    // In production, this would fetch from Firestore
    res.json({ 
      chats: [],
      total: 0
    });
  } catch (error) {
    console.error('[ChatController] Error getting chat history:', error);
    res.status(500).json({ error: 'Failed to fetch chat history' });
  }
}

export async function getUserCredits(req: Request, res: Response): Promise<void> {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      res.status(401).json({ error: 'User not authenticated' });
      return;
    }

    const user = await storage.getUser(userId);
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    res.json({
      credits: user.credits,
      maxCredits: user.maxCredits,
      plan: user.plan
    });
  } catch (error) {
    console.error('[ChatController] Error getting user credits:', error);
    res.status(500).json({ error: 'Failed to fetch user credits' });
  }
}