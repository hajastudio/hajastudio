import axios from 'axios';

export interface MercadoPagoConfig {
  accessToken: string;
  publicKey: string;
  webhookSecret: string;
  sandboxMode: boolean;
}

export interface PaymentPreference {
  userId: string;
  plan: 'basic' | 'pro' | 'premium';
  creditsAmount?: number;
  customAmount?: number;
}

export interface PaymentResponse {
  id: string;
  status: string;
  init_point: string;
  sandbox_init_point?: string;
}

export class MercadoPagoIntegration {
  private config: MercadoPagoConfig;
  private baseUrl: string;

  constructor(config: MercadoPagoConfig) {
    this.config = config;
    this.baseUrl = config.sandboxMode 
      ? 'https://api.mercadopago.com' 
      : 'https://api.mercadopago.com';
  }

  // 💳 Cria preferência de pagamento para planos
  async createPaymentPreference(preference: PaymentPreference): Promise<PaymentResponse> {
    try {
      const planConfig = this.getPlanConfig(preference.plan);
      
      const paymentData = {
        items: [
          {
            title: `Hja²Ops - Plano ${preference.plan.toUpperCase()}`,
            description: `${planConfig.credits} créditos + acesso ${preference.plan}`,
            quantity: 1,
            unit_price: planConfig.price,
            currency_id: 'BRL'
          }
        ],
        payer: {
          email: `user${preference.userId}@hja2ops.com` // Mock - usar email real
        },
        external_reference: `${preference.userId}_plan_${preference.plan}`,
        notification_url: `${process.env.WEBHOOK_BASE_URL}/mercadopago/webhook`,
        back_urls: {
          success: `${process.env.FRONTEND_URL}/payment/success`,
          failure: `${process.env.FRONTEND_URL}/payment/failure`,
          pending: `${process.env.FRONTEND_URL}/payment/pending`
        },
        auto_return: 'approved',
        payment_methods: {
          excluded_payment_types: [
            { id: 'ticket' } // Excluir boleto para pagamento imediato
          ],
          installments: preference.plan === 'premium' ? 12 : 6 // Parcelas
        },
        statement_descriptor: 'HJA2OPS'
      };

      const response = await axios.post(
        `${this.baseUrl}/checkout/preferences`,
        paymentData,
        {
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return {
        id: response.data.id,
        status: 'created',
        init_point: this.config.sandboxMode 
          ? response.data.sandbox_init_point 
          : response.data.init_point,
        sandbox_init_point: response.data.sandbox_init_point
      };

    } catch (error) {
      console.error('Erro ao criar preferência MP:', error);
      throw new Error('Falha na criação do pagamento');
    }
  }

  // 💰 Cria preferência para compra avulsa de créditos
  async createCreditsPayment(userId: string, creditsAmount: number): Promise<PaymentResponse> {
    const pricePerCredit = 0.10; // R$ 0,10 por crédito
    const totalPrice = creditsAmount * pricePerCredit;
    
    const paymentData = {
      items: [
        {
          title: `${creditsAmount} Créditos Hja²Ops`,
          description: `Pacote de ${creditsAmount} créditos para uso na plataforma`,
          quantity: 1,
          unit_price: totalPrice,
          currency_id: 'BRL'
        }
      ],
      payer: {
        email: `user${userId}@hja2ops.com`
      },
      external_reference: `${userId}_credits_${creditsAmount}`,
      notification_url: `${process.env.WEBHOOK_BASE_URL}/mercadopago/webhook`,
      back_urls: {
        success: `${process.env.FRONTEND_URL}/credits/success`,
        failure: `${process.env.FRONTEND_URL}/credits/failure`
      },
      auto_return: 'approved'
    };

    try {
      const response = await axios.post(
        `${this.baseUrl}/checkout/preferences`,
        paymentData,
        {
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );

      return {
        id: response.data.id,
        status: 'created',
        init_point: this.config.sandboxMode 
          ? response.data.sandbox_init_point 
          : response.data.init_point
      };

    } catch (error) {
      console.error('Erro ao criar pagamento de créditos:', error);
      throw new Error('Falha na criação do pagamento');
    }
  }

  // 🔍 Verifica status de pagamento
  async getPaymentStatus(paymentId: string): Promise<any> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/v1/payments/${paymentId}`,
        {
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`
          }
        }
      );

      return {
        id: response.data.id,
        status: response.data.status,
        status_detail: response.data.status_detail,
        external_reference: response.data.external_reference,
        transaction_amount: response.data.transaction_amount,
        net_received_amount: response.data.net_received_amount,
        date_created: response.data.date_created,
        date_approved: response.data.date_approved
      };

    } catch (error) {
      console.error('Erro ao consultar pagamento:', error);
      throw new Error('Falha na consulta do pagamento');
    }
  }

  // ✅ Valida webhook do Mercado Pago
  validateWebhook(body: any, signature: string): boolean {
    // Implementar validação de assinatura
    // const expectedSignature = crypto
    //   .createHmac('sha256', this.config.webhookSecret)
    //   .update(JSON.stringify(body))
    //   .digest('hex');
    
    // return signature === expectedSignature;
    
    // Mock validation para desenvolvimento
    return true;
  }

  // ⚙️ Configurações dos planos
  private getPlanConfig(plan: string) {
    const plans = {
      basic: {
        credits: 300,
        price: 29.90,
        features: ['3 agentes', 'Suporte email', '300 créditos/mês']
      },
      pro: {
        credits: 500, 
        price: 59.90,
        features: ['6 agentes', 'Suporte prioritário', '500 créditos/mês', 'API access']
      },
      premium: {
        credits: 1000,
        price: 99.90,
        features: ['Todos os agentes', 'Suporte 24/7', '1000 créditos/mês', 'API access', 'Custom agents']
      }
    };

    return plans[plan] || plans.basic;
  }

  // 📊 Relatório de vendas
  async getSalesReport(startDate: string, endDate: string): Promise<any> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/v1/payments/search`,
        {
          params: {
            'range': 'date_created',
            'begin_date': startDate,
            'end_date': endDate,
            'status': 'approved'
          },
          headers: {
            'Authorization': `Bearer ${this.config.accessToken}`
          }
        }
      );

      const payments = response.data.results;
      
      const report = {
        totalPayments: payments.length,
        totalRevenue: payments.reduce((sum: number, p: any) => sum + p.transaction_amount, 0),
        byPlan: this.groupPaymentsByPlan(payments),
        byDate: this.groupPaymentsByDate(payments)
      };

      return report;

    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
      throw new Error('Falha na geração do relatório');
    }
  }

  private groupPaymentsByPlan(payments: any[]): any {
    return payments.reduce((acc, payment) => {
      const ref = payment.external_reference || '';
      const plan = ref.includes('_plan_') ? ref.split('_plan_')[1] : 'credits';
      
      if (!acc[plan]) {
        acc[plan] = { count: 0, revenue: 0 };
      }
      
      acc[plan].count++;
      acc[plan].revenue += payment.transaction_amount;
      
      return acc;
    }, {});
  }

  private groupPaymentsByDate(payments: any[]): any {
    return payments.reduce((acc, payment) => {
      const date = payment.date_created.split('T')[0];
      
      if (!acc[date]) {
        acc[date] = { count: 0, revenue: 0 };
      }
      
      acc[date].count++;
      acc[date].revenue += payment.transaction_amount;
      
      return acc;
    }, {});
  }
}

// 🎯 Instância singleton para uso nas Cloud Functions
export const mercadoPago = new MercadoPagoIntegration({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || '',
  publicKey: process.env.MERCADOPAGO_PUBLIC_KEY || '',
  webhookSecret: process.env.MERCADOPAGO_WEBHOOK_SECRET || '',
  sandboxMode: process.env.NODE_ENV !== 'production'
});

// 💡 Exemplos de uso:

// 1. Criar pagamento para plano Pro
// const payment = await mercadoPago.createPaymentPreference({
//   userId: 'user123',
//   plan: 'pro'
// });

// 2. Comprar 100 créditos avulsos  
// const creditsPayment = await mercadoPago.createCreditsPayment('user123', 100);

// 3. Verificar status de pagamento
// const status = await mercadoPago.getPaymentStatus('payment_id_123');

// 4. Validar webhook
// const isValid = mercadoPago.validateWebhook(req.body, req.headers['x-signature']);

// 5. Relatório de vendas do mês
// const report = await mercadoPago.getSalesReport('2025-09-01T00:00:00Z', '2025-09-30T23:59:59Z');