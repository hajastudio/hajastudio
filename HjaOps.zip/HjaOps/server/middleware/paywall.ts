import type { Request, Response, NextFunction } from "express";
import { storage } from "../storage";
import type { User, Post } from "@shared/schema";

// Access level hierarchy
const ACCESS_LEVELS = {
  free: 0,
  pro: 1,
  vip: 2,
  "token-5": 3
};

export interface PaywallRequest extends Request {
  user?: any;
  post?: Post;
  hasAccess?: boolean;
  accessType?: string;
}

// Middleware to check if user can access a post
export const checkPostAccess = async (req: PaywallRequest, res: Response, next: NextFunction) => {
  try {
    const { slug } = req.params;
    const user = req.user;

    // Get the post
    const post = await storage.getPostBySlug(slug);
    if (!post) {
      return res.status(404).json({ message: "Post not found" });
    }

    // Add post to request for later use
    req.post = post;

    // If post is free, everyone can access
    if (post.requiredLevel === "free") {
      req.hasAccess = true;
      req.accessType = "free";
      return next();
    }

    // If user is not authenticated, check if they can pay with tokens
    if (!user) {
      if (post.requiredLevel === "token-5") {
        req.hasAccess = false;
        req.accessType = "token-required";
        return next();
      }
      req.hasAccess = false;
      req.accessType = "login-required";
      return next();
    }

    const userId = user.claims?.sub;
    if (!userId) {
      req.hasAccess = false;
      req.accessType = "invalid-user";
      return next();
    }

    // Get user details
    const userDetails = await storage.getUser(userId);
    if (!userDetails) {
      req.hasAccess = false;
      req.accessType = "user-not-found";
      return next();
    }

    // Check if user already unlocked this post
    const hasRead = await storage.hasUserReadPost(userId, post.id);
    if (hasRead) {
      req.hasAccess = true;
      req.accessType = "already-unlocked";
      return next();
    }

    // Check user plan level
    const userLevel = ACCESS_LEVELS[userDetails.plan as keyof typeof ACCESS_LEVELS] || 0;
    const requiredLevel = ACCESS_LEVELS[post.requiredLevel as keyof typeof ACCESS_LEVELS] || 0;

    if (userLevel >= requiredLevel && post.requiredLevel !== "token-5") {
      req.hasAccess = true;
      req.accessType = "plan-access";
      return next();
    }

    // For token-5 posts or insufficient plan level
    if (post.requiredLevel === "token-5" || userLevel < requiredLevel) {
      req.hasAccess = false;
      req.accessType = "token-required";
      return next();
    }

    req.hasAccess = false;
    req.accessType = "access-denied";
    next();
  } catch (error) {
    console.error("Paywall middleware error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Middleware to unlock post with credits
export const unlockPostWithCredits = async (req: PaywallRequest, res: Response, next: NextFunction) => {
  try {
    const user = req.user;
    const post = req.post;

    if (!user || !post) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const userId = user.claims?.sub;
    const userDetails = await storage.getUser(userId);

    if (!userDetails) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if post can be unlocked with credits
    if (post.requiredLevel !== "token-5") {
      return res.status(400).json({ message: "This post cannot be unlocked with credits" });
    }

    // Check if user has enough credits (5 credits required)
    const creditsRequired = 5;
    if ((userDetails.credits || 0) < creditsRequired) {
      return res.status(400).json({ 
        message: "Insufficient credits",
        required: creditsRequired,
        available: userDetails.credits
      });
    }

    // Deduct credits
    await storage.deductCredits(userId, creditsRequired);

    // Create post read record
    await storage.createPostRead({
      postId: post.id,
      userId,
      accessType: "credits",
      creditsUsed: creditsRequired,
      sessionId: req.sessionID,
    });

    // Create transaction record
    await storage.createTransaction({
      userId,
      type: "read-post",
      amount: (creditsRequired * 10).toString(), // 5 credits = 50 cents
      creditsAdded: -creditsRequired,
      status: "completed",
      metadata: {
        postId: post.id,
        postTitle: post.title,
        creditsUsed: creditsRequired
      }
    });

    req.hasAccess = true;
    req.accessType = "credits-used";
    next();
  } catch (error) {
    console.error("Unlock post error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

// Helper function to format post content based on access
export const formatPostContent = (post: Post, hasAccess: boolean) => {
  if (hasAccess) {
    return {
      ...post,
      content: post.content,
      locked: false
    };
  }

  return {
    ...post,
    content: post.excerpt,
    locked: true,
    fullContentLength: post.content.length,
    excerptLength: post.excerpt.length
  };
};