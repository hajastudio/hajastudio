import type { Request, Response, NextFunction } from 'express';
import { storage } from '../storage.js';

interface AuthenticatedRequest extends Request {
  user?: { claims: { sub: string } };
}

export const checkCredits = (requiredCredits: number = 1) => {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user?.claims?.sub) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const userCredits = user.credits || 0;
      if (userCredits < requiredCredits) {
        return res.status(402).json({ 
          message: 'Insufficient credits',
          required: requiredCredits,
          available: userCredits
        });
      }

      // Attach user to request for downstream use
      (req as any).userData = user;
      next();
    } catch (error) {
      console.error('Credits check error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  };
};

export const deductCredits = async (userId: string, amount: number) => {
  try {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const userCredits = user.credits || 0;
    if (userCredits < amount) {
      throw new Error('Insufficient credits');
    }

    await storage.updateUserCredits(userId, userCredits - amount);
    return true;
  } catch (error) {
    console.error('Error deducting credits:', error);
    throw error;
  }
};

export const addCredits = async (userId: string, amount: number) => {
  try {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const currentCredits = user.credits || 0;
    const newCredits = currentCredits + amount;
    await storage.updateUserCredits(userId, newCredits);
    return newCredits;
  } catch (error) {
    console.error('Error adding credits:', error);
    throw error;
  }
};