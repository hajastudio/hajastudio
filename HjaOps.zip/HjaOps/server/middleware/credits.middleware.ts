import { Request, Response, NextFunction } from "express";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export const checkCredits = async (req: Request, res: Response, next: NextFunction) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ error: "userId obrigatório" });

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || user.credits <= 0) {
    return res.status(402).json({
      error: "Créditos insuficientes",
      action: "upsell",
      message: "Seu plano acabou. Recarregue créditos ou faça upgrade.",
    });
  }

  next();
};