import { OrchestrationResult } from './aiOrchestrator';

export interface ConsumptionLog {
  id: string;
  userId: string;
  agentId: string;
  timestamp: Date;
  provider: string;
  model: string;
  tokensUsed: number;
  cost: number;
  latency: number;
  success: boolean;
  fallbacksUsed: string[];
  error?: string;
  userPlan: string;
  sessionId?: string;
}

export interface DailyConsumptionSummary {
  date: string;
  totalRequests: number;
  totalTokens: number;
  totalCost: number;
  avgLatency: number;
  successRate: number;
  providerBreakdown: Record<string, {
    requests: number;
    tokens: number;
    cost: number;
    successRate: number;
  }>;
  topUsers: Array<{
    userId: string;
    requests: number;
    tokens: number;
    cost: number;
  }>;
}

export class ConsumptionLogger {
  private logs: ConsumptionLog[] = [];
  private dailySummaries: Map<string, DailyConsumptionSummary> = new Map();

  async logConsumption(
    userId: string,
    agentId: string,
    result: OrchestrationResult,
    userPlan: string,
    sessionId?: string
  ): Promise<void> {
    const log: ConsumptionLog = {
      id: this.generateLogId(),
      userId,
      agentId,
      timestamp: new Date(),
      provider: result.provider,
      model: result.model,
      tokensUsed: result.tokensUsed,
      cost: result.cost,
      latency: result.latency,
      success: result.success,
      fallbacksUsed: result.fallbacksUsed,
      error: result.error,
      userPlan,
      sessionId
    };

    // Store log
    this.logs.push(log);
    
    // Update daily summary
    await this.updateDailySummary(log);
    
    // Log to console for development
    console.log(`[ConsumptionLogger] ${log.userId} used ${log.tokensUsed} tokens via ${log.provider} (${log.model}) - Cost: $${log.cost.toFixed(4)}`);
    
    // In production, this would write to Firestore
    // await this.writeToFirestore(log);
  }

  async getDailyConsumption(date: string): Promise<DailyConsumptionSummary | null> {
    return this.dailySummaries.get(date) || null;
  }

  async getUserConsumption(userId: string, days: number = 30): Promise<ConsumptionLog[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return this.logs.filter(log => 
      log.userId === userId && 
      log.timestamp >= cutoffDate
    );
  }

  async getProviderStats(days: number = 7): Promise<Record<string, any>> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    const recentLogs = this.logs.filter(log => log.timestamp >= cutoffDate);
    
    const stats: Record<string, any> = {};
    
    for (const log of recentLogs) {
      if (!stats[log.provider]) {
        stats[log.provider] = {
          requests: 0,
          tokens: 0,
          cost: 0,
          latencies: [],
          errors: 0
        };
      }
      
      const providerStats = stats[log.provider];
      providerStats.requests++;
      providerStats.tokens += log.tokensUsed;
      providerStats.cost += log.cost;
      providerStats.latencies.push(log.latency);
      
      if (!log.success) {
        providerStats.errors++;
      }
    }
    
    // Calculate averages and success rates
    for (const provider in stats) {
      const providerStats = stats[provider];
      providerStats.avgLatency = providerStats.latencies.reduce((a: number, b: number) => a + b, 0) / providerStats.latencies.length;
      providerStats.successRate = ((providerStats.requests - providerStats.errors) / providerStats.requests) * 100;
      delete providerStats.latencies; // Remove raw latencies from response
    }
    
    return stats;
  }

  async getRecentErrors(limit: number = 10): Promise<ConsumptionLog[]> {
    return this.logs
      .filter(log => !log.success)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  private async updateDailySummary(log: ConsumptionLog): Promise<void> {
    const dateKey = log.timestamp.toISOString().split('T')[0];
    
    let summary = this.dailySummaries.get(dateKey);
    if (!summary) {
      summary = {
        date: dateKey,
        totalRequests: 0,
        totalTokens: 0,
        totalCost: 0,
        avgLatency: 0,
        successRate: 0,
        providerBreakdown: {},
        topUsers: []
      };
      this.dailySummaries.set(dateKey, summary);
    }
    
    // Update totals
    summary.totalRequests++;
    summary.totalTokens += log.tokensUsed;
    summary.totalCost += log.cost;
    
    // Update provider breakdown
    if (!summary.providerBreakdown[log.provider]) {
      summary.providerBreakdown[log.provider] = {
        requests: 0,
        tokens: 0,
        cost: 0,
        successRate: 0
      };
    }
    
    const providerStats = summary.providerBreakdown[log.provider];
    providerStats.requests++;
    providerStats.tokens += log.tokensUsed;
    providerStats.cost += log.cost;
    
    // Recalculate averages (simplified for demo)
    const allLogsToday = this.logs.filter(l => 
      l.timestamp.toISOString().split('T')[0] === dateKey
    );
    
    summary.avgLatency = allLogsToday.reduce((sum, l) => sum + l.latency, 0) / allLogsToday.length;
    summary.successRate = (allLogsToday.filter(l => l.success).length / allLogsToday.length) * 100;
    
    // Update provider success rates
    for (const provider in summary.providerBreakdown) {
      const providerLogs = allLogsToday.filter(l => l.provider === provider);
      const successfulLogs = providerLogs.filter(l => l.success);
      summary.providerBreakdown[provider].successRate = (successfulLogs.length / providerLogs.length) * 100;
    }
  }

  private generateLogId(): string {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Development helper methods
  getTotalLogs(): number {
    return this.logs.length;
  }

  clearLogs(): void {
    this.logs = [];
    this.dailySummaries.clear();
  }
}