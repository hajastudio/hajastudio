import { db } from '../db';
import { 
  monitoring, 
  techTrends, 
  notifications, 
  users,
  chats,
  transactions 
} from '@shared/schema';
import { eq, gte, lte, desc, asc, sum, count, avg } from 'drizzle-orm';
import { sql } from 'drizzle-orm';

export interface TokenConsumption {
  userId: string;
  tokensUsed: number;
  tokensRemaining: number;
  projectedDays: number;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface ProviderMetrics {
  providerId: string;
  averageLatency: number;
  errorRate: number;
  totalRequests: number;
  successRate: number;
  fallbackCount: number;
}

export interface PlatformStatus {
  isHealthy: boolean;
  totalUsers: number;
  activeChats: number;
  tokensConsumedToday: number;
  revenue24h: number;
  topModels: Array<{ model: string; usage: number }>;
}

export interface TechTrend {
  id: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  category: string;
  source: string;
  detectedAt: Date;
  relevanceScore: number;
}

export interface Alert {
  type: 'token_low' | 'api_failure' | 'trend_detected' | 'revenue_spike';
  severity: 'critical' | 'warning' | 'info';
  message: string;
  userId?: string;
  metadata?: Record<string, any>;
}

export class HVCCore {
  private static instance: HVCCore;
  private techScanInterval?: NodeJS.Timeout;
  private monitoringInterval?: NodeJS.Timeout;

  private constructor() {
    this.initializeMonitoring();
    this.initializeTechScan();
  }

  public static getInstance(): HVCCore {
    if (!HVCCore.instance) {
      HVCCore.instance = new HVCCore();
    }
    return HVCCore.instance;
  }

  // === TOKEN MANAGEMENT ===
  
  async analyzeTokenConsumption(): Promise<TokenConsumption[]> {
    try {
      // Get users with their recent token usage
      const usersWithUsage = await db
        .select({
          userId: users.id,
          credits: users.credits,
          maxCredits: users.maxCredits,
          plan: users.plan
        })
        .from(users)
        .where(gte(users.credits, 0));

      const consumptionAnalysis: TokenConsumption[] = [];

      for (const user of usersWithUsage) {
        // Calculate daily usage from last 7 days
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

        const recentUsage = await db
          .select({ totalTokens: sum(chats.tokensUsed) })
          .from(chats)
          .where(
            gte(chats.createdAt, sevenDaysAgo)
          );

        const dailyAverage = recentUsage[0]?.totalTokens 
          ? Number(recentUsage[0].totalTokens) / 7 
          : 0;

        const tokensRemaining = user.credits || 0;
        const projectedDays = dailyAverage > 0 
          ? Math.floor(tokensRemaining / dailyAverage) 
          : 999;

        let riskLevel: 'low' | 'medium' | 'high' = 'low';
        if (projectedDays < 3) riskLevel = 'high';
        else if (projectedDays < 7) riskLevel = 'medium';

        consumptionAnalysis.push({
          userId: user.userId,
          tokensUsed: Math.floor(dailyAverage),
          tokensRemaining,
          projectedDays,
          riskLevel
        });
      }

      // Log the analysis
      await this.logMetric('token_analysis', {
        totalUsers: consumptionAnalysis.length,
        highRiskUsers: consumptionAnalysis.filter(u => u.riskLevel === 'high').length,
        averageTokensRemaining: consumptionAnalysis.reduce((acc, u) => acc + u.tokensRemaining, 0) / consumptionAnalysis.length
      });

      return consumptionAnalysis;
    } catch (error) {
      console.error('Error analyzing token consumption:', error);
      await this.logError('token_analysis_failed', error);
      return [];
    }
  }

  async suggestUpgrades(): Promise<Alert[]> {
    const consumption = await this.analyzeTokenConsumption();
    const alerts: Alert[] = [];

    for (const user of consumption) {
      if (user.riskLevel === 'high') {
        alerts.push({
          type: 'token_low',
          severity: 'critical',
          message: `Usuário ${user.userId} tem apenas ${user.tokensRemaining} tokens restantes (${user.projectedDays} dias)`,
          userId: user.userId,
          metadata: { projectedDays: user.projectedDays, tokensRemaining: user.tokensRemaining }
        });
      }
    }

    return alerts;
  }

  // === TECHNICAL MONITORING ===

  async getProviderMetrics(): Promise<ProviderMetrics[]> {
    try {
      const last24h = new Date();
      last24h.setHours(last24h.getHours() - 24);

      const metrics = await db
        .select({
          providerId: monitoring.metadata,
          avgLatency: avg(monitoring.responseTime),
          totalRequests: count(monitoring.id),
          errors: sum(sql`CASE WHEN ${monitoring.success} = false THEN 1 ELSE 0 END`)
        })
        .from(monitoring)
        .where(
          gte(monitoring.timestamp, last24h)
        )
        .groupBy(monitoring.metadata);

      return metrics.map(m => ({
        providerId: m.providerId || 'unknown',
        averageLatency: Number(m.avgLatency) || 0,
        totalRequests: Number(m.totalRequests) || 0,
        errorRate: m.errors ? Number(m.errors) / Number(m.totalRequests) * 100 : 0,
        successRate: m.errors ? (Number(m.totalRequests) - Number(m.errors)) / Number(m.totalRequests) * 100 : 100,
        fallbackCount: 0 // TODO: Calculate from provider fallback logs
      }));
    } catch (error) {
      console.error('Error getting provider metrics:', error);
      return [];
    }
  }

  async getPlatformStatus(): Promise<PlatformStatus> {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const [
        totalUsersResult,
        activeChatsResult,
        tokensConsumedResult,
        revenueResult
      ] = await Promise.all([
        db.select({ count: count() }).from(users),
        db.select({ count: count() }).from(chats).where(gte(chats.createdAt, today)),
        db.select({ total: sum(chats.tokensUsed) }).from(chats).where(gte(chats.createdAt, today)),
        db.select({ total: sum(transactions.amount) }).from(transactions).where(
          gte(transactions.createdAt, today)
        )
      ]);

      // Check system health
      const recentErrors = await db
        .select({ count: count() })
        .from(monitoring)
        .where(
          gte(monitoring.timestamp, new Date(Date.now() - 30 * 60 * 1000)) // Last 30 minutes
        );

      const isHealthy = Number(recentErrors[0]?.count || 0) < 10; // Less than 10 errors in 30 min

      return {
        isHealthy,
        totalUsers: Number(totalUsersResult[0]?.count || 0),
        activeChats: Number(activeChatsResult[0]?.count || 0),
        tokensConsumedToday: Number(tokensConsumedResult[0]?.total || 0),
        revenue24h: Number(revenueResult[0]?.total || 0),
        topModels: [] // TODO: Implement model usage tracking
      };
    } catch (error) {
      console.error('Error getting platform status:', error);
      return {
        isHealthy: false,
        totalUsers: 0,
        activeChats: 0,
        tokensConsumedToday: 0,
        revenue24h: 0,
        topModels: []
      };
    }
  }

  // === TECH SCAN ===

  async scanTechTrends(): Promise<TechTrend[]> {
    try {
      // Mock implementation - in production, this would use APIs like:
      // - GitHub trending AI repos
      // - HuggingFace model releases
      // - ArXiv papers
      // - AI news aggregators
      
      const trends: TechTrend[] = [
        {
          id: 'trend_' + Date.now(),
          title: 'GPT-5 Beta Released',
          description: 'OpenAI released GPT-5 beta with improved reasoning capabilities',
          impact: 'high',
          category: 'model_release',
          source: 'openai.com',
          detectedAt: new Date(),
          relevanceScore: 0.95
        }
      ];

      // Save trends to database
      for (const trend of trends) {
        await db.insert(techTrends).values({
          title: trend.title,
          description: trend.description,
          impact: trend.impact,
          category: trend.category,
          source: trend.source,
          relevanceScore: trend.relevanceScore,
          metadata: JSON.stringify({ detectedAt: trend.detectedAt })
        });
      }

      await this.logMetric('tech_scan_completed', {
        trendsFound: trends.length,
        highImpact: trends.filter(t => t.impact === 'high').length
      });

      return trends;
    } catch (error) {
      console.error('Error scanning tech trends:', error);
      await this.logError('tech_scan_failed', error);
      return [];
    }
  }

  // === NOTIFICATIONS ===

  async sendAlert(alert: Alert): Promise<void> {
    try {
      // Save notification to database
      await db.insert(notifications).values({
        type: alert.type,
        severity: alert.severity,
        message: alert.message,
        userId: alert.userId,
        metadata: JSON.stringify(alert.metadata || {}),
        isRead: false
      });

      // In production, implement actual notification sending:
      // - Email via SendGrid/SES
      // - WhatsApp via Twilio
      // - Discord webhook
      // - Slack webhook

      console.log(`[HVC Alert ${alert.severity.toUpperCase()}] ${alert.message}`);
    } catch (error) {
      console.error('Error sending alert:', error);
    }
  }

  // === LOGGING & METRICS ===

  async logMetric(eventType: string, data: Record<string, any>): Promise<void> {
    try {
      await db.insert(monitoring).values({
        eventType,
        success: true,
        responseTime: 0,
        metadata: JSON.stringify(data),
        timestamp: new Date()
      });
    } catch (error) {
      console.error('Error logging metric:', error);
    }
  }

  async logError(eventType: string, error: any): Promise<void> {
    try {
      await db.insert(monitoring).values({
        eventType,
        success: false,
        responseTime: 0,
        errorMessage: error?.message || String(error),
        metadata: JSON.stringify({ 
          stack: error?.stack,
          timestamp: new Date().toISOString()
        }),
        timestamp: new Date()
      });
    } catch (dbError) {
      console.error('Error logging error:', dbError);
    }
  }

  async logApiCall(
    providerId: string, 
    success: boolean, 
    responseTime: number, 
    error?: string
  ): Promise<void> {
    try {
      await db.insert(monitoring).values({
        eventType: 'api_call',
        success,
        responseTime,
        errorMessage: error,
        metadata: JSON.stringify({ providerId }),
        timestamp: new Date()
      });
    } catch (dbError) {
      console.error('Error logging API call:', dbError);
    }
  }

  // === INITIALIZATION ===

  private initializeMonitoring(): void {
    // Run monitoring checks every 5 minutes
    this.monitoringInterval = setInterval(async () => {
      try {
        // Check for token alerts
        const alerts = await this.suggestUpgrades();
        for (const alert of alerts) {
          await this.sendAlert(alert);
        }

        // Log platform status
        const status = await this.getPlatformStatus();
        await this.logMetric('platform_status', status);

      } catch (error) {
        console.error('Monitoring cycle error:', error);
      }
    }, 5 * 60 * 1000);
  }

  private initializeTechScan(): void {
    // Run tech scan daily at midnight
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    const msUntilMidnight = tomorrow.getTime() - now.getTime();

    setTimeout(() => {
      this.scanTechTrends();
      
      // Then run every 24 hours
      this.techScanInterval = setInterval(() => {
        this.scanTechTrends();
      }, 24 * 60 * 60 * 1000);
    }, msUntilMidnight);
  }

  // === PREDICTION ALGORITHMS ===

  async predictTokenConsumption(userId: string, days: number = 30): Promise<{
    predictedUsage: number;
    confidence: number;
    recommendation: string;
  }> {
    try {
      // Get historical usage for the user
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const historicalUsage = await db
        .select({
          date: sql<string>`DATE(${chats.createdAt})`,
          tokens: sum(chats.tokensUsed)
        })
        .from(chats)
        .where(
          gte(chats.createdAt, thirtyDaysAgo)
        )
        .groupBy(sql`DATE(${chats.createdAt})`)
        .orderBy(asc(sql`DATE(${chats.createdAt})`));

      if (historicalUsage.length < 7) {
        return {
          predictedUsage: 0,
          confidence: 0.1,
          recommendation: 'Insuficientes dados históricos para previsão precisa'
        };
      }

      // Simple linear regression for trend analysis
      const dailyUsage = historicalUsage.map(h => Number(h.tokens) || 0);
      const average = dailyUsage.reduce((a, b) => a + b, 0) / dailyUsage.length;
      
      // Calculate trend (simplified)
      const trend = (dailyUsage[dailyUsage.length - 1] - dailyUsage[0]) / dailyUsage.length;
      
      // Predict future usage
      const predictedDailyUsage = average + (trend * days);
      const predictedUsage = Math.max(0, predictedDailyUsage * days);
      
      // Calculate confidence based on usage consistency
      const variance = dailyUsage.reduce((acc, usage) => acc + Math.pow(usage - average, 2), 0) / dailyUsage.length;
      const confidence = Math.max(0.1, Math.min(0.9, 1 - (variance / (average * average))));

      let recommendation = 'Uso estável, continue monitorando';
      if (trend > average * 0.1) {
        recommendation = 'Crescimento detectado, considere upgrade';
      } else if (trend < -average * 0.1) {
        recommendation = 'Uso decrescente, talvez possa reduzir plano';
      }

      return {
        predictedUsage: Math.round(predictedUsage),
        confidence: Math.round(confidence * 100) / 100,
        recommendation
      };
    } catch (error) {
      console.error('Error predicting token consumption:', error);
      return {
        predictedUsage: 0,
        confidence: 0,
        recommendation: 'Erro na previsão, contacte suporte'
      };
    }
  }

  // === CLEANUP ===

  destroy(): void {
    if (this.techScanInterval) {
      clearInterval(this.techScanInterval);
    }
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
  }
}

// Export singleton instance
export const hvcCore = HVCCore.getInstance();