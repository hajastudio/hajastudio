import OpenAI from 'openai';
import { storage } from '../storage';
import type { Message } from '@shared/schema';

interface ChatRequest {
  userId: string;
  agentId: string;
  messages: Message[];
}

interface ChatResponse {
  success: boolean;
  message?: string;
  response?: string;
  tokensUsed?: number;
  creditsDeducted?: number;
  error?: string;
}

interface ModelConfig {
  name: string;
  costPerToken: number;
  maxTokens: number;
}

// Model configurations with credit costs
const MODEL_CONFIGS: Record<string, ModelConfig> = {
  'gpt-5': {
    name: 'gpt-4-turbo-preview', // Using GPT-4 as GPT-5 isn't available yet
    costPerToken: 0.1, // 0.1 credits per token
    maxTokens: 4000
  },
  'gpt-4': {
    name: 'gpt-4-turbo-preview',
    costPerToken: 0.08,
    maxTokens: 4000
  },
  'gpt-3.5': {
    name: 'gpt-3.5-turbo',
    costPerToken: 0.02,
    maxTokens: 4000
  }
};

class OrchestratorService {
  private openai: OpenAI | null = null;

  constructor() {
    // Initialize OpenAI client if API key is available
    if (process.env.OPENAI_API_KEY) {
      this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
    }
  }

  async processChat(request: ChatRequest): Promise<ChatResponse> {
    try {
      // 1. Validate user and check credits
      const user = await storage.getUser(request.userId);
      if (!user) {
        return {
          success: false,
          error: "User not found"
        };
      }

      // 2. Get agent configuration
      const agent = await storage.getAgent(request.agentId);
      if (!agent) {
        return {
          success: false,
          error: "Agent not found"
        };
      }

      if (!agent.active) {
        return {
          success: false,
          error: "Agent is currently inactive"
        };
      }

      // 3. Choose optimal model based on user credits and agent configuration
      const modelConfig = this.selectOptimalModel(user.credits || 0, agent.defaultModel || undefined);
      
      // 4. Check if user has enough credits
      const estimatedTokens = this.estimateTokenUsage(request.messages);
      const estimatedCost = Math.ceil(estimatedTokens * modelConfig.costPerToken);
      const userCredits = user.credits ?? 0;
      
      if (userCredits < estimatedCost) {
        return {
          success: false,
          error: `Insufficient credits. Need ${estimatedCost} credits, have ${userCredits}.`
        };
      }

      // 5. Call AI provider
      const aiResponse = await this.callAIProvider(
        modelConfig,
        agent.promptBase,
        request.messages
      );

      if (!aiResponse.success) {
        return aiResponse;
      }

      // 6. Calculate actual token usage and credit cost
      const actualTokens = aiResponse.tokensUsed || estimatedTokens;
      const actualCost = Math.ceil(actualTokens * modelConfig.costPerToken);

      // 7. Deduct credits from user
      await storage.deductCredits(request.userId, actualCost);

      // 8. Save chat to database
      const updatedMessages = [
        ...request.messages,
        {
          role: 'assistant' as const,
          content: aiResponse.response!,
          timestamp: new Date().toISOString(),
          tokensUsed: actualTokens
        }
      ];

      await storage.createChat({
        userId: request.userId,
        agentId: request.agentId,
        title: this.generateChatTitle(request.messages[0]?.content || "Chat"),
        messages: updatedMessages,
        modelUsed: modelConfig.name,
        tokensUsed: actualTokens
      });

      return {
        success: true,
        response: aiResponse.response,
        tokensUsed: actualTokens,
        creditsDeducted: actualCost,
        message: "Chat processed successfully"
      };

    } catch (error) {
      console.error("Error in orchestrator:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Internal server error"
      };
    }
  }

  private selectOptimalModel(userCredits: number, preferredModel: string = 'gpt-5'): ModelConfig {
    const preferred = MODEL_CONFIGS[preferredModel];
    if (preferred && userCredits >= 10) { // Minimum 10 credits for premium models
      return preferred;
    }

    // Fallback to cheaper models based on available credits
    if (userCredits >= 5) {
      return MODEL_CONFIGS['gpt-4'];
    }
    
    return MODEL_CONFIGS['gpt-3.5'];
  }

  private estimateTokenUsage(messages: Message[]): number {
    // Simple estimation: ~4 characters per token
    const totalChars = messages.reduce((sum, msg) => sum + msg.content.length, 0);
    return Math.ceil(totalChars / 4) + 100; // Add buffer for system prompt
  }

  private async callAIProvider(
    modelConfig: ModelConfig,
    systemPrompt: string,
    messages: Message[]
  ): Promise<ChatResponse> {
    try {
      // If OpenAI is not configured, return mock response
      if (!this.openai) {
        const mockResponse = this.generateMockResponse(messages);
        return {
          success: true,
          response: mockResponse,
          tokensUsed: 150
        };
      }

      // Prepare messages for OpenAI
      const openaiMessages = [
        { role: 'system' as const, content: systemPrompt },
        ...messages.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      ];

      const completion = await this.openai.chat.completions.create({
        model: modelConfig.name,
        messages: openaiMessages,
        max_tokens: modelConfig.maxTokens,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content;
      const tokensUsed = completion.usage?.total_tokens || 0;

      if (!response) {
        return {
          success: false,
          error: "No response from AI provider"
        };
      }

      return {
        success: true,
        response,
        tokensUsed
      };

    } catch (error) {
      console.error("Error calling AI provider:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "AI provider error"
      };
    }
  }

  private generateMockResponse(messages: Message[]): string {
    const lastMessage = messages[messages.length - 1]?.content || "";
    
    // Simple mock responses based on content
    if (lastMessage.toLowerCase().includes("viral")) {
      return "🚀 Para criar conteúdo viral, foque em: 1) Hook poderoso nos primeiros 3 segundos, 2) Emoção genuína (surpresa, alegria, curiosidade), 3) Timing perfeito com tendências atuais, 4) Call-to-action claro. Exemplo: 'Você não vai acreditar no que aconteceu quando testei IA com meu gato...' + mostrar reação autêntica.";
    }
    
    if (lastMessage.toLowerCase().includes("roteiro")) {
      return "🎬 Estrutura de roteiro eficaz: 1) ABERTURA (gancho em 5s), 2) DESENVOLVIMENTO (problema/conflito), 3) CLÍMAX (ponto de virada), 4) RESOLUÇÃO (satisfação). Use a regra 15-70-15: 15% setup, 70% desenvolvimento, 15% conclusão. Para vídeos curtos: problema → agitação → solução → CTA.";
    }

    return `Olá! Recebi sua mensagem: "${lastMessage}". Esta é uma resposta de demonstração do sistema HVC Core. O orquestrador está funcionando perfeitamente! 🤖✨`;
  }

  private generateChatTitle(firstMessage: string): string {
    const truncated = firstMessage.substring(0, 50);
    return truncated.length === firstMessage.length ? truncated : `${truncated}...`;
  }
}

export const orchestrator = new OrchestratorService();