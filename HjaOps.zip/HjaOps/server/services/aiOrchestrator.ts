import { 
  GroqProvider, 
  HuggingFaceProvider, 
  ReplitProvider, 
  AIProvider, 
  AIResponse, 
  ChatMessage 
} from './aiProviders';

export interface OrchestrationConfig {
  maxRetries: number;
  fallbackChain: string[];
  timeoutMs: number;
}

export interface OrchestrationResult {
  success: boolean;
  response?: AIResponse;
  provider: string;
  model: string;
  tokensUsed: number;
  cost: number;
  latency: number;
  error?: string;
  fallbacksUsed: string[];
}

export class AIOrchestrator {
  private providers: Map<string, AIProvider>;
  private config: OrchestrationConfig;

  constructor(config: OrchestrationConfig = {
    maxRetries: 3,
    fallbackChain: ['groq', 'huggingface', 'replit'],
    timeoutMs: 30000
  }) {
    this.config = config;
    this.providers = new Map();
    
    // Initialize providers
    this.providers.set('groq', new GroqProvider());
    this.providers.set('huggingface', new HuggingFaceProvider());
    this.providers.set('replit', new ReplitProvider());
  }

  async orchestrate(
    messages: ChatMessage[], 
    agentId: string,
    preferredModel?: string
  ): Promise<OrchestrationResult> {
    const startTime = Date.now();
    const fallbacksUsed: string[] = [];
    
    for (const providerName of this.config.fallbackChain) {
      const provider = this.providers.get(providerName);
      if (!provider) continue;

      try {
        console.log(`[AIOrchestrator] Trying provider: ${providerName}`);
        
        const response = await Promise.race([
          provider.chat(messages, agentId, preferredModel),
          this.createTimeoutPromise()
        ]);

        const latency = Date.now() - startTime;
        
        return {
          success: true,
          response,
          provider: providerName,
          model: response.model,
          tokensUsed: response.tokensUsed,
          cost: this.calculateCost(response.tokensUsed, providerName),
          latency,
          fallbacksUsed
        };

      } catch (error) {
        console.error(`[AIOrchestrator] ${providerName} failed:`, error);
        fallbacksUsed.push(providerName);
        
        // Continue to next provider in fallback chain
        continue;
      }
    }

    // All providers failed
    const latency = Date.now() - startTime;
    return {
      success: false,
      provider: 'none',
      model: 'none',
      tokensUsed: 0,
      cost: 0,
      latency,
      error: 'All AI providers failed',
      fallbacksUsed
    };
  }

  private createTimeoutPromise(): Promise<never> {
    return new Promise((_, reject) => {
      setTimeout(() => {
        reject(new Error(`Request timeout after ${this.config.timeoutMs}ms`));
      }, this.config.timeoutMs);
    });
  }

  private calculateCost(tokens: number, provider: string): number {
    // Cost per 1000 tokens (mock pricing)
    const pricing: Record<string, number> = {
      'groq': 0.10,        // $0.10 per 1K tokens
      'huggingface': 0.05, // $0.05 per 1K tokens  
      'replit': 0.08       // $0.08 per 1K tokens
    };

    const pricePerK = pricing[provider] || 0.10;
    return (tokens / 1000) * pricePerK;
  }

  getProviderStatus(): Record<string, boolean> {
    const status: Record<string, boolean> = {};
    
    for (const [name, provider] of this.providers) {
      status[name] = provider.isHealthy();
    }
    
    return status;
  }
}