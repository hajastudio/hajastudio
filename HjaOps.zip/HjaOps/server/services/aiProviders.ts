export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp?: number;
}

export interface AIResponse {
  content: string;
  model: string;
  tokensUsed: number;
  finishReason: string;
  metadata?: Record<string, any>;
}

export abstract class AIProvider {
  protected healthy: boolean = true;
  protected lastError?: Error;

  abstract chat(
    messages: ChatMessage[], 
    agentId: string, 
    preferredModel?: string
  ): Promise<AIResponse>;

  isHealthy(): boolean {
    return this.healthy;
  }

  getLastError(): Error | undefined {
    return this.lastError;
  }
}

export class GroqProvider extends AIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://api.groq.com/openai/v1';

  constructor() {
    super();
    this.apiKey = process.env.GROQ_API_KEY || '';
    
    if (!this.apiKey) {
      console.warn('[GroqProvider] API key not found');
      this.healthy = false;
    }
  }

  async chat(
    messages: ChatMessage[], 
    agentId: string, 
    preferredModel?: string
  ): Promise<AIResponse> {
    if (!this.healthy) {
      throw new Error('Groq provider is not healthy');
    }

    const model = preferredModel || 'llama-3.1-70b-versatile';
    
    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          messages: messages.map(msg => ({
            role: msg.role,
            content: msg.content
          })),
          max_tokens: 2048,
          temperature: 0.7,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`Groq API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data.choices || data.choices.length === 0) {
        throw new Error('No response from Groq API');
      }

      const choice = data.choices[0];
      
      this.healthy = true;
      return {
        content: choice.message.content,
        model: data.model,
        tokensUsed: data.usage?.total_tokens || 0,
        finishReason: choice.finish_reason,
        metadata: {
          promptTokens: data.usage?.prompt_tokens,
          completionTokens: data.usage?.completion_tokens
        }
      };

    } catch (error) {
      this.lastError = error as Error;
      this.healthy = false;
      throw error;
    }
  }
}

export class HuggingFaceProvider extends AIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://api-inference.huggingface.co/models';

  constructor() {
    super();
    this.apiKey = process.env.HF_API_KEY || '';
    
    if (!this.apiKey) {
      console.warn('[HuggingFaceProvider] API key not found');
      this.healthy = false;
    }
  }

  async chat(
    messages: ChatMessage[], 
    agentId: string, 
    preferredModel?: string
  ): Promise<AIResponse> {
    if (!this.healthy) {
      throw new Error('HuggingFace provider is not healthy');
    }

    const model = preferredModel || 'mistralai/Mistral-7B-Instruct-v0.3';
    
    // Convert chat messages to single prompt for HF
    const prompt = this.formatMessagesForHF(messages);
    
    try {
      const response = await fetch(`${this.baseUrl}/${model}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          inputs: prompt,
          parameters: {
            max_new_tokens: 1024,
            temperature: 0.7,
            return_full_text: false
          },
          options: {
            wait_for_model: true
          }
        })
      });

      if (!response.ok) {
        throw new Error(`HuggingFace API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data || !Array.isArray(data) || data.length === 0) {
        throw new Error('Invalid response from HuggingFace API');
      }

      const result = data[0];
      const content = result.generated_text || '';
      
      this.healthy = true;
      return {
        content: content.trim(),
        model,
        tokensUsed: this.estimateTokens(prompt + content),
        finishReason: 'stop',
        metadata: {
          promptLength: prompt.length,
          responseLength: content.length
        }
      };

    } catch (error) {
      this.lastError = error as Error;
      this.healthy = false;
      throw error;
    }
  }

  private formatMessagesForHF(messages: ChatMessage[]): string {
    return messages
      .map(msg => `${msg.role.toUpperCase()}: ${msg.content}`)
      .join('\n') + '\nASSISTANT:';
  }

  private estimateTokens(text: string): number {
    // Rough estimation: ~4 characters per token
    return Math.ceil(text.length / 4);
  }
}

export class ReplitProvider extends AIProvider {
  private apiKey: string;
  private baseUrl: string = 'https://api.replit.com/v1';

  constructor() {
    super();
    this.apiKey = process.env.REPLIT_API_KEY || '';
    
    if (!this.apiKey) {
      console.warn('[ReplitProvider] API key not found');
      this.healthy = false;
    }
  }

  async chat(
    messages: ChatMessage[], 
    agentId: string, 
    preferredModel?: string
  ): Promise<AIResponse> {
    if (!this.healthy) {
      throw new Error('Replit provider is not healthy');
    }

    const model = preferredModel || 'replit-code-v1_5-3b';
    
    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model,
          messages: messages.map(msg => ({
            role: msg.role,
            content: msg.content
          })),
          max_tokens: 1024,
          temperature: 0.7,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`Replit API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data.choices || data.choices.length === 0) {
        throw new Error('No response from Replit API');
      }

      const choice = data.choices[0];
      
      this.healthy = true;
      return {
        content: choice.message.content,
        model: data.model,
        tokensUsed: data.usage?.total_tokens || 0,
        finishReason: choice.finish_reason,
        metadata: {
          promptTokens: data.usage?.prompt_tokens,
          completionTokens: data.usage?.completion_tokens
        }
      };

    } catch (error) {
      this.lastError = error as Error;
      this.healthy = false;
      throw error;
    }
  }
}