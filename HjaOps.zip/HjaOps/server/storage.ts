import {
  users,
  agents,
  chats,
  transactions,
  plans,
  affiliateProducts,
  affiliateClicks,
  affiliateImpressions,
  affiliateMetrics,
  affiliateUserLimits,
  posts,
  postReads,
  capsules,
  reactions,
  comments,
  type User,
  type UpsertUser,
  type Agent,
  type InsertAgent,
  type Chat,
  type InsertChat,
  type Transaction,
  type InsertTransaction,
  type Plan,
  type InsertPlan,
  type AffiliateProduct,
  type InsertAffiliateProduct,
  type AffiliateClick,
  type InsertAffiliateClick,
  type AffiliateImpression,
  type InsertAffiliateImpression,
  type AffiliateMetrics,
  type InsertAffiliateMetrics,
  type AffiliateUserLimit,
  type InsertAffiliateUserLimit,
  type Post,
  type InsertPost,
  type PostRead,
  type InsertPostRead,
  type Capsule,
  type InsertCapsule,
  type Reaction,
  type InsertReaction,
  type Comment,
  type InsertComment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, count, sum, gte } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Agent operations
  getAgents(): Promise<Agent[]>;
  getActiveAgents(): Promise<Agent[]>;
  getAgent(id: string): Promise<Agent | undefined>;
  createAgent(agent: InsertAgent): Promise<Agent>;
  updateAgent(id: string, agent: Partial<InsertAgent>): Promise<Agent>;
  deleteAgent(id: string): Promise<void>;
  
  // Chat operations
  getChats(userId: string): Promise<Chat[]>;
  getChat(id: string): Promise<Chat | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  updateChat(id: string, chat: Partial<InsertChat>): Promise<Chat>;
  
  // Transaction operations
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction>;
  
  // Credit operations
  updateUserCredits(userId: string, credits: number): Promise<User>;
  deductCredits(userId: string, amount: number): Promise<User>;
  
  // Plan operations
  getPlans(): Promise<Plan[]>;
  getActivePlans(): Promise<Plan[]>;
  getPlan(id: string): Promise<Plan | undefined>;
  createPlan(plan: InsertPlan): Promise<Plan>;
  updatePlan(id: string, plan: Partial<InsertPlan>): Promise<Plan>;
  
  // Affiliate Product operations
  getAffiliateProducts(): Promise<AffiliateProduct[]>;
  getActiveAffiliateProducts(): Promise<AffiliateProduct[]>;
  getFeaturedAffiliateProducts(): Promise<AffiliateProduct[]>;
  getAffiliateProductsByCategory(category: string): Promise<AffiliateProduct[]>;
  getAffiliateProduct(id: string): Promise<AffiliateProduct | undefined>;
  createAffiliateProduct(product: InsertAffiliateProduct): Promise<AffiliateProduct>;
  updateAffiliateProduct(id: string, product: Partial<InsertAffiliateProduct>): Promise<AffiliateProduct>;
  deleteAffiliateProduct(id: string): Promise<void>;
  
  // Affiliate Metrics operations
  createAffiliateMetric(metric: InsertAffiliateMetrics): Promise<AffiliateMetrics>;
  getAffiliateMetrics(productId?: string): Promise<AffiliateMetrics[]>;
  getAffiliateMetricsSummary(): Promise<any>;
  getTopClickedProducts(limit?: number): Promise<any[]>;
  
  // Blog Post operations
  getPosts(): Promise<Post[]>;
  getPublishedPosts(): Promise<Post[]>;
  getPostsByAuthor(authorId: string): Promise<Post[]>;
  getPostBySlug(slug: string): Promise<Post | undefined>;
  getPost(id: string): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: string, post: Partial<InsertPost>): Promise<Post>;
  deletePost(id: string): Promise<void>;
  incrementPostViews(postId: string): Promise<void>;
  
  // Post Read operations
  createPostRead(read: InsertPostRead): Promise<PostRead>;
  getPostReads(postId?: string): Promise<PostRead[]>;
  getUserPostReads(userId: string): Promise<PostRead[]>;
  getPostReadStats(): Promise<any>;
  hasUserReadPost(userId: string, postId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  // Agent operations
  async getAgents(): Promise<Agent[]> {
    return await db.select().from(agents).orderBy(desc(agents.createdAt));
  }
  
  async getActiveAgents(): Promise<Agent[]> {
    return await db.select().from(agents).where(eq(agents.active, true)).orderBy(desc(agents.createdAt));
  }
  
  async getAgent(id: string): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }
  
  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [newAgent] = await db.insert(agents).values(agent).returning();
    return newAgent;
  }
  
  async updateAgent(id: string, agent: Partial<InsertAgent>): Promise<Agent> {
    const [updatedAgent] = await db
      .update(agents)
      .set({ ...agent, updatedAt: new Date() })
      .where(eq(agents.id, id))
      .returning();
    return updatedAgent;
  }
  
  async deleteAgent(id: string): Promise<void> {
    await db.delete(agents).where(eq(agents.id, id));
  }
  
  // Chat operations
  async getChats(userId: string): Promise<Chat[]> {
    return await db.select().from(chats).where(eq(chats.userId, userId)).orderBy(desc(chats.updatedAt));
  }
  
  async getChat(id: string): Promise<Chat | undefined> {
    const [chat] = await db.select().from(chats).where(eq(chats.id, id));
    return chat;
  }
  
  async createChat(chat: InsertChat): Promise<Chat> {
    const [newChat] = await db.insert(chats).values(chat).returning();
    return newChat;
  }
  
  async updateChat(id: string, chat: Partial<InsertChat>): Promise<Chat> {
    const [updatedChat] = await db
      .update(chats)
      .set({ ...chat, updatedAt: new Date() })
      .where(eq(chats.id, id))
      .returning();
    return updatedChat;
  }
  
  // Transaction operations
  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(desc(transactions.createdAt));
  }
  
  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }
  
  async updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction> {
    const [updatedTransaction] = await db
      .update(transactions)
      .set(transaction)
      .where(eq(transactions.id, id))
      .returning();
    return updatedTransaction;
  }
  
  // Credit operations
  async updateUserCredits(userId: string, credits: number): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ credits, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }
  
  async deductCredits(userId: string, amount: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    const newCredits = Math.max(0, (user.credits || 0) - amount);
    return await this.updateUserCredits(userId, newCredits);
  }
  
  // Plan operations
  async getPlans(): Promise<Plan[]> {
    return await db.select().from(plans).orderBy(desc(plans.createdAt));
  }
  
  async getActivePlans(): Promise<Plan[]> {
    return await db.select().from(plans).where(eq(plans.isActive, true)).orderBy(plans.price);
  }
  
  async getPlan(id: string): Promise<Plan | undefined> {
    const [plan] = await db.select().from(plans).where(eq(plans.id, id));
    return plan;
  }
  
  async createPlan(plan: InsertPlan): Promise<Plan> {
    const [newPlan] = await db.insert(plans).values(plan).returning();
    return newPlan;
  }
  
  async updatePlan(id: string, plan: Partial<InsertPlan>): Promise<Plan> {
    const [updatedPlan] = await db
      .update(plans)
      .set(plan)
      .where(eq(plans.id, id))
      .returning();
    return updatedPlan;
  }
  
  // Affiliate Product operations
  async getAffiliateProducts(): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts).orderBy(desc(affiliateProducts.createdAt));
  }
  
  async getActiveAffiliateProducts(): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts)
      .where(eq(affiliateProducts.active, true))
      .orderBy(desc(affiliateProducts.featured), desc(affiliateProducts.createdAt));
  }
  
  async getFeaturedAffiliateProducts(): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts)
      .where(and(eq(affiliateProducts.active, true), eq(affiliateProducts.featured, true)))
      .orderBy(desc(affiliateProducts.createdAt));
  }
  
  async getAffiliateProductsByCategory(category: string): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts)
      .where(and(eq(affiliateProducts.active, true), eq(affiliateProducts.category, category)))
      .orderBy(desc(affiliateProducts.featured), desc(affiliateProducts.createdAt));
  }
  
  async getAffiliateProduct(id: string): Promise<AffiliateProduct | undefined> {
    const [product] = await db.select().from(affiliateProducts).where(eq(affiliateProducts.id, id));
    return product;
  }
  
  async createAffiliateProduct(product: InsertAffiliateProduct): Promise<AffiliateProduct> {
    const [newProduct] = await db.insert(affiliateProducts).values(product).returning();
    return newProduct;
  }
  
  async updateAffiliateProduct(id: string, product: Partial<InsertAffiliateProduct>): Promise<AffiliateProduct> {
    const [updatedProduct] = await db
      .update(affiliateProducts)
      .set({ ...product, updatedAt: new Date() })
      .where(eq(affiliateProducts.id, id))
      .returning();
    return updatedProduct;
  }
  
  async deleteAffiliateProduct(id: string): Promise<void> {
    await db.delete(affiliateProducts).where(eq(affiliateProducts.id, id));
  }
  
  // Affiliate Metrics operations
  async createAffiliateMetric(metric: InsertAffiliateMetrics): Promise<AffiliateMetrics> {
    const [newMetric] = await db.insert(affiliateMetrics).values(metric).returning();
    return newMetric;
  }
  
  async getAffiliateMetrics(productId?: string): Promise<AffiliateMetrics[]> {
    const query = db.select().from(affiliateMetrics);
    if (productId) {
      return await query.where(eq(affiliateMetrics.productId, productId)).orderBy(desc(affiliateMetrics.createdAt));
    }
    return await query.orderBy(desc(affiliateMetrics.createdAt));
  }
  
  async getAffiliateMetricsSummary(): Promise<any> {
    // Get total clicks, views, and conversions
    const totalMetrics = await db
      .select({
        eventType: affiliateMetrics.eventType,
        count: sql<number>`count(*)`.as('count')
      })
      .from(affiliateMetrics)
      .groupBy(affiliateMetrics.eventType);
    
    return totalMetrics.reduce((acc, curr) => {
      acc[curr.eventType] = curr.count;
      return acc;
    }, {} as Record<string, number>);
  }
  
  async getTopClickedProducts(limit = 10): Promise<any[]> {
    return await db
      .select({
        productId: affiliateMetrics.productId,
        title: affiliateProducts.title,
        imageUrl: affiliateProducts.imageUrl,
        category: affiliateProducts.category,
        clicks: sql<number>`count(*)`.as('clicks')
      })
      .from(affiliateMetrics)
      .innerJoin(affiliateProducts, eq(affiliateMetrics.productId, affiliateProducts.id))
      .where(eq(affiliateMetrics.eventType, 'click'))
      .groupBy(affiliateMetrics.productId, affiliateProducts.title, affiliateProducts.imageUrl, affiliateProducts.category)
      .orderBy(desc(sql`count(*)`))
      .limit(limit);
  }
  
  // Blog Post operations
  async getPosts(): Promise<Post[]> {
    return await db.select().from(posts).orderBy(desc(posts.createdAt));
  }
  
  async getPublishedPosts(): Promise<Post[]> {
    return await db.select().from(posts)
      .where(eq(posts.published, true))
      .orderBy(desc(posts.publishedAt));
  }
  
  async getPostsByAuthor(authorId: string): Promise<Post[]> {
    return await db.select().from(posts)
      .where(eq(posts.authorId, authorId))
      .orderBy(desc(posts.createdAt));
  }
  
  async getPostBySlug(slug: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.slug, slug));
    return post;
  }
  
  async getPost(id: string): Promise<Post | undefined> {
    const [post] = await db.select().from(posts).where(eq(posts.id, id));
    return post;
  }
  
  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db.insert(posts).values(post).returning();
    return newPost;
  }
  
  async updatePost(id: string, post: Partial<InsertPost>): Promise<Post> {
    const [updatedPost] = await db
      .update(posts)
      .set({ ...post, updatedAt: new Date() })
      .where(eq(posts.id, id))
      .returning();
    return updatedPost;
  }
  
  async deletePost(id: string): Promise<void> {
    await db.delete(posts).where(eq(posts.id, id));
  }
  
  async incrementPostViews(postId: string): Promise<void> {
    await db
      .update(posts)
      .set({ views: sql`${posts.views} + 1` })
      .where(eq(posts.id, postId));
  }
  
  // Post Read operations
  async createPostRead(read: InsertPostRead): Promise<PostRead> {
    const [newRead] = await db.insert(postReads).values(read).returning();
    return newRead;
  }
  
  async getPostReads(postId?: string): Promise<PostRead[]> {
    const query = db.select().from(postReads);
    if (postId) {
      return await query.where(eq(postReads.postId, postId)).orderBy(desc(postReads.createdAt));
    }
    return await query.orderBy(desc(postReads.createdAt));
  }
  
  async getUserPostReads(userId: string): Promise<PostRead[]> {
    return await db.select().from(postReads)
      .where(eq(postReads.userId, userId))
      .orderBy(desc(postReads.createdAt));
  }
  
  async getPostReadStats(): Promise<any> {
    const stats = await db
      .select({
        accessType: postReads.accessType,
        count: sql<number>`count(*)`.as('count'),
        totalCredits: sql<number>`sum(${postReads.creditsUsed})`.as('totalCredits')
      })
      .from(postReads)
      .groupBy(postReads.accessType);
    
    return stats.reduce((acc, curr) => {
      acc[curr.accessType] = {
        count: curr.count,
        totalCredits: curr.totalCredits || 0
      };
      return acc;
    }, {} as Record<string, { count: number; totalCredits: number }>);
  }
  
  async hasUserReadPost(userId: string, postId: string): Promise<boolean> {
    const [read] = await db.select().from(postReads)
      .where(and(eq(postReads.userId, userId), eq(postReads.postId, postId)))
      .limit(1);
    return !!read;
  }

  // Gamification: Track and award tokens for affiliate clicks (1 per product per day)
  async canEarnTokensForProduct(userId: string, productId: string): Promise<boolean> {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    const [existing] = await db.select().from(affiliateUserLimits)
      .where(and(
        eq(affiliateUserLimits.userId, userId),
        eq(affiliateUserLimits.productId, productId),
        eq(affiliateUserLimits.date, today)
      ));
    
    return !existing || existing.tokensEarnedToday === 0;
  }

  async awardTokensForAffiliateClick(userId: string, productId: string, tokensToAward: number = 1): Promise<boolean> {
    const today = new Date().toISOString().split('T')[0];
    
    // Check if user can still earn tokens for this product today
    const canEarn = await this.canEarnTokensForProduct(userId, productId);
    if (!canEarn) {
      return false;
    }

    await db.transaction(async (tx) => {
      // Update or create user limit record
      const [existing] = await tx.select().from(affiliateUserLimits)
        .where(and(
          eq(affiliateUserLimits.userId, userId),
          eq(affiliateUserLimits.productId, productId),
          eq(affiliateUserLimits.date, today)
        ));

      if (existing) {
        await tx.update(affiliateUserLimits)
          .set({
            clicksToday: (existing.clicksToday || 0) + 1,
            tokensEarnedToday: tokensToAward,
            updatedAt: new Date()
          })
          .where(eq(affiliateUserLimits.id, existing.id));
      } else {
        await tx.insert(affiliateUserLimits).values({
          userId,
          productId,
          date: today,
          clicksToday: 1,
          tokensEarnedToday: tokensToAward
        });
      }

      // Award tokens to user
      await tx.update(users)
        .set({ 
          credits: sql`${users.credits} + ${tokensToAward}`,
          updatedAt: new Date()
        })
        .where(eq(users.id, userId));
    });

    return true;
  }

  async getAffiliateUserStats(userId: string): Promise<{ totalTokensEarned: number, clicksToday: number }> {
    const today = new Date().toISOString().split('T')[0];
    
    const todayStats = await db.select().from(affiliateUserLimits)
      .where(and(
        eq(affiliateUserLimits.userId, userId),
        eq(affiliateUserLimits.date, today)
      ));

    const totalTokensEarned = await db.select({
      total: sql<number>`sum(${affiliateUserLimits.tokensEarnedToday})`
    }).from(affiliateUserLimits)
      .where(eq(affiliateUserLimits.userId, userId));

    return {
      totalTokensEarned: totalTokensEarned[0]?.total || 0,
      clicksToday: todayStats.reduce((sum, stat) => sum + (stat.clicksToday || 0), 0)
    };
  }

  // Affiliate Products operations
  async getActiveAffiliateProducts(): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts).where(eq(affiliateProducts.active, true)).orderBy(desc(affiliateProducts.featured), desc(affiliateProducts.createdAt));
  }

  async getAffiliateProduct(id: string): Promise<AffiliateProduct | undefined> {
    const [product] = await db.select().from(affiliateProducts).where(eq(affiliateProducts.id, id));
    return product;
  }

  async createAffiliateProduct(productData: InsertAffiliateProduct): Promise<AffiliateProduct> {
    const [product] = await db.insert(affiliateProducts).values(productData).returning();
    return product;
  }

  async updateAffiliateProduct(id: string, productData: Partial<InsertAffiliateProduct>): Promise<AffiliateProduct> {
    const [product] = await db.update(affiliateProducts)
      .set({ ...productData, updatedAt: new Date() })
      .where(eq(affiliateProducts.id, id))
      .returning();
    return product;
  }

  async deleteAffiliateProduct(id: string): Promise<void> {
    await db.delete(affiliateProducts).where(eq(affiliateProducts.id, id));
  }

  async getAllAffiliateProducts(): Promise<AffiliateProduct[]> {
    return await db.select().from(affiliateProducts).orderBy(desc(affiliateProducts.createdAt));
  }

  async recordAffiliateClick(clickData: InsertAffiliateClick): Promise<AffiliateClick> {
    const [click] = await db.insert(affiliateClicks).values(clickData).returning();
    
    // Update product click count
    await db.update(affiliateProducts)
      .set({ clicks: sql`${affiliateProducts.clicks} + 1` })
      .where(eq(affiliateProducts.id, clickData.productId));
    
    return click;
  }

  async recordAffiliateImpression(impressionData: InsertAffiliateImpression): Promise<AffiliateImpression> {
    const [impression] = await db.insert(affiliateImpressions).values(impressionData).returning();
    
    // Update product impression count
    await db.update(affiliateProducts)
      .set({ impressions: sql`${affiliateProducts.impressions} + 1` })
      .where(eq(affiliateProducts.id, impressionData.productId));
    
    return impression;
  }

  async getAffiliateClicksByProduct(productId: string): Promise<AffiliateClick[]> {
    return await db.select().from(affiliateClicks).where(eq(affiliateClicks.productId, productId)).orderBy(desc(affiliateClicks.timestamp));
  }

  async getAffiliateMetrics(productId?: string) {
    if (productId) {
      // Metrics for specific product
      const [product] = await db.select().from(affiliateProducts).where(eq(affiliateProducts.id, productId));
      const clicksToday = await db.select({ count: count() })
        .from(affiliateClicks)
        .where(and(
          eq(affiliateClicks.productId, productId),
          gte(affiliateClicks.timestamp, new Date(Date.now() - 24 * 60 * 60 * 1000))
        ));
      
      return {
        product,
        totalClicks: product?.clicks || 0,
        totalImpressions: product?.impressions || 0,
        ctr: product && product.impressions > 0 ? ((product.clicks / product.impressions) * 100).toFixed(2) : 0,
        clicksToday: clicksToday[0]?.count || 0
      };
    } else {
      // Global metrics
      const totalProducts = await db.select({ count: count() }).from(affiliateProducts);
      const totalClicks = await db.select({ sum: sum(affiliateProducts.clicks) }).from(affiliateProducts);
      const totalImpressions = await db.select({ sum: sum(affiliateProducts.impressions) }).from(affiliateProducts);
      const topProducts = await db.select().from(affiliateProducts)
        .orderBy(desc(affiliateProducts.clicks))
        .limit(10);
      
      return {
        totalProducts: totalProducts[0]?.count || 0,
        totalClicks: totalClicks[0]?.sum || 0,
        totalImpressions: totalImpressions[0]?.sum || 0,
        globalCtr: totalImpressions[0]?.sum > 0 ? (((totalClicks[0]?.sum || 0) / (totalImpressions[0]?.sum || 1)) * 100).toFixed(2) : 0,
        topProducts
      };
    }
  }

  async checkDailyClickLimit(userId: string, productId: string): Promise<boolean> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const clicksToday = await db.select({ count: count() })
      .from(affiliateClicks)
      .where(and(
        eq(affiliateClicks.userId, userId),
        eq(affiliateClicks.productId, productId),
        gte(affiliateClicks.timestamp, today)
      ));
    
    return (clicksToday[0]?.count || 0) < 1; // Limit: 1 click per product per day
  }

  // CapS'ula operations
  async createCapsule(capsuleData: InsertCapsule): Promise<Capsule> {
    const [capsule] = await db.insert(capsules).values(capsuleData).returning();
    return capsule;
  }

  async getCapsules(limit: number = 20, offset: number = 0, sortBy: 'recent' | 'popular' = 'recent'): Promise<Capsule[]> {
    const orderBy = sortBy === 'popular' 
      ? [desc(capsules.reactionsCount), desc(capsules.createdAt)]
      : [desc(capsules.isPinned), desc(capsules.createdAt)];

    return await db.select({
      id: capsules.id,
      userId: capsules.userId,
      content: capsules.content,
      mediaUrl: capsules.mediaUrl,
      linkUrl: capsules.linkUrl,
      reactionsCount: capsules.reactionsCount,
      commentsCount: capsules.commentsCount,
      isPinned: capsules.isPinned,
      createdAt: capsules.createdAt,
      updatedAt: capsules.updatedAt,
      user: {
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
      }
    })
    .from(capsules)
    .leftJoin(users, eq(capsules.userId, users.id))
    .orderBy(...orderBy)
    .limit(limit)
    .offset(offset);
  }

  async getCapsule(id: string): Promise<Capsule | undefined> {
    const [capsule] = await db.select().from(capsules).where(eq(capsules.id, id));
    return capsule;
  }

  async addReaction(reactionData: InsertReaction): Promise<Reaction> {
    // Check if user already reacted with this type to this capsule
    const existingReaction = await db.select()
      .from(reactions)
      .where(and(
        eq(reactions.capsuleId, reactionData.capsuleId),
        eq(reactions.userId, reactionData.userId),
        eq(reactions.type, reactionData.type)
      ));

    if (existingReaction.length > 0) {
      // Remove existing reaction (toggle)
      await db.delete(reactions).where(eq(reactions.id, existingReaction[0].id));
      
      // Decrease reaction count
      await db.update(capsules)
        .set({ reactionsCount: sql`${capsules.reactionsCount} - 1` })
        .where(eq(capsules.id, reactionData.capsuleId));
      
      return existingReaction[0];
    } else {
      // Add new reaction
      const [reaction] = await db.insert(reactions).values(reactionData).returning();
      
      // Increase reaction count
      await db.update(capsules)
        .set({ reactionsCount: sql`${capsules.reactionsCount} + 1` })
        .where(eq(capsules.id, reactionData.capsuleId));
      
      return reaction;
    }
  }

  async addComment(commentData: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(commentData).returning();
    
    // Increase comment count
    await db.update(capsules)
      .set({ commentsCount: sql`${capsules.commentsCount} + 1` })
      .where(eq(capsules.id, commentData.capsuleId));
    
    return comment;
  }

  async getComments(capsuleId: string, limit: number = 20, offset: number = 0): Promise<Comment[]> {
    return await db.select({
      id: comments.id,
      capsuleId: comments.capsuleId,
      userId: comments.userId,
      text: comments.text,
      createdAt: comments.createdAt,
      updatedAt: comments.updatedAt,
      user: {
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
      }
    })
    .from(comments)
    .leftJoin(users, eq(comments.userId, users.id))
    .where(eq(comments.capsuleId, capsuleId))
    .orderBy(desc(comments.createdAt))
    .limit(limit)
    .offset(offset);
  }

  async getReactionsByUser(capsuleId: string, userId: string): Promise<Reaction[]> {
    return await db.select()
      .from(reactions)
      .where(and(
        eq(reactions.capsuleId, capsuleId),
        eq(reactions.userId, userId)
      ));
  }

  async togglePinCapsule(capsuleId: string, isPinned: boolean): Promise<Capsule> {
    const [capsule] = await db.update(capsules)
      .set({ isPinned, updatedAt: new Date() })
      .where(eq(capsules.id, capsuleId))
      .returning();
    return capsule;
  }

  async deleteCapsule(capsuleId: string): Promise<void> {
    await db.delete(capsules).where(eq(capsules.id, capsuleId));
  }
}

export const storage = new DatabaseStorage();
