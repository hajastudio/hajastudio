import { MercadoPagoConfig, Preference, Payment } from 'mercadopago';

// Initialize MercadoPago client
const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || 'TEST-ACCESS-TOKEN',
  options: {
    timeout: 5000,
    idempotencyKey: 'abc'
  }
});

const preference = new Preference(client);
const payment = new Payment(client);

export interface PaymentPreferenceData {
  userId: string;
  productType: 'credits' | 'plan';
  productId: string;
  title: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  credits: number;
  promoCode?: string;
  metadata?: Record<string, any>;
}

export interface PaymentResult {
  preferenceId: string;
  initPoint: string;
  sandboxInitPoint: string;
}

export interface WebhookData {
  id: string;
  live_mode: boolean;
  type: string;
  date_created: string;
  application_id: string;
  user_id: string;
  version: string;
  api_version: string;
  action: string;
  data: {
    id: string;
  };
}

export class MercadoPagoService {
  
  /**
   * Create a payment preference for Mercado Pago checkout
   */
  async createPaymentPreference(data: PaymentPreferenceData): Promise<PaymentResult> {
    try {
      const preferenceData = {
        items: [
          {
            id: data.productId,
            title: data.title,
            description: data.description,
            category_id: 'services',
            quantity: data.quantity,
            currency_id: 'BRL',
            unit_price: data.unitPrice
          }
        ],
        payer: {
          email: 'user@example.com' // Will be replaced with actual user email
        },
        payment_methods: {
          excluded_payment_methods: [],
          excluded_payment_types: [],
          installments: 12
        },
        back_urls: {
          success: `${process.env.BASE_URL}/payment/success`,
          failure: `${process.env.BASE_URL}/payment/failure`,
          pending: `${process.env.BASE_URL}/payment/pending`
        },
        auto_return: 'approved',
        notification_url: `${process.env.BASE_URL}/api/webhooks/mercadopago`,
        external_reference: `${data.userId}-${data.productId}-${Date.now()}`,
        expires: true,
        expiration_date_from: new Date().toISOString(),
        expiration_date_to: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
        metadata: {
          user_id: data.userId,
          product_type: data.productType,
          product_id: data.productId,
          credits: data.credits,
          promo_code: data.promoCode || null,
          ...data.metadata
        },
        additional_info: data.description,
        binary_mode: true
      };

      console.log('Creating MercadoPago preference:', {
        userId: data.userId,
        productId: data.productId,
        amount: data.totalAmount
      });

      const response = await preference.create({ body: preferenceData });
      
      if (!response.id) {
        throw new Error('Failed to create MercadoPago preference');
      }

      return {
        preferenceId: response.id,
        initPoint: response.init_point || '',
        sandboxInitPoint: response.sandbox_init_point || ''
      };
    } catch (error) {
      console.error('Error creating MercadoPago preference:', error);
      throw new Error(`MercadoPago preference creation failed: ${error.message}`);
    }
  }

  /**
   * Get payment details from MercadoPago
   */
  async getPaymentDetails(paymentId: string) {
    try {
      console.log('Fetching payment details for ID:', paymentId);
      
      const paymentData = await payment.get({ id: paymentId });
      
      return {
        id: paymentData.id,
        status: paymentData.status,
        status_detail: paymentData.status_detail,
        transaction_amount: paymentData.transaction_amount,
        currency_id: paymentData.currency_id,
        date_created: paymentData.date_created,
        date_last_updated: paymentData.date_last_updated,
        external_reference: paymentData.external_reference,
        metadata: paymentData.metadata,
        payer: paymentData.payer,
        payment_method: paymentData.payment_method,
        installments: paymentData.installments,
        description: paymentData.description
      };
    } catch (error) {
      console.error('Error fetching payment details:', error);
      throw new Error(`Failed to fetch payment details: ${error.message}`);
    }
  }

  /**
   * Process webhook notification from MercadoPago
   */
  async processWebhook(webhookData: WebhookData) {
    try {
      console.log('Processing MercadoPago webhook:', webhookData);

      if (webhookData.type !== 'payment') {
        console.log('Webhook type not supported:', webhookData.type);
        return null;
      }

      const paymentId = webhookData.data.id;
      const paymentDetails = await this.getPaymentDetails(paymentId);

      return {
        paymentId,
        status: paymentDetails.status,
        statusDetail: paymentDetails.status_detail,
        amount: paymentDetails.transaction_amount,
        externalReference: paymentDetails.external_reference,
        metadata: paymentDetails.metadata,
        dateCreated: paymentDetails.date_created,
        paymentMethod: paymentDetails.payment_method
      };
    } catch (error) {
      console.error('Error processing webhook:', error);
      throw new Error(`Webhook processing failed: ${error.message}`);
    }
  }

  /**
   * Validate webhook signature (for production security)
   */
  validateWebhookSignature(signature: string, data: string): boolean {
    // In production, implement proper signature validation
    // using MercadoPago's webhook secret
    return true;
  }
}

// Payment status mapping
export const PAYMENT_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  AUTHORIZED: 'authorized',
  IN_PROCESS: 'in_process',
  IN_MEDIATION: 'in_mediation',
  REJECTED: 'rejected',
  CANCELLED: 'cancelled',
  REFUNDED: 'refunded',
  CHARGED_BACK: 'charged_back'
} as const;

export type PaymentStatus = typeof PAYMENT_STATUS[keyof typeof PAYMENT_STATUS];

// Webhook action types
export const WEBHOOK_ACTIONS = {
  PAYMENT_CREATED: 'payment.created',
  PAYMENT_UPDATED: 'payment.updated'
} as const;

export const mercadoPagoService = new MercadoPagoService();