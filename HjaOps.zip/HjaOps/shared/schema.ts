import { sql, relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  date,
  decimal,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("user"), // user, admin
  plan: varchar("plan").default("free"), // free, basic, pro, premium
  credits: integer("credits").default(100),
  maxCredits: integer("max_credits").default(200),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const agents = pgTable("agents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description").notNull(),
  defaultModel: varchar("default_model").default("gpt-5"),
  promptBase: text("prompt_base").notNull(),
  active: boolean("active").default(true),
  tags: text("tags").array().default([]), // Use .array() method
  avatarUrl: varchar("avatar_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  agentId: varchar("agent_id").notNull(),
  title: varchar("title"),
  messages: jsonb("messages").default([]), // Array of message objects
  modelUsed: varchar("model_used").default("gpt-5"),
  tokensUsed: integer("tokens_used").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const plans = pgTable("plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  price: varchar("price").notNull(), // monetary value in cents
  creditsIncluded: integer("credits_included").notNull(),
  perks: jsonb("perks").default([]), // Array of features/perks
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  planId: varchar("plan_id"), // Reference to plan if buying a plan
  type: varchar("type").notNull(), // credits, plan
  amount: varchar("amount").notNull(), // monetary amount in cents
  creditsAdded: integer("credits_added").default(0),
  provider: varchar("provider").default("mercadopago"),
  providerPaymentId: varchar("provider_payment_id"), // MP payment ID
  status: varchar("status").default("pending"), // pending, completed, failed, cancelled
  metadata: jsonb("metadata"), // Additional payment info
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// HVC Core tables
export const monitoring = pgTable("monitoring", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventType: varchar("event_type").notNull(),
  success: boolean("success").notNull(),
  responseTime: integer("response_time").default(0),
  errorMessage: text("error_message"),
  metadata: jsonb("metadata"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const techTrends = pgTable("tech_trends", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  impact: varchar("impact").notNull(), // high, medium, low
  category: varchar("category").notNull(),
  source: varchar("source").notNull(),
  relevanceScore: integer("relevance_score").default(50),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: varchar("type").notNull(), // token_low, api_failure, trend_detected
  severity: varchar("severity").notNull(), // critical, warning, info
  message: text("message").notNull(),
  userId: varchar("user_id"),
  metadata: jsonb("metadata"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});


// Affiliate Metrics table for tracking clicks and conversions
export const affiliateMetrics = pgTable("affiliate_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").notNull(), // Reference to affiliate_products
  userId: varchar("user_id"), // Optional - if user is logged in
  sessionId: varchar("session_id"), // For tracking anonymous users
  eventType: varchar("event_type").notNull(), // click, view, conversion
  userAgent: varchar("user_agent"),
  ipAddress: varchar("ip_address"),
  referrer: varchar("referrer"),
  metadata: jsonb("metadata"), // Additional tracking data
  tokensAwarded: integer("tokens_awarded").default(0), // tokens given for this action
  conversions: integer("conversions").default(0), // number of conversions from this click
  createdAt: timestamp("created_at").defaultNow(),
});

// Track daily limits for gamification (1 token per product per day)
export const affiliateUserLimits = pgTable("affiliate_user_limits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(),
  date: date("date").notNull(), // YYYY-MM-DD format
  clicksToday: integer("clicks_today").default(0),
  tokensEarnedToday: integer("tokens_earned_today").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Blog Posts table for newsletter with paywall
export const posts = pgTable("posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  slug: varchar("slug").notNull().unique(),
  content: text("content").notNull(), // Full rich text/Markdown content
  excerpt: text("excerpt").notNull(), // Preview text (first paragraphs)
  coverImage: varchar("cover_image"),
  authorId: varchar("author_id").references(() => users.id),
  tags: text("tags").array().default([]), // Post tags for categorization
  requiredLevel: varchar("required_level").notNull().default("free"), // free, pro, vip, token-5, token-10, etc
  tokenCost: integer("token_cost").default(0), // Cost in tokens for pay-per-read
  published: boolean("published").default(false),
  views: integer("views").default(0),
  paidReads: integer("paid_reads").default(0), // Number of paid unlocks
  readTime: integer("read_time").default(5), // Estimated read time in minutes
  seoTitle: varchar("seo_title"),
  seoDescription: text("seo_description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  publishedAt: timestamp("published_at"),
});

// Post Read Metrics table for tracking paid reads
export const postReads = pgTable("post_reads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").notNull(), // Reference to posts
  userId: varchar("user_id"), // Optional - if user is logged in
  sessionId: varchar("session_id"), // For tracking anonymous users
  accessType: varchar("access_type").notNull(), // plan, credits, free
  creditsUsed: integer("credits_used").default(0), // Credits spent to unlock
  readDuration: integer("read_duration"), // Time spent reading in seconds
  completedRead: boolean("completed_read").default(false), // If user scrolled to end
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema definitions
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatSchema = createInsertSchema(chats).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPlanSchema = createInsertSchema(plans).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});


export const insertAffiliateMetricsSchema = createInsertSchema(affiliateMetrics).omit({
  id: true,
  createdAt: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPostReadSchema = createInsertSchema(postReads).omit({
  id: true,
  createdAt: true,
});

export const insertAffiliateUserLimitSchema = createInsertSchema(affiliateUserLimits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Affiliate Products System
export const affiliateProducts = pgTable("affiliate_products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  imageUrl: varchar("image_url"),
  affiliateUrl: varchar("affiliate_url").notNull(),
  source: varchar("source").default("mercado_livre"), // mercado_livre, amazon, etc
  category: varchar("category"),
  tags: text("tags").array().default([]),
  clicks: integer("clicks").default(0),
  conversions: integer("conversions").default(0),
  impressions: integer("impressions").default(0),
  active: boolean("active").default(true),
  featured: boolean("featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const affiliateClicks = pgTable("affiliate_clicks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").references(() => affiliateProducts.id).notNull(),
  userId: varchar("user_id").references(() => users.id), // Optional - anonymous clicks allowed
  sessionId: varchar("session_id"), // Track anonymous users
  userAgent: text("user_agent"),
  referrer: text("referrer"),
  ipAddress: varchar("ip_address"),
  timestamp: timestamp("timestamp").defaultNow(),
  tokensAwarded: integer("tokens_awarded").default(0),
});

export const affiliateImpressions = pgTable("affiliate_impressions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  productId: varchar("product_id").references(() => affiliateProducts.id).notNull(),
  userId: varchar("user_id").references(() => users.id),
  sessionId: varchar("session_id"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Relations
export const affiliateProductsRelations = relations(affiliateProducts, ({ many }) => ({
  clicks: many(affiliateClicks),
  impressions: many(affiliateImpressions),
}));

export const affiliateClicksRelations = relations(affiliateClicks, ({ one }) => ({
  product: one(affiliateProducts, {
    fields: [affiliateClicks.productId],
    references: [affiliateProducts.id],
  }),
  user: one(users, {
    fields: [affiliateClicks.userId],
    references: [users.id],
  }),
}));

export const affiliateImpressionsRelations = relations(affiliateImpressions, ({ one }) => ({
  product: one(affiliateProducts, {
    fields: [affiliateImpressions.productId],
    references: [affiliateProducts.id],
  }),
  user: one(users, {
    fields: [affiliateImpressions.userId],
    references: [users.id],
  }),
}));

// CapS'ula (Social Feed) Tables
export const capsules = pgTable("capsules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  mediaUrl: varchar("media_url"),
  linkUrl: varchar("link_url"),
  reactionsCount: integer("reactions_count").default(0),
  commentsCount: integer("comments_count").default(0),
  isPinned: boolean("is_pinned").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const reactions = pgTable("reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  capsuleId: varchar("capsule_id").notNull().references(() => capsules.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: varchar("type", { length: 10 }).notNull(), // 🔥 ❤️ 👏
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueUserReaction: uniqueIndex("unique_user_reaction").on(table.capsuleId, table.userId, table.type),
}));

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  capsuleId: varchar("capsule_id").notNull().references(() => capsules.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// CapS'ula Relations
export const capsulesRelations = relations(capsules, ({ one, many }) => ({
  user: one(users, {
    fields: [capsules.userId],
    references: [users.id],
  }),
  reactions: many(reactions),
  comments: many(comments),
}));

export const reactionsRelations = relations(reactions, ({ one }) => ({
  capsule: one(capsules, {
    fields: [reactions.capsuleId],
    references: [capsules.id],
  }),
  user: one(users, {
    fields: [reactions.userId],
    references: [users.id],
  }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  capsule: one(capsules, {
    fields: [comments.capsuleId],
    references: [capsules.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

// CapS'ula Schemas
export const insertCapsuleSchema = createInsertSchema(capsules).omit({
  id: true,
  reactionsCount: true,
  commentsCount: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  content: z.string().min(1).max(500, "Máximo 500 caracteres"),
  mediaUrl: z.string().url().optional(),
  linkUrl: z.string().url().optional(),
});

export const insertReactionSchema = createInsertSchema(reactions).omit({
  id: true,
  createdAt: true,
}).extend({
  type: z.enum(["🔥", "❤️", "👏"]),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  text: z.string().min(1).max(300, "Máximo 300 caracteres"),
});

// Additional schemas for affiliate system  
export const insertAffiliateProductSchema = createInsertSchema(affiliateProducts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAffiliateClickSchema = createInsertSchema(affiliateClicks).omit({
  id: true,
  timestamp: true,
});

export const insertAffiliateImpressionSchema = createInsertSchema(affiliateImpressions).omit({
  id: true,
  timestamp: true,
});

// Types
export type AffiliateClick = typeof affiliateClicks.$inferSelect;
export type InsertAffiliateClick = typeof affiliateClicks.$inferInsert;
export type AffiliateImpression = typeof affiliateImpressions.$inferSelect;
export type InsertAffiliateImpression = typeof affiliateImpressions.$inferInsert;

export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Chat = typeof chats.$inferSelect;
export type InsertChat = z.infer<typeof insertChatSchema>;
export type Plan = typeof plans.$inferSelect;
export type InsertPlan = z.infer<typeof insertPlanSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type AffiliateProduct = typeof affiliateProducts.$inferSelect;
export type InsertAffiliateProduct = z.infer<typeof insertAffiliateProductSchema>;
export type AffiliateMetrics = typeof affiliateMetrics.$inferSelect;
export type InsertAffiliateMetrics = z.infer<typeof insertAffiliateMetricsSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type PostRead = typeof postReads.$inferSelect;
export type InsertPostRead = z.infer<typeof insertPostReadSchema>;
export type AffiliateUserLimit = typeof affiliateUserLimits.$inferSelect;
export type InsertAffiliateUserLimit = z.infer<typeof insertAffiliateUserLimitSchema>;

// CapS'ula types
export type Capsule = typeof capsules.$inferSelect;
export type InsertCapsule = z.infer<typeof insertCapsuleSchema>;
export type Reaction = typeof reactions.$inferSelect;
export type InsertReaction = z.infer<typeof insertReactionSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

// HVC Core types
export type Monitoring = typeof monitoring.$inferSelect;
export type TechTrend = typeof techTrends.$inferSelect;
export type Notification = typeof notifications.$inferSelect;

export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  tokensUsed?: number;
}
