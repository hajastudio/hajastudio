import { pgTable, text, varchar, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"), 
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").default("user"),
  plan: varchar("plan").default("free"),
  credits: integer("credits").default(100),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const agents = pgTable("agents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  prompt: text("prompt"),
  defaultModel: text("default_model"),
  tags: text("tags").array(),
  active: boolean("active").default(true),
});

export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  agentId: varchar("agent_id").notNull().references(() => agents.id),
  title: text("title"),
  messages: jsonb("messages").$type<
    { role: "user" | "assistant"; content: string; timestamp: string }[]
  >(),
  modelUsed: text("model_used"),
  tokens: integer("tokens"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(), // credit | plan
  amount: integer("amount").notNull(),
  creditsAdded: integer("credits_added"),
  provider: text("provider").default("mercadopago"),
  createdAt: timestamp("created_at").defaultNow(),
});