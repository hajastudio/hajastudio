# 🚀 Plano de Deploy Firebase - Hja²Ops

## 📋 Pré-requisitos

```bash
# 1. Instalar Firebase CLI
npm install -g firebase-tools

# 2. Login no Firebase
firebase login

# 3. Verificar se está logado
firebase projects:list
```

## 🔧 Configuração Inicial

### 1. Inicializar Projeto Firebase
```bash
# Na raiz do projeto
firebase init

# Selecionar:
# ✅ Firestore: Deploy rules and create indexes
# ✅ Functions: Configure and deploy Cloud Functions  
# ✅ Hosting: Configure files for Firebase Hosting
# ✅ Storage: Configure security rules for Cloud Storage
```

### 2. Configurar firebase.json
```json
{
  "firestore": {
    "rules": "firebase-security-rules.rules",
    "indexes": "firestore.indexes.json"
  },
  "functions": [
    {
      "source": "firebase-functions",
      "codebase": "default",
      "runtime": "nodejs18"
    }
  ],
  "hosting": {
    "public": "dist",
    "ignore": [
      "firebase.json",
      "**/.*",
      "**/node_modules/**"
    ],
    "rewrites": [
      {
        "source": "**",
        "destination": "/index.html"
      }
    ]
  },
  "storage": {
    "rules": "storage.rules"
  },
  "emulators": {
    "auth": {
      "port": 9099
    },
    "functions": {
      "port": 5001
    },
    "firestore": {
      "port": 8080
    },
    "hosting": {
      "port": 5000
    },
    "storage": {
      "port": 9199
    },
    "ui": {
      "enabled": true,
      "port": 4000
    },
    "singleProjectMode": true
  }
}
```

## 🔑 Variáveis de Ambiente

### 1. Configurar secrets no Firebase
```bash
# APIs dos provedores de IA
firebase functions:secrets:set GROQ_API_KEY
firebase functions:secrets:set HF_API_KEY  
firebase functions:secrets:set REPLIT_API_KEY
firebase functions:secrets:set OPENAI_API_KEY

# Mercado Pago
firebase functions:secrets:set MERCADOPAGO_ACCESS_TOKEN
firebase functions:secrets:set MERCADOPAGO_WEBHOOK_SECRET

# URLs dos provedores
firebase functions:config:set \
  groq.api_url="https://api.groq.com/openai/v1" \
  huggingface.api_url="https://api-inference.huggingface.co" \
  replit.api_url="https://api.replit.com/v1"
```

### 2. Arquivo .env local (desenvolvimento)
```env
# firebase-functions/.env
GROQ_API_KEY=your_groq_key_here
HF_API_KEY=your_hf_key_here
REPLIT_API_KEY=your_replit_key_here
OPENAI_API_KEY=your_openai_key_here
MERCADOPAGO_ACCESS_TOKEN=your_mp_token_here
```

## 📚 População Inicial do Firestore

### 1. Usando Firebase Admin SDK
```bash
# Instalar dependências
npm install firebase-admin

# Executar script de import
node firebase-import.js
```

### 2. Via Firebase Console (Manual)
- Acessar https://console.firebase.google.com
- Ir em Firestore Database
- Importar firebase-seed-complete.json

### 3. Usando Emulators (Desenvolvimento)
```bash
# Iniciar emulators
firebase emulators:start

# Em outro terminal, popular dados
node firebase-import.js --emulator
```

## 🚀 Deploy Passo a Passo

### 1. Deploy de Desenvolvimento (Emulators)
```bash
# Terminal 1: Inicia emulators
firebase emulators:start

# Terminal 2: Deploy functions local
cd firebase-functions
npm run serve

# Terminal 3: Popular dados
node firebase-import.js
```

### 2. Deploy de Produção

#### Etapa 1: Build e Validação
```bash
# Build das functions
cd firebase-functions
npm run build

# Validar regras do Firestore
firebase firestore:rules:validate

# Testar functions localmente
npm run serve
```

#### Etapa 2: Deploy Firestore Rules
```bash
# Deploy apenas das regras (primeiro deploy)
firebase deploy --only firestore:rules
```

#### Etapa 3: Deploy Functions
```bash
# Deploy das Cloud Functions
firebase deploy --only functions

# Verificar logs
firebase functions:log --only onChatSubmit
```

#### Etapa 4: Popular Dados Iniciais
```bash
# Executar população inicial
node firebase-import.js

# Verificar no console
firebase firestore:indexes
```

#### Etapa 5: Deploy Completo
```bash
# Deploy de tudo
firebase deploy

# Verificar status
firebase functions:log
firebase hosting:channel:open live
```

## 🔍 Validação e Testes

### 1. Testar Cloud Functions
```bash
# Testar função de chat
curl -X POST https://your-region-your-project.cloudfunctions.net/onChatSubmit \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "userId": "user001",
      "agentId": "roteirista", 
      "message": "Crie um roteiro viral"
    }
  }'
```

### 2. Testar Webhook Mercado Pago
```bash
# Testar webhook
curl -X POST https://your-region-your-project.cloudfunctions.net/onTransactionApproved \
  -H "Content-Type: application/json" \
  -d '{
    "type": "payment",
    "data": { "id": "123456789" }
  }'
```

### 3. Verificar Cron Jobs
```bash
# Verificar agendamento
firebase functions:log --only dailyTechScan

# Forçar execução manual
firebase functions:shell
> dailyTechScan()
```

## 📊 Monitoramento Pós-Deploy

### 1. Métricas Essenciais
- **Functions**: Execuções, erros, latência
- **Firestore**: Leituras/escritas, custos
- **Storage**: Uploads, downloads
- **Auth**: Logins, criações de conta

### 2. Alertas Recomendados
```yaml
# Cloud Monitoring
alerts:
  - name: "Function Errors"
    condition: "error_rate > 5%"
    notification: "email"
    
  - name: "High Firestore Usage" 
    condition: "reads > 100k/day"
    notification: "slack"
    
  - name: "Credit System Down"
    condition: "onChatSubmit errors > 10"
    notification: "sms"
```

### 3. Logs e Debug
```bash
# Logs em tempo real
firebase functions:log --only onChatSubmit --follow

# Métricas de performance
firebase functions:get onChatSubmit

# Debug de regras
firebase firestore:rules:debug
```

## 🔄 Workflow de CI/CD (Opcional)

### GitHub Actions (.github/workflows/firebase.yml)
```yaml
name: Deploy to Firebase
on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: |
          npm ci
          cd firebase-functions && npm ci
      
      - name: Build functions
        run: cd firebase-functions && npm run build
      
      - name: Deploy to Firebase
        uses: FirebaseExtended/action-hosting-deploy@v0
        with:
          repoToken: '${{ secrets.GITHUB_TOKEN }}'
          firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT }}'
          projectId: your-project-id
```

## ✅ Checklist Final

- [ ] Firebase CLI instalado e autenticado
- [ ] Projeto criado no Console Firebase
- [ ] Regras de segurança deployadas
- [ ] Cloud Functions deployadas sem erros
- [ ] Dados iniciais populados
- [ ] Variáveis de ambiente configuradas
- [ ] Webhooks testados e funcionando
- [ ] Cron jobs agendados corretamente
- [ ] Monitoramento configurado
- [ ] Backup/restore documentado

## 🆘 Troubleshooting

### Erros Comuns
1. **"Permission denied"**: Verificar regras do Firestore
2. **"Function timeout"**: Aumentar timeout nas functions
3. **"Quota exceeded"**: Verificar limites do Firebase
4. **"Webhook not working"**: Verificar URLs e secrets

### Comandos de Debug
```bash
# Verificar configuração
firebase use --add

# Resetar emulators
firebase emulators:exec --only firestore,functions "echo done"

# Verificar quotas
firebase projects:list --format=json
```

---

🎯 **Com este plano, o Hja²Ops terá uma infraestrutura Firebase robusta, segura e escalável para suportar o HVC Core em produção.**