// Configuração dos provedores de IA
export interface AIProvider {
  name: string;
  apiKey: string;
  baseURL: string;
  models: string[];
  priority: number;
  tokensPerMinute: number;
  costPerToken: number;
}

export const AI_PROVIDERS: Record<string, AIProvider> = {
  groq: {
    name: 'Groq',
    apiKey: process.env.GROQ_API_KEY || '',
    baseURL: 'https://api.groq.com/openai/v1',
    models: ['llama-3.1-70b-versatile', 'llama-3.1-8b-instant'],
    priority: 1,
    tokensPerMinute: 30000,
    costPerToken: 0.0001
  },
  huggingface: {
    name: 'Hugging Face',
    apiKey: process.env.HF_API_KEY || '',
    baseURL: 'https://api-inference.huggingface.co/models',
    models: ['microsoft/DialoGPT-large', 'facebook/blenderbot-400M-distill'],
    priority: 2,
    tokensPerMinute: 10000,
    costPerToken: 0.00005
  },
  replit: {
    name: 'Replit',
    apiKey: process.env.REPLIT_API_KEY || '',
    baseURL: 'https://replit.com/api/v1',
    models: ['replit-code-v1.5-3b'],
    priority: 3,
    tokensPerMinute: 20000,
    costPerToken: 0.00003
  }
};

export const DEFAULT_MODEL_SETTINGS = {
  temperature: 0.7,
  maxTokens: 1000,
  topP: 0.9,
  frequencyPenalty: 0,
  presencePenalty: 0
};

// Configurações de fallback
export const FALLBACK_CHAIN = ['groq', 'huggingface', 'replit'];

// Rate limiting
export const RATE_LIMITS = {
  userRequestsPerMinute: 60,
  globalRequestsPerSecond: 100,
  tokensPerUserPerHour: 50000
};