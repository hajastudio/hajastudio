import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth.middleware';
import { prisma } from '../index';

// Middleware to check if user has enough credits
export const requireCredits = (minimumCredits: number = 1) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Get fresh credit count from database
      const user = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { credits: true, plan: true }
      });

      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Admin users have unlimited credits
      if (user.plan === 'admin') {
        req.user.credits = user.credits;
        return next();
      }

      if (user.credits < minimumCredits) {
        return res.status(402).json({ 
          error: 'Insufficient credits',
          required: minimumCredits,
          available: user.credits,
          message: 'Please purchase more credits to continue'
        });
      }

      // Update user credits in request
      req.user.credits = user.credits;
      next();
    } catch (error) {
      console.error('Credits middleware error:', error);
      return res.status(500).json({ error: 'Credit check failed' });
    }
  };
};

// Middleware to deduct credits after successful operation
export const deductCredits = (credits: number) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      // Skip deduction for admin users
      if (req.user.plan === 'admin') {
        return next();
      }

      // Deduct credits atomically
      const updatedUser = await prisma.user.update({
        where: { 
          id: req.user.id,
          credits: { gte: credits } // Ensure user still has enough credits
        },
        data: { 
          credits: { decrement: credits }
        },
        select: { credits: true }
      });

      // Update user credits in request
      req.user.credits = updatedUser.credits;
      
      // Log the transaction
      await prisma.transaction.create({
        data: {
          userId: req.user.id,
          type: 'usage',
          amount: 0,
          creditsAdded: -credits,
          provider: 'system'
        }
      });

      next();
    } catch (error) {
      console.error('Credit deduction error:', error);
      
      // Check if it's a constraint violation (not enough credits)
      if (error.code === 'P2025') {
        return res.status(402).json({ 
          error: 'Insufficient credits',
          message: 'Credits were exhausted during processing'
        });
      }

      return res.status(500).json({ error: 'Credit deduction failed' });
    }
  };
};

// Dynamic credit calculation based on operation
export const calculateCredits = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const { agentId, messageLength = 0 } = req.body;

    // Get agent information to calculate credits
    const agent = await prisma.agent.findUnique({
      where: { id: agentId }
    });

    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    // Estimate tokens (rough calculation: ~4 characters per token)
    const estimatedTokens = Math.ceil(messageLength / 4);
    const baseCost = Math.max(1, Math.ceil(estimatedTokens * 0.001)); // Default cost per token
    
    // Add to request for later use
    req.estimatedCredits = baseCost;
    
    next();
  } catch (error) {
    console.error('Credit calculation error:', error);
    return res.status(500).json({ error: 'Credit calculation failed' });
  }
};

// Helper function to log credit transactions
async function logCreditTransaction(userId: string, credits: number, type: string) {
  try {
    await prisma.transaction.create({
      data: {
        userId,
        type,
        amount: 0,
        creditsAdded: type === 'usage' ? -credits : credits,
        provider: 'system'
      }
    });
  } catch (error) {
    console.error('Failed to log credit transaction:', error);
    // Don't throw - logging failure shouldn't break the main operation
  }
}

// Check for low credits and send warning
export const checkLowCredits = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    if (!req.user || req.user.plan === 'admin') {
      return next();
    }

    const LOW_CREDIT_THRESHOLD = 10;

    if (req.user.credits <= LOW_CREDIT_THRESHOLD) {
      // Add warning to response headers
      res.set('X-Credits-Warning', 'low');
      res.set('X-Credits-Remaining', req.user.credits.toString());
      
      // Could also trigger email notification here
      console.log(`Low credits warning for user ${req.user.id}: ${req.user.credits} remaining`);
    }

    next();
  } catch (error) {
    console.error('Low credits check error:', error);
    // Don't fail the request for this check
    next();
  }
};

// Extend AuthRequest interface
declare global {
  namespace Express {
    interface Request {
      estimatedCredits?: number;
    }
  }
}