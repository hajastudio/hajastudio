import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../index';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    plan: string;
    credits: number;
  };
}

// JWT Authentication Middleware
export const authenticateToken = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({ error: 'Access token required' });
    }

    const JWT_SECRET = process.env.JWT_SECRET;
    if (!JWT_SECRET) {
      throw new Error('JWT_SECRET not configured');
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any;
    
    // Get fresh user data from database
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId }
    });

    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    // Attach user to request
    req.user = {
      id: user.id,
      email: user.email,
      plan: user.plan,
      credits: user.credits
    };

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date() }
    });

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    console.error('Auth middleware error:', error);
    return res.status(500).json({ error: 'Authentication failed' });
  }
};

// Admin-only middleware
export const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  if (req.user.plan !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }

  next();
};

// Plan-based access middleware
export const requirePlan = (minimumPlan: string) => {
  const planHierarchy = ['free', 'basic', 'pro', 'premium', 'admin'];
  
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const userPlanIndex = planHierarchy.indexOf(req.user.plan);
    const requiredPlanIndex = planHierarchy.indexOf(minimumPlan);

    if (userPlanIndex < requiredPlanIndex) {
      return res.status(403).json({ 
        error: 'Insufficient plan level',
        required: minimumPlan,
        current: req.user.plan
      });
    }

    next();
  };
};

// Rate limiting per user
export const createUserRateLimit = (windowMs: number, maxRequests: number) => {
  const userRequestCounts = new Map<string, { count: number; resetTime: number }>();

  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const userId = req.user.id;
    const now = Date.now();
    const userLimits = userRequestCounts.get(userId);

    if (!userLimits || now > userLimits.resetTime) {
      // Reset or initialize limits
      userRequestCounts.set(userId, {
        count: 1,
        resetTime: now + windowMs
      });
      return next();
    }

    if (userLimits.count >= maxRequests) {
      return res.status(429).json({
        error: 'Rate limit exceeded',
        resetTime: new Date(userLimits.resetTime).toISOString()
      });
    }

    userLimits.count++;
    next();
  };
};