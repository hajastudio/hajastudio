import express from 'express';
import { prisma } from '../index';
import { authenticateToken, AuthRequest } from '../middleware/auth.middleware';

const router = express.Router();

// Middleware to check admin access
const requireAdmin = async (req: AuthRequest, res: express.Response, next: express.NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const user = await prisma.user.findUnique({
    where: { id: req.user.id }
  });

  if (!user || user.plan !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }

  next();
};

// Admin usage statistics
router.get('/usage', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    // Get overall metrics
    const totalUsers = await prisma.user.count();
    const totalChats = await prisma.chat.count();
    const totalTransactions = await prisma.transaction.count();
    
    // Get today's data
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const todayStats = await Promise.all([
      prisma.chat.count({
        where: {
          createdAt: {
            gte: today,
            lt: tomorrow
          }
        }
      }),
      prisma.chat.aggregate({
        where: {
          createdAt: {
            gte: today,
            lt: tomorrow
          }
        },
        _sum: { tokens: true }
      })
    ]);

    // Get top agents by usage
    const topAgents = await prisma.chat.groupBy({
      by: ['agentId'],
      _count: { agentId: true },
      orderBy: {
        _count: { agentId: 'desc' }
      },
      take: 5
    });

    // Get usage data for the last 7 days
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date;
    });

    const usageData = await Promise.all(
      last7Days.map(async (date) => {
        const nextDay = new Date(date);
        nextDay.setDate(nextDay.getDate() + 1);
        
        const dayUsage = await prisma.chat.aggregate({
          where: {
            createdAt: {
              gte: date,
              lt: nextDay
            }
          },
          _sum: { tokens: true },
          _count: { id: true }
        });

        return {
          date: date.toISOString().split('T')[0],
          tokens: dayUsage._sum.tokens || 0,
          chats: dayUsage._count || 0
        };
      })
    );

    // Get model distribution
    const modelStats = await prisma.chat.groupBy({
      by: ['modelUsed'],
      _count: { modelUsed: true },
      orderBy: {
        _count: { modelUsed: 'desc' }
      }
    });

    const totalModelUsage = modelStats.reduce((sum, stat) => sum + stat._count.modelUsed, 0);
    const modelDistribution = modelStats.map(stat => ({
      model: stat.modelUsed,
      percentage: totalModelUsage > 0 ? Math.round((stat._count.modelUsed / totalModelUsage) * 100) : 0
    }));

    // Get recent activity
    const recentChats = await prisma.chat.findMany({
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: {
        user: { select: { email: true } },
        agent: { select: { name: true } }
      }
    });

    const logs = recentChats.map(chat => ({
      id: chat.id,
      timestamp: chat.createdAt.toLocaleString('pt-BR'),
      user: chat.user.email,
      agent: chat.agent.name,
      tokens: chat.tokens,
      cost: chat.cost,
      status: 'success' as const
    }));

    res.json({
      success: true,
      metrics: {
        totalUsers,
        creditsConsumedToday: todayStats[1]._sum.tokens || 0,
        topAgent: topAgents[0]?.agentId || 'N/A',
        errorsDetected: 0 // Mock for now
      },
      usageData,
      modelDistribution,
      logs
    });
  } catch (error) {
    console.error('Admin usage error:', error);
    res.status(500).json({ error: 'Failed to get admin usage data' });
  }
});

// Get all users
router.get('/users', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const users = await prisma.user.findMany({
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        email: true,
        credits: true,
        plan: true,
        createdAt: true,
        lastLogin: true,
        _count: {
          select: {
            chats: true,
            transactions: true
          }
        }
      }
    });

    res.json({ success: true, users });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

// Add credits to user
router.post('/users/:userId/credits', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { userId } = req.params;
    const { credits, reason = 'admin_manual' } = req.body;

    if (!credits || credits <= 0) {
      return res.status(400).json({ error: 'Invalid credits amount' });
    }

    // Update user credits
    const user = await prisma.user.update({
      where: { id: userId },
      data: { credits: { increment: credits } }
    });

    // Log the transaction
    await prisma.transaction.create({
      data: {
        userId,
        type: 'bonus',
        amount: 0,
        creditsAdded: credits,
        provider: 'manual'
      }
    });

    res.json({ 
      success: true, 
      message: `Added ${credits} credits to user`,
      newBalance: user.credits
    });
  } catch (error) {
    console.error('Add credits error:', error);
    res.status(500).json({ error: 'Failed to add credits' });
  }
});

// System status
router.get('/system', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    // Mock system status for now
    const systemStatus = {
      providers: {
        groq: { status: 'operational', latency: 80 },
        huggingface: { status: 'operational', latency: 200 },
        replit: { status: 'operational', latency: 150 }
      },
      alerts: [
        {
          type: 'HIGH_USAGE',
          message: 'Uso elevado detectado nos últimos 30 minutos',
          severity: 'medium',
          timestamp: new Date().toISOString()
        }
      ]
    };

    res.json({ success: true, system: systemStatus });
  } catch (error) {
    console.error('System status error:', error);
    res.status(500).json({ error: 'Failed to get system status' });
  }
});

// Get system overview
router.get('/overview', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const [totalUsers, totalChats, totalTransactions, totalAgents] = await Promise.all([
      prisma.user.count(),
      prisma.chat.count(),
      prisma.transaction.count(),
      prisma.agent.count({ where: { active: true } })
    ]);

    const overview = {
      totalUsers,
      totalChats,
      totalTransactions,
      totalAgents,
      systemStatus: 'operational'
    };

    res.json({ success: true, overview });
  } catch (error) {
    console.error('Admin overview error:', error);
    res.status(500).json({ error: 'Failed to get system overview' });
  }
});

// Update agent status
router.patch('/agents/:agentId/status', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { agentId } = req.params;
    const { active } = req.body;

    const agent = await prisma.agent.update({
      where: { id: agentId },
      data: { active }
    });

    res.json({ success: true, agent });
  } catch (error) {
    console.error('Update agent status error:', error);
    res.status(500).json({ error: 'Failed to update agent status' });
  }
});

export default router;