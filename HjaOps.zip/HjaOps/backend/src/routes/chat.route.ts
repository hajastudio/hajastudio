import express from 'express';
import { prisma } from '../index';
import { authenticateToken, AuthRequest } from '../middleware/auth.middleware';
import { requireCredits } from '../middleware/credits.middleware';

const router = express.Router();

// Get user's chats
router.get('/', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const [chats, total] = await Promise.all([
      prisma.chat.findMany({
        where: { userId: req.user!.id },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        include: {
          agent: {
            select: {
              name: true,
              description: true
            }
          }
        }
      }),
      prisma.chat.count({
        where: { userId: req.user!.id }
      })
    ]);

    res.json({
      success: true,
      chats,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get chats error:', error);
    res.status(500).json({ error: 'Failed to get chats' });
  }
});

// Get specific chat
router.get('/:chatId', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { chatId } = req.params;

    const chat = await prisma.chat.findFirst({
      where: {
        id: chatId,
        userId: req.user!.id
      },
      include: {
        agent: {
          select: {
            name: true,
            description: true,
            defaultModel: true
          }
        }
      }
    });

    if (!chat) {
      return res.status(404).json({ error: 'Chat not found' });
    }

    res.json({ success: true, chat });
  } catch (error) {
    console.error('Get chat error:', error);
    res.status(500).json({ error: 'Failed to get chat' });
  }
});

// Start new chat with agent
router.post('/start', authenticateToken, requireCredits(1), async (req: AuthRequest, res) => {
  try {
    const { agentId, message } = req.body;

    if (!agentId || !message) {
      return res.status(400).json({ 
        error: 'Agent ID and initial message required' 
      });
    }

    // Get agent
    const agent = await prisma.agent.findUnique({
      where: { id: agentId, active: true }
    });

    if (!agent) {
      return res.status(404).json({ error: 'Agent not found or inactive' });
    }

    // Create initial messages array
    const messages = [
      {
        role: 'user' as const,
        content: message,
        timestamp: new Date().toISOString()
      }
    ];

    // Create chat record
    const chat = await prisma.chat.create({
      data: {
        userId: req.user!.id,
        agentId: agent.id,
        messages,
        modelUsed: agent.defaultModel,
        tokens: 0,
        cost: 0
      },
      include: {
        agent: {
          select: {
            name: true,
            description: true,
            defaultModel: true
          }
        }
      }
    });

    res.json({ 
      success: true, 
      chat,
      message: 'Chat started successfully. Send a message to get AI response.'
    });
  } catch (error) {
    console.error('Start chat error:', error);
    res.status(500).json({ error: 'Failed to start chat' });
  }
});

// Send message to chat
router.post('/:chatId/message', authenticateToken, requireCredits(1), async (req: AuthRequest, res) => {
  try {
    const { chatId } = req.params;
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message content required' });
    }

    // Get chat
    const chat = await prisma.chat.findFirst({
      where: {
        id: chatId,
        userId: req.user!.id
      },
      include: { agent: true }
    });

    if (!chat) {
      return res.status(404).json({ error: 'Chat not found' });
    }

    // Simulate AI response (replace with actual AI integration)
    const aiResponse = await generateAIResponse(chat.agent, message);
    
    // Update messages array
    const currentMessages = Array.isArray(chat.messages) ? chat.messages : [];
    const newMessages = [
      ...currentMessages,
      {
        role: 'user' as const,
        content: message,
        timestamp: new Date().toISOString()
      },
      {
        role: 'assistant' as const,
        content: aiResponse.content,
        timestamp: new Date().toISOString()
      }
    ];

    // Update chat with new messages and usage
    const updatedChat = await prisma.chat.update({
      where: { id: chatId },
      data: {
        messages: newMessages,
        tokens: chat.tokens + aiResponse.tokens,
        cost: chat.cost + 1 // Always cost 1 credit per message
      }
    });

    // Deduct credits from user
    await prisma.user.update({
      where: { id: req.user!.id },
      data: { credits: { decrement: 1 } }
    });

    // Log usage
    await prisma.usage.create({
      data: {
        userId: req.user!.id,
        agentId: chat.agentId,
        action: 'chat_completion',
        tokens: aiResponse.tokens,
        cost: 1,
        provider: aiResponse.provider,
        model: chat.agent.defaultModel,
        success: true
      }
    });

    // Create transaction record
    await prisma.transaction.create({
      data: {
        userId: req.user!.id,
        type: 'usage',
        amount: 0,
        creditsAdded: -1,
        provider: 'system',
        status: 'approved',
        processedAt: new Date()
      }
    });

    res.json({
      success: true,
      response: aiResponse.content,
      tokensUsed: aiResponse.tokens,
      creditsDeducted: 1,
      remainingCredits: req.user!.credits - 1
    });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Delete chat
router.delete('/:chatId', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { chatId } = req.params;

    const deletedChat = await prisma.chat.deleteMany({
      where: {
        id: chatId,
        userId: req.user!.id
      }
    });

    if (deletedChat.count === 0) {
      return res.status(404).json({ error: 'Chat not found' });
    }

    res.json({ success: true, message: 'Chat deleted successfully' });
  } catch (error) {
    console.error('Delete chat error:', error);
    res.status(500).json({ error: 'Failed to delete chat' });
  }
});

// Mock AI response function (replace with actual AI integration)
async function generateAIResponse(agent: any, message: string) {
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Mock responses based on agent
  const responses = {
    'Roteirista': `Como roteirista especializado, vou ajudar você com: "${message}". Aqui está uma estrutura criativa para desenvolver sua ideia...`,
    'Viral': `Para criar conteúdo viral sobre "${message}", sugiro estas estratégias de alto engajamento...`,
    'Branding': `Do ponto de vista de branding para "${message}", vamos trabalhar a identidade e posicionamento...`
  };

  const defaultResponse = `Como ${agent.name}, vou responder sobre: "${message}". Baseado no meu conhecimento especializado...`;

  return {
    content: responses[agent.name as keyof typeof responses] || defaultResponse,
    tokens: Math.floor(Math.random() * 200) + 50, // 50-250 tokens
    provider: agent.defaultModel.includes('groq') ? 'groq' : 
              agent.defaultModel.includes('huggingface') ? 'huggingface' : 'replit'
  };
}

export default router;