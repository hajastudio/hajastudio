import express from 'express';
import { prisma } from '../index';
import { authenticateToken, AuthRequest } from '../middleware/auth.middleware';

const router = express.Router();

// Get current user profile
router.get('/profile', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true,
        email: true,
        credits: true,
        plan: true,
        profile: true,
        createdAt: true,
        lastLogin: true,
        _count: {
          select: {
            chats: true,
            transactions: true
          }
        }
      }
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ success: true, user });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ error: 'Failed to get user profile' });
  }
});

// Update user profile
router.put('/profile', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { profile } = req.body;

    if (!profile || typeof profile !== 'object') {
      return res.status(400).json({ error: 'Valid profile object required' });
    }

    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { profile },
      select: {
        id: true,
        email: true,
        credits: true,
        plan: true,
        profile: true,
        createdAt: true,
        lastLogin: true
      }
    });

    res.json({ success: true, user });
  } catch (error) {
    console.error('Update user profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Get user's usage statistics
router.get('/stats', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const [totalChats, totalTokens, monthlyUsage, recentChats] = await Promise.all([
      // Total chats
      prisma.chat.count({
        where: { userId: req.user!.id }
      }),
      
      // Total tokens used
      prisma.chat.aggregate({
        where: { userId: req.user!.id },
        _sum: { tokens: true }
      }),
      
      // Monthly usage (last 30 days)
      prisma.chat.aggregate({
        where: {
          userId: req.user!.id,
          createdAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
          }
        },
        _sum: { tokens: true },
        _count: { id: true }
      }),
      
      // Recent chats
      prisma.chat.findMany({
        where: { userId: req.user!.id },
        orderBy: { createdAt: 'desc' },
        take: 10,
        include: {
          agent: {
            select: {
              name: true,
              description: true
            }
          }
        }
      })
    ]);

    const stats = {
      totalChats,
      totalTokens: totalTokens._sum.tokens || 0,
      monthlyChats: monthlyUsage._count || 0,
      monthlyTokens: monthlyUsage._sum.tokens || 0,
      recentChats: recentChats.map(chat => ({
        id: chat.id,
        agentName: chat.agent.name,
        tokens: chat.tokens,
        modelUsed: chat.modelUsed,
        createdAt: chat.createdAt
      }))
    };

    res.json({ success: true, stats });
  } catch (error) {
    console.error('Get user stats error:', error);
    res.status(500).json({ error: 'Failed to get user statistics' });
  }
});

// Get user's transaction history
router.get('/transactions', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where: { userId: req.user!.id },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        select: {
          id: true,
          type: true,
          amount: true,
          creditsAdded: true,
          provider: true,
          status: true,
          createdAt: true,
          processedAt: true
        }
      }),
      prisma.transaction.count({
        where: { userId: req.user!.id }
      })
    ]);

    res.json({
      success: true,
      transactions,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get user transactions error:', error);
    res.status(500).json({ error: 'Failed to get transactions' });
  }
});

// Delete user account
router.delete('/account', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { confirmEmail } = req.body;

    if (confirmEmail !== req.user!.email) {
      return res.status(400).json({ 
        error: 'Email confirmation required to delete account' 
      });
    }

    // Delete user and cascade to related records
    await prisma.user.delete({
      where: { id: req.user!.id }
    });

    res.json({ 
      success: true, 
      message: 'Account deleted successfully' 
    });
  } catch (error) {
    console.error('Delete user account error:', error);
    res.status(500).json({ error: 'Failed to delete account' });
  }
});

export default router;