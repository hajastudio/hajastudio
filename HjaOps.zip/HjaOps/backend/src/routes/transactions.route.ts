import express from 'express';
import { prisma } from '../index';
import { authenticateToken, AuthRequest } from '../middleware/auth.middleware';

const router = express.Router();

// Get credit packages
router.get('/packages', async (req, res) => {
  try {
    const packages = [
      {
        id: 'starter',
        name: 'Pacote Inicial',
        credits: 100,
        price: 19.90,
        bonus: 10,
        description: 'Ideal para começar',
        popular: false
      },
      {
        id: 'popular',
        name: 'Pacote Popular',
        credits: 250,
        price: 39.90,
        bonus: 30,
        description: 'Mais escolhido',
        popular: true
      },
      {
        id: 'pro',
        name: 'Pacote Pro',
        credits: 500,
        price: 69.90,
        bonus: 75,
        description: 'Para usuários avançados',
        popular: false
      },
      {
        id: 'enterprise',
        name: 'Pacote Enterprise',
        credits: 1000,
        price: 119.90,
        bonus: 200,
        description: 'Para empresas',
        popular: false
      }
    ];

    res.json({ success: true, packages });
  } catch (error) {
    console.error('Get packages error:', error);
    res.status(500).json({ error: 'Failed to get packages' });
  }
});

// Purchase credits (Mock Mercado Pago)
router.post('/purchase', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { packageId, paymentMethod = 'credit_card' } = req.body;

    if (!packageId) {
      return res.status(400).json({ error: 'Package ID required' });
    }

    // Package definitions
    const packages = {
      starter: { credits: 100, price: 19.90, bonus: 10 },
      popular: { credits: 250, price: 39.90, bonus: 30 },
      pro: { credits: 500, price: 69.90, bonus: 75 },
      enterprise: { credits: 1000, price: 119.90, bonus: 200 }
    };

    const selectedPackage = packages[packageId as keyof typeof packages];
    if (!selectedPackage) {
      return res.status(400).json({ error: 'Invalid package ID' });
    }

    const totalCredits = selectedPackage.credits + selectedPackage.bonus;

    // Create transaction record
    const transaction = await prisma.transaction.create({
      data: {
        userId: req.user!.id,
        type: 'credit_purchase',
        amount: selectedPackage.price,
        creditsAdded: totalCredits,
        provider: 'mercadopago',
        status: 'pending',
        externalId: `mp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // Mock MP ID
        paymentData: {
          packageId,
          paymentMethod,
          mockPayment: true
        }
      }
    });

    // Mock Mercado Pago response
    const mockMPResponse = {
      id: transaction.externalId,
      status: 'approved',
      status_detail: 'accredited',
      payment_method_id: paymentMethod,
      payment_type_id: 'credit_card',
      transaction_amount: selectedPackage.price,
      date_created: new Date().toISOString(),
      date_approved: new Date().toISOString(),
      payer: {
        email: req.user!.email
      }
    };

    // Simulate payment processing (auto-approve for mock)
    setTimeout(async () => {
      try {
        // Update transaction status
        await prisma.transaction.update({
          where: { id: transaction.id },
          data: {
            status: 'approved',
            processedAt: new Date(),
            paymentData: mockMPResponse
          }
        });

        // Add credits to user
        await prisma.user.update({
          where: { id: req.user!.id },
          data: { credits: { increment: totalCredits } }
        });

        console.log(`✅ Mock payment approved: ${totalCredits} credits added to user ${req.user!.email}`);
      } catch (error) {
        console.error('Mock payment processing error:', error);
      }
    }, 2000); // 2 second delay to simulate processing

    res.json({
      success: true,
      transaction: {
        id: transaction.id,
        externalId: transaction.externalId,
        status: 'pending',
        amount: selectedPackage.price,
        creditsToAdd: totalCredits
      },
      paymentResponse: mockMPResponse,
      message: 'Payment initiated. Processing...'
    });
  } catch (error) {
    console.error('Purchase error:', error);
    res.status(500).json({ error: 'Failed to process purchase' });
  }
});

// Check transaction status
router.get('/status/:transactionId', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { transactionId } = req.params;

    const transaction = await prisma.transaction.findFirst({
      where: {
        id: transactionId,
        userId: req.user!.id
      }
    });

    if (!transaction) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    res.json({ success: true, transaction });
  } catch (error) {
    console.error('Check transaction status error:', error);
    res.status(500).json({ error: 'Failed to check transaction status' });
  }
});

// Get user's transaction history
router.get('/history', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const { page = 1, limit = 10, type } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = { userId: req.user!.id };
    if (type) {
      where.type = type;
    }

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        select: {
          id: true,
          type: true,
          amount: true,
          creditsAdded: true,
          provider: true,
          status: true,
          createdAt: true,
          processedAt: true,
          externalId: true
        }
      }),
      prisma.transaction.count({ where })
    ]);

    res.json({
      success: true,
      transactions,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get transaction history error:', error);
    res.status(500).json({ error: 'Failed to get transaction history' });
  }
});

// Webhook for Mercado Pago (mock)
router.post('/webhook/mercadopago', async (req, res) => {
  try {
    const { type, data } = req.body;

    if (type === 'payment') {
      const paymentId = data.id;
      
      // Find transaction by external ID
      const transaction = await prisma.transaction.findFirst({
        where: { externalId: paymentId }
      });

      if (transaction && transaction.status === 'pending') {
        // Update transaction and add credits
        await prisma.transaction.update({
          where: { id: transaction.id },
          data: {
            status: 'approved',
            processedAt: new Date()
          }
        });

        await prisma.user.update({
          where: { id: transaction.userId },
          data: { credits: { increment: transaction.creditsAdded } }
        });

        console.log(`✅ Webhook: Payment ${paymentId} approved`);
      }
    }

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Admin: Manual credit adjustment
router.post('/admin/adjust-credits', authenticateToken, async (req: AuthRequest, res) => {
  try {
    // Check if user is admin
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id }
    });

    if (!user || user.plan !== 'admin') {
      return res.status(403).json({ error: 'Admin access required' });
    }

    const { userId, credits, reason = 'manual_adjustment' } = req.body;

    if (!userId || credits === undefined) {
      return res.status(400).json({ error: 'User ID and credits amount required' });
    }

    // Update user credits
    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: { credits: { increment: credits } }
    });

    // Create transaction record
    await prisma.transaction.create({
      data: {
        userId,
        type: credits > 0 ? 'bonus' : 'adjustment',
        amount: 0,
        creditsAdded: credits,
        provider: 'manual',
        status: 'approved',
        processedAt: new Date(),
        paymentData: { reason, adminId: req.user!.id }
      }
    });

    res.json({
      success: true,
      message: `${Math.abs(credits)} credits ${credits > 0 ? 'added to' : 'deducted from'} user`,
      newBalance: updatedUser.credits
    });
  } catch (error) {
    console.error('Admin credit adjustment error:', error);
    res.status(500).json({ error: 'Failed to adjust credits' });
  }
});

export default router;