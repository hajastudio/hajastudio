import express from 'express';
import { prisma } from '../index';
import { authenticateToken, requireAdmin, AuthRequest } from '../middleware/auth.middleware';

const router = express.Router();

// Get all active agents
router.get('/', async (req, res) => {
  try {
    const agents = await prisma.agent.findMany({
      where: { active: true },
      select: {
        id: true,
        name: true,
        description: true,
        defaultModel: true,
        costPerToken: true
      }
    });

    res.json(agents);
  } catch (error) {
    console.error('Get agents error:', error);
    res.status(500).json({ error: 'Failed to get agents' });
  }
});

// Get agent by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const agent = await prisma.agent.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        description: true,
        defaultModel: true,
        active: true,
        systemPrompt: true,
        temperature: true,
        maxTokens: true,
        costPerToken: true
      }
    });

    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    res.json(agent);
  } catch (error) {
    console.error('Get agent error:', error);
    res.status(500).json({ error: 'Failed to get agent' });
  }
});

// Admin: Create new agent
router.post('/', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const {
      name,
      description,
      defaultModel,
      systemPrompt,
      temperature = 0.7,
      maxTokens = 2000,
      costPerToken = 0.001
    } = req.body;

    if (!name || !description || !defaultModel) {
      return res.status(400).json({ 
        error: 'Name, description, and defaultModel are required' 
      });
    }

    const agent = await prisma.agent.create({
      data: {
        name,
        description,
        defaultModel,
        systemPrompt,
        temperature,
        maxTokens,
        costPerToken,
        active: true
      }
    });

    res.status(201).json(agent);
  } catch (error) {
    console.error('Create agent error:', error);
    res.status(500).json({ error: 'Failed to create agent' });
  }
});

// Admin: Update agent
router.put('/:id', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    const agent = await prisma.agent.update({
      where: { id },
      data: updateData
    });

    res.json(agent);
  } catch (error) {
    console.error('Update agent error:', error);
    res.status(500).json({ error: 'Failed to update agent' });
  }
});

// Admin: Toggle agent active status
router.patch('/:id/toggle', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const agent = await prisma.agent.findUnique({
      where: { id },
      select: { active: true }
    });

    if (!agent) {
      return res.status(404).json({ error: 'Agent not found' });
    }

    const updatedAgent = await prisma.agent.update({
      where: { id },
      data: { active: !agent.active }
    });

    res.json(updatedAgent);
  } catch (error) {
    console.error('Toggle agent error:', error);
    res.status(500).json({ error: 'Failed to toggle agent status' });
  }
});

// Admin: Delete agent
router.delete('/:id', authenticateToken, requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    await prisma.agent.delete({
      where: { id }
    });

    res.json({ message: 'Agent deleted successfully' });
  } catch (error) {
    console.error('Delete agent error:', error);
    res.status(500).json({ error: 'Failed to delete agent' });
  }
});

export default router;