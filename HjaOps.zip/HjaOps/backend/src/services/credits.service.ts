import { prisma } from '../index';

export class CreditsService {
  // Add credits to user account
  static async addCredits(userId: string, amount: number, reason: string = 'purchase'): Promise<number> {
    try {
      const user = await prisma.user.update({
        where: { id: userId },
        data: { credits: { increment: amount } },
        select: { credits: true }
      });

      // Log the credit addition
      await prisma.transaction.create({
        data: {
          userId,
          type: reason,
          amount: 0, // No money involved in direct credit additions
          creditsAdded: amount,
          provider: 'manual',
          status: 'approved'
        }
      });

      console.log(`Added ${amount} credits to user ${userId}. New balance: ${user.credits}`);
      return user.credits;
    } catch (error) {
      console.error('Error adding credits:', error);
      throw new Error('Failed to add credits');
    }
  }

  // Deduct credits from user account
  static async deductCredits(userId: string, amount: number, reason: string = 'usage'): Promise<number> {
    try {
      const user = await prisma.user.update({
        where: { 
          id: userId,
          credits: { gte: amount } // Ensure sufficient credits
        },
        data: { credits: { decrement: amount } },
        select: { credits: true }
      });

      // Log the usage
      await this.logUsage(userId, amount, reason);

      console.log(`Deducted ${amount} credits from user ${userId}. New balance: ${user.credits}`);
      return user.credits;
    } catch (error) {
      if (error.code === 'P2025') {
        throw new Error('Insufficient credits');
      }
      console.error('Error deducting credits:', error);
      throw new Error('Failed to deduct credits');
    }
  }

  // Get user's current credit balance
  static async getBalance(userId: string): Promise<number> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { credits: true }
      });

      if (!user) {
        throw new Error('User not found');
      }

      return user.credits;
    } catch (error) {
      console.error('Error getting credit balance:', error);
      throw new Error('Failed to get credit balance');
    }
  }

  // Check if user has enough credits
  static async hasEnoughCredits(userId: string, requiredAmount: number): Promise<boolean> {
    try {
      const balance = await this.getBalance(userId);
      return balance >= requiredAmount;
    } catch (error) {
      console.error('Error checking credits:', error);
      return false;
    }
  }

  // Get user's transaction history
  static async getTransactionHistory(userId: string, limit: number = 50) {
    try {
      const transactions = await prisma.transaction.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        take: limit,
        select: {
          id: true,
          type: true,
          amount: true,
          creditsAdded: true,
          provider: true,
          status: true,
          createdAt: true,
          externalId: true
        }
      });

      return transactions;
    } catch (error) {
      console.error('Error getting transaction history:', error);
      throw new Error('Failed to get transaction history');
    }
  }

  // Calculate credits needed for operation
  static calculateCreditsForTokens(tokens: number, costPerToken: number = 0.001): number {
    return Math.max(1, Math.ceil(tokens * costPerToken));
  }

  // Estimate tokens from text
  static estimateTokens(text: string): number {
    // Rough estimation: ~4 characters per token
    return Math.ceil(text.length / 4);
  }

  // Process credit purchase transaction
  static async processPurchase(
    userId: string, 
    packageType: string, 
    amount: number, 
    credits: number,
    externalId?: string,
    paymentData?: any
  ) {
    try {
      // Create transaction record
      const transaction = await prisma.transaction.create({
        data: {
          userId,
          type: 'credit_purchase',
          amount,
          creditsAdded: credits,
          provider: 'mercadopago',
          status: 'pending',
          externalId,
          paymentData
        }
      });

      return transaction;
    } catch (error) {
      console.error('Error processing purchase:', error);
      throw new Error('Failed to process purchase');
    }
  }

  // Confirm payment and add credits
  static async confirmPayment(transactionId: string) {
    try {
      const transaction = await prisma.transaction.findUnique({
        where: { id: transactionId },
        include: { user: true }
      });

      if (!transaction) {
        throw new Error('Transaction not found');
      }

      if (transaction.status === 'approved') {
        throw new Error('Transaction already processed');
      }

      // Update transaction status
      await prisma.transaction.update({
        where: { id: transactionId },
        data: { 
          status: 'approved',
          processedAt: new Date()
        }
      });

      // Add credits to user
      await this.addCredits(transaction.userId, transaction.creditsAdded, 'purchase');

      console.log(`Payment confirmed for transaction ${transactionId}. Added ${transaction.creditsAdded} credits.`);
      return transaction;
    } catch (error) {
      console.error('Error confirming payment:', error);
      throw new Error('Failed to confirm payment');
    }
  }

  // Log credit usage for analytics
  private static async logUsage(userId: string, credits: number, action: string) {
    try {
      await prisma.usage.create({
        data: {
          userId,
          agentId: 'system',
          action,
          tokens: 0,
          cost: credits,
          provider: 'credits',
          model: 'credits',
          success: true
        }
      });
    } catch (error) {
      console.error('Failed to log usage:', error);
      // Don't throw - logging failure shouldn't break main operation
    }
  }

  // Get credit packages available for purchase
  static getCreditPackages() {
    return [
      {
        id: 'starter',
        name: 'Pacote Inicial',
        credits: 100,
        price: 19.90,
        bonus: 10,
        description: 'Ideal para começar'
      },
      {
        id: 'popular',
        name: 'Pacote Popular',
        credits: 250,
        price: 39.90,
        bonus: 30,
        description: 'Mais popular',
        featured: true
      },
      {
        id: 'pro',
        name: 'Pacote Pro',
        credits: 500,
        price: 69.90,
        bonus: 75,
        description: 'Para usuários avançados'
      },
      {
        id: 'enterprise',
        name: 'Pacote Enterprise',
        credits: 1000,
        price: 119.90,
        bonus: 200,
        description: 'Para empresas'
      }
    ];
  }
}