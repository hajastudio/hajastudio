import express from "express";
import dotenv from "dotenv";
import { PrismaClient } from "@prisma/client";
import { hvcOrchestrator } from "./services/ai/orchestrator.service";

dotenv.config();
const app = express();
const prisma = new PrismaClient();

app.use(express.json());

// CORS simples
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// ✅ Rota teste
app.get("/", (req, res) => {
  res.send("🚀 Hja²Ops Backend Online");
});

/* ============ AUTH ============ */

// Mock user auth (demo purposes)
const DEMO_USER = {
  id: "demo-user-123",
  email: "demo@haja.app",
  credits: 50,
  plan: "pro"
};

app.get("/api/auth/user", (req, res) => {
  res.json({ user: DEMO_USER });
});

app.get("/api/auth/me", (req, res) => {
  res.json({ user: DEMO_USER });
});

/* ============ AGENTS ============ */

// Listar agentes disponíveis
app.get("/api/agents", async (req, res) => {
  try {
    const agents = await prisma.agent.findMany({ where: { active: true } });
    res.json({ agents });
  } catch (error) {
    res.status(400).json({ error: "Erro ao buscar agentes" });
  }
});

/* ============ CHAT ============ */

// Processar chat via HVC Core
app.post("/api/chat", async (req, res) => {
  const { message, agentId } = req.body;
  
  try {
    console.log(`🤖 Processando chat: agente=${agentId}, mensagem="${message.substring(0, 50)}..."`);
    
    const chatRequest = {
      agentId,
      messages: [{ role: 'user' as const, content: message }],
      userId: DEMO_USER.id
    };

    const response = await hvcOrchestrator.processChat(chatRequest);
    
    // Simulação de gasto de créditos
    const creditsUsed = Math.max(1, Math.floor(response.tokensUsed / 100));
    
    res.json({
      response: response.content,
      tokensUsed: response.tokensUsed,
      model: response.model,
      provider: response.provider,
      cost: response.cost,
      creditsUsed,
      processingTime: response.processingTime
    });

  } catch (error: any) {
    console.error("❌ Erro no chat:", error);
    res.status(400).json({ error: error.message || "Erro ao processar chat" });
  }
});

/* ============ CHATS HISTORY ============ */

// Histórico de chats
app.get("/api/chats", async (req, res) => {
  try {
    const chats = await prisma.chat.findMany({
      where: { userId: DEMO_USER.id },
      orderBy: { createdAt: 'desc' },
      take: 20
    });
    res.json({ chats });
  } catch (error) {
    res.json({ chats: [] }); // Retornar vazio em caso de erro
  }
});

/* ============ TRANSACTIONS ============ */

// Listar transações
app.get("/api/transactions", async (req, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: { userId: DEMO_USER.id },
      orderBy: { createdAt: 'desc' },
      take: 20
    });
    res.json({ transactions });
  } catch (error) {
    res.json({ transactions: [] }); // Retornar vazio em caso de erro
  }
});

// Criar transação
app.post("/api/transactions", async (req, res) => {
  const { type, creditsAdded, amount } = req.body;
  try {
    const txn = await prisma.transaction.create({
      data: { 
        userId: DEMO_USER.id,
        type,
        amount: amount || 0,
        creditsAdded: creditsAdded || 0,
        provider: "mercado_pago"
      },
    });

    res.json({ success: true, transaction: txn });
  } catch (error) {
    res.status(400).json({ error: "Erro ao criar transação" });
  }
});

/* ============ ADMIN ============ */

// Status do sistema (Admin)
app.get("/api/admin/usage", (req, res) => {
  const stats = hvcOrchestrator.getSystemStats();
  res.json({
    success: true,
    overview: {
      totalUsers: 1,
      totalChats: 12,
      totalTransactions: 3,
      systemStatus: stats.systemStatus
    },
    topUsers: [{
      userId: DEMO_USER.id,
      userEmail: DEMO_USER.email,
      totalChats: 12,
      totalTokens: 5420
    }],
    estimatedCosts: {
      totalTokens: 15420,
      estimatedCostUSD: 1.542,
      creditsIssued: 50,
      totalTransactionValue: 39.90
    },
    hvcStats: stats,
    recentChats: [{
      id: "chat-1",
      userEmail: DEMO_USER.email,
      title: "Chat com Roteirista",
      tokens: 234,
      modelUsed: "groq/llama-3.1-70b",
      createdAt: new Date().toISOString()
    }]
  });
});

app.get("/api/admin/users", (req, res) => {
  res.json({
    users: [{
      id: DEMO_USER.id,
      email: DEMO_USER.email,
      credits: DEMO_USER.credits,
      plan: DEMO_USER.plan,
      createdAt: new Date().toISOString(),
      _count: { chats: 12 }
    }]
  });
});

app.get("/api/admin/system", (req, res) => {
  const alerts = hvcOrchestrator.getRecentAlerts(10);
  res.json({
    system: {
      alerts,
      database: {
        users: 1,
        chats: 12,
        agents: 3,
        transactions: 3
      }
    }
  });
});

app.post("/api/admin/users/:userId/credits", (req, res) => {
  const { credits, reason } = req.body;
  res.json({ 
    success: true, 
    message: `${credits} créditos adicionados com sucesso`,
    reason 
  });
});

/* ============ USER STATS ============ */

app.get("/api/user/:userId", (req, res) => {
  res.json({
    stats: {
      totalChats: 12,
      totalTransactions: 3,
      totalTokensUsed: 5420,
      tokensLastWeek: 1200,
      averageTokensPerChat: 452
    }
  });
});

/* ============ HEALTH CHECK ============ */

app.get("/health", (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    service: 'Hja²Ops Backend with HVC Core'
  });
});

/* ============ SERVER ============ */

const PORT = process.env.PORT || 5000; // Usar porta 5000 para frontend
app.listen(PORT, () => {
  console.log(`🚀 Hja²Ops Backend with HVC Core running at http://localhost:${PORT}`);
  console.log(`🧠 HVC Core: Sistema de orquestração IA ativo`);
  console.log(`🔥 Agentes disponíveis: Roteirista, Vibe Code, Agente Viral`);
});