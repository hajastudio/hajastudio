import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/db';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    plan: string;
    credits: number;
  };
}

export const creditsMiddleware = (minimumCredits: number = 1) => {
  return async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Autenticação necessária'
        });
      }

      // Buscar créditos atualizados do usuário
      const user = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { credits: true, plan: true }
      });

      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Usuário não encontrado'
        });
      }

      if (user.credits < minimumCredits) {
        return res.status(403).json({
          success: false,
          message: 'Créditos insuficientes para realizar esta ação',
          currentCredits: user.credits,
          requiredCredits: minimumCredits
        });
      }

      // Atualizar dados do usuário na requisição
      req.user.credits = user.credits;
      next();

    } catch (error) {
      console.error('❌ Erro ao verificar créditos:', error);
      res.status(500).json({
        success: false,
        message: 'Erro interno do servidor'
      });
    }
  };
};