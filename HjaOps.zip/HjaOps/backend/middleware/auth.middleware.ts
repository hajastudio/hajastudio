import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/db';

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    plan: string;
    credits: number;
  };
}

export const authMiddleware = async (req: AuthRequest, res: Response, next: NextFunction) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token de autorização não fornecido'
      });
    }

    // Validar token (mock: token é o próprio ID do usuário)
    const user = await prisma.user.findUnique({
      where: { id: token },
      select: {
        id: true,
        email: true,
        plan: true,
        credits: true
      }
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Token inválido ou usuário não encontrado'
      });
    }

    req.user = user;
    next();

  } catch (error) {
    console.error('❌ Erro na autenticação:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
};

export const adminMiddleware = (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Autenticação necessária'
    });
  }

  if (req.user.plan !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Acesso negado. Permissão de administrador necessária'
    });
  }

  next();
};