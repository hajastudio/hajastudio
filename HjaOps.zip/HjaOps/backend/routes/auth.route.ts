import express from 'express';
import { prisma } from '../config/db';
import { z } from 'zod';

const router = express.Router();

// Schema de validação para login
const loginSchema = z.object({
  email: z.string().email('Email inválido')
});

// POST /auth/login - Login simples com email
router.post('/login', async (req, res) => {
  try {
    const { email } = loginSchema.parse(req.body);

    // Buscar ou criar usuário
    let user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) {
      // Criar usuário automaticamente no primeiro login
      user = await prisma.user.create({
        data: {
          email,
          credits: 50, // Créditos iniciais
          plan: 'free'
        }
      });
      console.log(`✅ Novo usuário criado: ${email}`);
    } else {
      // Atualizar último login
      user = await prisma.user.update({
        where: { id: user.id },
        data: { lastLogin: new Date() }
      });
    }

    // Gerar token simples (em produção, use JWT)
    const token = user.id; // Mock: usar ID como token

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        credits: user.credits,
        plan: user.plan,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('❌ Erro no login:', error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: error.errors
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /auth/me - Verificar token e obter dados do usuário
router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Token não fornecido'
      });
    }

    // Validar token (mock: token é o próprio ID)
    const user = await prisma.user.findUnique({
      where: { id: token }
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Token inválido'
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        credits: user.credits,
        plan: user.plan,
        profile: user.profile,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin
      }
    });

  } catch (error) {
    console.error('❌ Erro ao verificar token:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

export default router;