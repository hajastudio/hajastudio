import express from 'express';
import { prisma } from '../config/db';

const router = express.Router();

// GET /agents - Listar agentes ativos
router.get('/', async (req, res) => {
  try {
    const agents = await prisma.agent.findMany({
      where: { active: true },
      orderBy: { id: 'asc' }
    });

    res.json({
      success: true,
      agents
    });

  } catch (error) {
    console.error('❌ Erro ao listar agentes:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /agents/:id - Obter agente específico
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const agent = await prisma.agent.findFirst({
      where: {
        id,
        active: true
      }
    });

    if (!agent) {
      return res.status(404).json({
        success: false,
        message: 'Agente não encontrado'
      });
    }

    res.json({
      success: true,
      agent
    });

  } catch (error) {
    console.error('❌ Erro ao buscar agente:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

export default router;