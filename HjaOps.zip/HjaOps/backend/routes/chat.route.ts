import express from 'express';
import { prisma } from '../config/db';
import { hvcOrchestrator } from '../services/ai/orchestrator.service';
import { creditsMiddleware } from '../middleware/credits.middleware';
import { z } from 'zod';

const router = express.Router();

// Schema de validação para chat
const chatRequestSchema = z.object({
  agentId: z.string().min(1, 'Agent ID é obrigatório'),
  message: z.string().min(1, 'Mensagem é obrigatória'),
  model: z.string().optional(),
  temperature: z.number().min(0).max(2).optional()
});

// POST /chat - Envia mensagem, valida créditos, chama orquestrador
router.post('/', creditsMiddleware(5), async (req: any, res) => {
  try {
    const userId = req.user.id;
    const validatedData = chatRequestSchema.parse(req.body);

    // Verificar se o agente existe e está ativo
    const agent = await prisma.agent.findFirst({
      where: {
        id: validatedData.agentId,
        active: true
      }
    });

    if (!agent) {
      return res.status(404).json({
        success: false,
        message: 'Agente não encontrado ou inativo'
      });
    }

    // Preparar mensagens para o HVC Core
    const messages = [
      {
        role: 'system' as const,
        content: agent.prompt
      },
      {
        role: 'user' as const,
        content: validatedData.message
      }
    ];

    // Processar com HVC Core
    const response = await hvcOrchestrator.processChat({
      agentId: validatedData.agentId,
      messages,
      userId,
      model: validatedData.model,
      temperature: validatedData.temperature
    });

    // Deduzir créditos do usuário
    const creditsUsed = Math.ceil(response.tokensUsed / 100); // 1 crédito por 100 tokens
    await prisma.user.update({
      where: { id: userId },
      data: {
        credits: {
          decrement: creditsUsed
        }
      }
    });

    // Salvar chat no banco
    const chatMessages = [
      {
        role: 'user',
        content: validatedData.message,
        timestamp: new Date().toISOString()
      },
      {
        role: 'assistant',
        content: response.content,
        timestamp: new Date().toISOString(),
        tokensUsed: response.tokensUsed
      }
    ];

    const chat = await prisma.chat.create({
      data: {
        userId,
        agentId: validatedData.agentId,
        title: validatedData.message.substring(0, 100),
        messages: JSON.stringify(chatMessages),
        modelUsed: response.model,
        tokens: response.tokensUsed
      }
    });

    res.json({
      success: true,
      chatId: chat.id,
      response: response.content,
      tokensUsed: response.tokensUsed,
      creditsUsed,
      model: response.model,
      provider: response.provider,
      processingTime: response.processingTime
    });

  } catch (error: any) {
    console.error('❌ Erro no chat:', error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: error.errors
      });
    }

    if (error.message === 'Créditos insuficientes') {
      return res.status(403).json({
        success: false,
        message: 'Créditos insuficientes para esta operação'
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /chat/:chatId - Obter histórico do chat
router.get('/:chatId', async (req: any, res) => {
  try {
    const { chatId } = req.params;
    const userId = req.user.id;

    const chat = await prisma.chat.findFirst({
      where: {
        id: chatId,
        userId
      },
      include: {
        user: {
          select: {
            email: true
          }
        }
      }
    });

    if (!chat) {
      return res.status(404).json({
        success: false,
        message: 'Chat não encontrado'
      });
    }

    res.json({
      success: true,
      chat: {
        id: chat.id,
        title: chat.title,
        messages: typeof chat.messages === 'string' 
          ? JSON.parse(chat.messages) 
          : chat.messages,
        modelUsed: chat.modelUsed,
        tokens: chat.tokens,
        createdAt: chat.createdAt,
        agentId: chat.agentId
      }
    });

  } catch (error) {
    console.error('❌ Erro ao buscar chat:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /chat - Listar chats do usuário
router.get('/', async (req: any, res) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const [chats, total] = await Promise.all([
      prisma.chat.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id: true,
          title: true,
          agentId: true,
          modelUsed: true,
          tokens: true,
          createdAt: true
        }
      }),
      prisma.chat.count({
        where: { userId }
      })
    ]);

    res.json({
      success: true,
      chats,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('❌ Erro ao listar chats:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

export default router;