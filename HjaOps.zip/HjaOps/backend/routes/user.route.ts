import express from 'express';
import { prisma } from '../config/db';
import { TokensService } from '../services/tokens.service';

const router = express.Router();
const tokensService = new TokensService();

// GET /user/:id - Perfil + créditos
router.get('/:id', async (req: any, res) => {
  try {
    const { id } = req.params;
    const currentUserId = req.user.id;

    // Verificar se o usuário pode acessar este perfil
    if (id !== currentUserId && req.user.plan !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Acesso negado'
      });
    }

    // Buscar dados do usuário
    const user = await prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        credits: true,
        plan: true,
        profile: true,
        createdAt: true,
        lastLogin: true
      }
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }

    // Estatísticas do usuário
    const [totalChats, totalTransactions, recentChats] = await Promise.all([
      prisma.chat.count({
        where: { userId: id }
      }),
      prisma.transaction.count({
        where: { userId: id }
      }),
      prisma.chat.findMany({
        where: { userId: id },
        orderBy: { createdAt: 'desc' },
        take: 5,
        select: {
          id: true,
          title: true,
          tokens: true,
          modelUsed: true,
          createdAt: true,
          agentId: true
        }
      })
    ]);

    // Calcular estatísticas de tokens
    const allChats = await prisma.chat.findMany({
      where: { userId: id },
      select: {
        tokens: true,
        modelUsed: true,
        createdAt: true
      }
    });

    const tokensStats = tokensService.calculateUsageStats(
      allChats.map(chat => ({
        tokens: chat.tokens,
        model: chat.modelUsed,
        createdAt: chat.createdAt
      }))
    );

    res.json({
      success: true,
      user,
      stats: {
        totalChats,
        totalTransactions,
        totalTokensUsed: tokensStats.totalTokens,
        tokensLastWeek: tokensStats.tokensLastWeek,
        averageTokensPerChat: tokensStats.averageTokensPerConversation
      },
      recentChats,
      tokensStats
    });

  } catch (error) {
    console.error('❌ Erro ao buscar perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// PUT /user/:id - Atualizar perfil
router.put('/:id', async (req: any, res) => {
  try {
    const { id } = req.params;
    const currentUserId = req.user.id;

    // Verificar se o usuário pode atualizar este perfil
    if (id !== currentUserId) {
      return res.status(403).json({
        success: false,
        message: 'Acesso negado'
      });
    }

    const { profile } = req.body;

    const updatedUser = await prisma.user.update({
      where: { id },
      data: {
        profile,
        lastLogin: new Date()
      },
      select: {
        id: true,
        email: true,
        credits: true,
        plan: true,
        profile: true,
        createdAt: true,
        lastLogin: true
      }
    });

    res.json({
      success: true,
      user: updatedUser
    });

  } catch (error) {
    console.error('❌ Erro ao atualizar perfil:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /user/:id/credits - Histórico de créditos
router.get('/:id/credits', async (req: any, res) => {
  try {
    const { id } = req.params;
    const currentUserId = req.user.id;

    if (id !== currentUserId && req.user.plan !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Acesso negado'
      });
    }

    // Histórico de transações (créditos adicionados)
    const transactions = await prisma.transaction.findMany({
      where: { userId: id },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    // Histórico de chats (créditos gastos)
    const chats = await prisma.chat.findMany({
      where: { userId: id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      select: {
        id: true,
        title: true,
        tokens: true,
        modelUsed: true,
        createdAt: true
      }
    });

    const creditsSpent = chats.reduce((total, chat) => {
      return total + tokensService.tokensToCredits(chat.tokens);
    }, 0);

    const creditsAdded = transactions.reduce((total, transaction) => {
      return total + transaction.creditsAdded;
    }, 0);

    res.json({
      success: true,
      creditsHistory: {
        current: req.user.credits,
        totalAdded: creditsAdded,
        totalSpent: creditsSpent,
        transactions: transactions.map(t => ({
          id: t.id,
          type: t.type,
          amount: t.amount,
          creditsAdded: t.creditsAdded,
          createdAt: t.createdAt
        })),
        recentUsage: chats.map(c => ({
          id: c.id,
          title: c.title,
          tokens: c.tokens,
          creditsUsed: tokensService.tokensToCredits(c.tokens),
          model: c.modelUsed,
          createdAt: c.createdAt
        }))
      }
    });

  } catch (error) {
    console.error('❌ Erro ao buscar histórico de créditos:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

export default router;