import express from 'express';
import { prisma } from '../config/db';
import { z } from 'zod';

const router = express.Router();

// Schema de validação para transação
const transactionSchema = z.object({
  type: z.enum(['credits', 'plan']),
  amount: z.number().positive('Valor deve ser positivo'),
  creditsAdded: z.number().min(0),
  provider: z.string().default('mercadopago')
});

// POST /transactions - Registrar compra de créditos (via Mercado Pago)
router.post('/', async (req: any, res) => {
  try {
    const userId = req.user.id;
    const validatedData = transactionSchema.parse(req.body);

    // Simular processamento do Mercado Pago
    const mpResponse = await processMercadoPago({
      amount: validatedData.amount,
      userId,
      description: `Compra de ${validatedData.creditsAdded} créditos`
    });

    // Criar transação no banco
    const transaction = await prisma.transaction.create({
      data: {
        userId,
        type: validatedData.type,
        amount: validatedData.amount,
        creditsAdded: validatedData.creditsAdded,
        provider: validatedData.provider
      }
    });

    // Adicionar créditos ao usuário se transação foi aprovada
    if (mpResponse.status === 'approved') {
      await prisma.user.update({
        where: { id: userId },
        data: {
          credits: {
            increment: validatedData.creditsAdded
          }
        }
      });
    }

    res.json({
      success: true,
      transaction: {
        id: transaction.id,
        status: mpResponse.status,
        paymentUrl: mpResponse.paymentUrl,
        amount: transaction.amount,
        creditsAdded: transaction.creditsAdded
      }
    });

  } catch (error: any) {
    console.error('❌ Erro na transação:', error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Dados inválidos',
        errors: error.errors
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Erro ao processar transação'
    });
  }
});

// GET /transactions - Listar transações do usuário
router.get('/', async (req: any, res) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const [transactions, total] = await Promise.all([
      prisma.transaction.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      prisma.transaction.count({
        where: { userId }
      })
    ]);

    res.json({
      success: true,
      transactions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('❌ Erro ao listar transações:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// Mock do Mercado Pago
async function processMercadoPago(data: { amount: number; userId: string; description: string }) {
  // Simular processamento do pagamento
  console.log('💳 Processando pagamento Mercado Pago:', data);
  
  // Simular delay da API
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock de resposta aprovada
  return {
    status: 'approved',
    paymentUrl: `https://mercadopago.com/payment/mock-${Date.now()}`,
    transactionId: `mp_${Date.now()}`
  };
}

export default router;