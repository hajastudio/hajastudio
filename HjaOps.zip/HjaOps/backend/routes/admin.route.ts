import express from 'express';
import { prisma } from '../config/db';
import { adminMiddleware } from '../middleware/auth.middleware';
import { hvcOrchestrator } from '../services/ai/orchestrator.service';
import { TokensService } from '../services/tokens.service';

const router = express.Router();
const tokensService = new TokensService();

// Aplicar middleware de admin em todas as rotas
router.use(adminMiddleware);

// GET /admin/usage - Métricas (tokens, custos, alertas)
router.get('/usage', async (req, res) => {
  try {
    // Estatísticas gerais do sistema
    const [totalUsers, totalChats, totalTransactions] = await Promise.all([
      prisma.user.count(),
      prisma.chat.count(),
      prisma.transaction.count()
    ]);

    // Últimas 100 interações para análise
    const recentChats = await prisma.chat.findMany({
      orderBy: { createdAt: 'desc' },
      take: 100,
      include: {
        user: {
          select: { email: true }
        }
      }
    });

    // Calcular estatísticas de tokens
    const allChats = await prisma.chat.findMany({
      select: {
        tokens: true,
        modelUsed: true,
        createdAt: true
      }
    });

    const tokensStats = tokensService.calculateUsageStats(
      allChats.map(chat => ({
        tokens: chat.tokens,
        model: chat.modelUsed,
        createdAt: chat.createdAt
      }))
    );

    // Usuários mais ativos
    const userUsage = await prisma.chat.groupBy({
      by: ['userId'],
      _count: { userId: true },
      _sum: { tokens: true },
      orderBy: { _count: { userId: 'desc' } },
      take: 10
    });

    // Buscar dados dos usuários
    const userIds = userUsage.map(u => u.userId);
    const users = await prisma.user.findMany({
      where: { id: { in: userIds } },
      select: { id: true, email: true }
    });

    const userMap = users.reduce((acc, user) => {
      acc[user.id] = user.email;
      return acc;
    }, {} as Record<string, string>);

    const topUsers = userUsage.map(usage => ({
      userId: usage.userId,
      userEmail: userMap[usage.userId] || 'Email não encontrado',
      totalChats: usage._count.userId,
      totalTokens: usage._sum.tokens || 0
    }));

    // Alertas do HVC Core
    const systemStats = hvcOrchestrator.getSystemStats();
    const recentAlerts = hvcOrchestrator.getRecentAlerts(20);

    // Custos estimados
    const totalTokens = tokensStats.totalTokens;
    const estimatedCosts = {
      totalTokens,
      estimatedCostUSD: (totalTokens * 0.0001), // $0.0001 por token média
      creditsIssued: await prisma.transaction.aggregate({
        _sum: { creditsAdded: true }
      }).then(result => result._sum.creditsAdded || 0),
      totalTransactionValue: await prisma.transaction.aggregate({
        _sum: { amount: true }
      }).then(result => result._sum.amount || 0)
    };

    res.json({
      success: true,
      overview: {
        totalUsers,
        totalChats,
        totalTransactions,
        systemStatus: systemStats.systemStatus
      },
      tokensStats,
      topUsers,
      estimatedCosts,
      recentChats: recentChats.slice(0, 20).map(chat => ({
        id: chat.id,
        userEmail: chat.user.email,
        title: chat.title,
        tokens: chat.tokens,
        modelUsed: chat.modelUsed,
        createdAt: chat.createdAt
      })),
      hvcStats: {
        ...systemStats,
        recentAlerts: recentAlerts.map(alert => ({
          type: alert.type,
          message: alert.message,
          severity: alert.severity,
          timestamp: alert.timestamp,
          userId: alert.userId
        }))
      }
    });

  } catch (error) {
    console.error('❌ Erro nas métricas admin:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /admin/users - Listar todos os usuários
router.get('/users', async (req, res) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id: true,
          email: true,
          credits: true,
          plan: true,
          createdAt: true,
          lastLogin: true,
          _count: {
            select: {
              chats: true,
              transactions: true
            }
          }
        }
      }),
      prisma.user.count()
    ]);

    res.json({
      success: true,
      users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    console.error('❌ Erro ao listar usuários:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// POST /admin/users/:id/credits - Adicionar créditos manualmente
router.post('/users/:id/credits', async (req, res) => {
  try {
    const { id } = req.params;
    const { credits, reason } = req.body;

    if (!credits || credits <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Valor de créditos inválido'
      });
    }

    // Atualizar créditos do usuário
    const user = await prisma.user.update({
      where: { id },
      data: {
        credits: {
          increment: credits
        }
      }
    });

    // Registrar transação administrativa
    await prisma.transaction.create({
      data: {
        userId: id,
        type: 'credits',
        amount: 0, // Sem cobrança
        creditsAdded: credits,
        provider: `admin_${reason || 'manual'}`
      }
    });

    res.json({
      success: true,
      message: `${credits} créditos adicionados ao usuário`,
      user: {
        id: user.id,
        email: user.email,
        credits: user.credits
      }
    });

  } catch (error) {
    console.error('❌ Erro ao adicionar créditos:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

// GET /admin/system - Status detalhado do sistema
router.get('/system', async (req, res) => {
  try {
    const systemStats = hvcOrchestrator.getSystemStats();
    const recentAlerts = hvcOrchestrator.getRecentAlerts(50);

    // Estatísticas do banco de dados
    const dbStats = await Promise.all([
      prisma.user.count(),
      prisma.chat.count(),
      prisma.agent.count(),
      prisma.transaction.count(),
    ]);

    // Últimas atividades
    const [recentUsers, recentChats, recentTransactions] = await Promise.all([
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        select: { id: true, email: true, createdAt: true }
      }),
      prisma.chat.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: { user: { select: { email: true } } }
      }),
      prisma.transaction.findMany({
        orderBy: { createdAt: 'desc' },
        take: 5,
        include: { user: { select: { email: true } } }
      })
    ]);

    res.json({
      success: true,
      system: {
        status: systemStats.systemStatus,
        database: {
          users: dbStats[0],
          chats: dbStats[1],
          agents: dbStats[2],
          transactions: dbStats[3]
        },
        hvc: systemStats,
        alerts: recentAlerts,
        recentActivity: {
          users: recentUsers,
          chats: recentChats.map(chat => ({
            id: chat.id,
            title: chat.title,
            userEmail: chat.user.email,
            createdAt: chat.createdAt
          })),
          transactions: recentTransactions.map(tx => ({
            id: tx.id,
            type: tx.type,
            amount: tx.amount,
            userEmail: tx.user.email,
            createdAt: tx.createdAt
          }))
        }
      }
    });

  } catch (error) {
    console.error('❌ Erro no status do sistema:', error);
    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
});

export default router;