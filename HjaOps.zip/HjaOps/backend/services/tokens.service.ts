export class TokensService {
  /**
   * Estima tokens baseado no texto de entrada
   */
  estimateTokens(text: string): number {
    if (!text) return 0;
    
    // Estimativa baseada em:
    // - Palavras em português: ~1.3 tokens por palavra
    // - Caracteres: ~4 caracteres por token
    const wordCount = text.trim().split(/\s+/).length;
    const charBasedEstimate = Math.ceil(text.length / 4);
    const wordBasedEstimate = Math.ceil(wordCount * 1.3);
    
    // Usar a maior estimativa para ser conservador
    return Math.max(wordBasedEstimate, charBasedEstimate);
  }

  /**
   * Calcula tokens de uma conversa completa
   */
  calculateConversationTokens(messages: Array<{ role: string; content: string }>): number {
    let total = 0;
    
    for (const message of messages) {
      // Adicionar tokens do conteúdo
      total += this.estimateTokens(message.content);
      
      // Adicionar tokens do sistema/metadata (role, formatting)
      total += 4; // ~4 tokens para metadata por mensagem
    }
    
    // Adicionar tokens de prompt base
    total += 50; // ~50 tokens para prompt system/formatting
    
    return total;
  }

  /**
   * Previsão de tokens para resposta
   */
  predictResponseTokens(inputTokens: number): number {
    // Baseado em dados históricos, respostas tendem a ser:
    // - 50-200% do tamanho da entrada para conversas normais
    // - Máximo de 1000 tokens para respostas longas
    
    const predictedTokens = Math.min(
      inputTokens * 1.5, // 150% da entrada
      1000 // Máximo de 1000 tokens
    );
    
    return Math.max(predictedTokens, 50); // Mínimo de 50 tokens
  }

  /**
   * Cálculo de custo em créditos
   */
  tokensToCredits(tokens: number, provider: string = 'groq'): number {
    // Conversão padrão: 100 tokens = 1 crédito
    // Ajustado por provedor
    const baseCredits = tokens / 100;
    
    const multipliers: Record<string, number> = {
      'groq': 1.0,
      'huggingface': 0.5,
      'replit': 0.3,
      'emergency': 0.1
    };
    
    const multiplier = multipliers[provider] || 1.0;
    return Math.ceil(baseCredits * multiplier);
  }

  /**
   * Verifica se usuário tem créditos suficientes
   */
  hasEnoughCredits(userCredits: number, estimatedTokens: number, provider: string = 'groq'): boolean {
    const requiredCredits = this.tokensToCredits(estimatedTokens, provider);
    return userCredits >= requiredCredits;
  }

  /**
   * Estatísticas de uso de tokens
   */
  calculateUsageStats(conversations: Array<{ tokens: number; model: string; createdAt: Date }>) {
    const now = new Date();
    const lastHour = new Date(now.getTime() - 60 * 60 * 1000);
    const lastDay = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

    const recentConversations = conversations.filter(c => c.createdAt > lastWeek);
    
    return {
      totalTokens: conversations.reduce((sum, c) => sum + c.tokens, 0),
      tokensLastHour: conversations
        .filter(c => c.createdAt > lastHour)
        .reduce((sum, c) => sum + c.tokens, 0),
      tokensLastDay: conversations
        .filter(c => c.createdAt > lastDay)
        .reduce((sum, c) => sum + c.tokens, 0),
      tokensLastWeek: recentConversations.reduce((sum, c) => sum + c.tokens, 0),
      averageTokensPerConversation: recentConversations.length > 0 
        ? Math.round(recentConversations.reduce((sum, c) => sum + c.tokens, 0) / recentConversations.length)
        : 0,
      modelUsage: this.groupByModel(recentConversations),
      peakUsageHour: this.findPeakUsage(conversations)
    };
  }

  private groupByModel(conversations: Array<{ tokens: number; model: string }>) {
    const usage: Record<string, { count: number; tokens: number }> = {};
    
    for (const conv of conversations) {
      if (!usage[conv.model]) {
        usage[conv.model] = { count: 0, tokens: 0 };
      }
      usage[conv.model].count++;
      usage[conv.model].tokens += conv.tokens;
    }
    
    return usage;
  }

  private findPeakUsage(conversations: Array<{ tokens: number; createdAt: Date }>) {
    const hourlyUsage: Record<string, number> = {};
    
    for (const conv of conversations) {
      const hour = conv.createdAt.toISOString().slice(0, 13); // YYYY-MM-DDTHH
      hourlyUsage[hour] = (hourlyUsage[hour] || 0) + conv.tokens;
    }
    
    const peakHour = Object.entries(hourlyUsage)
      .sort(([, a], [, b]) => b - a)[0];
    
    return peakHour ? {
      hour: peakHour[0],
      tokens: peakHour[1]
    } : null;
  }
}