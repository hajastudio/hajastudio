import { AI_PROVIDERS } from '../../config/providers';
import { GenerateRequest, GenerateResponse } from './groq.service';

export class HuggingFaceService {
  private apiKey: string;
  private baseURL: string;

  constructor() {
    const provider = AI_PROVIDERS.huggingface;
    this.apiKey = provider.apiKey;
    this.baseURL = provider.baseURL;
  }

  async generateResponse(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new Error('HF_API_KEY não configurada');
    }

    try {
      // HuggingFace Inference API
      const response = await fetch(`${this.baseURL}/${request.model}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: this.formatMessagesForHF(request.messages),
          parameters: {
            temperature: request.temperature,
            max_length: request.maxTokens,
            return_full_text: false
          }
        }),
      });

      if (!response.ok) {
        throw new Error(`HuggingFace API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      // HF retorna array de objetos
      const generatedText = Array.isArray(data) 
        ? data[0]?.generated_text || 'Resposta vazia'
        : data.generated_text || 'Resposta vazia';

      return {
        content: generatedText,
        tokensUsed: this.estimateTokens(generatedText),
        model: request.model
      };

    } catch (error) {
      console.error('❌ Erro HuggingFace Service:', error);
      throw error;
    }
  }

  private formatMessagesForHF(messages: Array<{ role: string; content: string }>): string {
    // Converter mensagens para formato de texto simples
    return messages
      .map(msg => `${msg.role === 'user' ? 'Human' : 'Assistant'}: ${msg.content}`)
      .join('\n') + '\nAssistant:';
  }

  private estimateTokens(text: string): number {
    // Estimativa simples: ~4 caracteres por token
    return Math.ceil(text.length / 4);
  }
}