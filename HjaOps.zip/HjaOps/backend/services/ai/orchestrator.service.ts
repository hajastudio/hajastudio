import { AI_PROVIDERS, FALLBACK_CHAIN, DEFAULT_MODEL_SETTINGS } from '../../config/providers';
import { GroqService } from './groq.service';
import { HuggingFaceService } from './hf.service';
import { ReplitService } from './replit.service';
import { TokensService } from '../tokens.service';

export interface ChatRequest {
  agentId: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  userId: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface ChatResponse {
  content: string;
  tokensUsed: number;
  model: string;
  provider: string;
  cost: number;
  processingTime: number;
}

export interface HVCAlert {
  type: 'CREDITS_LOW' | 'API_FAILURE' | 'HIGH_USAGE' | 'COST_SPIKE';
  message: string;
  userId?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
}

/**
 * HVC Core - Algoritmo Inteligente de Orquestração
 * 
 * Funcionalidades:
 * - Orquestração de modelos (Groq, HF, Replit, etc.)
 * - Fallback automático
 * - Previsão de uso de tokens
 * - Alertas (baixa de créditos, falhas técnicas)
 * - Otimização de custos
 */
export class HVCOrchestrator {
  private services: Map<string, any> = new Map();
  private tokensService: TokensService;
  private alerts: HVCAlert[] = [];

  constructor() {
    this.tokensService = new TokensService();
    this.initializeServices();
  }

  private initializeServices() {
    this.services.set('groq', new GroqService());
    this.services.set('huggingface', new HuggingFaceService());
    this.services.set('replit', new ReplitService());
  }

  /**
   * Processamento inteligente de chat
   */
  async processChat(request: ChatRequest): Promise<ChatResponse> {
    const startTime = Date.now();
    
    try {
      // 1. Verificar créditos do usuário
      const userCredits = await this.getUserCredits(request.userId);
      const estimatedTokens = this.tokensService.estimateTokens(
        request.messages[request.messages.length - 1].content
      );
      
      if (userCredits < estimatedTokens * 0.001) {
        this.addAlert({
          type: 'CREDITS_LOW',
          message: `Usuário ${request.userId} com créditos baixos`,
          userId: request.userId,
          severity: 'high',
          timestamp: new Date()
        });
        throw new Error('Créditos insuficientes');
      }

      // 2. Selecionar melhor provedor
      const provider = await this.selectOptimalProvider(request);
      
      // 3. Processar com fallback automático
      const response = await this.processWithFallback(request, provider);
      
      // 4. Calcular métricas
      response.processingTime = Date.now() - startTime;
      response.cost = this.calculateCost(response.tokensUsed, response.provider);

      // 5. Verificar alertas
      this.checkForAlerts(request.userId, response);

      return response;

    } catch (error) {
      console.error('❌ Erro no HVC Core:', error);
      
      // Fallback de emergência
      return {
        content: 'Desculpe, ocorreu um erro temporário. Tente novamente em alguns instantes.',
        tokensUsed: 50,
        model: 'fallback',
        provider: 'emergency',
        cost: 0,
        processingTime: Date.now() - startTime
      };
    }
  }

  /**
   * Seleciona o provedor mais adequado baseado em:
   * - Disponibilidade
   * - Custo
   * - Velocidade
   * - Histórico de performance
   */
  private async selectOptimalProvider(request: ChatRequest): Promise<string> {
    const availableProviders = FALLBACK_CHAIN.filter(provider => 
      this.services.has(provider) && AI_PROVIDERS[provider].apiKey
    );

    if (availableProviders.length === 0) {
      throw new Error('Nenhum provedor de IA disponível');
    }

    // Estratégia: usar o provedor com menor custo e maior prioridade
    return availableProviders.sort((a, b) => {
      const providerA = AI_PROVIDERS[a];
      const providerB = AI_PROVIDERS[b];
      
      // Priorizar por ordem de prioridade e custo
      if (providerA.priority !== providerB.priority) {
        return providerA.priority - providerB.priority;
      }
      
      return providerA.costPerToken - providerB.costPerToken;
    })[0];
  }

  /**
   * Processa com fallback automático
   */
  private async processWithFallback(request: ChatRequest, primaryProvider: string): Promise<ChatResponse> {
    const providers = [primaryProvider, ...FALLBACK_CHAIN.filter(p => p !== primaryProvider)];
    
    for (const providerKey of providers) {
      try {
        const service = this.services.get(providerKey);
        if (!service) continue;

        console.log(`🔄 Tentando provedor: ${providerKey}`);
        
        const response = await service.generateResponse({
          messages: request.messages,
          model: request.model || AI_PROVIDERS[providerKey].models[0],
          ...DEFAULT_MODEL_SETTINGS,
          temperature: request.temperature || DEFAULT_MODEL_SETTINGS.temperature,
          maxTokens: request.maxTokens || DEFAULT_MODEL_SETTINGS.maxTokens
        });

        return {
          ...response,
          provider: providerKey
        };

      } catch (error) {
        console.error(`❌ Falha no provedor ${providerKey}:`, error);
        
        this.addAlert({
          type: 'API_FAILURE',
          message: `Falha no provedor ${providerKey}: ${error}`,
          severity: 'medium',
          timestamp: new Date()
        });
        
        continue; // Tentar próximo provedor
      }
    }

    throw new Error('Todos os provedores falharam');
  }

  /**
   * Calcula custo baseado no provedor e tokens
   */
  private calculateCost(tokens: number, provider: string): number {
    const providerInfo = AI_PROVIDERS[provider];
    if (!providerInfo) return 0;
    
    return tokens * providerInfo.costPerToken;
  }

  /**
   * Verifica alertas automáticos
   */
  private checkForAlerts(userId: string, response: ChatResponse) {
    // Alert de uso alto
    if (response.tokensUsed > 5000) {
      this.addAlert({
        type: 'HIGH_USAGE',
        message: `Uso alto de tokens: ${response.tokensUsed} tokens em uma requisição`,
        userId,
        severity: 'medium',
        timestamp: new Date()
      });
    }

    // Alert de custo elevado
    if (response.cost > 1.0) {
      this.addAlert({
        type: 'COST_SPIKE',
        message: `Custo elevado: $${response.cost.toFixed(4)} em uma requisição`,
        userId,
        severity: 'high',
        timestamp: new Date()
      });
    }
  }

  /**
   * Adiciona alert ao sistema
   */
  private addAlert(alert: HVCAlert) {
    this.alerts.push(alert);
    
    // Manter apenas os últimos 1000 alerts
    if (this.alerts.length > 1000) {
      this.alerts = this.alerts.slice(-1000);
    }
    
    // Log crítico
    if (alert.severity === 'critical') {
      console.error('🚨 ALERT CRÍTICO:', alert);
    }
  }

  /**
   * Buscar créditos do usuário (mock)
   */
  private async getUserCredits(userId: string): Promise<number> {
    // TODO: Implementar busca real no banco
    return 1000; // Mock
  }

  /**
   * Obter alertas recentes
   */
  getRecentAlerts(limit: number = 50): HVCAlert[] {
    return this.alerts
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  /**
   * Estatísticas do sistema
   */
  getSystemStats() {
    const now = new Date();
    const lastHour = new Date(now.getTime() - 60 * 60 * 1000);
    
    const recentAlerts = this.alerts.filter(alert => alert.timestamp > lastHour);
    
    return {
      totalAlerts: this.alerts.length,
      recentAlerts: recentAlerts.length,
      criticalAlerts: recentAlerts.filter(a => a.severity === 'critical').length,
      availableProviders: Object.keys(AI_PROVIDERS).filter(
        key => AI_PROVIDERS[key].apiKey
      ),
      systemStatus: recentAlerts.filter(a => a.severity === 'critical').length > 0 ? 'degraded' : 'operational'
    };
  }
}

// Instância global do orquestrador
export const hvcOrchestrator = new HVCOrchestrator();