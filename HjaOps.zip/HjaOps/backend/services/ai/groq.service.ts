import { AI_PROVIDERS } from '../../config/providers';

export interface GenerateRequest {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  model: string;
  temperature: number;
  maxTokens: number;
}

export interface GenerateResponse {
  content: string;
  tokensUsed: number;
  model: string;
}

export class GroqService {
  private apiKey: string;
  private baseURL: string;

  constructor() {
    const provider = AI_PROVIDERS.groq;
    this.apiKey = provider.apiKey;
    this.baseURL = provider.baseURL;
  }

  async generateResponse(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new Error('GROQ_API_KEY não configurada');
    }

    try {
      const response = await fetch(`${this.baseURL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: request.model,
          messages: request.messages,
          temperature: request.temperature,
          max_tokens: request.maxTokens,
        }),
      });

      if (!response.ok) {
        throw new Error(`Groq API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      return {
        content: data.choices[0]?.message?.content || 'Resposta vazia',
        tokensUsed: data.usage?.total_tokens || 0,
        model: request.model
      };

    } catch (error) {
      console.error('❌ Erro Groq Service:', error);
      throw error;
    }
  }
}