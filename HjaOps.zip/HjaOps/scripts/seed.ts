import { db } from "../server/db";
import { users, agents, chats, transactions } from "../shared/schema";

async function seedDatabase() {
  console.log("🌱 Iniciando seed do banco de dados...");

  try {
    // Limpar dados existentes
    await db.delete(transactions);
    await db.delete(chats);
    await db.delete(agents);
    await db.delete(users);

    // Inserir usuários
    const insertedUsers = await db.insert(users).values([
      {
        id: "927070657", // ID de exemplo do Replit Auth
        email: "admin@hja2ops.com",
        firstName: "Admin",
        lastName: "Hja2Ops",
        credits: 1000,
        plan: "premium",
        role: "admin"
      },
      {
        id: "user001",
        email: "user1@example.com", 
        firstName: "João",
        lastName: "Silva",
        credits: 50,
        plan: "free",
        role: "user"
      }
    ]).returning();

    console.log("✅ Usuários criados:", insertedUsers.length);

    // Inserir agentes
    const insertedAgents = await db.insert(agents).values([
      {
        name: "Roteirista Viral",
        description: "Especialista em criar roteiros virais para redes sociais",
        promptBase: "Você é um roteirista especializado em conteúdo viral para redes sociais. Crie roteiros envolventes, com hooks poderosos e estrutura narrativa que gera engajamento.",
        active: true,
        defaultModel: "groq/llama-3.1-70b",
        tags: ["roteiro", "viral", "social-media"]
      },
      {
        name: "Estrategista Digital",
        description: "Especialista em marketing digital e estratégias online",
        promptBase: "Você é um estrategista de marketing digital experiente. Ajude com planejamento de campanhas, análise de mercado e estratégias de crescimento digital.",
        active: true,
        defaultModel: "groq/llama-3.1-70b",
        tags: ["marketing", "digital", "estrategia"]
      },
      {
        name: "Analista de Dados",
        description: "Especialista em análise de dados e insights",
        promptBase: "Você é um analista de dados experiente. Ajude com interpretação de dados, criação de relatórios e extração de insights valiosos.",
        active: true,
        defaultModel: "groq/llama-3.1-70b",
        tags: ["dados", "analise", "insights"]
      }
    ]).returning();

    console.log("✅ Agentes criados:", insertedAgents.length);

    // Inserir algumas transações de exemplo
    await db.insert(transactions).values([
      {
        userId: "user001",
        type: "credits",
        amount: "29.90",
        creditsAdded: 300,
        status: "completed",
        provider: "mercadopago"
      },
      {
        userId: "927070657",
        type: "plan",
        amount: "99.90",
        status: "completed",
        provider: "mercadopago"
      }
    ]);

    console.log("✅ Transações de exemplo criadas");

    console.log("🎉 Seed do banco concluído com sucesso!");

  } catch (error) {
    console.error("❌ Erro no seed:", error);
    process.exit(1);
  }
}

seedDatabase();