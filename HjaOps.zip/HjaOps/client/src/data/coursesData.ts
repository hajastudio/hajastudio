import type { Course } from '@/types/courses';

export const coursesData: Course[] = [
  {
    id: '1',
    title: 'Editor Mestre',
    description: 'Domine as técnicas de edição de vídeo para criar conteúdo viral no TikTok e YouTube',
    thumbnail: '/api/placeholder/400/250',
    status: 'free',
    progress: 40,
    duration: '6h 45min',
    level: 'Iniciante',
    instructor: 'Carlos Silva',
    category: 'Edição de Vídeo',
    totalLessons: 12,
    completedLessons: 5,
    rating: 4.8,
    studentsCount: 1240,
    lessons: [
      {
        id: '1-1',
        title: 'Introdução à Edição de Vídeo',
        description: 'Conceitos básicos e ferramentas essenciais',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '12:30',
        isCompleted: true,
        isLocked: false,
        tokensReward: 2,
        attachments: [
          {
            id: 'att-1',
            title: 'Atalhos de Teclado',
            type: 'pdf',
            url: '/downloads/atalhos.pdf',
            size: '1.2 MB'
          }
        ]
      },
      {
        id: '1-2',
        title: 'Cortes e Transições',
        description: 'Técnicas de corte e transições cinematográficas',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '18:45',
        isCompleted: true,
        isLocked: false,
        tokensReward: 3
      },
      {
        id: '1-3',
        title: 'Efeitos Especiais Básicos',
        description: 'Adicione efeitos que chamam atenção',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '25:10',
        isCompleted: false,
        isLocked: false,
        tokensReward: 4
      }
    ]
  },
  {
    id: '2',
    title: 'Criatividade FullStack',
    description: 'Desenvolva aplicações completas usando IA e tecnologias modernas',
    thumbnail: '/api/placeholder/400/250',
    status: 'premium',
    progress: 0,
    cost: 50,
    duration: '12h 30min',
    level: 'Intermediário',
    instructor: 'Ana Rodriguez',
    category: 'Desenvolvimento',
    totalLessons: 20,
    completedLessons: 0,
    rating: 4.9,
    studentsCount: 890,
    lessons: [
      {
        id: '2-1',
        title: 'Arquitetura de Aplicações Modernas',
        description: 'Planejamento e estrutura de projetos escaláveis',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '20:15',
        isCompleted: false,
        isLocked: true,
        tokensReward: 5
      },
      {
        id: '2-2',
        title: 'Integração com APIs de IA',
        description: 'Conecte sua aplicação com GPT, Claude e outras IAs',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '35:40',
        isCompleted: false,
        isLocked: true,
        tokensReward: 6
      }
    ]
  },
  {
    id: '3',
    title: 'Marketing Digital com IA',
    description: 'Estratégias de marketing potencializadas por inteligência artificial',
    thumbnail: '/api/placeholder/400/250',
    status: 'premium',
    progress: 0,
    cost: 35,
    duration: '8h 15min',
    level: 'Iniciante',
    instructor: 'Pedro Santos',
    category: 'Marketing',
    totalLessons: 15,
    completedLessons: 0,
    rating: 4.7,
    studentsCount: 567,
    lessons: [
      {
        id: '3-1',
        title: 'Fundamentos do Marketing Digital',
        description: 'Base sólida para campanhas de sucesso',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '16:20',
        isCompleted: false,
        isLocked: true,
        tokensReward: 3
      }
    ]
  },
  {
    id: '4',
    title: 'Branding & Identidade Visual',
    description: 'Crie marcas memoráveis com design estratégico',
    thumbnail: '/api/placeholder/400/250',
    status: 'free',
    progress: 0,
    duration: '5h 20min',
    level: 'Iniciante',
    instructor: 'Maria Design',
    category: 'Design',
    totalLessons: 10,
    completedLessons: 0,
    rating: 4.6,
    studentsCount: 423,
    lessons: [
      {
        id: '4-1',
        title: 'Psicologia das Cores',
        description: 'Como as cores influenciam decisões',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '14:50',
        isCompleted: false,
        isLocked: false,
        tokensReward: 2
      }
    ]
  },
  {
    id: '5',
    title: 'YouTube Mastery 2024',
    description: 'Estratégias avançadas para crescer no YouTube',
    thumbnail: '/api/placeholder/400/250',
    status: 'premium',
    progress: 0,
    cost: 75,
    duration: '10h 45min',
    level: 'Avançado',
    instructor: 'João Creator',
    category: 'Content Creation',
    totalLessons: 18,
    completedLessons: 0,
    rating: 4.9,
    studentsCount: 1120,
    lessons: [
      {
        id: '5-1',
        title: 'Algoritmo do YouTube 2024',
        description: 'Entenda como funciona e como se destacar',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '28:30',
        isCompleted: false,
        isLocked: true,
        tokensReward: 8
      }
    ]
  },
  {
    id: '6',
    title: 'Prompt Engineering Avançado',
    description: 'Masterize a arte de criar prompts eficazes para IA',
    thumbnail: '/api/placeholder/400/250',
    status: 'unlocked',
    progress: 15,
    duration: '7h 10min',
    level: 'Intermediário',
    instructor: 'Sophie AI',
    category: 'Inteligência Artificial',
    totalLessons: 14,
    completedLessons: 2,
    rating: 4.8,
    studentsCount: 780,
    lessons: [
      {
        id: '6-1',
        title: 'Fundamentos de Prompt Engineering',
        description: 'Estrutura básica de prompts eficazes',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '19:45',
        isCompleted: true,
        isLocked: false,
        tokensReward: 4
      },
      {
        id: '6-2',
        title: 'Técnicas Avançadas de Contexto',
        description: 'Como fornecer contexto relevante',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '22:10',
        isCompleted: true,
        isLocked: false,
        tokensReward: 5
      },
      {
        id: '6-3',
        title: 'Chain of Thought Prompting',
        description: 'Técnica para raciocínio complexo',
        videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        duration: '31:25',
        isCompleted: false,
        isLocked: false,
        tokensReward: 6
      }
    ]
  }
];