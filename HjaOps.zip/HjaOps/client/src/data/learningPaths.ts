import type { LearningPath } from '@/types/onboarding';

export const learningPaths: LearningPath[] = [
  {
    id: 'content-creator-basics',
    name: 'Criador de Conteúdo - Iniciante',
    description: 'Aprenda a usar o Hja²Ops para criar conteúdo viral e engajar sua audiência',
    targetAudience: ['content-creator', 'influencer', 'beginner'],
    difficulty: 'beginner',
    estimatedTime: 15,
    tags: ['viral', 'social-media', 'content'],
    outcomes: [
      'Criar seu primeiro roteiro viral',
      'Entender o Chat Multiagente',
      'Usar ferramentas de análise',
      'Configurar seu perfil'
    ],
    steps: [
      {
        id: 'welcome-creator',
        title: 'Bem-vindo, Criador! 🎬',
        content: 'Você está prestes a descobrir como criar conteúdo que realmente <strong>viral</strong>! Vamos começar conhecendo sua nova ferramenta favorita.',
        position: 'center',
        type: 'modal',
        interactive: true,
        priority: 1,
        actions: [
          {
            id: 'start-tour',
            label: 'Começar Tour',
            type: 'next',
            style: 'primary'
          },
          {
            id: 'skip-tour',
            label: 'Pular por Agora',
            type: 'skip',
            style: 'ghost'
          }
        ]
      },
      {
        id: 'dashboard-overview',
        title: 'Seu Dashboard de Criação',
        content: 'Este é seu <strong>centro de comando</strong>. Aqui você acessa todas as ferramentas para criar conteúdo viral, desde roteiros até análises de performance.',
        targetSelector: '[data-testid="main-dashboard"]',
        position: 'center',
        type: 'spotlight',
        interactive: true,
        priority: 2,
        actions: [
          {
            id: 'explore-sections',
            label: 'Explorar Seções',
            type: 'next',
            style: 'primary'
          }
        ]
      },
      {
        id: 'chat-multiagente-intro',
        title: 'Chat Multiagente - Seu Time de Experts',
        content: 'Aqui está a <strong>mágica</strong>! Converse com agentes especializados em roteiros, análise, branding e muito mais. Cada um tem superpoderes únicos.',
        targetSelector: '[data-testid="sidebar-chat"]',
        position: 'right',
        type: 'tooltip',
        interactive: true,
        priority: 3,
        actions: [
          {
            id: 'try-chat',
            label: 'Experimentar Chat',
            type: 'demo',
            style: 'primary'
          },
          {
            id: 'learn-agents',
            label: 'Conhecer Agentes',
            type: 'next',
            style: 'secondary'
          }
        ]
      },
      {
        id: 'roteirista-agent',
        title: 'Roteirista Viral - Seu Especialista em Scripts',
        content: 'Este agente é <strong>especialista em criar roteiros</strong> que param o scroll! Ele conhece todos os ganchos, estruturas e psicologia por trás do conteúdo viral.',
        targetSelector: '[data-testid="agent-roteirista"]',
        position: 'bottom',
        type: 'tooltip',
        interactive: true,
        priority: 4,
        aiGenerated: true,
        actions: [
          {
            id: 'chat-with-roteirista',
            label: 'Conversar Agora',
            type: 'demo',
            style: 'primary'
          },
          {
            id: 'next-agent',
            label: 'Próximo Agente',
            type: 'next',
            style: 'secondary'
          }
        ]
      },
      {
        id: 'youtube-analyst-intro',
        title: 'YouTube Analyst - Decodificador de Algoritmos',
        content: 'Quer <strong>entender porque alguns vídeos explodem</strong> e outros não? Este agente analisa URLs, métricas e te dá insights acionáveis.',
        targetSelector: '[data-testid="agent-youtube-analyst"]',
        position: 'bottom',
        type: 'tooltip',
        interactive: true,
        priority: 5,
        actions: [
          {
            id: 'demo-analysis',
            label: 'Ver Demo',
            type: 'demo',
            style: 'primary'
          },
          {
            id: 'continue-tour',
            label: 'Continuar',
            type: 'next',
            style: 'secondary'
          }
        ]
      },
      {
        id: 'first-script-creation',
        title: 'Vamos Criar Seu Primeiro Roteiro!',
        content: 'Hora da prática! Vamos usar o <strong>Roteirista Viral</strong> para criar um script que realmente engaja. Que tipo de conteúdo você quer criar?',
        position: 'center',
        type: 'modal',
        interactive: true,
        priority: 6,
        actions: [
          {
            id: 'create-tiktok',
            label: 'TikTok Viral',
            type: 'custom',
            style: 'primary'
          },
          {
            id: 'create-youtube',
            label: 'YouTube Short',
            type: 'custom',
            style: 'secondary'
          },
          {
            id: 'create-instagram',
            label: 'Instagram Reel',
            type: 'custom',
            style: 'secondary'
          }
        ]
      },
      {
        id: 'credits-system',
        title: 'Sistema de Créditos Inteligente',
        content: 'Cada conversa com os agentes usa <strong>créditos baseados no tamanho</strong> da sua mensagem. Seja específico para melhores resultados!',
        targetSelector: '[data-testid="credits-badge"]',
        position: 'bottom',
        type: 'tooltip',
        interactive: true,
        priority: 7,
        actions: [
          {
            id: 'understand-credits',
            label: 'Entendi',
            type: 'next',
            style: 'primary'
          },
          {
            id: 'buy-credits',
            label: 'Comprar Créditos',
            type: 'link',
            style: 'secondary',
            href: '/pricing'
          }
        ]
      },
      {
        id: 'completion-creator',
        title: 'Você Está Pronto para Viralizar! 🚀',
        content: 'Parabéns! Agora você conhece as ferramentas que vão <strong>transformar seu conteúdo</strong>. Comece criando seu primeiro roteiro e veja a mágica acontecer!',
        position: 'center',
        type: 'modal',
        interactive: true,
        priority: 8,
        actions: [
          {
            id: 'start-creating',
            label: 'Começar a Criar',
            type: 'complete',
            style: 'primary'
          },
          {
            id: 'explore-more',
            label: 'Explorar Mais',
            type: 'custom',
            style: 'secondary'
          }
        ]
      }
    ]
  },
  
  {
    id: 'developer-onboarding',
    name: 'Desenvolvedor - Otimização de Código',
    description: 'Descubra como usar IA para escrever código mais limpo e eficiente',
    targetAudience: ['developer', 'programmer', 'tech'],
    difficulty: 'intermediate',
    estimatedTime: 12,
    tags: ['coding', 'architecture', 'optimization'],
    outcomes: [
      'Refatorar código com IA',
      'Usar Vibe Code eficientemente',
      'Otimizar arquitetura',
      'Debug inteligente'
    ],
    steps: [
      {
        id: 'dev-welcome',
        title: 'Bem-vindo, Dev! 💻',
        content: 'Prepare-se para <strong>revolucionar</strong> sua forma de programar. Vamos conhecer seu novo pair programming partner!',
        position: 'center',
        type: 'modal',
        interactive: true,
        priority: 1,
        actions: [
          {
            id: 'start-dev-tour',
            label: 'Começar',
            type: 'next',
            style: 'primary'
          }
        ]
      },
      {
        id: 'vibe-code-intro',
        title: 'Vibe Code - Seu Senior Dev Pessoal',
        content: 'Este agente é <strong>especializado em arquitetura</strong>, padrões de projeto e código limpo. Ele pode revisar, refatorar e otimizar qualquer código.',
        targetSelector: '[data-testid="agent-vibe-code"]',
        position: 'right',
        type: 'tooltip',
        interactive: true,
        priority: 2,
        aiGenerated: true,
        actions: [
          {
            id: 'demo-code-review',
            label: 'Ver Demo',
            type: 'demo',
            style: 'primary'
          },
          {
            id: 'continue-dev',
            label: 'Continuar',
            type: 'next',
            style: 'secondary'
          }
        ]
      }
    ]
  },

  {
    id: 'business-owner-growth',
    name: 'Empreendedor - Crescimento Digital',
    description: 'Use IA para escalar seu negócio com estratégias de marketing e branding',
    targetAudience: ['business-owner', 'entrepreneur', 'marketing'],
    difficulty: 'beginner',
    estimatedTime: 18,
    tags: ['business', 'marketing', 'branding', 'growth'],
    outcomes: [
      'Criar estratégia de marca',
      'Desenvolver calendário editorial',
      'Otimizar conversões',
      'Analisar concorrência'
    ],
    steps: [
      {
        id: 'business-welcome',
        title: 'Bem-vindo, Empreendedor! 🚀',
        content: 'Vamos <strong>escalar seu negócio</strong> usando o poder da IA. Prepare-se para descobrir estratégias que realmente funcionam!',
        position: 'center',
        type: 'modal',
        interactive: true,
        priority: 1,
        actions: [
          {
            id: 'start-business-tour',
            label: 'Vamos Crescer',
            type: 'next',
            style: 'primary'
          }
        ]
      },
      {
        id: 'brand-expert-intro',
        title: 'Brand Expert - Seu Estrategista de Marca',
        content: 'Este agente vai ajudar você a <strong>construir uma marca forte</strong> e criar calendários editoriais que convertem.',
        targetSelector: '[data-testid="agent-branding-social"]',
        position: 'bottom',
        type: 'tooltip',
        interactive: true,
        priority: 2,
        actions: [
          {
            id: 'create-brand-strategy',
            label: 'Criar Estratégia',
            type: 'demo',
            style: 'primary'
          }
        ]
      }
    ]
  }
];