export interface Agent {
  id: string;
  name: string;
  description: string;
  instructions: string;
  defaultModel: string;
  uiMode: 'chat' | 'code' | 'creative';
  tools: string[];
  tags: string[];
  active: boolean;
  tone: string;
  safety: {
    allow_code: boolean;
    allow_images: boolean;
  };
  color: string;
  icon: string;
  avatar?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  agentId?: string;
  attachments?: Attachment[];
  metadata?: {
    model?: string;
    tokens?: number;
    latency?: number;
    provider?: string;
  };
  status?: 'sending' | 'sent' | 'error' | 'streaming';
}

export interface Attachment {
  id: string;
  type: 'image' | 'document' | 'url' | 'code';
  name: string;
  url: string;
  size?: number;
  mimeType?: string;
}

export interface ChatThread {
  id: string;
  title: string;
  agentId: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
  folder?: string;
  isFavorite: boolean;
  isDraft: boolean;
  totalTokens: number;
  totalCredits: number;
}

export interface ChatRequest {
  userId: string;
  agentId: string;
  messages: Pick<ChatMessage, 'role' | 'content'>[];
  options: {
    stream: boolean;
    attachments: Attachment[];
    toolHints: string[];
  };
}

export interface ChatResponse {
  id: string;
  model: string;
  usage: {
    inputTokens: number;
    outputTokens: number;
    creditsCharged: number;
  };
  messages: ChatMessage[];
  meta: {
    provider: string;
    latencyMs: number;
  };
}

export interface StreamEvent {
  type: 'chunk' | 'done' | 'error' | 'token_update';
  data: any;
}

export interface CreditEstimate {
  estimatedTokens: number;
  estimatedCredits: number;
}