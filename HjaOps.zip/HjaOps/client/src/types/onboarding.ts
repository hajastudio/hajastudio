export interface OnboardingStep {
  id: string;
  title: string;
  content: string;
  targetSelector?: string;
  targetElement?: string;
  position: 'top' | 'bottom' | 'left' | 'right' | 'center';
  type: 'tooltip' | 'modal' | 'spotlight' | 'overlay';
  interactive: boolean;
  actions: OnboardingAction[];
  conditions?: OnboardingCondition[];
  aiGenerated?: boolean;
  priority: number;
}

export interface OnboardingAction {
  id: string;
  label: string;
  type: 'next' | 'skip' | 'complete' | 'custom' | 'link' | 'demo';
  handler?: () => void | Promise<void>;
  href?: string;
  style: 'primary' | 'secondary' | 'ghost' | 'danger';
}

export interface OnboardingCondition {
  type: 'element_visible' | 'user_role' | 'feature_enabled' | 'progress_level' | 'time_spent';
  value: any;
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than';
}

export interface LearningPath {
  id: string;
  name: string;
  description: string;
  targetAudience: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: number; // minutes
  steps: OnboardingStep[];
  prerequisites?: string[];
  outcomes: string[];
  tags: string[];
}

export interface UserOnboardingProgress {
  userId: string;
  currentPath?: string;
  currentStep?: string;
  completedSteps: string[];
  skippedSteps: string[];
  startedAt: Date;
  lastActivity: Date;
  completionPercentage: number;
  preferences: OnboardingPreferences;
}

export interface OnboardingPreferences {
  showTooltips: boolean;
  animationSpeed: 'slow' | 'normal' | 'fast';
  interactionStyle: 'guided' | 'exploratory' | 'minimal';
  learningGoals: string[];
  skipCompleted: boolean;
}

export interface OnboardingContext {
  currentPage: string;
  userRole: string;
  featuresUsed: string[];
  timeOnPlatform: number;
  lastLogin: Date;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  browserLanguage: string;
}

export interface AITooltipRequest {
  context: OnboardingContext;
  element: string;
  userGoal?: string;
  previousSteps: string[];
}

export interface AITooltipResponse {
  title: string;
  content: string;
  tips: string[];
  nextSuggestions: string[];
  personalizedMessage?: string;
}