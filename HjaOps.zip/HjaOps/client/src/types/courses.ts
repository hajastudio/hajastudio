export interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  status: 'free' | 'premium' | 'unlocked';
  progress: number; // 0-100
  cost?: number; // tokens needed to unlock
  duration: string; // e.g. "4h 30min"
  level: 'Iniciante' | 'Intermediário' | 'Avançado';
  instructor: string;
  category: string;
  lessons: Lesson[];
  totalLessons: number;
  completedLessons: number;
  rating: number;
  studentsCount: number;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  duration: string; // e.g. "15:30"
  isCompleted: boolean;
  isLocked: boolean;
  attachments?: Attachment[];
  tokensReward: number; // tokens earned when completed
}

export interface Attachment {
  id: string;
  title: string;
  type: 'pdf' | 'code' | 'resource' | 'link';
  url: string;
  size?: string;
}

export interface CourseProgress {
  courseId: string;
  lessonsCompleted: string[];
  lastWatched?: string;
  totalWatchTime: number;
  lastAccessedAt: Date;
}