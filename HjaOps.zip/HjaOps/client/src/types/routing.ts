// Model Routing and Provider Management Types

export type Provider = 'groq' | 'huggingface' | 'replit' | 'openai';
export type UserTier = 'free' | 'basic' | 'pro' | 'premium' | 'enterprise';
export type AgentType = 'roteirista' | 'vibe-code' | 'branding' | 'youtube' | 'data-analyst' | 'creative-mind';

export interface ModelConfig {
  provider: Provider;
  modelName: string;
  displayName: string;
  costPerToken: number; // em centavos de USD
  maxTokens: number;
  avgLatencyMs: number;
  qualityScore: number; // 1-10
  contextWindow: number;
  capabilities: string[];
  restrictions?: {
    minTier?: UserTier;
    maxRequestsPerHour?: number;
    requiresApproval?: boolean;
  };
}

export interface RoutingRule {
  agentType: AgentType;
  primary: {
    modelId: string;
    conditions?: RoutingCondition[];
  };
  fallbacks: Array<{
    modelId: string;
    priority: number;
    conditions?: RoutingCondition[];
  }>;
  premiumOverride?: {
    modelId: string;
    minTier: UserTier;
  };
}

export interface RoutingCondition {
  type: 'cost_cap' | 'latency_cap' | 'error_rate' | 'user_tier' | 'time_window' | 'queue_length';
  operator: 'gt' | 'lt' | 'eq' | 'gte' | 'lte';
  value: number | string;
  window?: number; // em segundos para métricas temporais
}

export interface ProviderSLA {
  provider: Provider;
  maxLatencyMs: number;
  maxErrorRate: number; // porcentagem
  minSuccessRate: number; // porcentagem
  maxCostPerRequest: number; // em centavos USD
  healthCheckInterval: number; // em segundos
  lastHealthCheck: Date;
  status: 'healthy' | 'degraded' | 'unhealthy' | 'maintenance';
}

export interface ABTestConfig {
  id: string;
  name: string;
  description: string;
  agentType: AgentType;
  controlModelId: string;
  experimentModelId: string;
  trafficSplit: number; // 0-100, porcentagem para experimento
  startDate: Date;
  endDate: Date;
  active: boolean;
  metrics: {
    targetMetric: 'cost' | 'latency' | 'quality' | 'satisfaction';
    minimumSampleSize: number;
    significanceThreshold: number;
  };
  results?: ABTestResults;
}

export interface ABTestResults {
  totalRequests: number;
  controlPerformance: {
    requests: number;
    avgCost: number;
    avgLatency: number;
    successRate: number;
    satisfaction?: number;
  };
  experimentPerformance: {
    requests: number;
    avgCost: number;
    avgLatency: number;
    successRate: number;
    satisfaction?: number;
  };
  statisticalSignificance: boolean;
  winner?: 'control' | 'experiment' | 'inconclusive';
  recommendation: string;
}

export interface RouteDecision {
  selectedModel: ModelConfig;
  reason: string;
  fallbackChain?: string[];
  abTestGroup?: 'control' | 'experiment';
  estimatedCost: number;
  estimatedLatency: number;
  metadata: {
    userId: string;
    agentType: AgentType;
    userTier: UserTier;
    requestId: string;
    timestamp: Date;
  };
}

export interface ProviderMetrics {
  provider: Provider;
  timeWindow: '1h' | '6h' | '24h' | '7d';
  metrics: {
    totalRequests: number;
    successfulRequests: number;
    failedRequests: number;
    avgLatency: number;
    p95Latency: number;
    p99Latency: number;
    avgCost: number;
    totalCost: number;
    errorRate: number;
    satisfactionScore?: number;
  };
  lastUpdated: Date;
}

export interface CostOptimization {
  agentType: AgentType;
  currentCostPerRequest: number;
  targetCostPerRequest: number;
  recommendations: Array<{
    action: 'switch_model' | 'reduce_tokens' | 'increase_tier_requirement' | 'implement_caching';
    modelId?: string;
    expectedSaving: number; // porcentagem
    impact: 'low' | 'medium' | 'high';
    description: string;
  }>;
}

// Configuração de roteamento por agente
export const AGENT_ROUTING_MATRIX: Record<AgentType, RoutingRule> = {
  'roteirista': {
    agentType: 'roteirista',
    primary: {
      modelId: 'groq-llama-3.1-70b',
      conditions: [
        { type: 'cost_cap', operator: 'lt', value: 0.05 },
        { type: 'latency_cap', operator: 'lt', value: 3000 }
      ]
    },
    fallbacks: [
      { modelId: 'huggingface-mistral-7b', priority: 1 },
      { modelId: 'groq-llama-3.1-8b', priority: 2 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'pro'
    }
  },
  'vibe-code': {
    agentType: 'vibe-code',
    primary: {
      modelId: 'replit-code-v1.5',
      conditions: [
        { type: 'latency_cap', operator: 'lt', value: 2000 }
      ]
    },
    fallbacks: [
      { modelId: 'groq-llama-3.1-8b', priority: 1 },
      { modelId: 'huggingface-codellama-7b', priority: 2 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'pro'
    }
  },
  'branding': {
    agentType: 'branding',
    primary: {
      modelId: 'huggingface-mistral-7b',
      conditions: [
        { type: 'cost_cap', operator: 'lt', value: 0.03 }
      ]
    },
    fallbacks: [
      { modelId: 'groq-llama-3.1-8b', priority: 1 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'basic'
    }
  },
  'youtube': {
    agentType: 'youtube',
    primary: {
      modelId: 'groq-llama-3.1-70b',
      conditions: [
        { type: 'cost_cap', operator: 'lt', value: 0.08 }
      ]
    },
    fallbacks: [
      { modelId: 'huggingface-mistral-7b', priority: 1 },
      { modelId: 'groq-llama-3.1-8b', priority: 2 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'pro'
    }
  },
  'data-analyst': {
    agentType: 'data-analyst',
    primary: {
      modelId: 'groq-deepseek-r1',
      conditions: [
        { type: 'latency_cap', operator: 'lt', value: 4000 }
      ]
    },
    fallbacks: [
      { modelId: 'groq-llama-3.1-70b', priority: 1 },
      { modelId: 'huggingface-mistral-7b', priority: 2 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'premium'
    }
  },
  'creative-mind': {
    agentType: 'creative-mind',
    primary: {
      modelId: 'groq-deepseek-r1',
      conditions: [
        { type: 'cost_cap', operator: 'lt', value: 0.06 }
      ]
    },
    fallbacks: [
      { modelId: 'groq-llama-3.1-8b', priority: 1 },
      { modelId: 'huggingface-mistral-7b', priority: 2 }
    ],
    premiumOverride: {
      modelId: 'openai-gpt-4o',
      minTier: 'pro'
    }
  }
};

// Métricas de SLA por provider
export const PROVIDER_SLA_TARGETS: Record<Provider, ProviderSLA> = {
  groq: {
    provider: 'groq',
    maxLatencyMs: 3000,
    maxErrorRate: 5,
    minSuccessRate: 95,
    maxCostPerRequest: 0.08,
    healthCheckInterval: 30,
    lastHealthCheck: new Date(),
    status: 'healthy'
  },
  huggingface: {
    provider: 'huggingface',
    maxLatencyMs: 5000,
    maxErrorRate: 8,
    minSuccessRate: 92,
    maxCostPerRequest: 0.05,
    healthCheckInterval: 60,
    lastHealthCheck: new Date(),
    status: 'healthy'
  },
  replit: {
    provider: 'replit',
    maxLatencyMs: 2000,
    maxErrorRate: 3,
    minSuccessRate: 97,
    maxCostPerRequest: 0.04,
    healthCheckInterval: 30,
    lastHealthCheck: new Date(),
    status: 'healthy'
  },
  openai: {
    provider: 'openai',
    maxLatencyMs: 8000,
    maxErrorRate: 2,
    minSuccessRate: 98,
    maxCostPerRequest: 0.20,
    healthCheckInterval: 45,
    lastHealthCheck: new Date(),
    status: 'healthy'
  }
};

// Políticas de acesso por tier de usuário
export const USER_TIER_POLICIES: Record<UserTier, {
  maxCostPerRequest: number;
  allowedProviders: Provider[];
  maxRequestsPerHour: number;
  premiumModelsAccess: boolean;
  abTestParticipation: boolean;
}> = {
  free: {
    maxCostPerRequest: 0.02,
    allowedProviders: ['groq', 'huggingface'],
    maxRequestsPerHour: 10,
    premiumModelsAccess: false,
    abTestParticipation: true
  },
  basic: {
    maxCostPerRequest: 0.05,
    allowedProviders: ['groq', 'huggingface', 'replit'],
    maxRequestsPerHour: 50,
    premiumModelsAccess: false,
    abTestParticipation: true
  },
  pro: {
    maxCostPerRequest: 0.12,
    allowedProviders: ['groq', 'huggingface', 'replit', 'openai'],
    maxRequestsPerHour: 200,
    premiumModelsAccess: true,
    abTestParticipation: true
  },
  premium: {
    maxCostPerRequest: 0.25,
    allowedProviders: ['groq', 'huggingface', 'replit', 'openai'],
    maxRequestsPerHour: 500,
    premiumModelsAccess: true,
    abTestParticipation: false
  },
  enterprise: {
    maxCostPerRequest: 0.50,
    allowedProviders: ['groq', 'huggingface', 'replit', 'openai'],
    maxRequestsPerHour: 1000,
    premiumModelsAccess: true,
    abTestParticipation: false
  }
};

export interface RoutingAnalytics {
  timeRange: string;
  totalRequests: number;
  routingDecisions: Record<string, number>;
  fallbackActivations: number;
  costSavings: number;
  abTestsRunning: number;
  providerHealth: Record<Provider, 'healthy' | 'degraded' | 'unhealthy'>;
  topCostSavingRecommendations: CostOptimization[];
}