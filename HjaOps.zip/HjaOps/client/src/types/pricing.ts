// Pricing and Credit System Types

export interface CreditPackage {
  id: string;
  name: string;
  credits: number;
  price: number;
  originalPrice?: number;
  discount?: number;
  popular?: boolean;
  bonus?: number;
  description: string;
  features: string[];
}

export interface Plan {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  credits: number;
  interval: 'monthly' | 'annually';
  popular?: boolean;
  features: string[];
  models: string[];
  addons?: string[];
}

export interface Transaction {
  id: string;
  type: 'credit_purchase' | 'plan_subscription' | 'bonus' | 'refund';
  amount: number;
  credits: number;
  status: 'pending' | 'approved' | 'rejected' | 'processing' | 'chargeback';
  paymentMethod: 'mercadopago' | 'bonus' | 'promo';
  mercadopagoId?: string;
  timestamp: Date;
  description: string;
  invoice?: string;
}

export interface CreditUsage {
  id: string;
  agentId: string;
  agentName: string;
  model: string;
  credits: number;
  timestamp: Date;
  messageId?: string;
  details: string;
}

export interface PromoCode {
  id: string;
  code: string;
  type: 'percentage' | 'fixed' | 'credits';
  value: number;
  minPurchase?: number;
  maxDiscount?: number;
  validUntil?: Date;
  usageLimit?: number;
  usedCount: number;
  active: boolean;
}

export interface PaymentIntent {
  id: string;
  userId: string;
  productType: 'credits' | 'plan';
  productId: string;
  amount: number;
  credits: number;
  mercadopagoPreferenceId?: string;
  status: 'created' | 'pending' | 'completed' | 'failed' | 'expired';
  promoCode?: string;
  createdAt: Date;
  completedAt?: Date;
}

// Product Configuration
export const CREDIT_PACKAGES: CreditPackage[] = [
  {
    id: 'credits_50',
    name: 'Starter',
    credits: 50,
    price: 19.90,
    description: 'Perfeito para testar nossos agentes',
    features: [
      'Todos os agentes disponíveis',
      'Suporte por email',
      'Histórico de 30 dias'
    ]
  },
  {
    id: 'credits_200',
    name: 'Popular',
    credits: 200,
    price: 69.90,
    originalPrice: 79.60,
    discount: 12,
    popular: true,
    bonus: 20,
    description: 'Ideal para uso regular',
    features: [
      'Todos os agentes disponíveis',
      'Suporte prioritário',
      'Histórico de 90 dias',
      '+20 créditos bônus'
    ]
  },
  {
    id: 'credits_500',
    name: 'Professional',
    credits: 500,
    price: 149.90,
    originalPrice: 199.00,
    discount: 25,
    bonus: 100,
    description: 'Para criadores profissionais',
    features: [
      'Todos os agentes disponíveis',
      'Modelos premium',
      'Suporte via WhatsApp',
      'Histórico ilimitado',
      '+100 créditos bônus'
    ]
  },
  {
    id: 'credits_1000',
    name: 'Enterprise',
    credits: 1000,
    price: 249.90,
    originalPrice: 399.00,
    discount: 37,
    bonus: 300,
    description: 'Para equipes e agências',
    features: [
      'Todos os agentes disponíveis',
      'Modelos premium',
      'Suporte dedicado',
      'API access',
      'Relatórios avançados',
      '+300 créditos bônus'
    ]
  }
];

export const PLANS: Plan[] = [
  {
    id: 'basic_monthly',
    name: 'Basic',
    description: 'Para uso pessoal',
    price: 39.90,
    credits: 200,
    interval: 'monthly',
    features: [
      '200 créditos/mês',
      'Todos os agentes',
      'Suporte por email',
      'Histórico 30 dias'
    ],
    models: ['groq', 'huggingface']
  },
  {
    id: 'pro_monthly',
    name: 'Pro',
    description: 'Para criadores profissionais',
    price: 89.90,
    credits: 500,
    interval: 'monthly',
    popular: true,
    features: [
      '500 créditos/mês',
      'Todos os agentes',
      'Modelos premium',
      'Suporte WhatsApp',
      'Histórico 90 dias',
      'Exportação avançada'
    ],
    models: ['groq', 'huggingface', 'gpt-4o', 'claude-3']
  },
  {
    id: 'premium_monthly',
    name: 'Premium',
    description: 'Para equipes e agências',
    price: 179.90,
    credits: 1000,
    interval: 'monthly',
    features: [
      '1000 créditos/mês',
      'Todos os agentes',
      'Modelos premium',
      'Suporte dedicado',
      'Histórico ilimitado',
      'API access',
      'Relatórios custom',
      'Multi-usuário'
    ],
    models: ['groq', 'huggingface', 'gpt-4o', 'claude-3', 'gpt-4o-mini'],
    addons: ['video-ai-pack']
  }
];

export const ADDON_PRODUCTS = [
  {
    id: 'video-ai-pack',
    name: 'Pacote Vídeo IA',
    description: 'Recursos avançados para criação de vídeos',
    price: 49.90,
    features: [
      'Análise avançada de vídeos',
      'Geração de thumbnails IA',
      'Roteiros otimizados',
      'Métricas preditivas'
    ]
  }
];

// Pricing Configuration
export const PRICING_CONFIG = {
  // Cost per credit by model (in BRL)
  modelCosts: {
    'groq': 0.008,
    'huggingface': 0.012,
    'gpt-4o': 0.18,
    'claude-3': 0.15,
    'gpt-4o-mini': 0.09
  },
  
  // Bonus rules
  bonusRules: {
    onboarding: 5,
    referral: 10,
    feedback: 2,
    firstPurchase: 10
  },

  // Upsell triggers
  upsellTriggers: {
    lowCreditsThreshold: 10,
    outOfCreditsModal: true,
    contextualSuggestions: true
  },

  // Payment settings
  payment: {
    currency: 'BRL',
    webhookTimeout: 120000, // 2 minutes
    retryAttempts: 3,
    reconciliationWindow: 300000 // 5 minutes
  }
};

// Helper functions
export const calculateCreditCost = (credits: number, model: string): number => {
  const costPerCredit = PRICING_CONFIG.modelCosts[model] || 0.08;
  return credits * costPerCredit;
};

export const getBestValue = (packages: CreditPackage[]): CreditPackage => {
  return packages.reduce((best, current) => {
    const currentValue = current.credits / current.price;
    const bestValue = best.credits / best.price;
    return currentValue > bestValue ? current : best;
  });
};

export const calculateDiscount = (originalPrice: number, currentPrice: number): number => {
  return Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
};

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(price);
};

export const formatCredits = (credits: number): string => {
  if (credits >= 1000) {
    return `${(credits / 1000).toFixed(1)}k`;
  }
  return credits.toString();
};