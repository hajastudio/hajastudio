import { motion } from 'framer-motion';
interface AgentCardProps {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  category: string;
  isActive?: boolean;
  tokensUsed?: number;
  specialty?: string[];
  onActivate: (agentId: string) => void;
}

export function AgentCard({
  id,
  name,
  description,
  icon: Icon,
  category,
  isActive = false,
  tokensUsed = 0,
  specialty = [],
  onActivate
}: AgentCardProps) {

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ 
        scale: 1.05, 
        y: -10,
        transition: { duration: 0.3, ease: "easeOut" }
      }}
      whileTap={{ scale: 0.98 }}
      className="group relative overflow-hidden"
    >
      {/* Main Card */}
      <div 
        className={`
          glass-morphism-strong rounded-3xl transition-all duration-300 cursor-pointer relative
          ${isActive 
            ? 'neon-glow shadow-2xl' 
            : 'hover:neon-glow'
          }
          hover:shadow-2xl animated-border
        `}
        onClick={() => onActivate(id)}
      >
        {/* Header */}
        <div className="p-6 pb-4">
          {/* Status indicator */}
          <div className="absolute top-4 right-4">
            <div className={`w-3 h-3 rounded-full ${
              isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-600'
            }`}></div>
          </div>

          <div className="mb-4">
            <div 
              className={`
                w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-lg transition-all duration-300
                ${isActive 
                  ? 'bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] neon-glow' 
                  : 'bg-gradient-to-br from-gray-600 to-gray-700 group-hover:from-[var(--blue)] group-hover:to-[var(--orange)]'
                }
              `}
            >
              <Icon 
                size={32} 
                className={`transition-all duration-300 ${
                  isActive ? 'text-white' : 'text-gray-300 group-hover:text-white'
                }`}
              />
            </div>
            
            <div className="text-xs text-[var(--smoke)]/60 uppercase tracking-wide font-medium mb-1">
              {category}
            </div>
            {tokensUsed > 0 && (
              <div className="text-xs text-[var(--orange)]">
                {tokensUsed.toLocaleString()} tokens usados
              </div>
            )}
          </div>

          <div className="space-y-3">
            <h3 className="text-lg font-orbitron font-semibold text-white mb-2 group-hover:text-[var(--blue)] transition-colors duration-300">
              {name}
            </h3>
            
            <p className="text-[var(--smoke)]/80 text-sm mb-4 leading-relaxed">
              {description}
            </p>

            {/* Specialties */}
            {specialty.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {specialty.slice(0, 2).map((spec, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-[var(--smoke)]/10 border border-[var(--smoke)]/20 rounded-lg text-xs text-[var(--smoke)]/70"
                  >
                    {spec}
                  </span>
                ))}
                {specialty.length > 2 && (
                  <span className="px-2 py-1 text-xs text-[var(--smoke)]/50">
                    +{specialty.length - 2} mais
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer / Action */}
        <div className="px-6 pb-6">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`
              w-full py-3 px-4 rounded-2xl font-medium transition-all duration-300
              ${isActive
                ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white neon-glow shadow-lg'
                : 'glass-morphism text-[var(--blue)] hover:neon-glow hover:text-white'
              }
            `}
            data-testid={`activate-agent-${id}`}
          >
            {isActive ? (
              <span className="flex items-center justify-center space-x-2">
                <span>Conversar</span>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              </span>
            ) : (
              'Ativar Agente'
            )}
          </motion.button>
        </div>

        {/* Hover Glow Effect */}
        <div className="absolute inset-0 gradient-bg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-3xl" />
      </div>

      {/* Netflix-style Hover Expansion */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        whileHover={{ opacity: 1, height: "auto" }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="absolute top-full left-0 right-0 mt-2 glass-morphism border border-[var(--blue)]/30 rounded-xl p-4 z-10 overflow-hidden"
      >
        <div className="space-y-3">
          <h4 className="font-orbitron font-bold text-[var(--blue)] text-sm">
            Capacidades Avançadas
          </h4>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            {specialty.map((spec, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-1.5 h-1.5 bg-[var(--orange)] rounded-full" />
                <span className="text-[var(--smoke)]/80">{spec}</span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-[var(--blue)]/20">
            <div className="flex justify-between text-xs text-[var(--smoke)]/60">
              <span>Eficiência:</span>
              <span className="text-[var(--blue)]">95%</span>
            </div>
            <div className="flex justify-between text-xs text-[var(--smoke)]/60">
              <span>Velocidade:</span>
              <span className="text-[var(--orange)]">2.3s média</span>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}