import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Award, 
  Star, 
  Gift, 
  Zap,
  Users,
  CheckCircle,
  Plus,
  Calendar,
  TrendingUp,
  Target,
  Heart,
  Share,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface Reward {
  id: string;
  title: string;
  description: string;
  tokens: number;
  type: 'onboarding' | 'referral' | 'engagement' | 'milestone' | 'daily';
  icon: any;
  isActive: boolean;
  triggers: number;
  conversions: number;
  totalTokensGiven: number;
}

interface TokenAnimation {
  id: string;
  tokens: number;
  x: number;
  y: number;
  timestamp: number;
}

export default function RewardsSystem() {
  const [selectedReward, setSelectedReward] = useState<string | null>(null);
  const [tokenAnimations, setTokenAnimations] = useState<TokenAnimation[]>([]);

  const rewards: Reward[] = [
    {
      id: '1',
      title: 'Onboarding Completo',
      description: 'Usuário finaliza tutorial e configuração inicial',
      tokens: 5,
      type: 'onboarding',
      icon: CheckCircle,
      isActive: true,
      triggers: 2847,
      conversions: 2401,
      totalTokensGiven: 12005
    },
    {
      id: '2',
      title: 'Primeiro Amigo',
      description: 'Indica um amigo que se cadastra na plataforma',
      tokens: 10,
      type: 'referral',
      icon: Users,
      isActive: true,
      triggers: 456,
      conversions: 423,
      totalTokensGiven: 4230
    },
    {
      id: '3',
      title: 'Engajamento Premium',
      description: 'Faz comentário que recebe 5+ curtidas',
      tokens: 2,
      type: 'engagement',
      icon: Heart,
      isActive: true,
      triggers: 1243,
      conversions: 987,
      totalTokensGiven: 1974
    },
    {
      id: '4',
      title: 'Criador Ativo',
      description: 'Publica 10 projetos de vídeo',
      tokens: 25,
      type: 'milestone',
      icon: Star,
      isActive: true,
      triggers: 89,
      conversions: 67,
      totalTokensGiven: 1675
    },
    {
      id: '5',
      title: 'Sequência Diária',
      description: 'Acessa plataforma por 7 dias consecutivos',
      tokens: 5,
      type: 'daily',
      icon: Calendar,
      isActive: true,
      triggers: 1567,
      conversions: 834,
      totalTokensGiven: 4170
    },
    {
      id: '6',
      title: 'Compartilhamento Viral',
      description: 'Post recebe 100+ visualizações',
      tokens: 15,
      type: 'engagement',
      icon: Share,
      isActive: false,
      triggers: 234,
      conversions: 89,
      totalTokensGiven: 1335
    }
  ];

  const gamificationStats = {
    totalTokensDistributed: 25389,
    activeRewards: rewards.filter(r => r.isActive).length,
    totalRewards: rewards.length,
    conversionRate: 84.2,
    userRetention: 73.5,
    engagementBoost: 156
  };

  const recentActivities = [
    {
      id: '1',
      user: 'Ana Designer',
      action: 'Onboarding Completo',
      tokens: 5,
      timestamp: new Date(Date.now() - 5 * 60 * 1000)
    },
    {
      id: '2',
      user: 'Carlos Creator',
      action: 'Primeiro Amigo',
      tokens: 10,
      timestamp: new Date(Date.now() - 12 * 60 * 1000)
    },
    {
      id: '3',
      user: 'Maria Viral',
      action: 'Engajamento Premium',
      tokens: 2,
      timestamp: new Date(Date.now() - 18 * 60 * 1000)
    },
    {
      id: '4',
      user: 'João Expert',
      action: 'Sequência Diária',
      tokens: 5,
      timestamp: new Date(Date.now() - 25 * 60 * 1000)
    }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'onboarding': return 'bg-green-500';
      case 'referral': return 'admin-bg-blue';
      case 'engagement': return 'bg-purple-600';
      case 'milestone': return 'admin-bg-orange';
      case 'daily': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'onboarding': return 'Integração';
      case 'referral': return 'Indicação';
      case 'engagement': return 'Engajamento';
      case 'milestone': return 'Marco';
      case 'daily': return 'Diário';
      default: return 'Outro';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const minutes = Math.floor((Date.now() - date.getTime()) / (1000 * 60));
    if (minutes < 1) return 'agora';
    if (minutes < 60) return `${minutes}m atrás`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h atrás`;
  };

  const triggerTokenAnimation = (tokens: number) => {
    const newAnimation: TokenAnimation = {
      id: Date.now().toString(),
      tokens,
      x: Math.random() * 300 + 50,
      y: Math.random() * 200 + 100,
      timestamp: Date.now()
    };
    
    setTokenAnimations(prev => [...prev, newAnimation]);
    
    // Remove animation after 2 seconds
    setTimeout(() => {
      setTokenAnimations(prev => prev.filter(a => a.id !== newAnimation.id));
    }, 2000);
  };

  const toggleReward = (id: string) => {
    console.log('Toggle reward:', id);
    // Simulate token animation
    const reward = rewards.find(r => r.id === id);
    if (reward) {
      triggerTokenAnimation(reward.tokens);
    }
  };

  return (
    <div className="space-y-8 relative">
      
      {/* Token Animations */}
      <AnimatePresence>
        {tokenAnimations.map((animation) => (
          <motion.div
            key={animation.id}
            initial={{ opacity: 1, scale: 0, x: animation.x, y: animation.y }}
            animate={{ 
              opacity: 0, 
              scale: 1.5, 
              x: animation.x + 50, 
              y: animation.y - 100 
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2, ease: "easeOut" }}
            className="absolute z-50 pointer-events-none"
            style={{ left: animation.x, top: animation.y }}
          >
            <div className="flex items-center gap-1 bg-orange-500 text-white px-3 py-1 rounded-full font-bold text-sm admin-glow-orange">
              <Zap className="w-4 h-4" />
              +{animation.tokens}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Sistema de Recompensas
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Gamificação inteligente que incentiva engajamento e retenção
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { 
            label: 'Tokens Distribuídos', 
            value: gamificationStats.totalTokensDistributed.toLocaleString(), 
            icon: Zap, 
            color: 'admin-text-orange' 
          },
          { 
            label: 'Recompensas Ativas', 
            value: `${gamificationStats.activeRewards}/${gamificationStats.totalRewards}`, 
            icon: Award, 
            color: 'admin-text-blue' 
          },
          { 
            label: 'Taxa Conversão', 
            value: `${gamificationStats.conversionRate}%`, 
            icon: Target, 
            color: 'text-green-400' 
          },
          { 
            label: 'Retenção', 
            value: `${gamificationStats.userRetention}%`, 
            icon: Users, 
            color: 'text-purple-400' 
          },
          { 
            label: 'Boost Engajamento', 
            value: `+${gamificationStats.engagementBoost}%`, 
            icon: TrendingUp, 
            color: 'admin-text-orange' 
          },
          { 
            label: 'Economia Gerada', 
            value: 'R$ 1.2k', 
            icon: Gift, 
            color: 'text-green-400' 
          }
        ].map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card p-4 text-center"
          >
            <div className={`w-10 h-10 rounded-xl bg-black/30 flex items-center justify-center mx-auto mb-3`}>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            <p className={`text-lg font-bold ${stat.color} mb-1`}>{stat.value}</p>
            <p className="admin-text-smoke text-xs">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Rewards Management */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Active Rewards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold admin-text-blue">Configuração de Recompensas</h2>
              <Button className="admin-bg-orange hover:opacity-90">
                <Plus className="w-4 h-4 mr-2" />
                Nova Recompensa
              </Button>
            </div>
            
            <div className="space-y-4">
              {rewards.map((reward, index) => (
                <motion.div
                  key={reward.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className={`p-4 rounded-lg border transition-all cursor-pointer ${
                    selectedReward === reward.id 
                      ? 'bg-blue-500/10 border-blue-500/30' 
                      : reward.isActive
                        ? 'bg-green-500/5 border-green-500/20 hover:bg-green-500/10'
                        : 'bg-gray-500/5 border-gray-500/20 hover:bg-gray-500/10'
                  }`}
                  onClick={() => setSelectedReward(selectedReward === reward.id ? null : reward.id)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 ${getTypeColor(reward.type)} rounded-xl flex items-center justify-center`}>
                        <reward.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold admin-text-blue">{reward.title}</h3>
                          <Badge className={`${getTypeColor(reward.type)} text-white text-xs`}>
                            {getTypeLabel(reward.type)}
                          </Badge>
                        </div>
                        <p className="text-sm admin-text-smoke">{reward.description}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="flex items-center gap-1">
                          <Zap className="w-4 h-4 admin-text-orange" />
                          <span className="font-bold admin-text-orange">{reward.tokens}</span>
                        </div>
                        <p className="text-xs admin-text-smoke">tokens</p>
                      </div>
                      
                      <Button
                        size="sm"
                        variant={reward.isActive ? "default" : "outline"}
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleReward(reward.id);
                        }}
                        className={reward.isActive 
                          ? "bg-green-500 hover:bg-green-600" 
                          : "border-gray-500/20 admin-text-smoke hover:admin-text-blue"
                        }
                      >
                        {reward.isActive ? 'Ativo' : 'Inativo'}
                      </Button>
                    </div>
                  </div>
                  
                  {selectedReward === reward.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="border-t border-blue-500/20 pt-4"
                    >
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-3 rounded-lg bg-black/30">
                          <p className="text-lg font-bold admin-text-blue">{reward.triggers}</p>
                          <p className="text-xs admin-text-smoke">Disparos</p>
                        </div>
                        
                        <div className="text-center p-3 rounded-lg bg-black/30">
                          <p className="text-lg font-bold text-green-400">{reward.conversions}</p>
                          <p className="text-xs admin-text-smoke">Conversões</p>
                        </div>
                        
                        <div className="text-center p-3 rounded-lg bg-black/30">
                          <p className="text-lg font-bold admin-text-orange">{reward.totalTokensGiven}</p>
                          <p className="text-xs admin-text-smoke">Tokens Dados</p>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex gap-2">
                        <Button size="sm" className="admin-bg-blue hover:opacity-90">
                          Editar Recompensa
                        </Button>
                        <Button size="sm" variant="outline" className="border-blue-500/20 admin-text-blue hover:bg-blue-500/10">
                          Ver Analytics
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          
          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Atividade Recente</h3>
            
            <div className="space-y-3">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg bg-black/30">
                  <div className="w-8 h-8 admin-bg-orange rounded-full flex items-center justify-center flex-shrink-0">
                    <Zap className="w-4 h-4 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium admin-text-blue text-sm">{activity.user}</span>
                      <span className="text-xs font-bold admin-text-orange">+{activity.tokens}</span>
                    </div>
                    <p className="text-xs admin-text-smoke mb-1">{activity.action}</p>
                    <p className="text-xs admin-text-smoke opacity-70">
                      {formatTimeAgo(activity.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <Button 
              variant="ghost" 
              className="w-full mt-4 admin-text-smoke hover:admin-text-blue"
              size="sm"
            >
              Ver Todas as Atividades
            </Button>
          </motion.div>

          {/* Performance Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Performance</h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Conversão Geral</span>
                  <span className="text-sm font-bold text-green-400">84.2%</span>
                </div>
                <Progress value={84.2} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Engajamento</span>
                  <span className="text-sm font-bold admin-text-blue">92.1%</span>
                </div>
                <Progress value={92.1} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Retenção</span>
                  <span className="text-sm font-bold admin-text-orange">73.5%</span>
                </div>
                <Progress value={73.5} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">ROI Tokens</span>
                  <span className="text-sm font-bold text-purple-400">340%</span>
                </div>
                <Progress value={100} className="h-2" />
              </div>
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Ações Rápidas</h3>
            
            <div className="space-y-2">
              <Button 
                className="w-full admin-bg-orange hover:opacity-90 justify-start"
                size="sm"
                onClick={() => triggerTokenAnimation(5)}
              >
                <Gift className="w-4 h-4 mr-2" />
                Distribuir Bônus
              </Button>
              
              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
                size="sm"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Analytics Detalhado
              </Button>
              
              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
                size="sm"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Campanha
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}