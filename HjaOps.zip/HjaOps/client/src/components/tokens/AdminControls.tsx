import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings, 
  Shield, 
  AlertTriangle, 
  DollarSign,
  Users,
  Zap,
  TrendingUp,
  Target,
  BarChart3,
  Pause,
  Play,
  StopCircle,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

interface AdminControlsProps {
  data: TokenData;
}

interface SystemControl {
  id: string;
  name: string;
  description: string;
  isActive: boolean;
  type: 'safety' | 'cost' | 'performance' | 'user';
  criticalLevel: 'low' | 'medium' | 'high';
}

interface PriceControl {
  plan: string;
  currentPrice: number;
  recommendedPrice: number;
  tokensIncluded: number;
  users: number;
  revenue: number;
}

export default function AdminControls({ data }: AdminControlsProps) {
  const [emergencyMode, setEmergencyMode] = useState(false);
  const [globalCostLimit, setGlobalCostLimit] = useState([500]);
  const [marginTarget, setMarginTarget] = useState([80]);
  
  const systemControls: SystemControl[] = [
    {
      id: '1',
      name: 'Fallback Automático',
      description: 'Redirecionar para modelos mais baratos quando custo exceder limite',
      isActive: true,
      type: 'cost',
      criticalLevel: 'high'
    },
    {
      id: '2',
      name: 'Limite por Usuário',
      description: 'Pausar usuários que excedem 10x o uso médio',
      isActive: true,
      type: 'safety',
      criticalLevel: 'high'
    },
    {
      id: '3',
      name: 'Load Balancing',
      description: 'Distribuir requisições entre provedores disponíveis',
      isActive: true,
      type: 'performance',
      criticalLevel: 'medium'
    },
    {
      id: '4',
      name: 'Rate Limiting',
      description: 'Limitar requisições por minuto por usuário',
      isActive: false,
      type: 'safety',
      criticalLevel: 'medium'
    },
    {
      id: '5',
      name: 'Upgrade Automático',
      description: 'Sugerir upgrade quando uso excede 80% do plano',
      isActive: true,
      type: 'user',
      criticalLevel: 'low'
    }
  ];

  const priceControls: PriceControl[] = [
    {
      plan: 'Gratuito',
      currentPrice: 0,
      recommendedPrice: 0,
      tokensIncluded: 50,
      users: data.totalUsers - data.premiumUsers,
      revenue: 0
    },
    {
      plan: 'Básico',
      currentPrice: 29.90,
      recommendedPrice: 34.90,
      tokensIncluded: 500,
      users: Math.floor(data.premiumUsers * 0.6),
      revenue: 5986
    },
    {
      plan: 'Pro',
      currentPrice: 59.90,
      recommendedPrice: 69.90,
      tokensIncluded: 1500,
      users: Math.floor(data.premiumUsers * 0.3),
      revenue: 2995
    },
    {
      plan: 'Enterprise',
      currentPrice: 149.90,
      recommendedPrice: 179.90,
      tokensIncluded: 5000,
      users: Math.floor(data.premiumUsers * 0.1),
      revenue: 1949
    }
  ];

  const realTimeMetrics = {
    currentCost: 67.45,
    costLimit: globalCostLimit[0],
    apiErrors: 12,
    avgResponseTime: 450,
    activeUsers: 234,
    tokensPerSecond: 12.3,
    systemHealth: 98.2
  };

  const emergencyActions = [
    {
      id: '1',
      name: 'Parar Todos os Agentes',
      description: 'Interrompe imediatamente todos os agentes IA',
      icon: StopCircle,
      color: 'bg-red-600',
      action: () => console.log('Emergency: Stop all agents')
    },
    {
      id: '2',
      name: 'Modo Economia Extrema',
      description: 'Ativa apenas modelos gratuitos (Groq/HF)',
      icon: AlertTriangle,
      color: 'admin-bg-orange',
      action: () => console.log('Emergency: Economy mode')
    },
    {
      id: '3',
      name: 'Pausar Novos Usuários',
      description: 'Bloqueia cadastros temporariamente',
      icon: Pause,
      color: 'bg-yellow-600',
      action: () => console.log('Emergency: Pause registrations')
    },
    {
      id: '4',
      name: 'Resetar Sistema',
      description: 'Reinicia todos os serviços',
      icon: RefreshCw,
      color: 'admin-bg-blue',
      action: () => console.log('Emergency: System reset')
    }
  ];

  const getControlColor = (type: string) => {
    switch (type) {
      case 'safety': return 'bg-red-500/10 border-red-500/30';
      case 'cost': return 'bg-green-500/10 border-green-500/30';
      case 'performance': return 'bg-blue-500/10 border-blue-500/30';
      case 'user': return 'bg-purple-500/10 border-purple-500/30';
      default: return 'bg-gray-500/10 border-gray-500/30';
    }
  };

  const getCriticalColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'admin-bg-orange';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const toggleControl = (id: string) => {
    console.log('Toggle control:', id);
  };

  const updatePrice = (plan: string, newPrice: number) => {
    console.log('Update price:', plan, newPrice);
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Controles Administrativos
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Monitoramento e controle total do sistema de tokens
        </p>
      </div>

      {/* Emergency Mode Banner */}
      {emergencyMode && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6 bg-red-500/10 border-red-500/30"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center animate-pulse">
                <AlertTriangle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-red-400 mb-1">
                  MODO DE EMERGÊNCIA ATIVO
                </h2>
                <p className="text-red-300">
                  Sistema operando com protocolos de segurança máxima
                </p>
              </div>
            </div>
            <Button 
              onClick={() => setEmergencyMode(false)}
              className="bg-red-600 hover:bg-red-700"
            >
              Desativar
            </Button>
          </div>
        </motion.div>
      )}

      {/* Real-time System Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="admin-card p-6"
      >
        <h2 className="text-xl font-bold admin-text-blue mb-6">Status em Tempo Real</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center p-4 rounded-lg bg-black/30">
            <div className="flex items-center justify-center gap-2 mb-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              <span className={`text-lg font-bold ${
                realTimeMetrics.currentCost > realTimeMetrics.costLimit * 0.8 
                  ? 'text-red-400' 
                  : 'text-green-400'
              }`}>
                R$ {realTimeMetrics.currentCost.toFixed(2)}
              </span>
            </div>
            <p className="admin-text-smoke text-sm">Custo Atual</p>
            <div className="mt-2 h-1 bg-gray-700 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all ${
                  realTimeMetrics.currentCost > realTimeMetrics.costLimit * 0.8 
                    ? 'bg-red-500' 
                    : 'bg-green-500'
                }`}
                style={{ 
                  width: `${Math.min((realTimeMetrics.currentCost / realTimeMetrics.costLimit) * 100, 100)}%` 
                }}
              />
            </div>
          </div>
          
          <div className="text-center p-4 rounded-lg bg-black/30">
            <div className="flex items-center justify-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 admin-text-orange" />
              <span className="text-lg font-bold admin-text-orange">
                {realTimeMetrics.apiErrors}
              </span>
            </div>
            <p className="admin-text-smoke text-sm">Erros API (hoje)</p>
          </div>
          
          <div className="text-center p-4 rounded-lg bg-black/30">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Users className="w-5 h-5 admin-text-blue" />
              <span className="text-lg font-bold admin-text-blue">
                {realTimeMetrics.activeUsers}
              </span>
            </div>
            <p className="admin-text-smoke text-sm">Usuários Ativos</p>
          </div>
          
          <div className="text-center p-4 rounded-lg bg-black/30">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Zap className="w-5 h-5 admin-text-orange" />
              <span className="text-lg font-bold admin-text-orange">
                {realTimeMetrics.tokensPerSecond.toFixed(1)}
              </span>
            </div>
            <p className="admin-text-smoke text-sm">Tokens/seg</p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* System Controls */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Global Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Configurações Globais</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium admin-text-blue mb-3">
                  Limite de Custo Diário: R$ {globalCostLimit[0]}
                </label>
                <Slider
                  value={globalCostLimit}
                  onValueChange={setGlobalCostLimit}
                  max={1000}
                  min={100}
                  step={50}
                  className="w-full"
                />
                <div className="flex justify-between text-xs admin-text-smoke mt-1">
                  <span>R$ 100</span>
                  <span>R$ 1.000</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium admin-text-blue mb-3">
                  Meta de Margem de Lucro: {marginTarget[0]}%
                </label>
                <Slider
                  value={marginTarget}
                  onValueChange={setMarginTarget}
                  max={95}
                  min={50}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs admin-text-smoke mt-1">
                  <span>50%</span>
                  <span>95%</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-4 rounded-lg bg-black/30">
                <div>
                  <h3 className="font-semibold admin-text-blue mb-1">Modo de Emergência</h3>
                  <p className="text-sm admin-text-smoke">Ativa protocolos de segurança extrema</p>
                </div>
                <Switch 
                  checked={emergencyMode}
                  onCheckedChange={setEmergencyMode}
                  className="data-[state=checked]:bg-red-500"
                />
              </div>
            </div>
          </motion.div>

          {/* System Controls */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Controles do Sistema</h2>
            
            <div className="space-y-4">
              {systemControls.map((control, index) => (
                <motion.div
                  key={control.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className={`p-4 rounded-lg border ${getControlColor(control.type)}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-start gap-3">
                      <Badge className={`${getCriticalColor(control.criticalLevel)} text-white text-xs mt-1`}>
                        {control.criticalLevel.toUpperCase()}
                      </Badge>
                      <div>
                        <h3 className="font-semibold admin-text-blue mb-1">{control.name}</h3>
                        <p className="text-sm admin-text-smoke">{control.description}</p>
                      </div>
                    </div>
                    
                    <Switch 
                      checked={control.isActive}
                      onCheckedChange={() => toggleControl(control.id)}
                      className="data-[state=checked]:bg-blue-500"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Price Controls */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Controle de Preços</h2>
            
            <div className="space-y-4">
              {priceControls.map((plan) => (
                <div key={plan.plan} className="p-4 rounded-lg bg-black/30">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold admin-text-blue">{plan.plan}</h3>
                      <p className="text-sm admin-text-smoke">
                        {plan.tokensIncluded.toLocaleString()} tokens • {plan.users} usuários
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-green-400">
                        R$ {(plan.revenue).toLocaleString()}
                      </p>
                      <p className="text-xs admin-text-smoke">Receita/mês</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs admin-text-smoke mb-1">Preço Atual</label>
                      <Input
                        type="number"
                        value={plan.currentPrice}
                        onChange={(e) => updatePrice(plan.plan, parseFloat(e.target.value))}
                        className="bg-black/50 border-blue-500/20"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-xs admin-text-smoke mb-1">IA Recomenda</label>
                      <div className="flex items-center gap-2 h-10 px-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-sm font-bold text-green-400">
                          R$ {plan.recommendedPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar - Emergency & Quick Actions */}
        <div className="space-y-6">
          
          {/* Emergency Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Ações de Emergência</h3>
            
            <div className="space-y-3">
              {emergencyActions.map((action) => (
                <Button
                  key={action.id}
                  onClick={action.action}
                  className={`w-full ${action.color} hover:opacity-90 justify-start`}
                  size="sm"
                >
                  <action.icon className="w-4 h-4 mr-2" />
                  {action.name}
                </Button>
              ))}
            </div>
            
            <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-4 h-4 text-red-400" />
                <span className="text-sm font-semibold text-red-400">Protocolo de Segurança</span>
              </div>
              <p className="text-xs text-red-300">
                Ações irreversíveis requerem confirmação dupla
              </p>
            </div>
          </motion.div>

          {/* System Health */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Saúde do Sistema</h3>
            
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400 mb-2">
                  {realTimeMetrics.systemHealth.toFixed(1)}%
                </div>
                <p className="admin-text-smoke text-sm mb-3">Score Geral</p>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all"
                    style={{ width: `${realTimeMetrics.systemHealth}%` }}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs admin-text-smoke">API Disponibilidade</span>
                  <span className="text-xs font-bold text-green-400">99.8%</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-xs admin-text-smoke">Tempo Resposta</span>
                  <span className="text-xs font-bold admin-text-blue">{realTimeMetrics.avgResponseTime}ms</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-xs admin-text-smoke">Erro Rate</span>
                  <span className="text-xs font-bold admin-text-orange">0.2%</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-xs admin-text-smoke">Throughput</span>
                  <span className="text-xs font-bold text-purple-400">
                    {realTimeMetrics.tokensPerSecond.toFixed(1)} tok/s
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Recent Alerts */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Alertas Recentes</h3>
            
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span className="text-xs font-semibold text-red-400">CRÍTICO</span>
                </div>
                <p className="text-xs text-red-300 mb-2">
                  OpenAI API com 15% de erro rate
                </p>
                <p className="text-xs admin-text-smoke">2 min atrás</p>
              </div>
              
              <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <span className="text-xs font-semibold text-yellow-400">ATENÇÃO</span>
                </div>
                <p className="text-xs text-yellow-300 mb-2">
                  Usuário excedeu limite diário
                </p>
                <p className="text-xs admin-text-smoke">8 min atrás</p>
              </div>
              
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <BarChart3 className="w-4 h-4 admin-text-blue" />
                  <span className="text-xs font-semibold admin-text-blue">INFO</span>
                </div>
                <p className="text-xs text-blue-300 mb-2">
                  Nova otimização ativada
                </p>
                <p className="text-xs admin-text-smoke">15 min atrás</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}