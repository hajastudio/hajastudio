import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  Users, 
  Crown, 
  Zap,
  Settings,
  BarChart3,
  ArrowRight,
  Check,
  X,
  AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

interface SmartDistributionProps {
  data: TokenData;
}

interface ModelProvider {
  id: string;
  name: string;
  cost: number;
  performance: number;
  latency: number;
  reliability: number;
  isActive: boolean;
  usage: number;
  costToday: number;
}

interface UserTier {
  id: string;
  name: string;
  users: number;
  tokensPerDay: number;
  allowedModels: string[];
  priority: number;
  color: string;
}

export default function SmartDistribution({ data }: SmartDistributionProps) {
  const [autoDistribution, setAutoDistribution] = useState(true);
  const [selectedTier, setSelectedTier] = useState<string | null>(null);

  const modelProviders: ModelProvider[] = [
    {
      id: 'groq',
      name: 'Groq (Llama 3)',
      cost: 0.001,
      performance: 85,
      latency: 120,
      reliability: 98,
      isActive: true,
      usage: 45,
      costToday: 23.40
    },
    {
      id: 'openai',
      name: 'OpenAI GPT-4o',
      cost: 0.030,
      performance: 98,
      latency: 800,
      reliability: 99,
      isActive: true,
      usage: 25,
      costToday: 89.50
    },
    {
      id: 'huggingface',
      name: 'HuggingFace Mixtral',
      cost: 0.002,
      performance: 80,
      latency: 200,
      reliability: 95,
      isActive: true,
      usage: 20,
      costToday: 12.80
    },
    {
      id: 'anthropic',
      name: 'Claude 3 Sonnet',
      cost: 0.025,
      performance: 95,
      latency: 600,
      reliability: 97,
      isActive: false,
      usage: 10,
      costToday: 45.20
    }
  ];

  const userTiers: UserTier[] = [
    {
      id: 'free',
      name: 'Usuários Gratuitos',
      users: data.totalUsers - data.premiumUsers,
      tokensPerDay: 50,
      allowedModels: ['groq', 'huggingface'],
      priority: 3,
      color: 'bg-gray-500'
    },
    {
      id: 'basic',
      name: 'Plano Básico',
      users: Math.floor(data.premiumUsers * 0.6),
      tokensPerDay: 200,
      allowedModels: ['groq', 'huggingface', 'openai'],
      priority: 2,
      color: 'admin-bg-blue'
    },
    {
      id: 'pro',
      name: 'Plano Pro',
      users: Math.floor(data.premiumUsers * 0.3),
      tokensPerDay: 500,
      allowedModels: ['groq', 'huggingface', 'openai', 'anthropic'],
      priority: 1,
      color: 'admin-bg-orange'
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      users: Math.floor(data.premiumUsers * 0.1),
      tokensPerDay: 2000,
      allowedModels: ['groq', 'huggingface', 'openai', 'anthropic'],
      priority: 0,
      color: 'bg-purple-600'
    }
  ];

  const distributionRules = [
    {
      id: '1',
      title: 'Fallback Inteligente',
      description: 'Se OpenAI estiver indisponível, redirecionar para Groq automaticamente',
      isActive: true,
      impact: 'high'
    },
    {
      id: '2',
      title: 'Limite de Custo',
      description: 'Pausar modelos caros quando custo diário > R$ 100',
      isActive: true,
      impact: 'high'
    },
    {
      id: '3',
      title: 'Horário de Pico',
      description: 'Entre 9h-18h, priorizar modelos mais rápidos para usuários Pro',
      isActive: false,
      impact: 'medium'
    },
    {
      id: '4',
      title: 'Load Balancing',
      description: 'Distribuir uniformemente entre provedores disponíveis',
      isActive: true,
      impact: 'medium'
    }
  ];

  const toggleModelProvider = (id: string) => {
    console.log('Toggle provider:', id);
  };

  const updateDistributionRule = (id: string) => {
    console.log('Update rule:', id);
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Distribuição Inteligente
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Otimização automática de custos e performance por tier de usuário
        </p>
      </div>

      {/* Auto Distribution Toggle */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="admin-card p-6 bg-gradient-to-r from-blue-500/10 to-green-500/10 border-blue-500/30"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold admin-text-blue mb-1">
                Distribuição Automática
              </h2>
              <p className="admin-text-smoke">
                IA gerencia automaticamente a alocação de tokens baseada em custos e performance
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-bold text-green-400">87.2% economia</p>
              <p className="text-xs admin-text-smoke">vs. distribuição manual</p>
            </div>
            <Switch 
              checked={autoDistribution}
              onCheckedChange={setAutoDistribution}
              className="data-[state=checked]:bg-blue-500"
            />
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Model Providers */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Providers Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Provedores de Modelo</h2>
            
            <div className="space-y-4">
              {modelProviders.map((provider, index) => (
                <motion.div
                  key={provider.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className={`p-4 rounded-lg border transition-all ${
                    provider.isActive 
                      ? 'bg-green-500/5 border-green-500/20' 
                      : 'bg-gray-500/5 border-gray-500/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${
                        provider.isActive ? 'bg-green-500' : 'bg-gray-500'
                      }`} />
                      <h3 className="font-semibold admin-text-blue">{provider.name}</h3>
                      <Badge className={`${provider.isActive ? 'bg-green-500' : 'bg-gray-500'} text-white text-xs`}>
                        {provider.isActive ? 'Ativo' : 'Inativo'}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-bold admin-text-blue">
                          R$ {provider.costToday.toFixed(2)}
                        </p>
                        <p className="text-xs admin-text-smoke">Custo hoje</p>
                      </div>
                      
                      <Switch 
                        checked={provider.isActive}
                        onCheckedChange={() => toggleModelProvider(provider.id)}
                        className="data-[state=checked]:bg-blue-500"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-xs admin-text-smoke mb-1">Custo/1k tokens</p>
                      <p className="text-sm font-bold admin-text-orange">
                        R$ {provider.cost.toFixed(3)}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-xs admin-text-smoke mb-1">Performance</p>
                      <p className="text-sm font-bold admin-text-blue">
                        {provider.performance}%
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-xs admin-text-smoke mb-1">Latência</p>
                      <p className="text-sm font-bold admin-text-smoke">
                        {provider.latency}ms
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-xs admin-text-smoke mb-1">Confiabilidade</p>
                      <p className="text-sm font-bold text-green-400">
                        {provider.reliability}%
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs admin-text-smoke">Uso hoje</span>
                      <span className="text-xs font-bold admin-text-blue">{provider.usage}%</span>
                    </div>
                    <Progress value={provider.usage} className="h-2" />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Distribution Rules */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Regras de Distribuição</h2>
            
            <div className="space-y-4">
              {distributionRules.map((rule, index) => (
                <div key={rule.id} className="flex items-center justify-between p-4 rounded-lg bg-black/30">
                  <div className="flex items-start gap-3">
                    <div className={`mt-1 w-2 h-2 rounded-full ${
                      rule.isActive ? 'bg-green-500' : 'bg-gray-500'
                    }`} />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold admin-text-blue">{rule.title}</h3>
                        <Badge className={`${
                          rule.impact === 'high' ? 'bg-red-500' :
                          rule.impact === 'medium' ? 'admin-bg-orange' : 'bg-green-500'
                        } text-white text-xs`}>
                          {rule.impact}
                        </Badge>
                      </div>
                      <p className="text-sm admin-text-smoke">{rule.description}</p>
                    </div>
                  </div>
                  
                  <Switch 
                    checked={rule.isActive}
                    onCheckedChange={() => updateDistributionRule(rule.id)}
                    className="data-[state=checked]:bg-blue-500"
                  />
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* User Tiers */}
        <div className="space-y-6">
          
          {/* Tier Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Tiers de Usuário</h3>
            
            <div className="space-y-3">
              {userTiers.map((tier) => (
                <button
                  key={tier.id}
                  onClick={() => setSelectedTier(tier.id)}
                  className={`w-full text-left p-3 rounded-lg transition-all ${
                    selectedTier === tier.id 
                      ? 'bg-blue-500/20 border border-blue-500/30' 
                      : 'bg-black/30 hover:bg-black/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${tier.color}`} />
                      <span className="font-medium admin-text-blue text-sm">{tier.name}</span>
                    </div>
                    <Badge className={`${tier.color} text-white text-xs`}>
                      P{tier.priority}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <p className="admin-text-smoke">Usuários</p>
                      <p className="font-bold admin-text-blue">{tier.users}</p>
                    </div>
                    <div>
                      <p className="admin-text-smoke">Tokens/dia</p>
                      <p className="font-bold admin-text-orange">{tier.tokensPerDay}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </motion.div>

          {/* Cost Optimization */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Otimização de Custos</h3>
            
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <Check className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-semibold text-green-400">Economia Ativa</span>
                </div>
                <p className="text-xs admin-text-smoke mb-2">
                  Redirecionando 70% do tráfego para Groq
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs admin-text-smoke">Economia hoje</span>
                  <span className="text-xs font-bold text-green-400">R$ 45.20</span>
                </div>
              </div>
              
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <BarChart3 className="w-4 h-4 admin-text-blue" />
                  <span className="text-sm font-semibold admin-text-blue">Balanceamento</span>
                </div>
                <p className="text-xs admin-text-smoke mb-2">
                  Distribuição equilibrada entre provedores
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs admin-text-smoke">Eficiência</span>
                  <span className="text-xs font-bold admin-text-blue">94.2%</span>
                </div>
              </div>
              
              <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-semibold text-yellow-400">Alerta</span>
                </div>
                <p className="text-xs admin-text-smoke mb-2">
                  OpenAI com latência alta (1.2s)
                </p>
                <Button size="sm" className="w-full admin-bg-orange hover:opacity-90">
                  Investigar
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Ações Rápidas</h3>
            
            <div className="space-y-2">
              <Button 
                className="w-full admin-bg-blue hover:opacity-90 justify-start"
                size="sm"
              >
                <Settings className="w-4 h-4 mr-2" />
                Ajustar Regras
              </Button>
              
              <Button 
                className="w-full admin-bg-orange hover:opacity-90 justify-start"
                size="sm"
              >
                <Target className="w-4 h-4 mr-2" />
                Modo Economia
              </Button>
              
              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
                size="sm"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Ver Analytics
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}