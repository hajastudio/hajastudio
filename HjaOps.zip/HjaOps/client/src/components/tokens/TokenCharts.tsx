import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  Calendar,
  Filter,
  Download,
  Zap,
  DollarSign,
  Users,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

interface TokenChartsProps {
  data: TokenData;
}

export default function TokenCharts({ data }: TokenChartsProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const [chartTheme, setChartTheme] = useState<ApexOptions>({});

  useEffect(() => {
    // Configuração do tema para ApexCharts
    setChartTheme({
      chart: {
        background: 'transparent',
        fontFamily: 'Inter, sans-serif',
        toolbar: {
          show: false
        }
      },
      theme: {
        mode: 'dark'
      },
      grid: {
        borderColor: '#374151',
        strokeDashArray: 3
      },
      tooltip: {
        theme: 'dark'
      }
    });
  }, []);

  // Dados dos gráficos
  const tokenUsageData = {
    series: [{
      name: 'Tokens Consumidos',
      data: [1200, 800, 1800, 2400, 3200, 2800, 2100, 2600, 1900, 2300, 2800, 3100, 2700, 2200, 2900, 3300, 2400, 2700, 3000, 2500, 2800, 3200, 2600, 2900, 3100, 2300, 2600, 2800, 3000, 2400]
    }],
    options: {
      ...chartTheme,
      chart: {
        ...chartTheme.chart,
        type: 'area' as const,
        height: 350,
        sparkline: {
          enabled: false
        }
      },
      stroke: {
        curve: 'smooth' as const,
        width: 3,
        colors: ['#0055ff']
      },
      fill: {
        type: 'gradient',
        gradient: {
          shadeIntensity: 1,
          opacityFrom: 0.7,
          opacityTo: 0.1,
          stops: [0, 100],
          colorStops: [
            {
              offset: 0,
              color: '#0055ff',
              opacity: 0.7
            },
            {
              offset: 100,
              color: '#0055ff',
              opacity: 0.1
            }
          ]
        }
      },
      xaxis: {
        categories: Array.from({length: 30}, (_, i) => `${i + 1}`),
        labels: {
          style: {
            colors: '#c5d1db'
          }
        }
      },
      yaxis: {
        labels: {
          style: {
            colors: '#c5d1db'
          },
          formatter: (value: number) => `${value.toLocaleString()}`
        }
      },
      colors: ['#0055ff']
    } as ApexOptions
  };

  const providerDistribution = {
    series: [45, 25, 20, 10],
    options: {
      ...chartTheme,
      chart: {
        ...chartTheme.chart,
        type: 'donut' as const,
        height: 350
      },
      labels: ['Groq (Llama 3)', 'OpenAI GPT-4o', 'HuggingFace', 'Claude 3'],
      colors: ['#0055ff', '#ff6a00', '#22c55e', '#8b5cf6'],
      legend: {
        position: 'bottom' as const,
        labels: {
          colors: '#c5d1db'
        }
      },
      plotOptions: {
        pie: {
          donut: {
            size: '70%',
            labels: {
              show: true,
              total: {
                show: true,
                label: 'Total',
                color: '#c5d1db',
                formatter: () => '100%'
              }
            }
          }
        }
      }
    } as ApexOptions
  };

  const costAnalysis = {
    series: [
      {
        name: 'Custo',
        type: 'column',
        data: [45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23]
      },
      {
        name: 'Margem',
        type: 'line',
        data: [85, 82, 88, 75, 84, 79, 86, 81, 77, 87, 80, 89, 76, 83, 78, 85, 82, 78, 86, 81, 88, 77, 83, 79, 85, 82, 78, 87, 81, 89]
      }
    ],
    options: {
      ...chartTheme,
      chart: {
        ...chartTheme.chart,
        type: 'line' as const,
        height: 350
      },
      stroke: {
        width: [0, 3],
        colors: ['transparent', '#ff6a00']
      },
      plotOptions: {
        bar: {
          columnWidth: '50%'
        }
      },
      colors: ['#0055ff', '#ff6a00'],
      xaxis: {
        categories: Array.from({length: 30}, (_, i) => `${i + 1}`),
        labels: {
          style: {
            colors: '#c5d1db'
          }
        }
      },
      yaxis: [
        {
          title: {
            text: 'Custo (R$)',
            style: {
              color: '#c5d1db'
            }
          },
          labels: {
            style: {
              colors: '#c5d1db'
            },
            formatter: (value: number) => `R$ ${value}`
          }
        },
        {
          opposite: true,
          title: {
            text: 'Margem (%)',
            style: {
              color: '#c5d1db'
            }
          },
          labels: {
            style: {
              colors: '#c5d1db'
            },
            formatter: (value: number) => `${value}%`
          }
        }
      ]
    } as ApexOptions
  };

  const userEngagement = {
    series: [
      {
        name: 'Usuários Ativos',
        data: [234, 267, 189, 298, 245, 267, 234, 298, 276, 245, 289, 312, 267, 234, 298, 245, 267, 289, 234, 267, 189, 298, 245, 267, 234, 298, 276, 245, 289, 312]
      },
      {
        name: 'Novos Usuários',
        data: [45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23, 89, 56, 78, 45, 67, 89, 45, 67, 23]
      }
    ],
    options: {
      ...chartTheme,
      chart: {
        ...chartTheme.chart,
        type: 'bar' as const,
        height: 350,
        stacked: true
      },
      colors: ['#0055ff', '#ff6a00'],
      xaxis: {
        categories: Array.from({length: 30}, (_, i) => `${i + 1}`),
        labels: {
          style: {
            colors: '#c5d1db'
          }
        }
      },
      yaxis: {
        labels: {
          style: {
            colors: '#c5d1db'
          }
        }
      },
      legend: {
        labels: {
          colors: '#c5d1db'
        }
      }
    } as ApexOptions
  };

  const kpiCards = [
    {
      title: 'Tokens Hoje',
      value: data.dailyUsage.toLocaleString(),
      change: '+12%',
      isPositive: true,
      icon: Zap,
      color: 'admin-text-blue'
    },
    {
      title: 'Custo Médio',
      value: `R$ ${(data.estimatedMonthlyCost / 30).toFixed(2)}`,
      change: '-8%',
      isPositive: false,
      icon: DollarSign,
      color: 'text-green-400'
    },
    {
      title: 'Eficiência',
      value: `${data.profitMargin.toFixed(1)}%`,
      change: '+5%',
      isPositive: true,
      icon: Target,
      color: 'admin-text-orange'
    },
    {
      title: 'Conversão',
      value: `${data.conversionRate.toFixed(1)}%`,
      change: '+2.1%',
      isPositive: true,
      icon: TrendingUp,
      color: 'text-purple-400'
    }
  ];

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Analytics & Visualizações
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Dashboards interativos com insights de consumo e performance
        </p>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {(['7d', '30d', '90d'] as const).map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedPeriod(period)}
              className={selectedPeriod === period 
                ? "admin-bg-blue hover:opacity-90" 
                : "border-blue-500/20 admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
              }
            >
              {period === '7d' ? '7 Dias' : period === '30d' ? '30 Dias' : '90 Dias'}
            </Button>
          ))}
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            className="border-blue-500/20 admin-text-blue hover:bg-blue-500/10"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filtros
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            className="border-blue-500/20 admin-text-blue hover:bg-blue-500/10"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((kpi, index) => (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-black/30 rounded-xl flex items-center justify-center">
                <kpi.icon className={`w-6 h-6 ${kpi.color}`} />
              </div>
              <Badge className={`${kpi.isPositive ? 'bg-green-500' : 'bg-red-500'} text-white text-xs`}>
                {kpi.change}
              </Badge>
            </div>
            
            <div>
              <p className={`text-2xl font-bold ${kpi.color} mb-1`}>{kpi.value}</p>
              <p className="admin-text-smoke text-sm">{kpi.title}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Token Usage Over Time */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 admin-text-blue" />
              <h2 className="text-xl font-bold admin-text-blue">Consumo de Tokens</h2>
            </div>
            <Badge className="admin-bg-blue text-white">
              Últimos {selectedPeriod}
            </Badge>
          </div>
          
          <Chart
            options={tokenUsageData.options}
            series={tokenUsageData.series}
            type="area"
            height={350}
          />
        </motion.div>

        {/* Provider Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <PieChart className="w-5 h-5 admin-text-orange" />
              <h2 className="text-xl font-bold admin-text-blue">Distribuição por Provedor</h2>
            </div>
            <Badge className="admin-bg-orange text-white">
              Hoje
            </Badge>
          </div>
          
          <Chart
            options={providerDistribution.options}
            series={providerDistribution.series}
            type="donut"
            height={350}
          />
        </motion.div>

        {/* Cost Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              <h2 className="text-xl font-bold admin-text-blue">Análise de Custos vs Margem</h2>
            </div>
            <Badge className="bg-green-500 text-white">
              87.2% Margem Média
            </Badge>
          </div>
          
          <Chart
            options={costAnalysis.options}
            series={costAnalysis.series}
            type="line"
            height={350}
          />
        </motion.div>

        {/* User Engagement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-400" />
              <h2 className="text-xl font-bold admin-text-blue">Engajamento de Usuários</h2>
            </div>
            <Badge className="bg-purple-500 text-white">
              +{data.conversionRate.toFixed(1)}% Crescimento
            </Badge>
          </div>
          
          <Chart
            options={userEngagement.options}
            series={userEngagement.series}
            type="bar"
            height={350}
          />
        </motion.div>
      </div>

      {/* Insights Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="admin-card p-6"
      >
        <h2 className="text-xl font-bold admin-text-blue mb-6">Insights Automáticos</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="font-semibold text-green-400">Economia Detectada</span>
            </div>
            <p className="admin-text-smoke text-sm mb-2">
              Migração para Groq resultou em 45% de economia nos últimos 7 dias.
            </p>
            <p className="text-sm font-bold text-green-400">R$ 156.30 economizados</p>
          </div>
          
          <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-5 h-5 admin-text-blue" />
              <span className="font-semibold admin-text-blue">Otimização Sugerida</span>
            </div>
            <p className="admin-text-smoke text-sm mb-2">
              Balanceamento de carga pode aumentar eficiência em 12%.
            </p>
            <p className="text-sm font-bold admin-text-blue">Implementar hoje</p>
          </div>
          
          <div className="p-4 rounded-lg bg-orange-500/10 border border-orange-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-5 h-5 admin-text-orange" />
              <span className="font-semibold admin-text-orange">Previsão de Pico</span>
            </div>
            <p className="admin-text-smoke text-sm mb-2">
              Pico de uso esperado entre 14h-16h baseado no histórico.
            </p>
            <p className="text-sm font-bold admin-text-orange">Preparar recursos</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}