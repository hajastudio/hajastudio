import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Target,
  Calendar,
  Zap,
  ArrowUp,
  ArrowDown,
  Clock,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

interface ForecastSectionProps {
  data: TokenData;
}

interface Prediction {
  id: string;
  type: 'shortage' | 'upgrade' | 'optimization' | 'cost';
  title: string;
  description: string;
  probability: number;
  impact: 'high' | 'medium' | 'low';
  daysUntil: number;
  action: string;
  estimatedSavings?: number;
}

export default function ForecastSection({ data }: ForecastSectionProps) {
  const [forecastPeriod, setForecastPeriod] = useState<'7d' | '30d' | '90d'>('30d');

  const predictions: Prediction[] = [
    {
      id: '1',
      type: 'shortage',
      title: 'Escassez de Tokens Prevista',
      description: `Com o uso atual de ${data.dailyUsage} tokens/dia, você ficará sem tokens em ${data.daysRemaining} dias.`,
      probability: 95,
      impact: 'high',
      daysUntil: data.daysRemaining,
      action: 'Comprar 2.000 tokens agora'
    },
    {
      id: '2',
      type: 'upgrade',
      title: 'Upgrade Recomendado',
      description: 'Seu padrão de uso indica que o plano Pro seria mais econômico.',
      probability: 78,
      impact: 'medium',
      daysUntil: 5,
      action: 'Upgrade para Pro',
      estimatedSavings: 89.50
    },
    {
      id: '3',
      type: 'optimization',
      title: 'Oportunidade de Otimização',
      description: 'Migrar 40% do tráfego para modelos Groq reduziria custos em 60%.',
      probability: 85,
      impact: 'high',
      daysUntil: 0,
      action: 'Ativar distribuição inteligente',
      estimatedSavings: 156.30
    },
    {
      id: '4',
      type: 'cost',
      title: 'Aumento de Custo Previsto',
      description: 'OpenAI pode aumentar preços em 15% no próximo trimestre.',
      probability: 65,
      impact: 'medium',
      daysUntil: 45,
      action: 'Diversificar provedores'
    }
  ];

  const usageProjection = [
    { period: 'Hoje', tokens: data.dailyUsage, cost: 8.50 },
    { period: 'Amanhã', tokens: 168, cost: 9.20 },
    { period: '7 dias', tokens: 1140, cost: 62.30 },
    { period: '30 dias', tokens: 4800, cost: 262.40 },
    { period: '90 dias', tokens: 15600, cost: 853.20 }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'shortage': return <AlertTriangle className="w-5 h-5" />;
      case 'upgrade': return <TrendingUp className="w-5 h-5" />;
      case 'optimization': return <Target className="w-5 h-5" />;
      case 'cost': return <Zap className="w-5 h-5" />;
      default: return <Brain className="w-5 h-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'shortage': return 'bg-red-500/10 border-red-500/30 text-red-400';
      case 'upgrade': return 'bg-blue-500/10 border-blue-500/30 admin-text-blue';
      case 'optimization': return 'bg-green-500/10 border-green-500/30 text-green-400';
      case 'cost': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'admin-bg-orange';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Previsão Inteligente
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          IA analisa padrões de uso e prevê cenários futuros
        </p>
      </div>

      {/* AI Status Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="admin-card p-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center admin-pulse">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold admin-text-blue mb-2">
              HVC IA Engine Ativa
            </h2>
            <p className="admin-text-smoke">
              Analisando 24/7 padrões de uso, custos de API e comportamento do usuário para otimizar distribuição de tokens.
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <span className="text-sm font-bold text-green-400">98.5% Precisão</span>
            </div>
            <p className="text-xs admin-text-smoke">Última análise: agora</p>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Predictions & Alerts */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Forecast Period Selector */}
          <div className="flex gap-2">
            {(['7d', '30d', '90d'] as const).map((period) => (
              <Button
                key={period}
                variant={forecastPeriod === period ? "default" : "outline"}
                size="sm"
                onClick={() => setForecastPeriod(period)}
                className={forecastPeriod === period 
                  ? "admin-bg-blue hover:opacity-90" 
                  : "border-blue-500/20 admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
                }
              >
                {period === '7d' ? '7 Dias' : period === '30d' ? '30 Dias' : '90 Dias'}
              </Button>
            ))}
          </div>

          {/* AI Predictions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Predições IA</h2>
            
            <div className="space-y-4">
              {predictions.map((prediction, index) => (
                <motion.div
                  key={prediction.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className={`p-4 rounded-lg border ${getTypeColor(prediction.type)}`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {getTypeIcon(prediction.type)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold">{prediction.title}</h3>
                        <Badge className={`${getImpactColor(prediction.impact)} text-white text-xs`}>
                          {prediction.impact}
                        </Badge>
                        <span className="text-xs admin-text-smoke">
                          {prediction.probability}% probabilidade
                        </span>
                      </div>
                      
                      <p className="text-sm admin-text-smoke mb-3">
                        {prediction.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 admin-text-smoke" />
                            <span className="text-xs admin-text-smoke">
                              {prediction.daysUntil === 0 ? 'Agora' : `${prediction.daysUntil} dias`}
                            </span>
                          </div>
                          
                          {prediction.estimatedSavings && (
                            <div className="flex items-center gap-1">
                              <ArrowDown className="w-3 h-3 text-green-400" />
                              <span className="text-xs text-green-400 font-semibold">
                                R$ {prediction.estimatedSavings.toFixed(2)}
                              </span>
                            </div>
                          )}
                        </div>
                        
                        <Button 
                          size="sm" 
                          className="admin-bg-blue hover:opacity-90"
                        >
                          {prediction.action}
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Usage Projection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Projeção de Uso</h2>
            
            <div className="space-y-4">
              {usageProjection.map((projection, index) => (
                <div key={projection.period} className="flex items-center justify-between p-3 rounded-lg bg-black/30">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 admin-bg-blue rounded-lg flex items-center justify-center">
                      <span className="text-xs font-bold text-white">{index + 1}</span>
                    </div>
                    <span className="font-medium admin-text-blue">{projection.period}</span>
                  </div>
                  
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-sm font-bold admin-text-blue">
                        {projection.tokens.toLocaleString()} tokens
                      </p>
                      <p className="text-xs admin-text-smoke">Uso estimado</p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-sm font-bold text-green-400">
                        R$ {projection.cost.toFixed(2)}
                      </p>
                      <p className="text-xs admin-text-smoke">Custo estimado</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar - Quick Stats & Actions */}
        <div className="space-y-6">
          
          {/* Forecast Accuracy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Precisão da IA</h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Predições Corretas</span>
                  <span className="text-sm font-bold text-green-400">98.5%</span>
                </div>
                <Progress value={98.5} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Economia Gerada</span>
                  <span className="text-sm font-bold admin-text-blue">R$ 2.847</span>
                </div>
                <Progress value={85} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Alertas Prevenidos</span>
                  <span className="text-sm font-bold admin-text-orange">23</span>
                </div>
                <Progress value={92} className="h-2" />
              </div>
            </div>
          </motion.div>

          {/* Emergency Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Ações de Emergência</h3>
            
            <div className="space-y-3">
              <Button 
                className="w-full bg-red-600 hover:bg-red-700 justify-start"
                size="sm"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                Parar Todos os Agentes
              </Button>
              
              <Button 
                className="w-full admin-bg-orange hover:opacity-90 justify-start"
                size="sm"
              >
                <Zap className="w-4 h-4 mr-2" />
                Compra de Emergência
              </Button>
              
              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
                size="sm"
              >
                <Target className="w-4 h-4 mr-2" />
                Ativar Modo Economia
              </Button>
            </div>
          </motion.div>

          {/* AI Recommendations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Recomendações IA</h3>
            
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-semibold text-green-400">Implementada</span>
                </div>
                <p className="text-xs admin-text-smoke">Fallback automático para Groq</p>
              </div>
              
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <Clock className="w-4 h-4 admin-text-blue" />
                  <span className="text-sm font-semibold admin-text-blue">Pendente</span>
                </div>
                <p className="text-xs admin-text-smoke">Agendar compra para 3ª feira</p>
              </div>
              
              <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-semibold text-yellow-400">Urgente</span>
                </div>
                <p className="text-xs admin-text-smoke">Revisar limites do usuário João</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}