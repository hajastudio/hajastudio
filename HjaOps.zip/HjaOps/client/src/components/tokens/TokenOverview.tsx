import { motion } from 'framer-motion';
import { 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  DollarSign,
  Target,
  Calendar,
  Users,
  Crown,
  CheckCircle,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

interface TokenOverviewProps {
  data: TokenData;
}

export default function TokenOverview({ data }: TokenOverviewProps) {
  const alertLevel = data.daysRemaining <= 7 ? 'high' : data.daysRemaining <= 14 ? 'medium' : 'low';
  
  const kpis = [
    {
      label: 'Saldo Atual',
      value: data.currentBalance.toLocaleString(),
      icon: Zap,
      color: 'admin-text-blue',
      bgColor: 'admin-bg-blue',
      change: '+12%',
      isPositive: true
    },
    {
      label: 'Uso Diário',
      value: data.dailyUsage.toString(),
      icon: TrendingUp,
      color: 'admin-text-orange',
      bgColor: 'admin-bg-orange',
      change: '-5%',
      isPositive: false
    },
    {
      label: 'Custo Estimado',
      value: `R$ ${data.estimatedMonthlyCost.toFixed(2)}`,
      icon: DollarSign,
      color: 'text-green-400',
      bgColor: 'bg-green-600',
      change: '+8%',
      isPositive: true
    },
    {
      label: 'Conversão',
      value: `${data.conversionRate.toFixed(1)}%`,
      icon: Target,
      color: 'text-purple-400',
      bgColor: 'bg-purple-600',
      change: '+2.1%',
      isPositive: true
    }
  ];

  const alerts = [
    {
      id: '1',
      level: 'high' as const,
      title: 'Tokens Acabando',
      message: `Restam apenas ${data.daysRemaining} dias. Considere comprar mais tokens.`,
      action: 'Comprar Agora',
      timestamp: new Date()
    },
    {
      id: '2',
      level: 'medium' as const,
      title: 'Uso Anômalo Detectado',
      message: 'Usuário João Silva consumiu 300% acima da média hoje.',
      action: 'Investigar',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000)
    },
    {
      id: '3',
      level: 'low' as const,
      title: 'Margem de Lucro Alta',
      message: `Margem atual de ${data.profitMargin.toFixed(1)}% está acima da meta.`,
      action: 'Ver Detalhes',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000)
    }
  ];

  const getAlertColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-500/10 border-red-500/30 text-red-400';
      case 'medium': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
      case 'low': return 'bg-green-500/10 border-green-500/30 text-green-400';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getAlertIcon = (level: string) => {
    switch (level) {
      case 'high': return <AlertTriangle className="w-4 h-4" />;
      case 'medium': return <AlertTriangle className="w-4 h-4" />;
      case 'low': return <CheckCircle className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Visão Geral do Sistema
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Monitoramento em tempo real de tokens, custos e performance
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <motion.div
            key={kpi.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${kpi.bgColor} rounded-xl flex items-center justify-center`}>
                <kpi.icon className="w-6 h-6 text-white" />
              </div>
              <div className={`flex items-center gap-1 text-sm ${
                kpi.isPositive ? 'text-green-400' : 'text-red-400'
              }`}>
                {kpi.isPositive ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                {kpi.change}
              </div>
            </div>
            
            <div>
              <p className="text-3xl font-bold admin-text-blue mb-1">{kpi.value}</p>
              <p className="admin-text-smoke text-sm">{kpi.label}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Token Balance & Forecast */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Token Balance Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold admin-text-blue">Balance & Previsão</h2>
              <Badge className={`${
                alertLevel === 'high' ? 'bg-red-500' : 
                alertLevel === 'medium' ? 'admin-bg-orange' : 'bg-green-500'
              } text-white`}>
                {data.daysRemaining} dias restantes
              </Badge>
            </div>
            
            <div className="space-y-6">
              {/* Current Balance */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="admin-text-smoke">Tokens Disponíveis</span>
                  <span className="text-2xl font-bold admin-text-blue">
                    {data.currentBalance.toLocaleString()}
                  </span>
                </div>
                <Progress 
                  value={(data.currentBalance / 5000) * 100} 
                  className="h-3 bg-gray-800"
                />
              </div>
              
              {/* Usage Stats */}
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-4 rounded-lg bg-black/30">
                  <p className="text-2xl font-bold admin-text-orange mb-1">
                    {data.dailyUsage}
                  </p>
                  <p className="admin-text-smoke text-sm">Uso Diário</p>
                </div>
                
                <div className="text-center p-4 rounded-lg bg-black/30">
                  <p className="text-2xl font-bold text-green-400 mb-1">
                    {data.monthlyUsage.toLocaleString()}
                  </p>
                  <p className="admin-text-smoke text-sm">Uso Mensal</p>
                </div>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button className="flex-1 admin-bg-orange hover:opacity-90">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Comprar Tokens
                </Button>
                <Button variant="outline" className="border-blue-500/20 admin-text-blue hover:bg-blue-500/10">
                  Ver Histórico
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Business Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Métricas de Negócio</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <p className="text-xl font-bold text-green-400 mb-1">
                  {data.profitMargin.toFixed(1)}%
                </p>
                <p className="admin-text-smoke text-sm">Margem de Lucro</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <p className="text-xl font-bold admin-text-blue mb-1">
                  {data.conversionRate.toFixed(1)}%
                </p>
                <p className="admin-text-smoke text-sm">Taxa Conversão</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <p className="text-xl font-bold text-purple-400 mb-1">
                  {data.totalUsers}
                </p>
                <p className="admin-text-smoke text-sm">Usuários Totais</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Crown className="w-6 h-6 text-white" />
                </div>
                <p className="text-xl font-bold admin-text-orange mb-1">
                  {data.premiumUsers}
                </p>
                <p className="admin-text-smoke text-sm">Usuários Premium</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Alerts & Notifications */}
        <div className="space-y-6">
          
          {/* System Alerts */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Alertas do Sistema</h3>
            
            <div className="space-y-3">
              {alerts.map((alert) => (
                <div 
                  key={alert.id} 
                  className={`p-4 rounded-lg border ${getAlertColor(alert.level)}`}
                >
                  <div className="flex items-start gap-3">
                    {getAlertIcon(alert.level)}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm mb-1">{alert.title}</h4>
                      <p className="text-xs opacity-80 mb-3">{alert.message}</p>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="border-current text-current hover:bg-current hover:text-black"
                      >
                        {alert.action}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Ações Rápidas</h3>
            
            <div className="space-y-3">
              <Button className="w-full admin-bg-orange hover:opacity-90 justify-start">
                <DollarSign className="w-4 h-4 mr-3" />
                Comprar Mais Tokens
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
              >
                <TrendingUp className="w-4 h-4 mr-3" />
                Ver Previsões IA
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
              >
                <Target className="w-4 h-4 mr-3" />
                Ajustar Distribuição
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
              >
                <Calendar className="w-4 h-4 mr-3" />
                Agendar Compra
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}