export function TopbarPlaceholder() {
  return (
    <header className="h-16 glass-morphism border-b border-white/10 flex items-center justify-between px-6">
      <div className="flex items-center space-x-4">
        <button className="lg:hidden p-2 rounded-lg hover:bg-hja-blue/10 text-hja-gray hover:text-hja-blue transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="font-orbitron font-bold text-hja-blue">Dashboard</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="text-sm text-hja-gray">Créditos: 1,250</div>
        <div className="w-8 h-8 bg-gradient-to-br from-hja-blue to-hja-orange rounded-full"></div>
      </div>
    </header>
  );
}