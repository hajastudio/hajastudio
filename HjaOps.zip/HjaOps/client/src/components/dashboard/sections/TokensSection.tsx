import { motion } from 'framer-motion';
import { Zap, TrendingUp, ShoppingCart, Gift, Calendar } from 'lucide-react';

interface TokensSectionProps {
  searchQuery: string;
  user: any;
}

export default function TokensSection({ searchQuery, user }: TokensSectionProps) {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Gerenciar <span className="text-gradient">Tokens</span>
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Acompanhe seu saldo, histórico de uso e adquira mais créditos para suas criações
        </p>
      </motion.div>

      {/* Current Balance */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-morphism rounded-2xl p-8 text-center border border-[var(--blue)]/20 neon-glow-subtle"
      >
        <div className="w-20 h-20 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center mx-auto mb-6 neon-glow">
          <Zap className="w-10 h-10 text-white" />
        </div>
        
        <h2 className="text-4xl font-orbitron font-bold text-white mb-2">
          {user?.credits || 0}
        </h2>
        <p className="text-lg text-[var(--smoke)]/70 mb-6">Créditos Disponíveis</p>
        
        <div className="max-w-md mx-auto mb-6">
          <div className="flex justify-between text-sm text-[var(--smoke)]/70 mb-2">
            <span>Usado este mês</span>
            <span>{200 - (user?.credits || 0)}/{user?.maxCredits || 200}</span>
          </div>
          <div className="w-full bg-[var(--smoke)]/10 rounded-full h-3">
            <div 
              className="h-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full neon-glow"
              style={{ width: `${((200 - (user?.credits || 0)) / (user?.maxCredits || 200)) * 100}%` }}
            />
          </div>
        </div>
        
        <button className="px-8 py-4 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
          Comprar Mais Créditos
        </button>
      </motion.div>

      {/* Quick Purchase Options */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Pacotes de Créditos
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { credits: 100, price: 9.90, bonus: 0, popular: false },
            { credits: 250, price: 19.90, bonus: 50, popular: true },
            { credits: 500, price: 39.90, bonus: 150, popular: false }
          ].map((pack, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`glass-morphism rounded-2xl p-6 relative ${
                pack.popular ? 'border-2 border-[var(--orange)] neon-glow' : ''
              }`}
            >
              {pack.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-[var(--orange)] text-white text-sm font-bold px-4 py-1 rounded-full">
                    MAIS POPULAR
                  </span>
                </div>
              )}
              
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-[var(--orange)]" />
                </div>
                
                <h3 className="text-2xl font-orbitron font-bold text-white mb-1">
                  {pack.credits} {pack.bonus > 0 && `+ ${pack.bonus}`}
                </h3>
                
                <p className="text-sm text-[var(--smoke)]/70 mb-4">
                  {pack.bonus > 0 ? `${pack.bonus} créditos bônus!` : 'Créditos básicos'}
                </p>
                
                <div className="text-3xl font-bold text-[var(--orange)] mb-6">
                  R$ {pack.price.toFixed(2)}
                </div>
                
                <button className={`w-full py-3 px-4 rounded-xl font-medium transition-all duration-300 ${
                  pack.popular
                    ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white hover:shadow-lg neon-glow'
                    : 'glass-morphism text-[var(--smoke)] hover:text-white'
                }`}>
                  Comprar Agora
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Usage Statistics */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Estatísticas de Uso
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Usage Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-morphism rounded-2xl p-6"
          >
            <h3 className="text-lg font-orbitron font-semibold text-white mb-4">
              Consumo dos Últimos 7 Dias
            </h3>
            
            <div className="space-y-3">
              {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, index) => {
                const usage = [5, 12, 8, 15, 10, 18, 7][index];
                return (
                  <div key={day} className="flex items-center gap-4">
                    <span className="w-8 text-sm text-[var(--smoke)]/70">{day}</span>
                    <div className="flex-1 bg-[var(--smoke)]/10 rounded-full h-2">
                      <div 
                        className="h-2 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full"
                        style={{ width: `${(usage / 20) * 100}%` }}
                      />
                    </div>
                    <span className="w-8 text-sm text-white text-right">{usage}</span>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Agent Usage */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-morphism rounded-2xl p-6"
          >
            <h3 className="text-lg font-orbitron font-semibold text-white mb-4">
              Uso por Agente
            </h3>
            
            <div className="space-y-4">
              {[
                { name: 'Roteirista AI', usage: 45, color: '#00f3ff' },
                { name: 'Vibe Code', usage: 32, color: '#ff6b00' },
                { name: 'Brand Expert', usage: 18, color: '#9f7aea' },
                { name: 'Viral Maker', usage: 5, color: '#10b981' }
              ].map((agent) => (
                <div key={agent.name} className="flex items-center gap-4">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: agent.color }}
                  />
                  <span className="flex-1 text-sm text-[var(--smoke)]/70">{agent.name}</span>
                  <span className="text-sm text-white">{agent.usage}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Transaction History */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Histórico de Transações
        </h2>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="space-y-4">
            {[
              {
                id: '1',
                type: 'purchase',
                description: 'Compra de 100 créditos',
                amount: '+100',
                date: '15/01/2024',
                status: 'completed'
              },
              {
                id: '2',
                type: 'usage',
                description: 'Chat com Roteirista AI',
                amount: '-15',
                date: '14/01/2024',
                status: 'completed'
              },
              {
                id: '3',
                type: 'bonus',
                description: 'Bônus de boas-vindas',
                amount: '+50',
                date: '10/01/2024',
                status: 'completed'
              }
            ].map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-4 glass-morphism rounded-xl">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    transaction.type === 'purchase' ? 'bg-green-500/20' :
                    transaction.type === 'usage' ? 'bg-red-500/20' :
                    'bg-[var(--orange)]/20'
                  }`}>
                    {transaction.type === 'purchase' && <ShoppingCart className="w-5 h-5 text-green-400" />}
                    {transaction.type === 'usage' && <Zap className="w-5 h-5 text-red-400" />}
                    {transaction.type === 'bonus' && <Gift className="w-5 h-5 text-[var(--orange)]" />}
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-white">{transaction.description}</h4>
                    <p className="text-sm text-[var(--smoke)]/60">{transaction.date}</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <span className={`font-bold ${
                    transaction.amount.startsWith('+') ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {transaction.amount}
                  </span>
                  <p className="text-xs text-[var(--smoke)]/60">créditos</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-6">
            <button className="text-[var(--blue)] hover:text-white transition-colors text-sm">
              Ver histórico completo →
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  );
}