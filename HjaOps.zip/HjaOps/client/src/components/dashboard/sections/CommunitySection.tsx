import { motion } from 'framer-motion';
import { Users, MessageCircle, Heart, Share, Calendar, Zap } from 'lucide-react';

interface CommunitySectionProps {
  searchQuery: string;
  user: any;
}

export default function CommunitySection({ searchQuery, user }: CommunitySectionProps) {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Comunidade <span className="text-gradient">Beta</span>
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Conecte-se com outros criadores, compartilhe projetos e colabore em uma comunidade vibrante de inovadores.
        </p>
      </motion.div>

      {/* Beta Notice */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-morphism rounded-2xl p-6 border border-[var(--orange)]/30"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center">
            <Zap className="w-6 h-6 text-[var(--orange)]" />
          </div>
          <div>
            <h3 className="font-orbitron font-semibold text-white mb-1">
              Versão Beta Ativa
            </h3>
            <p className="text-sm text-[var(--smoke)]/70">
              A comunidade está em desenvolvimento ativo. Sua participação nos ajuda a melhorar!
            </p>
          </div>
        </div>
      </motion.div>

      {/* Community Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-2xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-[var(--blue)]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Users className="w-6 h-6 text-[var(--blue)]" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white mb-1">1,247</h3>
          <p className="text-sm text-[var(--smoke)]/70">Membros Ativos</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-morphism rounded-2xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
            <MessageCircle className="w-6 h-6 text-[var(--orange)]" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white mb-1">456</h3>
          <p className="text-sm text-[var(--smoke)]/70">Discussões</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-morphism rounded-2xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Share className="w-6 h-6 text-purple-400" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white mb-1">89</h3>
          <p className="text-sm text-[var(--smoke)]/70">Projetos Compartilhados</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-morphism rounded-2xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-6 h-6 text-green-400" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white mb-1">12</h3>
          <p className="text-sm text-[var(--smoke)]/70">Eventos Mensais</p>
        </motion.div>
      </div>

      {/* Featured Posts */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Posts em Destaque
        </h2>
        
        <div className="space-y-6">
          {[
            {
              id: '1',
              author: 'Maria Silva',
              avatar: 'MS',
              time: '2h atrás',
              title: 'Como criei um vídeo viral usando IA em 30 minutos',
              content: 'Pessoal, queria compartilhar minha experiência usando o Roteirista IA para criar um script que viralizou no TikTok...',
              likes: 23,
              comments: 8,
              shares: 5,
              tags: ['viral', 'tiktok', 'ia']
            },
            {
              id: '2',
              author: 'João Developer',
              avatar: 'JD',
              time: '5h atrás',
              title: 'Automatizei meu workflow de design com o Vibe Code',
              content: 'Galera, consegui automatizar 80% do meu processo de criação de interfaces usando as dicas que aprendi aqui na comunidade...',
              likes: 15,
              comments: 12,
              shares: 3,
              tags: ['design', 'automação', 'workflow']
            },
            {
              id: '3',
              author: 'Ana Criativa',
              avatar: 'AC',
              time: '1d atrás',
              title: 'Workshop: Estratégias de Branding com IA - Sexta 19h',
              content: 'Pessoal, vou fazer um workshop ao vivo sobre como usar o Brand Expert para criar identidades visuais impactantes...',
              likes: 31,
              comments: 18,
              shares: 12,
              tags: ['workshop', 'branding', 'evento']
            }
          ].map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.1 }}
              className="glass-morphism rounded-2xl p-6 hover:bg-[var(--smoke)]/5 transition-all duration-300"
            >
              {/* Post Header */}
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{post.avatar}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-white">{post.author}</h3>
                  <p className="text-sm text-[var(--smoke)]/60">{post.time}</p>
                </div>
              </div>

              {/* Post Content */}
              <h4 className="font-orbitron font-semibold text-white text-lg mb-2">
                {post.title}
              </h4>
              
              <p className="text-[var(--smoke)]/80 mb-4">
                {post.content}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-[var(--blue)]/20 text-[var(--blue)] text-xs rounded-full">
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Post Actions */}
              <div className="flex items-center gap-6 text-sm text-[var(--smoke)]/60">
                <button className="flex items-center gap-2 hover:text-red-400 transition-colors">
                  <Heart className="w-4 h-4" />
                  {post.likes}
                </button>
                <button className="flex items-center gap-2 hover:text-[var(--blue)] transition-colors">
                  <MessageCircle className="w-4 h-4" />
                  {post.comments}
                </button>
                <button className="flex items-center gap-2 hover:text-[var(--orange)] transition-colors">
                  <Share className="w-4 h-4" />
                  {post.shares}
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Join Community CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="glass-morphism rounded-2xl p-8 text-center"
      >
        <h2 className="text-2xl font-orbitron font-bold text-white mb-4">
          Participe da Conversa
        </h2>
        <p className="text-[var(--smoke)]/70 mb-6">
          Compartilhe suas criações, tire dúvidas e conecte-se com outros criadores
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
          <button className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
            Criar Post
          </button>
          <button className="px-6 py-3 glass-morphism text-[var(--smoke)] hover:text-white rounded-xl font-medium transition-colors">
            Explorar Discussões
          </button>
        </div>
      </motion.div>
    </div>
  );
}