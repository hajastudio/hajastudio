import ChatShell from '@/components/chat/ChatShell';

interface ChatSectionProps {
  searchQuery: string;
  user: any;
}

export default function ChatSection({ searchQuery, user }: ChatSectionProps) {
  return (
    <div className="h-full">
      <ChatShell user={user} />
    </div>
  );
}