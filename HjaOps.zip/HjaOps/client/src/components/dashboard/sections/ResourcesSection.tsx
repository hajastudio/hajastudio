import { motion } from 'framer-motion';
import { Folder, Download, Star, Eye, Search, Filter } from 'lucide-react';

interface ResourcesSectionProps {
  searchQuery: string;
  user: any;
}

export default function ResourcesSection({ searchQuery, user }: ResourcesSectionProps) {
  const resources = [
    {
      id: '1',
      title: 'Pack de Templates TikTok',
      description: 'Templates prontos para criar conteúdo viral no TikTok',
      type: 'templates',
      downloads: 234,
      rating: 4.8,
      size: '15 MB',
      preview: true,
      premium: false
    },
    {
      id: '2',
      title: 'Prompts para YouTube Hooks',
      description: 'Coleção de prompts para criar ganchos irresistíveis',
      type: 'prompts',
      downloads: 156,
      rating: 4.9,
      size: '2 MB',
      preview: true,
      premium: true
    },
    {
      id: '3',
      title: 'Kit de Identidade Visual',
      description: 'Templates de logo, cores e tipografia para marcas',
      type: 'design',
      downloads: 89,
      rating: 4.7,
      size: '45 MB',
      preview: true,
      premium: false
    }
  ];

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Recursos <span className="text-gradient">Criativos</span>
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Templates, prompts e ferramentas para acelerar sua criação de conteúdo
        </p>
      </motion.div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[var(--smoke)]/50" />
          <input
            type="text"
            placeholder="Buscar recursos..."
            className="w-full pl-12 pr-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50"
          />
        </div>
        
        <button className="flex items-center gap-2 px-6 py-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors">
          <Filter className="w-5 h-5" />
          Filtros
        </button>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-3">
        {['Todos', 'Templates', 'Prompts', 'Design', 'Códigos', 'Guias'].map((category, index) => (
          <motion.button
            key={category}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
              index === 0 
                ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white neon-glow' 
                : 'glass-morphism text-[var(--smoke)]/70 hover:text-white'
            }`}
          >
            {category}
          </motion.button>
        ))}
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {resources.map((resource, index) => (
          <motion.div
            key={resource.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass-morphism rounded-2xl overflow-hidden hover:bg-[var(--smoke)]/5 transition-all duration-300 group"
          >
            {/* Resource Preview */}
            <div className="h-48 bg-gradient-to-br from-[var(--blue)]/20 to-[var(--orange)]/20 flex items-center justify-center relative">
              <Folder className="w-16 h-16 text-[var(--smoke)]/30" />
              
              {resource.premium && (
                <div className="absolute top-4 left-4 px-3 py-1 bg-[var(--orange)] text-white text-xs rounded-full">
                  Premium
                </div>
              )}
              
              {resource.preview && (
                <button className="absolute top-4 right-4 p-2 glass-morphism rounded-lg text-[var(--smoke)] hover:text-[var(--blue)] transition-colors">
                  <Eye className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Resource Info */}
            <div className="p-6">
              <h3 className="text-lg font-orbitron font-semibold text-white mb-2">
                {resource.title}
              </h3>
              
              <p className="text-sm text-[var(--smoke)]/70 mb-4">
                {resource.description}
              </p>

              {/* Resource Stats */}
              <div className="flex items-center justify-between text-xs text-[var(--smoke)]/60 mb-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Download className="w-3 h-3" />
                    {resource.downloads}
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-yellow-400" />
                    {resource.rating}
                  </div>
                </div>
                <span>{resource.size}</span>
              </div>

              {/* Download Button */}
              <button 
                className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium transition-all duration-300 ${
                  resource.premium && user?.plan === 'free'
                    ? 'glass-morphism text-[var(--smoke)]/50 cursor-not-allowed'
                    : 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white hover:shadow-lg neon-glow'
                }`}
                disabled={resource.premium && user?.plan === 'free'}
              >
                <Download className="w-4 h-4" />
                {resource.premium && user?.plan === 'free' ? 'Premium Necessário' : 'Download'}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Upload Resource CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass-morphism rounded-2xl p-8 text-center"
      >
        <h2 className="text-2xl font-orbitron font-bold text-white mb-4">
          Compartilhe Seus Recursos
        </h2>
        <p className="text-[var(--smoke)]/70 mb-6">
          Tem templates ou ferramentas úteis? Compartilhe com a comunidade e ganhe créditos!
        </p>
        
        <button className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
          Enviar Recurso
        </button>
      </motion.div>
    </div>
  );
}