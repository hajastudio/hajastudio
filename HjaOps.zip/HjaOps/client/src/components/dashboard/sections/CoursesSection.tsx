import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, BookOpen, Zap, Trophy, Star } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { coursesData } from '@/data/coursesData';
import CourseCard from '@/components/courses/CourseCard';
import UnlockCourseModal from '@/components/courses/UnlockCourseModal';
import CoursePlayer from '@/components/courses/CoursePlayer';
import type { Course, Lesson } from '@/types/courses';
import { useToast } from '@/hooks/use-toast';

interface CoursesSectionProps {
  searchQuery: string;
  user: any;
}

export default function CoursesSection({ searchQuery, user }: CoursesSectionProps) {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [courseToUnlock, setCourseToUnlock] = useState<Course | null>(null);
  const [filter, setFilter] = useState<'all' | 'free' | 'premium' | 'unlocked'>('all');
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Simulate fetching user progress and courses
  const { data: courses = coursesData } = useQuery({
    queryKey: ['courses'],
    queryFn: () => Promise.resolve(coursesData),
  });

  const { data: userCredits = user?.credits || 100 } = useQuery({
    queryKey: ['credits'],
    queryFn: () => Promise.resolve(user?.credits || 100),
  });

  // Unlock course mutation
  const unlockCourseMutation = useMutation({
    mutationFn: async ({ courseId, cost }: { courseId: string; cost: number }) => {
      // Simulate API call to unlock course and deduct tokens
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true, remainingCredits: userCredits - cost };
    },
    onSuccess: (data, variables) => {
      // Update course status locally
      const updatedCourses = courses.map(course => 
        course.id === variables.courseId 
          ? { ...course, status: 'unlocked' as const }
          : course
      );
      
      queryClient.setQueryData(['courses'], updatedCourses);
      queryClient.setQueryData(['credits'], data.remainingCredits);
      
      toast({
        title: "Curso Desbloqueado!",
        description: `Você pode começar a estudar agora. Restam ${data.remainingCredits} tokens.`,
      });
      
      setShowUnlockModal(false);
      setCourseToUnlock(null);
    },
    onError: () => {
      toast({
        title: "Erro ao Desbloquear",
        description: "Não foi possível desbloquear o curso. Tente novamente.",
        variant: "destructive",
      });
    }
  });

  // Complete lesson mutation
  const completeLessonMutation = useMutation({
    mutationFn: async ({ lessonId, tokensReward }: { lessonId: string; tokensReward: number }) => {
      await new Promise(resolve => setTimeout(resolve, 500));
      return { success: true, newCredits: userCredits + tokensReward };
    },
    onSuccess: (data, variables) => {
      queryClient.setQueryData(['credits'], data.newCredits);
      
      toast({
        title: "Aula Concluída! 🎉",
        description: `Você ganhou ${variables.tokensReward} tokens!`,
      });
    }
  });

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = filter === 'all' || course.status === filter;
    
    return matchesSearch && matchesFilter;
  });

  const handleCourseClick = (course: Course) => {
    if (course.status === 'premium') {
      setCourseToUnlock(course);
      setShowUnlockModal(true);
    } else {
      setSelectedCourse(course);
      setCurrentLesson(course.lessons[0]);
    }
  };

  const handleUnlockCourse = () => {
    if (courseToUnlock && courseToUnlock.cost) {
      unlockCourseMutation.mutate({
        courseId: courseToUnlock.id,
        cost: courseToUnlock.cost
      });
    }
  };

  const handleLessonComplete = (lessonId: string) => {
    if (!selectedCourse || !currentLesson) return;
    
    const lesson = selectedCourse.lessons.find(l => l.id === lessonId);
    if (lesson && !lesson.isCompleted) {
      completeLessonMutation.mutate({
        lessonId,
        tokensReward: lesson.tokensReward
      });
      
      // Update lesson status locally
      const updatedCourses = courses.map(course => 
        course.id === selectedCourse.id 
          ? {
              ...course,
              lessons: course.lessons.map(l => 
                l.id === lessonId ? { ...l, isCompleted: true } : l
              ),
              completedLessons: course.completedLessons + 1,
              progress: Math.round(((course.completedLessons + 1) / course.totalLessons) * 100)
            }
          : course
      );
      
      queryClient.setQueryData(['courses'], updatedCourses);
    }
  };

  const handleLessonChange = (lessonId: string) => {
    if (!selectedCourse) return;
    const lesson = selectedCourse.lessons.find(l => l.id === lessonId);
    if (lesson) setCurrentLesson(lesson);
  };

  // If viewing a course player
  if (selectedCourse && currentLesson) {
    return (
      <CoursePlayer
        course={selectedCourse}
        currentLesson={currentLesson}
        onLessonComplete={handleLessonComplete}
        onLessonChange={handleLessonChange}
        onBack={() => {
          setSelectedCourse(null);
          setCurrentLesson(null);
        }}
      />
    );
  }

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Cursos <span className="text-gradient">Interativos</span>
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Aprenda com especialistas e ganhe tokens completando aulas
        </p>
      </motion.div>

      {/* Stats Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-[var(--blue)]/20 rounded-xl flex items-center justify-center mx-auto mb-3">
            <BookOpen className="w-6 h-6 text-[var(--blue)]" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white">{courses.length}</h3>
          <p className="text-sm text-[var(--smoke)]/70">Cursos Disponíveis</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-morphism rounded-xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Zap className="w-6 h-6 text-[var(--orange)]" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white">{userCredits}</h3>
          <p className="text-sm text-[var(--smoke)]/70">Seus Tokens</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-morphism rounded-xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Trophy className="w-6 h-6 text-purple-400" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white">
            {courses.reduce((acc, course) => acc + course.completedLessons, 0)}
          </h3>
          <p className="text-sm text-[var(--smoke)]/70">Aulas Concluídas</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-morphism rounded-xl p-6 text-center"
        >
          <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Star className="w-6 h-6 text-green-400" />
          </div>
          <h3 className="text-2xl font-orbitron font-bold text-white">
            {courses.filter(c => c.progress > 0).length}
          </h3>
          <p className="text-sm text-[var(--smoke)]/70">Em Progresso</p>
        </motion.div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[var(--smoke)]/50" />
          <input
            type="text"
            placeholder="Buscar cursos..."
            value={searchQuery}
            readOnly
            className="w-full pl-12 pr-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50"
          />
        </div>
        
        <div className="flex gap-2">
          {[
            { key: 'all', label: 'Todos' },
            { key: 'free', label: 'Gratuitos' },
            { key: 'premium', label: 'Premium' },
            { key: 'unlocked', label: 'Desbloqueados' }
          ].map((filterOption) => (
            <button
              key={filterOption.key}
              onClick={() => setFilter(filterOption.key as any)}
              className={`px-4 py-3 rounded-xl font-medium transition-all duration-300 ${
                filter === filterOption.key
                  ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white neon-glow'
                  : 'glass-morphism text-[var(--smoke)]/70 hover:text-white'
              }`}
            >
              {filterOption.label}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          {filter === 'all' ? 'Todos os Cursos' :
           filter === 'free' ? 'Cursos Gratuitos' :
           filter === 'premium' ? 'Cursos Premium' :
           'Cursos Desbloqueados'}
        </h2>
        
        {filteredCourses.length > 0 ? (
          <div className="overflow-x-auto pb-4">
            <div className="flex gap-6 min-w-max">
              {filteredCourses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <CourseCard
                    course={course}
                    onClick={() => handleCourseClick(course)}
                    onUnlock={() => {
                      setCourseToUnlock(course);
                      setShowUnlockModal(true);
                    }}
                  />
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 text-[var(--smoke)]/30 mx-auto mb-4" />
            <p className="text-[var(--smoke)]/70">
              Nenhum curso encontrado para "{searchQuery}"
            </p>
          </div>
        )}
      </section>

      {/* Recommended Courses */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Recomendados para Você
        </h2>
        
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-6 min-w-max">
            {courses.filter(c => c.rating >= 4.8).slice(0, 3).map((course, index) => (
              <motion.div
                key={`rec-${course.id}`}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <CourseCard
                  course={course}
                  onClick={() => handleCourseClick(course)}
                  onUnlock={() => {
                    setCourseToUnlock(course);
                    setShowUnlockModal(true);
                  }}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Unlock Course Modal */}
      <UnlockCourseModal
        isOpen={showUnlockModal}
        onClose={() => {
          setShowUnlockModal(false);
          setCourseToUnlock(null);
        }}
        course={courseToUnlock}
        userTokens={userCredits}
        onConfirmUnlock={handleUnlockCourse}
      />
    </div>
  );
}