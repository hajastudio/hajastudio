import { motion } from 'framer-motion';
import { 
  BookOpen,
  Users,
  Folder,
  MessageSquare,
  TrendingUp,
  Zap,
  PlayCircle,
  Star,
  ChevronRight
} from 'lucide-react';

interface HomeSectionProps {
  searchQuery: string;
  user: any;
}

export default function HomeSection({ searchQuery, user }: HomeSectionProps) {
  
  const quickActions = [
    {
      id: 'new-chat',
      title: 'Novo Chat',
      description: 'Converse com agentes IA',
      icon: MessageSquare,
      color: 'from-[var(--blue)] to-blue-600',
      href: '/chat'
    },
    {
      id: 'courses',
      title: 'Explorar Cursos',
      description: 'Aprenda novas habilidades',
      icon: BookOpen,
      color: 'from-[var(--orange)] to-orange-600',
      href: '/courses',
      badge: 'Em Breve'
    },
    {
      id: 'community',
      title: 'Comunidade',
      description: 'Conecte-se com outros usuários',
      icon: Users,
      color: 'from-purple-500 to-purple-600',
      href: '/community',
      badge: 'Beta'
    },
    {
      id: 'resources',
      title: 'Recursos',
      description: 'Ferramentas e templates',
      icon: Folder,
      color: 'from-green-500 to-green-600',
      href: '/resources'
    }
  ];

  const featuredAgents = [
    {
      id: 'roteirista',
      name: 'Roteirista Viral',
      description: 'Crie roteiros virais para TikTok e YouTube',
      color: '#00f3ff',
      usage: 85,
      rating: 4.9
    },
    {
      id: 'vibe-code',
      name: 'Vibe Code',
      description: 'Desenvolvimento de software inteligente',
      color: '#ff6b00',
      usage: 72,
      rating: 4.8
    },
    {
      id: 'branding',
      name: 'Brand Expert',
      description: 'Estratégias de marca e identidade visual',
      color: '#9f7aea',
      usage: 68,
      rating: 4.7
    }
  ];

  const recentActivity = [
    {
      id: '1',
      type: 'chat',
      title: 'Conversa com Roteirista IA',
      description: 'Script para TikTok criado',
      time: '2h atrás',
      tokens: 45
    },
    {
      id: '2',
      type: 'credit',
      title: 'Créditos Adicionados',
      description: 'Compra de 100 créditos',
      time: '1d atrás',
      tokens: 100
    },
    {
      id: '3',
      type: 'achievement',
      title: 'Conquista Desbloqueada',
      description: 'Primeiro chat completado!',
      time: '3d atrás',
      tokens: 0
    }
  ];

  return (
    <div className="p-6 space-y-8">
      {/* Welcome Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Bem-vindo ao <span className="text-gradient">Haja²Verso</span>
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Sua plataforma completa de criação com IA. Explore agentes inteligentes, 
          cursos interativos e uma comunidade criativa.
        </p>
      </motion.div>

      {/* Quick Actions */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Ações Rápidas
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={action.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group cursor-pointer"
                data-testid={`quick-action-${action.id}`}
              >
                <div className="glass-morphism rounded-2xl p-6 h-full hover:bg-[var(--smoke)]/5 transition-all duration-300 group-hover:neon-glow">
                  <div className={`w-12 h-12 bg-gradient-to-r ${action.color} rounded-xl flex items-center justify-center mb-4 neon-glow`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  
                  <h3 className="text-lg font-orbitron font-semibold text-white mb-2">
                    {action.title}
                  </h3>
                  
                  <p className="text-sm text-[var(--smoke)]/70 mb-4">
                    {action.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <ChevronRight className="w-5 h-5 text-[var(--blue)] group-hover:translate-x-1 transition-transform" />
                    {action.badge && (
                      <span className="px-2 py-1 bg-[var(--orange)]/20 text-[var(--orange)] text-xs rounded-full">
                        {action.badge}
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Featured Agents */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-orbitron font-bold text-white">
            Agentes em Destaque
          </h2>
          <button className="text-[var(--blue)] hover:text-white transition-colors text-sm">
            Ver todos →
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredAgents.map((agent, index) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              className="glass-morphism rounded-2xl p-6 hover:bg-[var(--smoke)]/5 transition-all duration-300 cursor-pointer group"
              data-testid={`featured-agent-${agent.id}`}
            >
              <div className="flex items-center gap-4 mb-4">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center neon-glow"
                  style={{ backgroundColor: `${agent.color}20`, borderColor: agent.color }}
                >
                  <MessageSquare className="w-6 h-6" style={{ color: agent.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="font-orbitron font-semibold text-white">
                    {agent.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-[var(--smoke)]/70">{agent.rating}</span>
                  </div>
                </div>
              </div>
              
              <p className="text-sm text-[var(--smoke)]/70 mb-4">
                {agent.description}
              </p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-[var(--smoke)]/70">Popularidade</span>
                  <span className="text-white">{agent.usage}%</span>
                </div>
                <div className="w-full bg-[var(--smoke)]/10 rounded-full h-2">
                  <div 
                    className="h-2 rounded-full neon-glow"
                    style={{ 
                      width: `${agent.usage}%`,
                      backgroundColor: agent.color
                    }}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Recent Activity */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Atividade Recente
        </h2>
        
        <div className="glass-morphism rounded-2xl p-6">
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="flex items-center gap-4 p-4 glass-morphism rounded-xl hover:bg-[var(--smoke)]/5 transition-colors"
                data-testid={`activity-${activity.id}`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  activity.type === 'chat' ? 'bg-[var(--blue)]/20' :
                  activity.type === 'credit' ? 'bg-[var(--orange)]/20' :
                  'bg-purple-500/20'
                }`}>
                  {activity.type === 'chat' && <MessageSquare className="w-5 h-5 text-[var(--blue)]" />}
                  {activity.type === 'credit' && <Zap className="w-5 h-5 text-[var(--orange)]" />}
                  {activity.type === 'achievement' && <Star className="w-5 h-5 text-purple-400" />}
                </div>
                
                <div className="flex-1">
                  <h3 className="font-medium text-white">{activity.title}</h3>
                  <p className="text-sm text-[var(--smoke)]/70">{activity.description}</p>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-[var(--smoke)]/60">{activity.time}</p>
                  {activity.tokens > 0 && (
                    <p className="text-sm text-[var(--orange)]">+{activity.tokens} tokens</p>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-6">
            <button className="text-[var(--blue)] hover:text-white transition-colors text-sm">
              Ver toda atividade →
            </button>
          </div>
        </div>
      </section>

      {/* Stats Overview */}
      <section>
        <h2 className="text-2xl font-orbitron font-bold text-white mb-6">
          Seus Números
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="glass-morphism rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-[var(--blue)]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-6 h-6 text-[var(--blue)]" />
            </div>
            <h3 className="text-2xl font-orbitron font-bold text-white mb-1">127</h3>
            <p className="text-sm text-[var(--smoke)]/70">Chats Realizados</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="glass-morphism rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Zap className="w-6 h-6 text-[var(--orange)]" />
            </div>
            <h3 className="text-2xl font-orbitron font-bold text-white mb-1">{user?.credits || 0}</h3>
            <p className="text-sm text-[var(--smoke)]/70">Créditos Restantes</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-morphism rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-2xl font-orbitron font-bold text-white mb-1">7</h3>
            <p className="text-sm text-[var(--smoke)]/70">Nível Atual</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="glass-morphism rounded-2xl p-6 text-center"
          >
            <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Star className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-2xl font-orbitron font-bold text-white mb-1">12</h3>
            <p className="text-sm text-[var(--smoke)]/70">Conquistas</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}