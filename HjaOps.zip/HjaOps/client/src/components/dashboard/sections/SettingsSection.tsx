import { motion } from 'framer-motion';
import { User, Shield, Bell, Palette, Globe, Zap } from 'lucide-react';

interface SettingsSectionProps {
  searchQuery: string;
  user: any;
}

export default function SettingsSection({ searchQuery, user }: SettingsSectionProps) {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-4xl font-orbitron font-bold text-white mb-4">
          Configurações
        </h1>
        <p className="text-lg text-[var(--smoke)]/80 max-w-2xl mx-auto">
          Personalize sua experiência na plataforma
        </p>
      </motion.div>

      {/* Settings Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Profile Settings */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <User className="w-6 h-6 text-[var(--blue)]" />
            <h2 className="text-xl font-orbitron font-semibold text-white">Perfil</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--smoke)]/70 mb-2">
                Nome
              </label>
              <input
                type="text"
                defaultValue={`${user?.firstName || ''} ${user?.lastName || ''}`}
                className="w-full px-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[var(--smoke)]/70 mb-2">
                Email
              </label>
              <input
                type="email"
                defaultValue={user?.email || ''}
                className="w-full px-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[var(--smoke)]/70 mb-2">
                Biografia
              </label>
              <textarea
                rows={3}
                placeholder="Conte um pouco sobre você..."
                className="w-full px-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50 resize-none"
              />
            </div>
            
            <button className="w-full py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
              Salvar Alterações
            </button>
          </div>
        </motion.div>

        {/* Notification Settings */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Bell className="w-6 h-6 text-[var(--orange)]" />
            <h2 className="text-xl font-orbitron font-semibold text-white">Notificações</h2>
          </div>
          
          <div className="space-y-6">
            {[
              { 
                id: 'chat_responses',
                title: 'Respostas de Chat',
                description: 'Notificar quando os agentes responderem',
                enabled: true
              },
              {
                id: 'credit_alerts',
                title: 'Alertas de Créditos',
                description: 'Avisar quando os créditos estiverem baixos',
                enabled: true
              },
              {
                id: 'new_features',
                title: 'Novas Funcionalidades',
                description: 'Novidades e atualizações da plataforma',
                enabled: false
              },
              {
                id: 'community_activity',
                title: 'Atividade da Comunidade',
                description: 'Posts e discussões relevantes',
                enabled: false
              }
            ].map((setting) => (
              <div key={setting.id} className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-white">{setting.title}</h3>
                  <p className="text-sm text-[var(--smoke)]/70">{setting.description}</p>
                </div>
                
                <button className={`w-12 h-6 rounded-full transition-colors ${
                  setting.enabled ? 'bg-[var(--blue)]' : 'bg-[var(--smoke)]/20'
                }`}>
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    setting.enabled ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Theme Settings */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Palette className="w-6 h-6 text-purple-400" />
            <h2 className="text-xl font-orbitron font-semibold text-white">Aparência</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--smoke)]/70 mb-3">
                Tema
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button className="p-4 glass-morphism rounded-xl border-2 border-[var(--blue)] text-[var(--blue)] font-medium">
                  Cyberpunk
                </button>
                <button className="p-4 glass-morphism rounded-xl text-[var(--smoke)]/70 hover:text-white transition-colors">
                  Clássico
                </button>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-[var(--smoke)]/70 mb-3">
                Animações
              </label>
              <div className="flex items-center justify-between">
                <span className="text-white">Reduzir animações</span>
                <button className="w-12 h-6 rounded-full bg-[var(--smoke)]/20">
                  <div className="w-5 h-5 bg-white rounded-full translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Account Settings */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6 text-green-400" />
            <h2 className="text-xl font-orbitron font-semibold text-white">Conta</h2>
          </div>
          
          <div className="space-y-4">
            <div className="p-4 glass-morphism rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-white">Plano Atual</span>
                <span className="px-3 py-1 bg-[var(--orange)]/20 text-[var(--orange)] text-sm rounded-full">
                  {(user?.plan || 'free').toUpperCase()}
                </span>
              </div>
              <p className="text-sm text-[var(--smoke)]/70 mb-3">
                {user?.credits || 0} créditos restantes
              </p>
              <button className="w-full py-2 text-sm text-[var(--blue)] hover:text-white transition-colors">
                Gerenciar Plano →
              </button>
            </div>
            
            <div className="space-y-3">
              <button className="w-full text-left py-3 px-4 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors">
                Alterar Senha
              </button>
              
              <button className="w-full text-left py-3 px-4 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors">
                Privacidade e Dados
              </button>
              
              <button className="w-full text-left py-3 px-4 glass-morphism rounded-xl text-red-400 hover:text-red-300 transition-colors">
                Excluir Conta
              </button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Support Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-morphism rounded-2xl p-8 text-center"
      >
        <h2 className="text-2xl font-orbitron font-bold text-white mb-4">
          Precisa de Ajuda?
        </h2>
        <p className="text-[var(--smoke)]/70 mb-6">
          Nossa equipe está sempre pronta para ajudar você
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
          <button className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
            Falar com Suporte
          </button>
          <button className="px-6 py-3 glass-morphism text-[var(--smoke)] hover:text-white rounded-xl font-medium transition-colors">
            Ver FAQ
          </button>
        </div>
      </motion.div>
    </div>
  );
}