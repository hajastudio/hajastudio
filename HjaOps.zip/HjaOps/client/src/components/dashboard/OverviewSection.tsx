import { motion } from 'framer-motion';
import { 
  CreditCard, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  Users,
  MessageSquare,
  Brain
} from 'lucide-react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

interface OverviewSectionProps {
  data?: any;
  isLoading: boolean;
}

export default function OverviewSection({ data, isLoading }: OverviewSectionProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="glass-morphism rounded-2xl p-6 animate-pulse">
            <div className="h-4 bg-[var(--smoke)]/20 rounded mb-4"></div>
            <div className="h-8 bg-[var(--smoke)]/20 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  const credits = data?.credits || 85;
  const maxCredits = data?.maxCredits || 200;
  const creditsPercentage = (credits / maxCredits) * 100;

  // Mock data for charts (replace with real data)
  const creditChartData = {
    labels: ['Usados', 'Disponíveis'],
    datasets: [
      {
        data: [maxCredits - credits, credits],
        backgroundColor: [
          'rgba(255, 107, 0, 0.8)', // Orange
          'rgba(0, 243, 255, 0.8)', // Blue
        ],
        borderColor: [
          'rgba(255, 107, 0, 1)',
          'rgba(0, 243, 255, 1)',
        ],
        borderWidth: 2,
      },
    ],
  };

  const usageChartData = {
    labels: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
    datasets: [
      {
        label: 'Tokens Usados',
        data: [12, 19, 8, 15, 22, 18, 25],
        backgroundColor: 'rgba(0, 243, 255, 0.3)',
        borderColor: 'rgba(0, 243, 255, 1)',
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#c5d1db',
          font: {
            family: 'Orbitron',
            size: 12,
          },
        },
      },
    },
    scales: {
      x: {
        ticks: {
          color: '#c5d1db',
        },
        grid: {
          color: 'rgba(197, 209, 219, 0.1)',
        },
      },
      y: {
        ticks: {
          color: '#c5d1db',
        },
        grid: {
          color: 'rgba(197, 209, 219, 0.1)',
        },
      },
    },
  };

  const recentChats = data?.recentChats || [
    { id: '1', agentName: 'Roteirista AI', lastMessage: 'Script criado com sucesso!', time: '2h atrás' },
    { id: '2', agentName: 'Vibe Code', lastMessage: 'Código otimizado e documentado.', time: '5h atrás' },
    { id: '3', agentName: 'Viral Maker', lastMessage: 'Estratégia de viral content pronta.', time: '1d atrás' },
  ];

  const hvcRecommendations = data?.recommendations || [
    { type: 'upgrade', message: 'Considere fazer upgrade para Pro - você está usando 85% dos créditos', priority: 'high' },
    { type: 'usage', message: 'Ótimo uso do Roteirista AI! Continue explorando.', priority: 'low' },
    { type: 'alert', message: 'Novo modelo GPT-5 disponível com melhor performance', priority: 'medium' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-2xl p-6 border border-[var(--blue)]/20 neon-glow-subtle"
          data-testid="credits-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-[var(--blue)]/20 rounded-xl">
              <CreditCard className="w-6 h-6 text-[var(--blue)]" />
            </div>
            <span className="text-xs text-[var(--smoke)]/60 font-orbitron">CRÉDITOS</span>
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-orbitron font-bold text-white">{credits}</h3>
            <p className="text-sm text-[var(--smoke)]/70">de {maxCredits} disponíveis</p>
            <div className="w-full bg-[var(--smoke)]/10 rounded-full h-2">
              <motion.div
                className="h-2 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full neon-glow"
                initial={{ width: 0 }}
                animate={{ width: `${creditsPercentage}%` }}
                transition={{ duration: 1, delay: 0.5 }}
              />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-morphism rounded-2xl p-6"
          data-testid="chats-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-[var(--orange)]/20 rounded-xl">
              <MessageSquare className="w-6 h-6 text-[var(--orange)]" />
            </div>
            <span className="text-xs text-[var(--smoke)]/60 font-orbitron">CHATS</span>
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-orbitron font-bold text-white">127</h3>
            <p className="text-sm text-[var(--smoke)]/70">conversas este mês</p>
            <div className="flex items-center gap-1 text-green-400">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs">+23% vs mês anterior</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-morphism rounded-2xl p-6"
          data-testid="agents-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-purple-500/20 rounded-xl">
              <Brain className="w-6 h-6 text-purple-400" />
            </div>
            <span className="text-xs text-[var(--smoke)]/60 font-orbitron">AGENTES</span>
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-orbitron font-bold text-white">5</h3>
            <p className="text-sm text-[var(--smoke)]/70">agentes utilizados</p>
            <p className="text-xs text-purple-400">Mais usado: Roteirista AI</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-morphism rounded-2xl p-6"
          data-testid="plan-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-green-500/20 rounded-xl">
              <CheckCircle className="w-6 h-6 text-green-400" />
            </div>
            <span className="text-xs text-[var(--smoke)]/60 font-orbitron">PLANO</span>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-orbitron font-bold text-white">Pro</h3>
            <p className="text-sm text-[var(--smoke)]/70">Renovação em 15 dias</p>
            <button className="text-xs text-[var(--blue)] hover:text-[var(--orange)] transition-colors">
              Gerenciar plano →
            </button>
          </div>
        </motion.div>
      </div>

      {/* Charts and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Credit Usage Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <h3 className="text-lg font-orbitron font-bold text-white mb-6">
            Distribuição de Créditos
          </h3>
          <div className="h-64">
            <Doughnut 
              data={creditChartData} 
              options={{ 
                ...chartOptions, 
                plugins: { 
                  ...chartOptions.plugins,
                  legend: { position: 'bottom' as const }
                }
              }} 
            />
          </div>
        </motion.div>

        {/* Usage Chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <h3 className="text-lg font-orbitron font-bold text-white mb-6">
            Uso Semanal (Tokens)
          </h3>
          <div className="h-64">
            <Bar data={usageChartData} options={chartOptions} />
          </div>
        </motion.div>
      </div>

      {/* Recent Chats and Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Chats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-orbitron font-bold text-white">
              Últimas Conversas
            </h3>
            <button className="text-sm text-[var(--blue)] hover:text-[var(--orange)] transition-colors">
              Ver todos →
            </button>
          </div>
          
          <div className="space-y-4">
            {recentChats.map((chat, index) => (
              <motion.div
                key={chat.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + index * 0.1 }}
                className="flex items-center gap-4 p-4 glass-morphism rounded-xl hover:bg-[var(--smoke)]/5 transition-colors cursor-pointer"
                data-testid={`recent-chat-${chat.id}`}
              >
                <div className="w-10 h-10 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-xl flex items-center justify-center neon-glow">
                  <MessageSquare className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-white">{chat.agentName}</h4>
                  <p className="text-sm text-[var(--smoke)]/70 truncate">{chat.lastMessage}</p>
                </div>
                <div className="text-xs text-[var(--smoke)]/60">
                  {chat.time}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* HVC Core Recommendations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-lg flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <h3 className="text-lg font-orbitron font-bold text-white">
              Recomendações HVC Core
            </h3>
          </div>
          
          <div className="space-y-4">
            {hvcRecommendations.map((rec, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 + index * 0.1 }}
                className={`p-4 rounded-xl border-l-4 ${
                  rec.priority === 'high' 
                    ? 'bg-red-500/10 border-red-500' 
                    : rec.priority === 'medium'
                    ? 'bg-yellow-500/10 border-yellow-500'
                    : 'bg-green-500/10 border-green-500'
                }`}
                data-testid={`recommendation-${index}`}
              >
                <div className="flex items-start gap-3">
                  {rec.priority === 'high' && <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5" />}
                  {rec.priority === 'medium' && <Clock className="w-5 h-5 text-yellow-400 mt-0.5" />}
                  {rec.priority === 'low' && <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />}
                  <div className="flex-1">
                    <p className="text-sm text-[var(--smoke)]">{rec.message}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}