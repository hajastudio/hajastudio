import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { 
  Home, 
  MessageSquare, 
  Sparkles, 
  GraduationCap, 
  Users, 
  Coins,
  ShieldCheck,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  href: string;
  badge?: string;
  adminOnly?: boolean;
}

interface SidebarProps {
  navItems?: NavItem[];
  isAdmin?: boolean;
  collapsedDefault?: boolean;
  onMobileToggle?: () => void;
  isMobileOpen?: boolean;
}

const defaultNavItems: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home, href: '/dashboard' },
  { id: 'chats', label: 'Chats', icon: MessageSquare, href: '/dashboard/chats', badge: '3' },
  { id: 'agents', label: 'Agentes', icon: Sparkles, href: '/dashboard/agents' },
  { id: 'courses', label: 'Cursos', icon: GraduationCap, href: '/dashboard/courses', badge: 'NEW' },
  { id: 'community', label: 'Comunidade', icon: Users, href: '/dashboard/community' },
  { id: 'credits', label: 'Créditos', icon: Coins, href: '/dashboard/credits' },
  { id: 'admin', label: 'Admin', icon: ShieldCheck, href: '/dashboard/admin', adminOnly: true },
];

export function Sidebar({ 
  navItems = defaultNavItems, 
  isAdmin = false, 
  collapsedDefault = false,
  onMobileToggle,
  isMobileOpen = false
}: SidebarProps) {
  const [collapsed, setCollapsed] = useState(collapsedDefault);
  const [location] = useLocation();

  // Load collapsed state from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('hja-sidebar-collapsed');
    if (saved !== null) {
      setCollapsed(JSON.parse(saved));
    }
  }, []);

  // Save collapsed state to localStorage
  const toggleCollapsed = () => {
    const newCollapsed = !collapsed;
    setCollapsed(newCollapsed);
    localStorage.setItem('hja-sidebar-collapsed', JSON.stringify(newCollapsed));
  };

  // Filter items based on admin status
  const filteredItems = navItems.filter(item => !item.adminOnly || isAdmin);

  const sidebarVariants = {
    open: { 
      width: 280,
      transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
    },
    collapsed: { 
      width: 80,
      transition: { duration: 0.3, ease: [0.4, 0, 0.2, 1] }
    }
  };

  const itemVariants = {
    open: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.2 }
    },
    collapsed: {
      opacity: 0,
      x: -10,
      transition: { duration: 0.2 }
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={onMobileToggle}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        variants={sidebarVariants}
        animate={collapsed ? "collapsed" : "open"}
        className={`
          fixed top-0 left-0 h-full glass-morphism z-50 lg:relative
          ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          transition-transform duration-300 lg:transition-none
        `}
      >
        {/* Header */}
        <div className="flex items-center h-16 px-6 border-b border-white/10">
          <AnimatePresence mode="wait">
            {!collapsed && (
              <motion.div
                key="expanded-header"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="flex items-center space-x-3"
              >
                <div className="w-8 h-8 bg-gradient-to-br from-hja-blue to-hja-orange rounded-lg neon-glow flex items-center justify-center">
                  <span className="text-black font-orbitron font-bold text-sm">H</span>
                </div>
                <span className="font-orbitron font-bold text-hja-blue text-lg">
                  Hja²Ops
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {collapsed && (
            <div className="w-8 h-8 bg-gradient-to-br from-hja-blue to-hja-orange rounded-lg neon-glow flex items-center justify-center mx-auto">
              <span className="text-black font-orbitron font-bold text-sm">H</span>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-6">
          <ul className="space-y-2 px-4">
            {filteredItems.map((item) => {
              const isActive = location === item.href;
              const Icon = item.icon;

              return (
                <motion.li
                  key={item.id}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <a href={item.href}>
                    <div
                      className={`
                        group relative flex items-center p-3 rounded-xl transition-all duration-200
                        ${isActive 
                          ? 'neon-glow bg-hja-blue/10 text-hja-blue' 
                          : 'text-hja-gray hover:bg-hja-blue/5 hover:text-hja-blue'
                        }
                        ${collapsed ? 'justify-center' : 'space-x-3'}
                      `}
                    >
                      <Icon 
                        size={20} 
                        className={`flex-shrink-0 ${isActive ? 'animate-pulse' : 'group-hover:scale-110'} transition-transform`} 
                      />
                      
                      <AnimatePresence>
                        {!collapsed && (
                          <motion.div
                            variants={itemVariants}
                            initial="collapsed"
                            animate="open"
                            exit="collapsed"
                            className="flex items-center justify-between flex-1 min-w-0"
                          >
                            <span className="font-inter font-medium truncate">
                              {item.label}
                            </span>
                            
                            {item.badge && (
                              <motion.span
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                transition={{ delay: 0.1 }}
                                className="ml-auto px-2 py-1 bg-hja-orange text-black text-xs font-bold rounded-full"
                              >
                                {item.badge}
                              </motion.span>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Tooltip for collapsed state */}
                      {collapsed && (
                        <div className="absolute left-full ml-2 px-3 py-2 bg-black/90 text-hja-gray text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50">
                          {item.label}
                          {item.badge && (
                            <span className="ml-2 px-1.5 py-0.5 bg-hja-orange text-black text-xs font-bold rounded">
                              {item.badge}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Active indicator */}
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="absolute right-1 w-2 h-2 bg-hja-blue rounded-full"
                        />
                      )}
                    </div>
                  </a>
                </motion.li>
              );
            })}
          </ul>
        </nav>

        {/* Footer with Collapse Toggle */}
        <div className="p-4 border-t border-white/10">
          <motion.button
            onClick={toggleCollapsed}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`
              w-full flex items-center p-3 rounded-xl bg-hja-blue/5 hover:bg-hja-blue/10 
              text-hja-gray hover:text-hja-blue transition-all duration-200 group
              ${collapsed ? 'justify-center' : 'space-x-3'}
            `}
            aria-label={collapsed ? "Expandir sidebar" : "Colapsar sidebar"}
          >
            {collapsed ? (
              <ChevronRight size={20} className="group-hover:scale-110 transition-transform" />
            ) : (
              <>
                <ChevronLeft size={20} className="group-hover:scale-110 transition-transform" />
                <span className="font-inter font-medium">Colapsar</span>
              </>
            )}
          </motion.button>

          {/* Core Badge */}
          <AnimatePresence>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ delay: 0.1 }}
                className="mt-4 text-center"
              >
                <p className="text-xs text-hja-gray/70 mb-1">⚡ Powered by</p>
                <p className="text-sm font-orbitron font-bold text-gradient">
                  Hja²Ops Core
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.aside>
    </>
  );
}