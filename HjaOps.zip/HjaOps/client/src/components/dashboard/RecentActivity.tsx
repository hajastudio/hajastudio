import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";

export function RecentActivity() {
  const { data: chats = [] } = useQuery({
    queryKey: ["/api/chats"],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  });

  // Combine and sort recent activities
  const activities = [
    ...chats.slice(0, 3).map((chat: any) => ({
      type: 'chat',
      title: `Chat with Agent`,
      description: chat.title || 'New conversation',
      timestamp: chat.updatedAt,
      icon: 'fas fa-comment',
    })),
    ...transactions.slice(0, 2).map((transaction: any) => ({
      type: 'transaction',
      title: transaction.type === 'credits' ? 'Credit Purchase' : 'Plan Update',
      description: `${transaction.creditsAdded || 0} credits added`,
      timestamp: transaction.createdAt,
      icon: 'fas fa-credit-card',
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 5);

  return (
    <Card className="netflix-card p-6 mb-8">
      <CardContent className="p-0">
        <h3 className="text-xl font-semibold mb-4 flex items-center gap-2" data-testid="recent-activity-title">
          <i className="fas fa-history text-primary"></i>
          Recent Activity
        </h3>
        <div className="space-y-4">
          {activities.length === 0 ? (
            <p className="text-muted-foreground text-center py-8" data-testid="no-activity">
              No recent activity
            </p>
          ) : (
            activities.map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-3 bg-secondary/50 rounded-lg" data-testid={`activity-item-${index}`}>
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                  <i className={`${activity.icon} text-primary text-sm`}></i>
                </div>
                <div className="flex-1">
                  <p className="font-medium" data-testid={`activity-title-${index}`}>{activity.title}</p>
                  <p className="text-sm text-muted-foreground" data-testid={`activity-description-${index}`}>
                    {activity.description}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground" data-testid={`activity-time-${index}`}>
                  {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                </span>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
