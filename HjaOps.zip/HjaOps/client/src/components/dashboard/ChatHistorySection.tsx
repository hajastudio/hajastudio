import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Clock, 
  User, 
  Bot, 
  Filter,
  Search,
  Eye,
  MoreVertical,
  Download
} from 'lucide-react';

interface ChatHistorySectionProps {
  data?: any;
  isLoading: boolean;
}

export default function ChatHistorySection({ data, isLoading }: ChatHistorySectionProps) {
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChat, setSelectedChat] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-12 bg-[var(--smoke)]/20 rounded-lg animate-pulse"></div>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="glass-morphism rounded-2xl p-6 animate-pulse">
            <div className="h-4 bg-[var(--smoke)]/20 rounded mb-4"></div>
            <div className="h-16 bg-[var(--smoke)]/20 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  // Mock data (replace with real data from API)
  const chats = data?.chats || [
    {
      id: '1',
      title: 'Estratégia de Conteúdo Viral',
      agentId: 'roteirista',
      agentName: 'Roteirista AI',
      agentColor: '#00f3ff',
      messageCount: 15,
      tokensUsed: 245,
      lastMessage: 'Script para TikTok criado com sucesso! Use os hooks sugeridos.',
      lastActivity: '2024-01-15T10:30:00Z',
      status: 'completed'
    },
    {
      id: '2',
      title: 'Otimização de Código React',
      agentId: 'vibecode',
      agentName: 'Vibe Code',
      agentColor: '#ff6b00',
      messageCount: 8,
      tokensUsed: 178,
      lastMessage: 'Código refatorado e documentado. Performance melhorou 40%.',
      lastActivity: '2024-01-14T16:45:00Z',
      status: 'completed'
    },
    {
      id: '3',
      title: 'Análise de Trends YouTube',
      agentId: 'analista-youtube',
      agentName: 'Analista YouTube',
      agentColor: '#9f7aea',
      messageCount: 12,
      tokensUsed: 312,
      lastMessage: 'Relatório completo com 5 tendências em alta para março.',
      lastActivity: '2024-01-13T14:20:00Z',
      status: 'completed'
    },
    {
      id: '4',
      title: 'Branding para Startup',
      agentId: 'branding-social',
      agentName: 'Branding Social',
      agentColor: '#10b981',
      messageCount: 20,
      tokensUsed: 456,
      lastMessage: 'Identidade visual e tom de voz definidos para a marca.',
      lastActivity: '2024-01-12T11:15:00Z',
      status: 'completed'
    },
    {
      id: '5',
      title: 'Conteúdo Viral Instagram',
      agentId: 'viral-maker',
      agentName: 'Viral Maker',
      agentColor: '#f59e0b',
      messageCount: 6,
      tokensUsed: 134,
      lastMessage: 'Estou gerando ideias de posts virais...',
      lastActivity: '2024-01-15T12:00:00Z',
      status: 'active'
    }
  ];

  const agents = [
    { id: 'all', name: 'Todos os Agentes', count: chats.length },
    { id: 'roteirista', name: 'Roteirista AI', count: 1 },
    { id: 'vibecode', name: 'Vibe Code', count: 1 },
    { id: 'analista-youtube', name: 'Analista YouTube', count: 1 },
    { id: 'branding-social', name: 'Branding Social', count: 1 },
    { id: 'viral-maker', name: 'Viral Maker', count: 1 }
  ];

  const filteredChats = chats.filter(chat => {
    const matchesAgent = selectedAgent === 'all' || chat.agentId === selectedAgent;
    const matchesSearch = chat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         chat.agentName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesAgent && matchesSearch;
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Ontem';
    if (diffDays <= 7) return `${diffDays} dias atrás`;
    return date.toLocaleDateString('pt-BR');
  };

  return (
    <div className="space-y-6">
      {/* Header with Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[var(--smoke)]/50" />
            <input
              type="text"
              placeholder="Buscar conversas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50"
              data-testid="search-chats"
            />
          </div>

          {/* Export Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-xl text-white font-medium neon-glow flex items-center gap-2"
            data-testid="export-chats"
          >
            <Download className="w-5 h-5" />
            Exportar
          </motion.button>
        </div>

        {/* Agent Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {agents.map((agent) => (
            <motion.button
              key={agent.id}
              onClick={() => setSelectedAgent(agent.id)}
              className={`
                px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all duration-300
                ${selectedAgent === agent.id
                  ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white neon-glow'
                  : 'glass-morphism text-[var(--smoke)]/70 hover:text-white'
                }
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              data-testid={`filter-${agent.id}`}
            >
              {agent.name} ({agent.count})
            </motion.button>
          ))}
        </div>
      </div>

      {/* Chat List */}
      <div className="space-y-4">
        {filteredChats.map((chat, index) => (
          <motion.div
            key={chat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass-morphism rounded-2xl p-6 hover:bg-[var(--smoke)]/5 transition-all duration-300 cursor-pointer group"
            onClick={() => setSelectedChat(selectedChat === chat.id ? null : chat.id)}
            data-testid={`chat-item-${chat.id}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4 flex-1">
                {/* Agent Avatar */}
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center neon-glow"
                  style={{ backgroundColor: `${chat.agentColor}20`, borderColor: chat.agentColor }}
                >
                  <Bot className="w-6 h-6" style={{ color: chat.agentColor }} />
                </div>

                {/* Chat Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-orbitron font-semibold text-white truncate">
                      {chat.title}
                    </h3>
                    <span 
                      className={`
                        px-2 py-1 rounded-full text-xs font-medium
                        ${chat.status === 'active' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-gray-500/20 text-gray-400'
                        }
                      `}
                    >
                      {chat.status === 'active' ? 'Ativa' : 'Finalizada'}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-[var(--smoke)]/70 mb-3">
                    <span className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {chat.agentName}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      {chat.messageCount} mensagens
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatDate(chat.lastActivity)}
                    </span>
                  </div>

                  <p className="text-sm text-[var(--smoke)]/80 truncate">
                    {chat.lastMessage}
                  </p>
                </div>
              </div>

              {/* Stats and Actions */}
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-sm font-medium text-[var(--orange)]">
                    {chat.tokensUsed} tokens
                  </div>
                  <div className="text-xs text-[var(--smoke)]/60">
                    utilizados
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 glass-morphism rounded-lg text-[var(--smoke)]/70 hover:text-[var(--blue)] transition-colors"
                    data-testid={`view-chat-${chat.id}`}
                  >
                    <Eye className="w-4 h-4" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 glass-morphism rounded-lg text-[var(--smoke)]/70 hover:text-[var(--blue)] transition-colors"
                    data-testid={`chat-menu-${chat.id}`}
                  >
                    <MoreVertical className="w-4 h-4" />
                  </motion.button>
                </div>
              </div>
            </div>

            {/* Expanded Chat Details */}
            {selectedChat === chat.id && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-6 pt-6 border-t border-[var(--smoke)]/20"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="glass-morphism rounded-xl p-4">
                    <h4 className="font-medium text-white mb-2">Resumo</h4>
                    <p className="text-sm text-[var(--smoke)]/70">
                      Conversa focada em {chat.title.toLowerCase()} com {chat.messageCount} trocas de mensagens.
                    </p>
                  </div>
                  
                  <div className="glass-morphism rounded-xl p-4">
                    <h4 className="font-medium text-white mb-2">Métricas</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-[var(--smoke)]/70">Tokens:</span>
                        <span className="text-[var(--orange)]">{chat.tokensUsed}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--smoke)]/70">Mensagens:</span>
                        <span className="text-white">{chat.messageCount}</span>
                      </div>
                    </div>
                  </div>

                  <div className="glass-morphism rounded-xl p-4">
                    <h4 className="font-medium text-white mb-2">Ações</h4>
                    <div className="space-y-2">
                      <button className="w-full px-3 py-2 text-sm bg-[var(--blue)]/20 text-[var(--blue)] rounded-lg hover:bg-[var(--blue)]/30 transition-colors">
                        Continuar Chat
                      </button>
                      <button className="w-full px-3 py-2 text-sm text-[var(--smoke)]/70 hover:text-white transition-colors">
                        Exportar Conversa
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredChats.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <div className="w-16 h-16 bg-[var(--smoke)]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <MessageSquare className="w-8 h-8 text-[var(--smoke)]/50" />
          </div>
          <h3 className="text-lg font-orbitron font-semibold text-white mb-2">
            Nenhuma conversa encontrada
          </h3>
          <p className="text-[var(--smoke)]/70 mb-6">
            {searchQuery 
              ? 'Tente ajustar sua busca ou filtros'
              : 'Você ainda não iniciou conversas com os agentes'
            }
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-xl text-white font-medium neon-glow"
          >
            Iniciar Novo Chat
          </motion.button>
        </motion.div>
      )}
    </div>
  );
}