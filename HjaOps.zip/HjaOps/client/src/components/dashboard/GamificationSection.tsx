import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Trophy, 
  Star, 
  Target,
  Award,
  TrendingUp,
  Users,
  Calendar,
  CheckCircle,
  Lock,
  Zap,
  Crown,
  Gift,
  Flame
} from 'lucide-react';

interface GamificationSectionProps {
  data?: any;
  isLoading: boolean;
}

export default function GamificationSection({ data, isLoading }: GamificationSectionProps) {
  const [selectedAchievement, setSelectedAchievement] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="space-y-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glass-morphism rounded-2xl p-6 animate-pulse">
            <div className="h-4 bg-[var(--smoke)]/20 rounded mb-4"></div>
            <div className="h-20 bg-[var(--smoke)]/20 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  // Mock data (replace with real data from API)
  const userProgress = data?.progress || {
    level: 7,
    xp: 2450,
    xpToNextLevel: 3000,
    totalXp: 8950,
    rank: 'Explorador Avançado',
    streak: 12,
    totalChats: 127,
    tokensEarned: 240
  };

  const badges = data?.badges || [
    {
      id: 'welcome',
      name: 'Bem-vindo',
      description: 'Completou o primeiro chat',
      icon: '👋',
      category: 'basic',
      unlocked: true,
      unlockedAt: '2024-01-01T00:00:00Z',
      rarity: 'common'
    },
    {
      id: 'chat_master',
      name: 'Mestre dos Chats',
      description: 'Completou 100 conversas',
      icon: '💬',
      category: 'engagement',
      unlocked: true,
      unlockedAt: '2024-01-10T15:30:00Z',
      rarity: 'uncommon'
    },
    {
      id: 'agent_explorer',
      name: 'Explorador de Agentes',
      description: 'Conversou com todos os 5 agentes',
      icon: '🤖',
      category: 'discovery',
      unlocked: true,
      unlockedAt: '2024-01-05T10:15:00Z',
      rarity: 'rare'
    },
    {
      id: 'streak_legend',
      name: 'Lenda da Sequência',
      description: 'Manteve sequência de 30 dias',
      icon: '🔥',
      category: 'consistency',
      unlocked: false,
      progress: 12,
      target: 30,
      rarity: 'epic'
    },
    {
      id: 'token_collector',
      name: 'Colecionador de Tokens',
      description: 'Acumulou 500 tokens bônus',
      icon: '⚡',
      category: 'collection',
      unlocked: false,
      progress: 240,
      target: 500,
      rarity: 'rare'
    },
    {
      id: 'pro_user',
      name: 'Usuário Pro',
      description: 'Fez upgrade para plano Pro',
      icon: '👑',
      category: 'premium',
      unlocked: true,
      unlockedAt: '2024-01-15T09:00:00Z',
      rarity: 'legendary'
    }
  ];

  const missions = data?.missions || [
    {
      id: 'daily_chat',
      name: 'Conversa Diária',
      description: 'Tenha uma conversa com qualquer agente',
      type: 'daily',
      reward: { type: 'xp', amount: 50 },
      progress: 1,
      target: 1,
      completed: true,
      expiresAt: '2024-01-16T23:59:59Z'
    },
    {
      id: 'try_new_agent',
      name: 'Novo Agente',
      description: 'Experimente o Branding Social',
      type: 'weekly',
      reward: { type: 'tokens', amount: 25 },
      progress: 0,
      target: 1,
      completed: false,
      expiresAt: '2024-01-21T23:59:59Z'
    },
    {
      id: 'power_user',
      name: 'Usuário Avançado',
      description: 'Use 200 tokens em uma semana',
      type: 'weekly',
      reward: { type: 'badge', item: 'power_user' },
      progress: 145,
      target: 200,
      completed: false,
      expiresAt: '2024-01-21T23:59:59Z'
    }
  ];

  const leaderboard = data?.leaderboard || [
    { rank: 1, name: 'Ana Silva', xp: 12450, avatar: '👩‍💻' },
    { rank: 2, name: 'Carlos Dev', xp: 11200, avatar: '👨‍💼' },
    { rank: 3, name: 'Maria Design', xp: 10800, avatar: '👩‍🎨' },
    { rank: 4, name: 'Você', xp: userProgress.totalXp, avatar: '🚀', isCurrentUser: true },
    { rank: 5, name: 'Pedro Code', xp: 8200, avatar: '👨‍💻' }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common':
        return 'text-gray-400 border-gray-400/30';
      case 'uncommon':
        return 'text-green-400 border-green-400/30';
      case 'rare':
        return 'text-blue-400 border-blue-400/30';
      case 'epic':
        return 'text-purple-400 border-purple-400/30';
      case 'legendary':
        return 'text-yellow-400 border-yellow-400/30';
      default:
        return 'text-gray-400 border-gray-400/30';
    }
  };

  const progressPercentage = (userProgress.xp / userProgress.xpToNextLevel) * 100;

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-morphism rounded-2xl p-6 border border-[var(--blue)]/20 neon-glow-subtle"
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Level Progress */}
          <div>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center neon-glow">
                <Trophy className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-orbitron font-bold text-white">
                  Nível {userProgress.level}
                </h3>
                <p className="text-[var(--smoke)]/70">{userProgress.rank}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-[var(--smoke)]/70">XP atual</span>
                <span className="text-white">{userProgress.xp.toLocaleString()} / {userProgress.xpToNextLevel.toLocaleString()}</span>
              </div>
              
              <div className="w-full bg-[var(--smoke)]/10 rounded-full h-3">
                <motion.div
                  className="h-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full neon-glow"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
              </div>

              <div className="text-center">
                <p className="text-sm text-[var(--smoke)]/70">
                  {userProgress.xpToNextLevel - userProgress.xp} XP para o próximo nível
                </p>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 glass-morphism rounded-xl">
              <div className="w-8 h-8 bg-red-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Flame className="w-5 h-5 text-red-400" />
              </div>
              <div className="text-2xl font-orbitron font-bold text-white">{userProgress.streak}</div>
              <div className="text-xs text-[var(--smoke)]/70">dias consecutivos</div>
            </div>

            <div className="text-center p-4 glass-morphism rounded-xl">
              <div className="w-8 h-8 bg-[var(--blue)]/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Users className="w-5 h-5 text-[var(--blue)]" />
              </div>
              <div className="text-2xl font-orbitron font-bold text-white">{userProgress.totalChats}</div>
              <div className="text-xs text-[var(--smoke)]/70">chats totais</div>
            </div>

            <div className="text-center p-4 glass-morphism rounded-xl">
              <div className="w-8 h-8 bg-[var(--orange)]/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Zap className="w-5 h-5 text-[var(--orange)]" />
              </div>
              <div className="text-2xl font-orbitron font-bold text-white">{userProgress.tokensEarned}</div>
              <div className="text-xs text-[var(--smoke)]/70">tokens ganhos</div>
            </div>

            <div className="text-center p-4 glass-morphism rounded-xl">
              <div className="w-8 h-8 bg-yellow-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Star className="w-5 h-5 text-yellow-400" />
              </div>
              <div className="text-2xl font-orbitron font-bold text-white">
                {badges.filter(b => b.unlocked).length}
              </div>
              <div className="text-xs text-[var(--smoke)]/70">badges conquistadas</div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Missions and Achievements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily/Weekly Missions */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Target className="w-6 h-6 text-[var(--blue)]" />
            <h3 className="text-lg font-orbitron font-bold text-white">Missões</h3>
          </div>

          <div className="space-y-4">
            {missions.map((mission, index) => (
              <motion.div
                key={mission.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                className={`p-4 rounded-xl border ${
                  mission.completed 
                    ? 'border-green-400/30 bg-green-500/10' 
                    : 'border-[var(--smoke)]/20 glass-morphism'
                }`}
                data-testid={`mission-${mission.id}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-white">{mission.name}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        mission.type === 'daily' 
                          ? 'bg-blue-500/20 text-blue-400' 
                          : 'bg-purple-500/20 text-purple-400'
                      }`}>
                        {mission.type === 'daily' ? 'Diária' : 'Semanal'}
                      </span>
                    </div>
                    <p className="text-sm text-[var(--smoke)]/70 mb-2">{mission.description}</p>
                    
                    {!mission.completed && (
                      <div className="w-full bg-[var(--smoke)]/10 rounded-full h-2 mb-2">
                        <div 
                          className="h-2 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full"
                          style={{ width: `${(mission.progress / mission.target) * 100}%` }}
                        />
                      </div>
                    )}
                    
                    <div className="text-xs text-[var(--smoke)]/60">
                      {mission.completed ? 'Concluída!' : `${mission.progress}/${mission.target}`}
                    </div>
                  </div>

                  <div className="text-right">
                    {mission.completed ? (
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    ) : (
                      <div className="text-xs text-[var(--orange)]">
                        +{mission.reward.amount} {mission.reward.type === 'xp' ? 'XP' : 'tokens'}
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Badges/Achievements */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-morphism rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Award className="w-6 h-6 text-[var(--orange)]" />
            <h3 className="text-lg font-orbitron font-bold text-white">Conquistas</h3>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {badges.map((badge, index) => (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className={`
                  p-4 rounded-xl border-2 cursor-pointer transition-all duration-300
                  ${badge.unlocked 
                    ? `${getRarityColor(badge.rarity)} neon-glow-subtle` 
                    : 'border-[var(--smoke)]/20 opacity-50'
                  }
                  hover:scale-105
                `}
                onClick={() => setSelectedAchievement(selectedAchievement === badge.id ? null : badge.id)}
                data-testid={`badge-${badge.id}`}
              >
                <div className="text-center">
                  <div className="text-3xl mb-2">
                    {badge.unlocked ? badge.icon : <Lock className="w-8 h-8 mx-auto text-[var(--smoke)]/50" />}
                  </div>
                  <h4 className="font-medium text-white text-sm mb-1">{badge.name}</h4>
                  <p className="text-xs text-[var(--smoke)]/70 mb-2">{badge.description}</p>
                  
                  {!badge.unlocked && badge.progress !== undefined && (
                    <div className="text-xs text-[var(--orange)]">
                      {badge.progress}/{badge.target}
                    </div>
                  )}
                  
                  {badge.unlocked && (
                    <div className="text-xs text-green-400">
                      Desbloqueada
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Leaderboard */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass-morphism rounded-2xl p-6"
      >
        <div className="flex items-center gap-3 mb-6">
          <TrendingUp className="w-6 h-6 text-yellow-400" />
          <h3 className="text-lg font-orbitron font-bold text-white">Ranking Global</h3>
          <span className="text-xs text-[var(--smoke)]/60 ml-auto">Esta semana</span>
        </div>

        <div className="space-y-3">
          {leaderboard.map((entry, index) => (
            <motion.div
              key={entry.rank}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className={`
                flex items-center gap-4 p-4 rounded-xl transition-all duration-300
                ${entry.isCurrentUser 
                  ? 'border-2 border-[var(--blue)] bg-[var(--blue)]/10 neon-glow' 
                  : 'glass-morphism'
                }
              `}
              data-testid={`leaderboard-${entry.rank}`}
            >
              <div className={`
                w-8 h-8 rounded-lg flex items-center justify-center font-bold
                ${entry.rank <= 3 
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white' 
                  : 'bg-[var(--smoke)]/20 text-[var(--smoke)]'
                }
              `}>
                {entry.rank <= 3 ? (
                  entry.rank === 1 ? '🥇' : entry.rank === 2 ? '🥈' : '🥉'
                ) : (
                  entry.rank
                )}
              </div>

              <div className="text-2xl">{entry.avatar}</div>
              
              <div className="flex-1">
                <h4 className={`font-medium ${entry.isCurrentUser ? 'text-[var(--blue)]' : 'text-white'}`}>
                  {entry.name}
                </h4>
                <p className="text-sm text-[var(--smoke)]/70">
                  {entry.xp.toLocaleString()} XP
                </p>
              </div>

              {entry.isCurrentUser && (
                <div className="text-xs text-[var(--blue)] font-medium">
                  Você
                </div>
              )}
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-6">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 glass-morphism rounded-xl text-[var(--blue)] hover:text-white transition-colors"
          >
            Ver Ranking Completo
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}