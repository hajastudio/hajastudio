import { motion } from 'framer-motion';
import { Crown, Book, Lightbulb, Star, Lock, ArrowRight } from 'lucide-react';

interface ContextPanelProps {
  activeAgent?: {
    name: string;
    category: string;
    model: string;
    description: string;
  };
  userPlan?: 'Convidado' | 'PRO' | 'VIP' | 'SVIP';
}

export function ContextPanel({ activeAgent, userPlan = 'Convidado' }: ContextPanelProps) {
  const prompts = [
    '💡 Como criar conteúdo viral para TikTok?',
    '📊 Análise de tendências de mercado',
    '🎯 Estratégia de lançamento de produto',
    '✍️ Roteiro para vídeo explicativo',
    '🚀 Plano de marketing 360°'
  ];

  const unlockedContent = [
    {
      type: 'curso',
      title: 'Marketing Digital Avançado',
      progress: 75,
      locked: userPlan === 'Convidado'
    },
    {
      type: 'template',
      title: 'Templates de E-mail',
      progress: 100,
      locked: false
    },
    {
      type: 'documento',
      title: 'Guia de SEO 2024',
      progress: 50,
      locked: userPlan === 'Convidado'
    }
  ];

  const recommendations = [
    {
      title: 'Curso: Criação de Conteúdo',
      description: 'Aprenda a criar conteúdo que engaja',
      price: 'R$ 97',
      discount: '50% OFF',
      locked: userPlan === 'Convidado'
    },
    {
      title: 'Pack: Templates Premium',
      description: '100+ templates prontos para usar',
      price: 'R$ 197',
      discount: '30% OFF',
      locked: userPlan !== 'SVIP'
    }
  ];

  return (
    <motion.aside
      initial={{ x: 20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className="w-full lg:w-80 bg-hja-black/95 backdrop-blur-xl border-l border-hja-blue/20 overflow-y-auto"
    >
      <div className="p-6 space-y-6">
        {/* Active Agent */}
        {activeAgent && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="bg-glass-gradient border border-hja-blue/30 rounded-xl p-4"
          >
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-hja-blue to-hja-orange flex items-center justify-center">
                <span className="text-black font-orbitron font-bold">
                  {activeAgent.name.charAt(0)}
                </span>
              </div>
              <div>
                <h3 className="font-orbitron font-bold text-hja-blue text-sm">
                  {activeAgent.name}
                </h3>
                <p className="text-xs text-hja-gray">
                  {activeAgent.category}
                </p>
              </div>
            </div>
            
            <p className="text-sm text-hja-gray mb-3">
              {activeAgent.description}
            </p>
            
            <div className="flex items-center justify-between text-xs">
              <span className="text-hja-gray">Modelo:</span>
              <span className="text-hja-blue font-medium">{activeAgent.model}</span>
            </div>
          </motion.div>
        )}

        {/* Quick Prompts */}
        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4 flex items-center">
            <Lightbulb size={18} className="mr-2" />
            Sugestões Rápidas
          </h3>
          
          <div className="space-y-2">
            {prompts.map((prompt, index) => (
              <motion.button
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full text-left p-3 bg-hja-blue/5 hover:bg-hja-blue/10 border border-hja-blue/20 rounded-lg text-sm text-hja-gray hover:text-hja-blue transition-all duration-200"
              >
                {prompt}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Unlocked Content */}
        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4 flex items-center">
            <Book size={18} className="mr-2" />
            Conteúdo Desbloqueado
          </h3>
          
          <div className="space-y-3">
            {unlockedContent.map((content, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`
                  p-3 border rounded-lg transition-all duration-200
                  ${content.locked 
                    ? 'border-gray-800 bg-gray-900/50' 
                    : 'border-hja-blue/20 bg-hja-blue/5 hover:bg-hja-blue/10'
                  }
                `}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-sm font-medium ${content.locked ? 'text-gray-600' : 'text-hja-blue'}`}>
                    {content.title}
                  </span>
                  {content.locked ? (
                    <Lock size={14} className="text-gray-600" />
                  ) : (
                    <ArrowRight size={14} className="text-hja-blue" />
                  )}
                </div>
                
                {!content.locked && (
                  <div className="w-full bg-gray-800 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${content.progress}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                      className="h-2 bg-gradient-to-r from-hja-blue to-cyan-400 rounded-full"
                    />
                  </div>
                )}
                
                {content.locked && (
                  <p className="text-xs text-gray-600 mt-1">
                    Upgrade para acessar
                  </p>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4 flex items-center">
            <Star size={18} className="mr-2" />
            Recomendações
          </h3>
          
          <div className="space-y-3">
            {recommendations.map((rec, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className={`
                  p-4 border rounded-xl transition-all duration-200 cursor-pointer
                  ${rec.locked 
                    ? 'border-gray-800 bg-gray-900/50' 
                    : 'border-hja-orange/30 bg-hja-orange/5 hover:bg-hja-orange/10 hover:shadow-glow-orange'
                  }
                `}
              >
                <div className="flex items-start justify-between mb-2">
                  <h4 className={`font-medium text-sm ${rec.locked ? 'text-gray-600' : 'text-hja-orange'}`}>
                    {rec.title}
                  </h4>
                  {rec.locked && <Lock size={14} className="text-gray-600 mt-1" />}
                </div>
                
                <p className={`text-xs mb-3 ${rec.locked ? 'text-gray-600' : 'text-hja-gray'}`}>
                  {rec.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <span className={`text-sm font-bold ${rec.locked ? 'text-gray-600' : 'text-hja-orange'}`}>
                      {rec.price}
                    </span>
                    {!rec.locked && (
                      <span className="ml-2 text-xs bg-hja-orange/20 text-hja-orange px-2 py-1 rounded-full">
                        {rec.discount}
                      </span>
                    )}
                  </div>
                  
                  {!rec.locked && (
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="text-xs bg-gradient-to-r from-hja-orange to-red-500 text-black px-3 py-1 rounded-lg font-medium"
                    >
                      Ver Mais
                    </motion.button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Plan Upgrade */}
        {userPlan === 'Convidado' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-gradient-to-br from-hja-blue/20 to-hja-orange/20 border border-hja-blue/30 rounded-xl p-4"
          >
            <div className="flex items-center mb-3">
              <Crown size={20} className="text-hja-orange mr-2" />
              <h3 className="font-orbitron font-bold text-hja-blue">
                Upgrade PRO
              </h3>
            </div>
            
            <p className="text-sm text-hja-gray mb-4">
              Desbloqueie todos os agentes, cursos e templates premium.
            </p>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full bg-gradient-to-r from-hja-blue to-cyan-400 text-black font-bold py-2 px-4 rounded-lg text-sm animate-glow-pulse"
            >
              Fazer Upgrade
            </motion.button>
          </motion.div>
        )}
      </div>
    </motion.aside>
  );
}