import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  CreditCard, 
  Plus, 
  Download,
  Check,
  Clock,
  X,
  TrendingUp,
  Calendar,
  Filter,
  Star,
  Crown,
  Zap
} from 'lucide-react';

interface TransactionsSectionProps {
  data?: any;
  isLoading: boolean;
}

export default function TransactionsSection({ data, isLoading }: TransactionsSectionProps) {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showAllTransactions, setShowAllTransactions] = useState(false);

  if (isLoading) {
    return (
      <div className="space-y-6">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="glass-morphism rounded-2xl p-6 animate-pulse">
            <div className="h-4 bg-[var(--smoke)]/20 rounded mb-4"></div>
            <div className="h-20 bg-[var(--smoke)]/20 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  // Mock data (replace with real data from API)
  const currentPlan = data?.currentPlan || {
    name: 'Pro',
    credits: 500,
    price: 49.90,
    renewalDate: '2024-02-15',
    status: 'active'
  };

  const transactions = data?.transactions || [
    {
      id: 'tx_001',
      type: 'plan_upgrade',
      description: 'Upgrade para Plano Pro',
      amount: 49.90,
      credits: 500,
      status: 'completed',
      date: '2024-01-15T10:30:00Z',
      paymentMethod: 'PIX',
      mercadoPagoId: 'MP123456'
    },
    {
      id: 'tx_002',
      type: 'credit_purchase',
      description: 'Compra de Créditos Extras',
      amount: 19.90,
      credits: 200,
      status: 'completed',
      date: '2024-01-10T14:20:00Z',
      paymentMethod: 'Cartão',
      mercadoPagoId: 'MP123457'
    },
    {
      id: 'tx_003',
      type: 'bonus',
      description: 'Bônus de Boas-vindas',
      amount: 0,
      credits: 50,
      status: 'completed',
      date: '2024-01-01T00:00:00Z',
      paymentMethod: 'Grátis',
      mercadoPagoId: null
    }
  ];

  const plans = [
    {
      id: 'free',
      name: 'Free',
      credits: 50,
      price: 0,
      features: ['50 créditos/mês', 'Acesso básico aos agentes', 'Histórico limitado'],
      popular: false,
      current: currentPlan.name === 'Free'
    },
    {
      id: 'basic',
      name: 'Basic',
      credits: 200,
      price: 19.90,
      features: ['200 créditos/mês', 'Todos os agentes', 'Histórico completo', 'Suporte email'],
      popular: false,
      current: currentPlan.name === 'Basic'
    },
    {
      id: 'pro',
      name: 'Pro',
      credits: 500,
      price: 49.90,
      features: ['500 créditos/mês', 'Prioridade na fila', 'Modelos premium', 'Suporte prioritário'],
      popular: true,
      current: currentPlan.name === 'Pro'
    },
    {
      id: 'premium',
      name: 'Premium',
      credits: 1000,
      price: 99.90,
      features: ['1000 créditos/mês', 'Acesso antecipado', 'API personalizada', 'Suporte 24/7'],
      popular: false,
      current: currentPlan.name === 'Premium'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <Check className="w-5 h-5 text-green-400" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-400" />;
      case 'failed':
        return <X className="w-5 h-5 text-red-400" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-400 bg-green-500/20';
      case 'pending':
        return 'text-yellow-400 bg-yellow-500/20';
      case 'failed':
        return 'text-red-400 bg-red-500/20';
      default:
        return 'text-gray-400 bg-gray-500/20';
    }
  };

  const handlePlanUpgrade = (planId: string) => {
    // Here you would implement Mercado Pago integration
    console.log('Upgrading to plan:', planId);
    // Redirect to Mercado Pago checkout
  };

  const handleCreditPurchase = (amount: number, credits: number) => {
    // Here you would implement credit purchase via Mercado Pago
    console.log('Purchasing credits:', { amount, credits });
  };

  return (
    <div className="space-y-6">
      {/* Current Plan Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-morphism rounded-2xl p-6 border border-[var(--blue)]/20 neon-glow-subtle"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-xl flex items-center justify-center neon-glow">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-orbitron font-bold text-white">
                Plano {currentPlan.name}
              </h3>
              <p className="text-[var(--smoke)]/70">
                Renova em {new Date(currentPlan.renewalDate).toLocaleDateString('pt-BR')}
              </p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-2xl font-orbitron font-bold text-[var(--orange)]">
              {currentPlan.credits} créditos
            </div>
            <div className="text-sm text-[var(--smoke)]/70">
              R$ {currentPlan.price.toFixed(2)}/mês
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex-1 px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-xl text-white font-medium neon-glow"
            data-testid="upgrade-plan"
          >
            <Plus className="w-5 h-5 inline mr-2" />
            Fazer Upgrade
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors"
            data-testid="manage-plan"
          >
            Gerenciar Plano
          </motion.button>
        </div>
      </motion.div>

      {/* Quick Credit Purchase */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-morphism rounded-2xl p-6"
      >
        <h3 className="text-lg font-orbitron font-bold text-white mb-6">
          Comprar Créditos Extras
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { credits: 100, price: 9.90, bonus: 0 },
            { credits: 250, price: 19.90, bonus: 50 },
            { credits: 500, price: 39.90, bonus: 150 }
          ].map((pack, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="glass-morphism rounded-xl p-4 cursor-pointer hover:bg-[var(--smoke)]/5 transition-all duration-300"
              onClick={() => handleCreditPurchase(pack.price, pack.credits + pack.bonus)}
              data-testid={`credit-pack-${index}`}
            >
              <div className="text-center">
                <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-[var(--orange)]" />
                </div>
                <h4 className="font-orbitron font-bold text-white mb-1">
                  {pack.credits} {pack.bonus > 0 && `+ ${pack.bonus}`} créditos
                </h4>
                <p className="text-2xl font-bold text-[var(--orange)] mb-2">
                  R$ {pack.price.toFixed(2)}
                </p>
                {pack.bonus > 0 && (
                  <p className="text-xs text-green-400">+{pack.bonus} bônus!</p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Available Plans */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-morphism rounded-2xl p-6"
      >
        <h3 className="text-lg font-orbitron font-bold text-white mb-6">
          Planos Disponíveis
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className={`
                relative rounded-xl p-6 border-2 transition-all duration-300 cursor-pointer
                ${plan.current 
                  ? 'border-[var(--blue)] bg-[var(--blue)]/10 neon-glow' 
                  : 'border-[var(--smoke)]/20 glass-morphism hover:border-[var(--blue)]/50'
                }
                ${plan.popular ? 'ring-2 ring-[var(--orange)]' : ''}
              `}
              onClick={() => !plan.current && handlePlanUpgrade(plan.id)}
              data-testid={`plan-${plan.id}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-[var(--orange)] text-white text-xs font-bold px-3 py-1 rounded-full">
                    POPULAR
                  </span>
                </div>
              )}
              
              {plan.current && (
                <div className="absolute -top-3 right-3">
                  <span className="bg-[var(--blue)] text-white text-xs font-bold px-3 py-1 rounded-full">
                    ATUAL
                  </span>
                </div>
              )}

              <div className="text-center mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 ${
                  plan.id === 'free' ? 'bg-gray-500/20' :
                  plan.id === 'basic' ? 'bg-blue-500/20' :
                  plan.id === 'pro' ? 'bg-[var(--orange)]/20' :
                  'bg-purple-500/20'
                }`}>
                  {plan.id === 'free' && <Star className="w-6 h-6 text-gray-400" />}
                  {plan.id === 'basic' && <Zap className="w-6 h-6 text-blue-400" />}
                  {plan.id === 'pro' && <Crown className="w-6 h-6 text-[var(--orange)]" />}
                  {plan.id === 'premium' && <TrendingUp className="w-6 h-6 text-purple-400" />}
                </div>
                
                <h4 className="font-orbitron font-bold text-white text-lg mb-1">
                  {plan.name}
                </h4>
                <p className="text-2xl font-bold text-[var(--orange)] mb-1">
                  R$ {plan.price.toFixed(2)}
                </p>
                <p className="text-xs text-[var(--smoke)]/60">
                  {plan.credits} créditos/mês
                </p>
              </div>

              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center gap-2 text-sm text-[var(--smoke)]/80">
                    <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>

              {!plan.current && (
                <button className="w-full px-4 py-2 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-lg text-white font-medium hover:shadow-lg transition-all duration-300">
                  {plan.price === 0 ? 'Downgrade' : 'Upgrade'}
                </button>
              )}
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Transaction History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass-morphism rounded-2xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-orbitron font-bold text-white">
            Histórico de Transações
          </h3>
          <div className="flex gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-2 glass-morphism rounded-lg text-[var(--smoke)]/70 hover:text-white transition-colors"
              data-testid="filter-transactions"
            >
              <Filter className="w-5 h-5" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-2 glass-morphism rounded-lg text-[var(--smoke)]/70 hover:text-white transition-colors"
              data-testid="export-transactions"
            >
              <Download className="w-5 h-5" />
            </motion.button>
          </div>
        </div>

        <div className="space-y-4">
          {(showAllTransactions ? transactions : transactions.slice(0, 5)).map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className="flex items-center justify-between p-4 glass-morphism rounded-xl"
              data-testid={`transaction-${transaction.id}`}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-[var(--blue)]/20 rounded-lg flex items-center justify-center">
                  {getStatusIcon(transaction.status)}
                </div>
                <div>
                  <h4 className="font-medium text-white">{transaction.description}</h4>
                  <div className="flex items-center gap-4 text-sm text-[var(--smoke)]/70">
                    <span>{new Date(transaction.date).toLocaleDateString('pt-BR')}</span>
                    <span>{transaction.paymentMethod}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(transaction.status)}`}>
                      {transaction.status === 'completed' ? 'Concluída' :
                       transaction.status === 'pending' ? 'Pendente' : 'Falhou'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <p className="font-medium text-white">
                  {transaction.amount > 0 ? `R$ ${transaction.amount.toFixed(2)}` : 'Grátis'}
                </p>
                <p className="text-sm text-[var(--orange)]">
                  +{transaction.credits} créditos
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {transactions.length > 5 && (
          <div className="text-center mt-6">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowAllTransactions(!showAllTransactions)}
              className="px-6 py-3 glass-morphism rounded-xl text-[var(--blue)] hover:text-white transition-colors"
            >
              {showAllTransactions ? 'Ver Menos' : `Ver Todas (${transactions.length})`}
            </motion.button>
          </div>
        )}
      </motion.div>
    </div>
  );
}