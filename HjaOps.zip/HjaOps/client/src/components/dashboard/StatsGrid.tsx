import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

export function StatsGrid() {
  const { data: chats = [] } = useQuery({
    queryKey: ["/api/chats"],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const totalChats = chats.length;
  const totalTokens = chats.reduce((sum: number, chat: any) => sum + (chat.tokensUsed || 0), 0);
  const credits = user?.credits || 0;

  const stats = [
    {
      title: "Total Chats",
      value: totalChats.toLocaleString(),
      icon: "fas fa-comments",
    },
    {
      title: "Tokens Used",
      value: totalTokens > 1000 ? `${(totalTokens / 1000).toFixed(1)}K` : totalTokens.toString(),
      icon: "fas fa-microchip",
    },
    {
      title: "Active Agents",
      value: "8", // This would come from API
      icon: "fas fa-robot",
    },
    {
      title: "Credits Left",
      value: credits.toLocaleString(),
      icon: "fas fa-coins",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <Card key={index} className="netflix-card p-6" data-testid={`stat-card-${index}`}>
          <CardContent className="p-0">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground" data-testid={`stat-title-${index}`}>
                  {stat.title}
                </p>
                <p className="text-2xl font-bold text-primary" data-testid={`stat-value-${index}`}>
                  {stat.value}
                </p>
              </div>
              <i className={`${stat.icon} text-primary text-xl`}></i>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
