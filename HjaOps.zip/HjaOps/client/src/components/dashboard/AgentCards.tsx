import { motion } from 'framer-motion';
import { useState } from 'react';
import { Play, Star, Zap, Clock, TrendingUp } from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  description: string;
  category: string;
  model: string;
  rating: number;
  totalChats: number;
  avgTokens: number;
  image?: string;
  tags: string[];
  featured?: boolean;
  popular?: boolean;
}

interface AgentCardsProps {
  agents?: Agent[];
  onSelectAgent?: (agent: Agent) => void;
}

export function AgentCards({ agents = [], onSelectAgent }: AgentCardsProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');

  // Mock agents data
  const defaultAgents: Agent[] = [
    {
      id: '1',
      name: 'Roteirista Viral',
      description: 'Especialista em criar roteiros envolventes para vídeos virais e storytelling cativante.',
      category: 'Criação',
      model: 'GPT-4',
      rating: 4.9,
      totalChats: 1247,
      avgTokens: 350,
      tags: ['Roteiro', 'Viral', 'Storytelling'],
      featured: true,
      popular: true
    },
    {
      id: '2',
      name: 'Estrategista Digital',
      description: 'Desenvolve estratégias de marketing digital e campanhas de alto impacto.',
      category: 'Marketing',
      model: 'Claude-3',
      rating: 4.8,
      totalChats: 892,
      avgTokens: 280,
      tags: ['Marketing', 'Estratégia', 'Digital'],
      featured: true
    },
    {
      id: '3',
      name: 'Copywriter Persuasivo',
      description: 'Cria textos persuasivos que convertem visitantes em clientes.',
      category: 'Vendas',
      model: 'GPT-4',
      rating: 4.7,
      totalChats: 634,
      avgTokens: 220,
      tags: ['Copy', 'Vendas', 'Conversão']
    },
    {
      id: '4',
      name: 'Analista de Dados',
      description: 'Interpreta dados complexos e gera insights acionáveis para negócios.',
      category: 'Análise',
      model: 'Claude-3',
      rating: 4.6,
      totalChats: 456,
      avgTokens: 420,
      tags: ['Dados', 'Analytics', 'BI']
    },
    {
      id: '5',
      name: 'Designer UX/UI',
      description: 'Otimiza experiências digitais e interfaces intuitivas.',
      category: 'Design',
      model: 'GPT-4',
      rating: 4.5,
      totalChats: 723,
      avgTokens: 310,
      tags: ['UX', 'UI', 'Design']
    },
    {
      id: '6',
      name: 'Growth Hacker',
      description: 'Especialista em crescimento acelerado e growth hacking.',
      category: 'Crescimento',
      model: 'Claude-3',
      rating: 4.8,
      totalChats: 567,
      avgTokens: 290,
      tags: ['Growth', 'Hacking', 'Crescimento'],
      popular: true
    }
  ];

  const agentList = agents.length > 0 ? agents : defaultAgents;
  
  const categories = ['Todos', ...Array.from(new Set(agentList.map(a => a.category)))];
  
  const filteredAgents = selectedCategory === 'Todos' 
    ? agentList 
    : agentList.filter(a => a.category === selectedCategory);

  const handleSelectAgent = (agent: Agent) => {
    onSelectAgent?.(agent);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center justify-between"
      >
        <div>
          <h2 className="text-2xl font-orbitron font-bold text-hja-blue mb-2">
            Agentes IA
          </h2>
          <p className="text-hja-gray">
            Escolha um especialista para começar sua conversa
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex space-x-2 mt-4 md:mt-0 overflow-x-auto">
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category)}
              className={`
                px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap
                ${selectedCategory === category
                  ? 'bg-hja-blue/20 text-hja-blue border border-hja-blue/30 shadow-glow-blue'
                  : 'bg-hja-black/50 text-hja-gray border border-gray-800 hover:border-hja-blue/30'
                }
              `}
            >
              {category}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Agents Grid */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredAgents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ 
              scale: 1.03,
              rotateY: 5,
              rotateX: 5
            }}
            className="group perspective-1000"
          >
            <div className={`
              relative bg-glass-gradient backdrop-blur-xl border rounded-xl p-6 cursor-pointer
              transition-all duration-300 transform-gpu
              ${agent.featured 
                ? 'border-hja-blue/50 shadow-glow-blue' 
                : 'border-white/10 hover:border-hja-blue/30'
              }
              group-hover:shadow-glow-blue-strong
            `}>
              {/* Featured Badge */}
              {agent.featured && (
                <div className="absolute -top-2 -right-2 bg-gradient-to-r from-hja-blue to-cyan-400 text-black px-3 py-1 rounded-lg text-xs font-bold">
                  FEATURED
                </div>
              )}

              {/* Popular Badge */}
              {agent.popular && (
                <div className="absolute -top-2 -left-2 bg-gradient-to-r from-hja-orange to-red-500 text-black px-3 py-1 rounded-lg text-xs font-bold flex items-center space-x-1">
                  <TrendingUp size={12} />
                  <span>POPULAR</span>
                </div>
              )}

              {/* Agent Avatar */}
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-hja-blue to-hja-orange flex items-center justify-center group-hover:animate-glow-pulse">
                  <span className="text-black font-orbitron font-bold text-lg">
                    {agent.name.charAt(0)}
                  </span>
                </div>

                <div className="flex-1">
                  <h3 className="font-orbitron font-bold text-hja-blue group-hover:animate-neon-glow">
                    {agent.name}
                  </h3>
                  <p className="text-sm text-hja-gray">
                    {agent.category}
                  </p>
                </div>

                <div className="flex items-center space-x-1 text-yellow-400">
                  <Star size={16} fill="currentColor" />
                  <span className="text-sm font-medium">{agent.rating}</span>
                </div>
              </div>

              {/* Description */}
              <p className="text-hja-gray text-sm mb-4 leading-relaxed">
                {agent.description}
              </p>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-hja-blue font-bold text-lg">
                    {agent.totalChats.toLocaleString()}
                  </div>
                  <div className="text-xs text-hja-gray">Conversas</div>
                </div>
                <div className="text-center">
                  <div className="text-hja-blue font-bold text-lg">
                    {agent.avgTokens}
                  </div>
                  <div className="text-xs text-hja-gray">Avg Tokens</div>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {agent.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 bg-hja-blue/10 text-hja-blue text-xs rounded-lg border border-hja-blue/20"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Model Info */}
              <div className="flex items-center justify-between mb-4 text-sm text-hja-gray">
                <div className="flex items-center space-x-1">
                  <Zap size={14} />
                  <span>Modelo: {agent.model}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock size={14} />
                  <span>~2min</span>
                </div>
              </div>

              {/* Activate Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSelectAgent(agent)}
                className="w-full bg-gradient-to-r from-hja-blue to-cyan-400 hover:from-cyan-400 hover:to-hja-blue text-black font-bold py-3 px-4 rounded-lg transition-all duration-300 flex items-center justify-center space-x-2 shadow-glow-blue group-hover:animate-glow-pulse"
              >
                <Play size={16} />
                <span>Ativar Agente</span>
              </motion.button>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* No agents found */}
      {filteredAgents.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <div className="w-16 h-16 bg-gradient-to-br from-hja-blue to-hja-orange rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap size={24} className="text-black" />
          </div>
          <h3 className="text-xl font-orbitron font-bold text-hja-blue mb-2">
            Nenhum agente encontrado
          </h3>
          <p className="text-hja-gray">
            Tente selecionar uma categoria diferente
          </p>
        </motion.div>
      )}
    </div>
  );
}