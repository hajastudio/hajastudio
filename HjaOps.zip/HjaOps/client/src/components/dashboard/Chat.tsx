import { motion, AnimatePresence } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';
import { Send, Mic, Paperclip, MoreHorizontal, Bot, User } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  tokens?: number;
}

interface ChatProps {
  agent?: {
    name: string;
    description: string;
    model: string;
  };
  onSendMessage?: (message: string) => void;
}

export function Chat({ agent, onSendMessage }: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: `Olá! Eu sou o ${agent?.name || 'Assistente IA'}. ${agent?.description || 'Como posso ajudar você hoje?'}`,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickActions = [
    '💡 Gerar ideia',
    '📝 Criar roteiro',
    '🚀 Estratégia viral',
    '🎯 Análise de mercado'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Call parent callback
    onSendMessage?.(input);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: `Entendi! Sobre "${input}", vou elaborar uma resposta detalhada para você. Como ${agent?.name || 'especialista'}, posso ajudar com várias abordagens diferentes...`,
        timestamp: new Date(),
        tokens: Math.floor(Math.random() * 200) + 50,
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 2000);
  };

  const handleQuickAction = (action: string) => {
    setInput(action);
  };

  return (
    <div className="flex flex-col h-full bg-hja-black">
      {/* Chat Header */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-hja-blue/20 bg-hja-black/95 backdrop-blur-xl"
      >
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-hja-blue to-hja-orange flex items-center justify-center">
            <Bot size={20} className="text-black" />
          </div>
          <div>
            <h3 className="font-orbitron font-bold text-hja-blue">
              {agent?.name || 'Assistente IA'}
            </h3>
            <p className="text-sm text-hja-gray">
              {agent?.model || 'Modelo: GPT-4'} • Online
            </p>
          </div>
        </div>

        <button className="p-2 rounded-lg hover:bg-hja-blue/10 text-hja-gray transition-colors">
          <MoreHorizontal size={20} />
        </button>
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-3 max-w-[80%] ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                {/* Avatar */}
                <div className={`
                  w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
                  ${message.type === 'user' 
                    ? 'bg-gradient-to-br from-hja-blue to-cyan-400' 
                    : 'bg-gradient-to-br from-hja-orange to-red-500'
                  }
                `}>
                  {message.type === 'user' ? (
                    <User size={16} className="text-black" />
                  ) : (
                    <Bot size={16} className="text-black" />
                  )}
                </div>

                {/* Message Bubble */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className={`
                    relative px-4 py-3 rounded-2xl backdrop-blur-xl
                    ${message.type === 'user'
                      ? 'bg-hja-blue/20 text-hja-blue border border-hja-blue/30 shadow-glow-blue'
                      : 'bg-glass-gradient text-hja-gray border border-white/10'
                    }
                  `}
                >
                  <p className="font-inter leading-relaxed">
                    {message.content}
                  </p>

                  {/* Timestamp */}
                  <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                    <span>
                      {message.timestamp.toLocaleTimeString('pt-BR', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                    {message.tokens && (
                      <span className="text-hja-orange">
                        {message.tokens} tokens
                      </span>
                    )}
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex justify-start"
            >
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-hja-orange to-red-500 flex items-center justify-center">
                  <Bot size={16} className="text-black" />
                </div>
                <div className="bg-glass-gradient border border-white/10 rounded-2xl px-4 py-3">
                  <div className="flex space-x-1">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1, delay: 0 }}
                      className="w-2 h-2 bg-hja-blue rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1, delay: 0.2 }}
                      className="w-2 h-2 bg-hja-blue rounded-full"
                    />
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1, delay: 0.4 }}
                      className="w-2 h-2 bg-hja-blue rounded-full"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-2">
        <div className="flex space-x-2 overflow-x-auto">
          {quickActions.map((action) => (
            <motion.button
              key={action}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleQuickAction(action)}
              className="flex-shrink-0 px-3 py-2 bg-hja-blue/10 hover:bg-hja-blue/20 border border-hja-blue/30 rounded-lg text-sm text-hja-blue transition-colors"
            >
              {action}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="p-4 border-t border-hja-blue/20 bg-hja-black/95 backdrop-blur-xl"
      >
        <div className="flex items-end space-x-3">
          {/* Attachment */}
          <button className="p-3 rounded-lg hover:bg-hja-blue/10 text-hja-gray hover:text-hja-blue transition-colors">
            <Paperclip size={20} />
          </button>

          {/* Input Field */}
          <div className="flex-1 relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Digite sua mensagem..."
              rows={1}
              className="w-full bg-glass-gradient border border-hja-blue/30 rounded-xl px-4 py-3 text-hja-gray placeholder-hja-gray/50 focus:outline-none focus:border-hja-blue focus:shadow-glow-blue resize-none"
            />
          </div>

          {/* Voice */}
          <button className="p-3 rounded-lg hover:bg-hja-blue/10 text-hja-gray hover:text-hja-blue transition-colors">
            <Mic size={20} />
          </button>

          {/* Send */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSend}
            disabled={!input.trim()}
            className={`
              p-3 rounded-lg transition-all duration-200
              ${input.trim()
                ? 'bg-gradient-to-r from-hja-blue to-cyan-400 text-black shadow-glow-blue animate-glow-pulse'
                : 'bg-gray-800 text-gray-600 cursor-not-allowed'
              }
            `}
          >
            <Send size={20} />
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}