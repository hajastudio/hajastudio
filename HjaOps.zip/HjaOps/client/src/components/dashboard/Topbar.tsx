import { motion } from 'framer-motion';
import { Bell, Star, Trophy, Zap, Menu } from 'lucide-react';

interface TopbarProps {
  user: {
    name: string;
    plan: 'Convidado' | 'PRO' | 'VIP' | 'SVIP';
    avatar?: string;
    credits: number;
    maxCredits: number;
  };
  onMenuToggle?: () => void;
}

export function Topbar({ user, onMenuToggle }: TopbarProps) {
  const planColors = {
    'Convidado': 'text-hja-gray',
    'PRO': 'text-hja-blue',
    'VIP': 'text-hja-orange',
    'SVIP': 'text-gradient-to-r from-hja-blue to-hja-orange'
  };

  const creditPercentage = (user.credits / user.maxCredits) * 100;
  const isLowCredits = creditPercentage < 20;

  const badges = [
    { icon: Star, label: 'Primeira compra', earned: true },
    { icon: Trophy, label: 'Usuário ativo', earned: true },
    { icon: Zap, label: 'Creator', earned: false },
  ];

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-30 bg-hja-black/95 backdrop-blur-xl border-b border-hja-blue/20"
    >
      <div className="flex items-center justify-between p-4">
        {/* Left: Mobile Menu + User Info */}
        <div className="flex items-center space-x-4">
          {/* Mobile Menu Button */}
          <button
            onClick={onMenuToggle}
            className="p-2 rounded-lg bg-hja-blue/10 hover:bg-hja-blue/20 text-hja-blue transition-colors lg:hidden"
          >
            <Menu size={20} />
          </button>

          {/* User Avatar */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="relative"
          >
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-hja-blue to-hja-orange p-0.5">
              <div className="w-full h-full rounded-full bg-hja-black flex items-center justify-center">
                {user.avatar ? (
                  <img 
                    src={user.avatar} 
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                ) : (
                  <span className="text-hja-blue font-orbitron font-bold text-lg">
                    {user.name.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
            </div>
            
            {/* Online indicator */}
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-hja-black animate-pulse" />
          </motion.div>

          {/* User Info */}
          <div className="hidden md:block">
            <h2 className="font-orbitron font-bold text-hja-blue">
              {user.name}
            </h2>
            <p className={`text-sm font-inter ${planColors[user.plan]}`}>
              {user.plan}
            </p>
          </div>

          {/* Badges */}
          <div className="hidden lg:flex items-center space-x-2">
            {badges.map((badge, index) => (
              <motion.div
                key={badge.label}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className={`
                  p-2 rounded-lg transition-all duration-200
                  ${badge.earned 
                    ? 'bg-hja-blue/20 text-hja-blue shadow-glow-blue' 
                    : 'bg-gray-800 text-gray-600'
                  }
                `}
                title={badge.label}
              >
                <badge.icon size={16} />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Center: Credits Progress */}
        <div className="flex-1 max-w-md mx-8 hidden md:block">
          <div className="relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-inter text-hja-gray">Créditos</span>
              <span className={`text-sm font-inter ${isLowCredits ? 'text-hja-orange animate-pulse' : 'text-hja-blue'}`}>
                {user.credits.toLocaleString()} / {user.maxCredits.toLocaleString()}
              </span>
            </div>
            
            <div className="h-3 bg-gray-900 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${creditPercentage}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={`
                  h-full rounded-full transition-all duration-300
                  ${isLowCredits 
                    ? 'bg-gradient-to-r from-hja-orange to-red-500 animate-glow-pulse' 
                    : 'bg-gradient-to-r from-hja-blue to-cyan-400 animate-glow-pulse'
                  }
                `}
              />
            </div>

            {isLowCredits && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-full mt-2 left-0 right-0 text-center"
              >
                <span className="text-xs text-hja-orange animate-pulse">
                  ⚠️ Créditos baixos - Considere recarregar
                </span>
              </motion.div>
            )}
          </div>
        </div>

        {/* Right: Notifications */}
        <div className="flex items-center space-x-3">
          {/* Add Credits Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="hidden md:flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-hja-orange to-red-500 rounded-lg text-black font-inter font-medium hover:shadow-glow-orange transition-all"
          >
            <Zap size={16} />
            <span>Comprar</span>
          </motion.button>

          {/* Notifications */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative p-3 rounded-lg bg-hja-blue/10 hover:bg-hja-blue/20 text-hja-blue transition-colors"
          >
            <Bell size={20} />
            
            {/* Notification badge */}
            <div className="absolute -top-1 -right-1 w-5 h-5 bg-hja-orange rounded-full flex items-center justify-center">
              <span className="text-xs font-bold text-black">3</span>
            </div>
          </motion.button>
        </div>
      </div>

      {/* Mobile Credits Bar */}
      <div className="md:hidden px-4 pb-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-inter text-hja-gray">Créditos</span>
          <span className={`text-sm font-inter ${isLowCredits ? 'text-hja-orange' : 'text-hja-blue'}`}>
            {user.credits} / {user.maxCredits}
          </span>
        </div>
        
        <div className="h-2 bg-gray-900 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${creditPercentage}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={`
              h-full rounded-full
              ${isLowCredits 
                ? 'bg-gradient-to-r from-hja-orange to-red-500' 
                : 'bg-gradient-to-r from-hja-blue to-cyan-400'
              }
            `}
          />
        </div>
      </div>
    </motion.header>
  );
}