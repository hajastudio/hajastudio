export function ContextPanelPlaceholder() {
  return (
    <aside className="w-80 glass-morphism border-l border-white/10 p-6 hidden xl:block">
      <div className="space-y-6">
        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4">Agente Ativo</h3>
          <div className="p-4 bg-hja-blue/5 rounded-xl border border-hja-blue/20">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 bg-gradient-to-br from-hja-blue to-hja-orange rounded-lg"></div>
              <div>
                <div className="font-medium text-hja-blue">Roteirista Viral</div>
                <div className="text-xs text-hja-gray">Criação</div>
              </div>
            </div>
            <p className="text-sm text-hja-gray">Especialista em roteiros virais e storytelling.</p>
          </div>
        </div>

        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4">Sugestões</h3>
          <div className="space-y-2">
            {[
              '💡 Como criar viral TikTok?',
              '📊 Análise de tendências',
              '🎯 Estratégia de lançamento'
            ].map((suggestion, i) => (
              <button
                key={i}
                className="w-full text-left p-3 bg-hja-blue/5 hover:bg-hja-blue/10 rounded-lg text-sm text-hja-gray hover:text-hja-blue transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-orbitron font-bold text-hja-blue mb-4">Recomendações</h3>
          <div className="p-4 bg-hja-orange/5 rounded-xl border border-hja-orange/20">
            <h4 className="font-medium text-hja-orange mb-2">Curso: Marketing Digital</h4>
            <p className="text-sm text-hja-gray mb-3">Aprenda estratégias avançadas</p>
            <button className="w-full bg-gradient-to-r from-hja-orange to-red-500 text-black font-bold py-2 px-4 rounded-lg text-sm">
              Ver Mais
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}