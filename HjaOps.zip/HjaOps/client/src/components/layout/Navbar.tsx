import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { 
  Menu, 
  X, 
  Zap, 
  User, 
  LogOut,
  Home,
  MessageSquare,
  LayoutDashboard,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, isAuthenticated } = useAuth();

  const navigationItems = [
    { href: '/', label: 'Home', icon: Home },
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, authRequired: true },
    { href: '/chat', label: 'Chat', icon: MessageSquare, authRequired: true },
  ];

  const adminItems = [
    { href: '/admin', label: 'Admin', icon: Settings },
  ];

  const isActiveRoute = (href: string) => {
    if (href === '/') return location === '/';
    return location.startsWith(href);
  };

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="hv-navbar fixed top-0 left-0 right-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link href="/">
            <motion.div 
              className="flex items-center gap-3 cursor-pointer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="w-10 h-10 bg-hv-blue rounded-lg flex items-center justify-center hv-glow-blue">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="hv-title text-2xl hv-gradient-text">
                Haja²Verso
              </span>
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navigationItems.map((item) => {
              if (item.authRequired && !isAuthenticated) return null;
              
              return (
                <Link key={item.href} href={item.href}>
                  <motion.div
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                      isActiveRoute(item.href)
                        ? 'bg-hv-blue/20 text-hv-blue border border-hv-blue/30'
                        : 'text-hv-smoke hover:text-hv-blue hover:bg-hv-blue/10'
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <item.icon className="w-4 h-4" />
                    <span className="font-medium">{item.label}</span>
                  </motion.div>
                </Link>
              );
            })}

            {/* Admin Navigation */}
            {user?.plan === 'admin' && (
              <>
                <div className="w-px h-6 bg-hv-blue/20" />
                {adminItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <motion.div
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
                        isActiveRoute(item.href)
                          ? 'bg-hv-orange/20 text-hv-orange border border-hv-orange/30'
                          : 'text-hv-smoke hover:text-hv-orange hover:bg-hv-orange/10'
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <item.icon className="w-4 h-4" />
                      <span className="font-medium">{item.label}</span>
                    </motion.div>
                  </Link>
                ))}
              </>
            )}
          </div>

          {/* User Actions */}
          <div className="hidden md:flex items-center gap-4">
            {isAuthenticated ? (
              <>
                {/* Credits Display */}
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-hv-blue/10 border border-hv-blue/20">
                  <Zap className="w-4 h-4 text-hv-blue" />
                  <span className="text-sm font-medium text-hv-blue">
                    {user?.credits || 0}
                  </span>
                </div>

                {/* User Menu */}
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-hv-blue/20 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-hv-blue" />
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-hv-smoke hover:text-white"
                    onClick={() => window.location.href = '/api/logout'}
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              </>
            ) : (
              <Button 
                className="hv-btn-primary"
                onClick={() => window.location.href = '/api/login'}
              >
                Get Started
              </Button>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              className="text-hv-smoke"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-hv-black/95 border-t border-hv-blue/20 backdrop-blur-lg"
          >
            <div className="px-4 py-4 space-y-2">
              {navigationItems.map((item) => {
                if (item.authRequired && !isAuthenticated) return null;
                
                return (
                  <Link key={item.href} href={item.href}>
                    <div
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-300 ${
                        isActiveRoute(item.href)
                          ? 'bg-hv-blue/20 text-hv-blue border border-hv-blue/30'
                          : 'text-hv-smoke hover:text-hv-blue hover:bg-hv-blue/10'
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </div>
                  </Link>
                );
              })}

              {/* Mobile User Actions */}
              {isAuthenticated ? (
                <div className="pt-4 border-t border-hv-blue/20 space-y-2">
                  <div className="flex items-center justify-between px-4 py-2">
                    <span className="text-hv-smoke">Créditos</span>
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-hv-blue" />
                      <span className="font-medium text-hv-blue">
                        {user?.credits || 0}
                      </span>
                    </div>
                  </div>
                  
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-hv-smoke hover:text-white"
                    onClick={() => {
                      window.location.href = '/api/logout';
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </Button>
                </div>
              ) : (
                <div className="pt-4 border-t border-hv-blue/20">
                  <Button 
                    className="w-full hv-btn-primary"
                    onClick={() => {
                      window.location.href = '/api/login';
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Get Started
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}