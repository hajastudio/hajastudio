import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import Sidebar from './Sidebar';
import DashboardHeader from './DashboardHeader';
import DashboardContent from './DashboardContent';
import OnboardingTourManager from '@/components/onboarding/OnboardingTourManager';

export type DashboardSection = 
  | 'home' 
  | 'courses' 
  | 'community' 
  | 'resources' 
  | 'tokens' 
  | 'chat' 
  | 'settings';

export default function MainDashboard() {
  const { user, isLoading } = useAuth();
  const [activeSection, setActiveSection] = useState<DashboardSection>('home');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 border-4 border-[var(--blue)] border-t-transparent rounded-full animate-spin"></div>
          <span className="text-white font-orbitron">Carregando Dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex overflow-hidden" data-testid="main-dashboard">
      {/* Sidebar */}
      <motion.div
        initial={false}
        animate={{
          width: sidebarCollapsed ? '80px' : '280px'
        }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="relative z-20"
      >
        <Sidebar
          user={user}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
      </motion.div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Header */}
        <DashboardHeader
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          user={user}
        />

        {/* Content */}
        <main className="flex-1 overflow-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <DashboardContent
                activeSection={activeSection}
                searchQuery={searchQuery}
                user={user}
              />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Overlay */}
      {!sidebarCollapsed && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-10 lg:hidden"
          onClick={() => setSidebarCollapsed(true)}
        />
      )}

      {/* Onboarding Tour Manager */}
      <OnboardingTourManager
        userId={user?.id || 'guest'}
        userRole="content-creator"
      />
    </div>
  );
}