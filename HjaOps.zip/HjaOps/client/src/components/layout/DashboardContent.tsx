import { motion } from 'framer-motion';
import type { DashboardSection } from './MainDashboard';
import HomeSection from '../dashboard/sections/HomeSection';
import CoursesSection from '../dashboard/sections/CoursesSection';
import CommunitySection from '../dashboard/sections/CommunitySection';
import ResourcesSection from '../dashboard/sections/ResourcesSection';
import TokensSection from '../dashboard/sections/TokensSection';
import ChatSection from '../dashboard/sections/ChatSection';
import SettingsSection from '../dashboard/sections/SettingsSection';

interface DashboardContentProps {
  activeSection: DashboardSection;
  searchQuery: string;
  user: any;
}

export default function DashboardContent({ 
  activeSection, 
  searchQuery, 
  user 
}: DashboardContentProps) {
  
  const renderSection = () => {
    const commonProps = { searchQuery, user };
    
    switch (activeSection) {
      case 'home':
        return <HomeSection {...commonProps} />;
      case 'courses':
        return <CoursesSection {...commonProps} />;
      case 'community':
        return <CommunitySection {...commonProps} />;
      case 'resources':
        return <ResourcesSection {...commonProps} />;
      case 'tokens':
        return <TokensSection {...commonProps} />;
      case 'chat':
        return <ChatSection {...commonProps} />;
      case 'settings':
        return <SettingsSection {...commonProps} />;
      default:
        return <HomeSection {...commonProps} />;
    }
  };

  return (
    <div className="min-h-full">
      {renderSection()}
    </div>
  );
}