import { motion } from 'framer-motion';
import { 
  Home,
  BookOpen,
  Users,
  Folder,
  Zap,
  MessageSquare,
  Settings,
  ChevronLeft,
  ChevronRight,
  Crown,
  Star,
  Coins
} from 'lucide-react';
import type { DashboardSection } from './MainDashboard';

interface SidebarProps {
  user: any;
  activeSection: DashboardSection;
  onSectionChange: (section: DashboardSection) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

interface MenuItem {
  id: DashboardSection;
  name: string;
  icon: React.ElementType;
  badge?: string;
  disabled?: boolean;
}

export default function Sidebar({ 
  user, 
  activeSection, 
  onSectionChange, 
  collapsed, 
  onToggleCollapse 
}: SidebarProps) {
  
  const menuItems: MenuItem[] = [
    { id: 'home', name: 'Home', icon: Home },
    { id: 'courses', name: 'Cursos', icon: BookOpen, badge: 'Em Breve' },
    { id: 'community', name: 'Comunidade', icon: Users, badge: 'Beta' },
    { id: 'resources', name: 'Recursos', icon: Folder },
    { id: 'tokens', name: 'Tokens', icon: Zap },
    { id: 'chat', name: 'Chat', icon: MessageSquare },
    { id: 'settings', name: 'Configurações', icon: Settings },
  ];

  const getUserPlanInfo = (plan: string) => {
    switch (plan) {
      case 'premium':
        return { icon: Crown, color: 'text-purple-400', bg: 'bg-purple-500/20' };
      case 'pro':
        return { icon: Star, color: 'text-[var(--orange)]', bg: 'bg-[var(--orange)]/20' };
      case 'basic':
        return { icon: Zap, color: 'text-blue-400', bg: 'bg-blue-500/20' };
      default:
        return { icon: Coins, color: 'text-gray-400', bg: 'bg-gray-500/20' };
    }
  };

  const planInfo = getUserPlanInfo(user?.plan || 'free');
  const userCredits = user?.credits || 0;
  const maxCredits = user?.maxCredits || 200;
  const creditsPercentage = (userCredits / maxCredits) * 100;

  return (
    <motion.aside
      className="h-screen glass-morphism border-r border-[var(--smoke)]/20 flex flex-col"
      initial={false}
    >
      {/* Header */}
      <div className="p-6 border-b border-[var(--smoke)]/20">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-3"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-lg flex items-center justify-center neon-glow">
                <span className="text-white font-orbitron font-bold text-sm">H²</span>
              </div>
              <div>
                <h1 className="text-white font-orbitron font-bold text-lg">
                  Haja²Verso
                </h1>
                <p className="text-[var(--smoke)]/60 text-xs">AI Creative Suite</p>
              </div>
            </motion.div>
          )}
          
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onToggleCollapse}
            className="p-2 rounded-lg glass-morphism text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
            data-testid="sidebar-toggle"
          >
            {collapsed ? 
              <ChevronRight className="w-4 h-4" /> : 
              <ChevronLeft className="w-4 h-4" />
            }
          </motion.button>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-6 border-b border-[var(--smoke)]/20">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-lg">
              {user?.firstName?.[0] || 'U'}
            </span>
          </div>
          
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex-1 min-w-0"
            >
              <h3 className="text-white font-medium truncate">
                {user?.firstName || 'Usuário'} {user?.lastName || ''}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <div className={`p-1 rounded ${planInfo.bg}`}>
                  <planInfo.icon className={`w-3 h-3 ${planInfo.color}`} />
                </div>
                <span className={`text-xs font-medium ${planInfo.color}`}>
                  {(user?.plan || 'free').toUpperCase()}
                </span>
              </div>
            </motion.div>
          )}
        </div>

        {/* Credits Status */}
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-3 glass-morphism rounded-xl"
            data-testid="credits-badge"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-[var(--smoke)]/70">Créditos</span>
              <span className="text-sm font-medium text-white">
                {userCredits}/{maxCredits}
              </span>
            </div>
            
            <div className="w-full bg-[var(--smoke)]/10 rounded-full h-2 mb-2">
              <motion.div
                className="h-2 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full neon-glow"
                initial={{ width: 0 }}
                animate={{ width: `${creditsPercentage}%` }}
                transition={{ duration: 1, delay: 0.5 }}
              />
            </div>
            
            <p className="text-xs text-[var(--smoke)]/60">
              {creditsPercentage < 20 ? 'Créditos baixos!' : 
               creditsPercentage < 50 ? 'Nível moderado' : 
               'Nível adequado'}
            </p>
          </motion.div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <motion.button
                key={item.id}
                onClick={() => !item.disabled && onSectionChange(item.id)}
                disabled={item.disabled}
                className={`
                  relative w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all duration-300
                  ${isActive 
                    ? 'text-white shadow-lg' 
                    : item.disabled 
                      ? 'text-[var(--smoke)]/40 cursor-not-allowed'
                      : 'text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5'
                  }
                `}
                whileHover={!item.disabled ? { scale: 1.02 } : {}}
                whileTap={!item.disabled ? { scale: 0.98 } : {}}
                data-testid={`nav-${item.id}`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNavItem"
                    className="absolute inset-0 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-xl neon-glow"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                
                <div className="relative flex items-center gap-3 flex-1">
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  
                  {!collapsed && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex items-center justify-between w-full"
                    >
                      <span className="font-orbitron">{item.name}</span>
                      {item.badge && (
                        <span className="px-2 py-1 bg-[var(--orange)]/20 text-[var(--orange)] text-xs rounded-full">
                          {item.badge}
                        </span>
                      )}
                    </motion.div>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-[var(--smoke)]/20">
        {!collapsed && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center"
          >
            <p className="text-xs text-[var(--smoke)]/50">
              ⚡ Powered by <span className="font-orbitron text-gradient">HVC Core</span>
            </p>
          </motion.div>
        )}
      </div>
    </motion.aside>
  );
}