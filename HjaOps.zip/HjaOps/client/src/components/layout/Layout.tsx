import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import Navbar from './Navbar';

interface LayoutProps {
  children: ReactNode;
  showNavbar?: boolean;
  className?: string;
}

export default function Layout({ children, showNavbar = true, className = '' }: LayoutProps) {
  return (
    <div className={`min-h-screen bg-hv-black ${className}`}>
      {showNavbar && <Navbar />}
      
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className={showNavbar ? 'pt-16' : ''}
      >
        {children}
      </motion.main>
    </div>
  );
}