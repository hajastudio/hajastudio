import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search,
  Bell,
  User,
  Settings,
  LogOut,
  ChevronDown,
  Zap,
  CreditCard,
  Menu
} from 'lucide-react';

interface DashboardHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  user: any;
}

export default function DashboardHeader({ 
  searchQuery, 
  onSearchChange, 
  user 
}: DashboardHeaderProps) {
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    {
      id: '1',
      type: 'credit_low',
      title: 'Créditos Baixos',
      message: 'Você tem apenas 15 créditos restantes',
      time: '5 min atrás',
      read: false
    },
    {
      id: '2',
      type: 'new_feature',
      title: 'Nova Funcionalidade',
      message: 'Chat Multi-Agente agora disponível!',
      time: '1h atrás',
      read: true
    }
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="h-16 glass-morphism border-b border-[var(--smoke)]/20 flex items-center justify-between px-6 relative z-10">
      {/* Search Bar */}
      <div className="flex-1 max-w-2xl">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[var(--smoke)]/50" />
          <input
            type="text"
            placeholder="Buscar cursos, agentes ou recursos..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="
              w-full pl-12 pr-4 py-3 
              glass-morphism rounded-xl 
              text-[var(--smoke)] placeholder-[var(--smoke)]/50 
              focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50
              transition-all duration-300
            "
            data-testid="global-search"
          />
        </div>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-4 ml-6">
        {/* Credits Quick View */}
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="hidden md:flex items-center gap-2 px-4 py-2 glass-morphism rounded-xl cursor-pointer"
          data-testid="credits-quick-view"
        >
          <Zap className="w-4 h-4 text-[var(--orange)]" />
          <span className="text-sm font-medium text-white">
            {user?.credits || 0}
          </span>
        </motion.div>

        {/* Notifications */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
            data-testid="notifications-toggle"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-[var(--orange)] text-white text-xs rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </motion.button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute right-0 top-full mt-2 w-80 glass-morphism rounded-xl border border-[var(--smoke)]/20 overflow-hidden z-50"
            >
              <div className="p-4 border-b border-[var(--smoke)]/20">
                <h3 className="font-orbitron font-semibold text-white">Notificações</h3>
              </div>
              
              <div className="max-h-96 overflow-y-auto">
                {notifications.length > 0 ? (
                  notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 border-b border-[var(--smoke)]/10 hover:bg-[var(--smoke)]/5 transition-colors ${
                        !notification.read ? 'bg-[var(--blue)]/5' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-2 ${
                          !notification.read ? 'bg-[var(--orange)]' : 'bg-[var(--smoke)]/30'
                        }`} />
                        <div className="flex-1">
                          <h4 className="text-sm font-medium text-white mb-1">
                            {notification.title}
                          </h4>
                          <p className="text-sm text-[var(--smoke)]/70 mb-2">
                            {notification.message}
                          </p>
                          <span className="text-xs text-[var(--smoke)]/50">
                            {notification.time}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center">
                    <Bell className="w-8 h-8 text-[var(--smoke)]/30 mx-auto mb-2" />
                    <p className="text-[var(--smoke)]/50">Nenhuma notificação</p>
                  </div>
                )}
              </div>
              
              {notifications.length > 0 && (
                <div className="p-4 border-t border-[var(--smoke)]/20">
                  <button className="w-full text-sm text-[var(--blue)] hover:text-white transition-colors">
                    Marcar todas como lidas
                  </button>
                </div>
              )}
            </motion.div>
          )}
        </div>

        {/* User Menu */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-3 p-2 glass-morphism rounded-xl hover:bg-[var(--smoke)]/5 transition-colors"
            data-testid="user-menu-toggle"
          >
            <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">
                {user?.firstName?.[0] || 'U'}
              </span>
            </div>
            <div className="hidden md:block text-left">
              <p className="text-sm font-medium text-white">
                {user?.firstName || 'Usuário'}
              </p>
              <p className="text-xs text-[var(--smoke)]/60">
                {(user?.plan || 'free').toUpperCase()}
              </p>
            </div>
            <ChevronDown className={`w-4 h-4 text-[var(--smoke)] transition-transform ${
              showUserMenu ? 'rotate-180' : ''
            }`} />
          </motion.button>

          {/* User Menu Dropdown */}
          {showUserMenu && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute right-0 top-full mt-2 w-64 glass-morphism rounded-xl border border-[var(--smoke)]/20 overflow-hidden z-50"
            >
              {/* User Info */}
              <div className="p-4 border-b border-[var(--smoke)]/20">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">
                      {user?.firstName?.[0] || 'U'}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-white">
                      {user?.firstName || 'Usuário'} {user?.lastName || ''}
                    </p>
                    <p className="text-sm text-[var(--smoke)]/70">{user?.email}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[var(--smoke)]/70">Plano:</span>
                  <span className="text-[var(--orange)] font-medium">
                    {(user?.plan || 'free').toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Menu Items */}
              <div className="py-2">
                <button className="w-full flex items-center gap-3 px-4 py-3 text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors">
                  <User className="w-4 h-4" />
                  <span>Meu Perfil</span>
                </button>
                
                <button className="w-full flex items-center gap-3 px-4 py-3 text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors">
                  <CreditCard className="w-4 h-4" />
                  <span>Gerenciar Plano</span>
                </button>
                
                <button className="w-full flex items-center gap-3 px-4 py-3 text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors">
                  <Settings className="w-4 h-4" />
                  <span>Configurações</span>
                </button>
                
                <div className="border-t border-[var(--smoke)]/20 mt-2 pt-2">
                  <button 
                    onClick={() => window.location.href = '/api/logout'}
                    className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sair</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Click outside to close dropdowns */}
      {(showUserMenu || showNotifications) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setShowUserMenu(false);
            setShowNotifications(false);
          }}
        />
      )}
    </header>
  );
}