import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";

export function Header() {
  const { user, isAuthenticated } = useAuth();
  
  const { data: userStats } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) {
    return null;
  }

  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-cube text-black text-lg"></i>
          </div>
          <h1 className="text-2xl font-bold gradient-text">Hja²Ops</h1>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" data-testid="link-dashboard">
            <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
              Dashboard
            </span>
          </Link>
          <Link href="/#chat" data-testid="link-chat">
            <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
              Chat
            </span>
          </Link>
          <Link href="/#agents" data-testid="link-agents">
            <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
              Agents
            </span>
          </Link>
          <Link href="/#billing" data-testid="link-billing">
            <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
              Billing
            </span>
          </Link>
          {userStats?.role === 'admin' && (
            <Link href="/#admin" data-testid="link-admin">
              <span className="text-red-400 hover:text-red-300 transition-colors cursor-pointer">
                Admin
              </span>
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-secondary px-3 py-1 rounded-full" data-testid="credits-display">
            <i className="fas fa-coins text-primary"></i>
            <span className="text-sm font-medium">{userStats?.credits?.toLocaleString() || '0'}</span>
            <span className="text-xs text-muted-foreground">credits</span>
          </div>
          
          <div className="flex items-center gap-2">
            <img 
              src={userStats?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"} 
              alt="User avatar" 
              className="w-8 h-8 rounded-full object-cover"
              data-testid="user-avatar"
            />
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => window.location.href = '/api/logout'}
              data-testid="button-logout"
            >
              Logout
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
