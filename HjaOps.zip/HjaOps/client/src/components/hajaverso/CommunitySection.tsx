import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Heart, 
  Star, 
  Send, 
  Hash, 
  Users, 
  Crown,
  Trophy,
  User,
  Plus,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface Post {
  id: string;
  author: {
    id: string;
    name: string;
    avatar: string;
    badge: 'guest' | 'pro' | 'vip' | 'svip';
    level: number;
  };
  title: string;
  content: string;
  tags: string[];
  likes: number;
  comments: number;
  isLiked: boolean;
  isStarred: boolean;
  createdAt: Date;
  category: string;
}

export default function CommunitySection() {
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [newPost, setNewPost] = useState({ title: '', content: '', tags: '' });

  const categories = [
    { id: 'todos', label: 'Todos', icon: Hash },
    { id: 'design', label: 'Design', icon: Hash },
    { id: 'video', label: 'Vídeo', icon: Hash },
    { id: 'ia', label: 'IA & Tech', icon: Hash },
    { id: 'criatividade', label: 'Criatividade', icon: Hash },
    { id: 'negocios', label: 'Negócios', icon: Hash }
  ];

  const [posts] = useState<Post[]>([
    {
      id: '1',
      author: {
        id: '1',
        name: 'Ana Designer',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=40&h=40&fit=crop&crop=face',
        badge: 'vip',
        level: 24
      },
      title: 'Como criar thumbnails que convertem 10x mais',
      content: 'Pessoal, depois de testar mais de 200 thumbnails diferentes, descobri 3 técnicas que aumentaram meu CTR de 2% para 20%. Vou compartilhar tudo aqui...',
      tags: ['design', 'thumbnails', 'youtube'],
      likes: 47,
      comments: 12,
      isLiked: false,
      isStarred: true,
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      category: 'design'
    },
    {
      id: '2',
      author: {
        id: '2',
        name: 'Carlos Creator',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        badge: 'pro',
        level: 18
      },
      title: 'IA para edição: Testei 5 ferramentas, vou contar qual vale a pena',
      content: 'Galera, gastei mais de R$ 500 testando as principais ferramentas de IA para edição. Vou compartilhar minha análise completa e honest...',
      tags: ['ia', 'edicao', 'ferramentas'],
      likes: 23,
      comments: 8,
      isLiked: true,
      isStarred: false,
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      category: 'ia'
    },
    {
      id: '3',
      author: {
        id: '3',
        name: 'Maria Viral',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face',
        badge: 'svip',
        level: 31
      },
      title: '1M de views em 24h: A estratégia que mudou tudo',
      content: 'Consegui quebrar todos os recordes do meu canal usando uma estratégia que ninguém está falando. Vou explicar passo a passo como repliquei isso 3 vezes...',
      tags: ['viral', 'estrategia', 'growth'],
      likes: 156,
      comments: 34,
      isLiked: false,
      isStarred: true,
      createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      category: 'criatividade'
    }
  ]);

  const ranking = [
    { id: '1', name: 'Maria Viral', points: 2847, badge: 'svip', change: '+12' },
    { id: '2', name: 'João Expert', points: 2156, badge: 'vip', change: '+8' },
    { id: '3', name: 'Ana Designer', points: 1943, badge: 'vip', change: '+15' },
    { id: '4', name: 'Carlos Creator', points: 1672, badge: 'pro', change: '+5' },
    { id: '5', name: 'Pedro Tech', points: 1234, badge: 'pro', change: '+3' }
  ];

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case 'guest': return 'bg-gray-500';
      case 'pro': return 'admin-bg-blue';
      case 'vip': return 'bg-purple-600';
      case 'svip': return 'admin-bg-orange';
      default: return 'bg-gray-500';
    }
  };

  const getBadgeIcon = (badge: string) => {
    switch (badge) {
      case 'guest': return <User className="w-3 h-3" />;
      case 'pro': return <Star className="w-3 h-3" />;
      case 'vip': return <Crown className="w-3 h-3" />;
      case 'svip': return <Trophy className="w-3 h-3" />;
      default: return <User className="w-3 h-3" />;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const hours = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'agora';
    if (hours < 24) return `${hours}h atrás`;
    const days = Math.floor(hours / 24);
    return `${days}d atrás`;
  };

  const filteredPosts = selectedCategory === 'todos' 
    ? posts 
    : posts.filter(post => post.category === selectedCategory);

  const handleCreatePost = () => {
    if (!newPost.title.trim() || !newPost.content.trim()) return;
    
    console.log('Creating post:', newPost);
    setNewPost({ title: '', content: '', tags: '' });
    setShowCreatePost(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Comunidade Haja®Verso
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Conecte-se com outros criadores, compartilhe conhecimento e cresça junto
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Main Feed */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Categories & Create Post */}
          <div className="admin-card p-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between mb-6">
              
              {/* Categories */}
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className={selectedCategory === category.id 
                      ? "admin-bg-blue hover:opacity-90" 
                      : "border-blue-500/20 admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
                    }
                    data-testid={`category-${category.id}`}
                  >
                    <category.icon className="w-3 h-3 mr-1" />
                    {category.label}
                  </Button>
                ))}
              </div>

              {/* Create Post Button */}
              <Button 
                onClick={() => setShowCreatePost(!showCreatePost)}
                className="admin-bg-orange hover:opacity-90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Publicação
              </Button>
            </div>

            {/* Create Post Form */}
            {showCreatePost && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="border-t border-blue-500/20 pt-6 space-y-4"
              >
                <Input
                  placeholder="Título da sua publicação"
                  value={newPost.title}
                  onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  className="bg-black/50 border-blue-500/20 admin-text-smoke"
                />
                
                <Textarea
                  placeholder="Compartilhe seu conhecimento com a comunidade..."
                  rows={4}
                  value={newPost.content}
                  onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                  className="bg-black/50 border-blue-500/20 admin-text-smoke resize-none"
                />
                
                <Input
                  placeholder="Tags (separadas por vírgula)"
                  value={newPost.tags}
                  onChange={(e) => setNewPost({ ...newPost, tags: e.target.value })}
                  className="bg-black/50 border-blue-500/20 admin-text-smoke"
                />
                
                <div className="flex items-center gap-3">
                  <Button 
                    onClick={handleCreatePost}
                    className="admin-bg-blue hover:opacity-90"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Publicar
                  </Button>
                  <Button 
                    variant="ghost" 
                    onClick={() => setShowCreatePost(false)}
                    className="admin-text-smoke hover:admin-text-blue"
                  >
                    Cancelar
                  </Button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Posts Feed */}
          <div className="space-y-6">
            {filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="admin-card p-6"
              >
                
                {/* Post Header */}
                <div className="flex items-start gap-4 mb-4">
                  <Avatar>
                    <AvatarImage src={post.author.avatar} alt={post.author.name} />
                    <AvatarFallback>{post.author.name[0]}</AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold admin-text-blue">{post.author.name}</h3>
                      <Badge className={`${getBadgeColor(post.author.badge)} text-white text-xs`}>
                        {getBadgeIcon(post.author.badge)}
                        <span className="ml-1 uppercase">{post.author.badge}</span>
                      </Badge>
                      <span className="text-xs admin-text-smoke">Nível {post.author.level}</span>
                    </div>
                    <p className="text-sm admin-text-smoke">{formatTimeAgo(post.createdAt)}</p>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => console.log('Star post:', post.id)}
                    className={post.isStarred ? 'admin-text-orange' : 'admin-text-smoke hover:admin-text-orange'}
                  >
                    <Star className={`w-4 h-4 ${post.isStarred ? 'fill-current' : ''}`} />
                  </Button>
                </div>

                {/* Post Content */}
                <div className="mb-4">
                  <h2 className="text-lg font-bold admin-text-blue mb-2">{post.title}</h2>
                  <p className="admin-text-smoke leading-relaxed">{post.content}</p>
                </div>

                {/* Post Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {post.tags.map((tag) => (
                    <Badge 
                      key={tag} 
                      variant="outline" 
                      className="border-blue-500/20 admin-text-blue text-xs"
                    >
                      #{tag}
                    </Badge>
                  ))}
                </div>

                {/* Post Actions */}
                <div className="flex items-center gap-6 pt-4 border-t border-blue-500/20">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => console.log('Like post:', post.id)}
                    className={`gap-2 ${post.isLiked ? 'text-red-400' : 'admin-text-smoke hover:text-red-400'}`}
                  >
                    <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-current' : ''}`} />
                    {post.likes}
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-2 admin-text-smoke hover:admin-text-blue"
                  >
                    <MessageSquare className="w-4 h-4" />
                    {post.comments}
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          
          {/* Ranking Gamificado */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 admin-text-orange" />
              Ranking da Semana
            </h3>
            
            <div className="space-y-3">
              {ranking.map((user, index) => (
                <div key={user.id} className="flex items-center gap-3 p-2 rounded-lg bg-black/30">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    index === 0 ? 'admin-bg-orange text-white' :
                    index === 1 ? 'bg-gray-400 text-white' :
                    index === 2 ? 'bg-yellow-600 text-white' :
                    'bg-gray-600 text-white'
                  }`}>
                    {index + 1}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium admin-text-blue text-sm">{user.name}</span>
                      <Badge className={`${getBadgeColor(user.badge)} text-white text-xs`}>
                        {user.badge.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs admin-text-smoke">{user.points} pts</span>
                      <span className="text-xs text-green-400">{user.change}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Community Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Estatísticas</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="admin-text-smoke text-sm">Membros Ativos</span>
                <span className="font-bold admin-text-blue">1.247</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="admin-text-smoke text-sm">Posts Hoje</span>
                <span className="font-bold admin-text-orange">23</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="admin-text-smoke text-sm">Comentários</span>
                <span className="font-bold text-green-400">156</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="admin-text-smoke text-sm">Sua Posição</span>
                <span className="font-bold admin-text-blue">#24</span>
              </div>
            </div>
          </motion.div>

          {/* Espaços Temáticos */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Espaços Temáticos</h3>
            
            <div className="space-y-2">
              {categories.slice(1).map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`w-full flex items-center gap-3 p-2 rounded-lg transition-colors ${
                    selectedCategory === category.id 
                      ? 'bg-blue-500/20 admin-text-blue' 
                      : 'hover:bg-blue-500/10 admin-text-smoke hover:admin-text-blue'
                  }`}
                >
                  <Hash className="w-4 h-4" />
                  <span className="text-sm">{category.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}