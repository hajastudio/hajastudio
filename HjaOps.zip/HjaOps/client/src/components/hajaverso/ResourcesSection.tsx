import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Download, 
  Search, 
  Filter, 
  Package, 
  Zap, 
  Lock, 
  Star,
  FileText,
  Image,
  Video,
  Headphones,
  Palette,
  Code,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'pack' | 'tool' | 'prompt' | 'template';
  category: 'design' | 'video' | 'audio' | 'ia' | 'marketing';
  thumbnail: string;
  downloads: number;
  rating: number;
  price: number;
  isPremium: boolean;
  isUnlocked: boolean;
  tokensRequired: number;
  fileSize?: string;
  format?: string;
  tags: string[];
}

export default function ResourcesSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [selectedType, setSelectedType] = useState('todos');

  const categories = [
    { id: 'todos', label: 'Todos', icon: Package },
    { id: 'design', label: 'Design', icon: Palette },
    { id: 'video', label: 'Vídeo', icon: Video },
    { id: 'audio', label: 'Áudio', icon: Headphones },
    { id: 'ia', label: 'IA & Prompts', icon: Zap },
    { id: 'marketing', label: 'Marketing', icon: Star }
  ];

  const types = [
    { id: 'todos', label: 'Todos os Tipos' },
    { id: 'pack', label: 'Packs de Edição' },
    { id: 'tool', label: 'Ferramentas' },
    { id: 'prompt', label: 'Prompts IA' },
    { id: 'template', label: 'Templates' }
  ];

  const [resources] = useState<Resource[]>([
    {
      id: '1',
      title: 'Pack Transições Cinematográficas',
      description: '50 transições profissionais para dar um acabamento de cinema aos seus vídeos.',
      type: 'pack',
      category: 'video',
      thumbnail: 'https://images.unsplash.com/photo-1489598843681-ba1966d2c0e0?w=300&h=200&fit=crop',
      downloads: 2847,
      rating: 4.9,
      price: 0,
      isPremium: false,
      isUnlocked: true,
      tokensRequired: 15,
      fileSize: '2.3 GB',
      format: 'MP4, MOV',
      tags: ['transições', 'cinema', 'premium']
    },
    {
      id: '2',
      title: 'Prompts Virais para YouTube',
      description: 'Coleção com 100+ prompts testados para criar títulos, descrições e thumbnails que convertem.',
      type: 'prompt',
      category: 'ia',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=300&h=200&fit=crop',
      downloads: 1256,
      rating: 4.7,
      price: 0,
      isPremium: false,
      isUnlocked: false,
      tokensRequired: 25,
      fileSize: '1.2 MB',
      format: 'TXT, JSON',
      tags: ['youtube', 'viral', 'ia', 'prompts']
    },
    {
      id: '3',
      title: 'Templates Instagram Premium',
      description: 'Pack com 30 templates editáveis para Stories e Posts que garantem mais engajamento.',
      type: 'template',
      category: 'design',
      thumbnail: 'https://images.unsplash.com/photo-1611926653458-09294b3142bf?w=300&h=200&fit=crop',
      downloads: 3421,
      rating: 4.8,
      price: 97,
      isPremium: true,
      isUnlocked: false,
      tokensRequired: 50,
      fileSize: '850 MB',
      format: 'PSD, AI, FIGMA',
      tags: ['instagram', 'templates', 'design']
    },
    {
      id: '4',
      title: 'SFX Pack - Sons de Impacto',
      description: 'Biblioteca com 200+ efeitos sonoros para criar mais impacto nos seus vídeos.',
      type: 'pack',
      category: 'audio',
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=200&fit=crop',
      downloads: 892,
      rating: 4.6,
      price: 0,
      isPremium: false,
      isUnlocked: true,
      tokensRequired: 20,
      fileSize: '1.8 GB',
      format: 'WAV, MP3',
      tags: ['audio', 'sfx', 'impacto']
    },
    {
      id: '5',
      title: 'IA Video Generator Pro',
      description: 'Ferramenta avançada para gerar vídeos com IA usando apenas texto como entrada.',
      type: 'tool',
      category: 'ia',
      thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=300&h=200&fit=crop',
      downloads: 567,
      rating: 4.5,
      price: 197,
      isPremium: true,
      isUnlocked: false,
      tokensRequired: 100,
      tags: ['ia', 'video', 'automacao']
    },
    {
      id: '6',
      title: 'Prompts para Thumbnails Virais',
      description: 'Prompts específicos para criar thumbnails que aumentam CTR em até 300%.',
      type: 'prompt',
      category: 'ia',
      thumbnail: 'https://images.unsplash.com/photo-1541462608143-67571c6738dd?w=300&h=200&fit=crop',
      downloads: 1847,
      rating: 4.9,
      price: 0,
      isPremium: false,
      isUnlocked: false,
      tokensRequired: 30,
      fileSize: '500 KB',
      format: 'TXT',
      tags: ['thumbnails', 'ctr', 'viral']
    }
  ]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'pack': return <Package className="w-4 h-4" />;
      case 'tool': return <Code className="w-4 h-4" />;
      case 'prompt': return <Zap className="w-4 h-4" />;
      case 'template': return <FileText className="w-4 h-4" />;
      default: return <Package className="w-4 h-4" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'design': return <Palette className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      case 'audio': return <Headphones className="w-4 h-4" />;
      case 'ia': return <Zap className="w-4 h-4" />;
      case 'marketing': return <Star className="w-4 h-4" />;
      default: return <Package className="w-4 h-4" />;
    }
  };

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'todos' || resource.category === selectedCategory;
    const matchesType = selectedType === 'todos' || resource.type === selectedType;
    return matchesSearch && matchesCategory && matchesType;
  });

  const handleUnlockResource = (resource: Resource) => {
    console.log('Unlocking resource:', resource.id, 'Cost:', resource.tokensRequired, 'tokens');
  };

  const handleDownloadResource = (resource: Resource) => {
    console.log('Downloading resource:', resource.id);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Recursos & Ferramentas
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Packs, templates, prompts e ferramentas para turbinar sua criação de conteúdo
        </p>
      </div>

      {/* Filters */}
      <div className="admin-card p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar recursos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.label}
              </option>
            ))}
          </select>

          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            {types.map((type) => (
              <option key={type.id} value={type.id}>
                {type.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* My Resources Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center mx-auto mb-3">
            <Download className="w-6 h-6 text-white" />
          </div>
          <p className="text-2xl font-bold admin-text-blue mb-1">24</p>
          <p className="admin-text-smoke text-sm">Recursos Baixados</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center mx-auto mb-3">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <p className="text-2xl font-bold admin-text-orange mb-1">340</p>
          <p className="admin-text-smoke text-sm">Tokens Gastos</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Star className="w-6 h-6 text-white" />
          </div>
          <p className="text-2xl font-bold text-green-400 mb-1">8</p>
          <p className="admin-text-smoke text-sm">Recursos Premium</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Package className="w-6 h-6 text-white" />
          </div>
          <p className="text-2xl font-bold text-purple-400 mb-1">156</p>
          <p className="admin-text-smoke text-sm">Total Disponível</p>
        </motion.div>
      </div>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource, index) => (
          <motion.div
            key={resource.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card overflow-hidden hover:scale-105 transition-all duration-300"
            data-testid={`resource-card-${resource.id}`}
          >
            
            {/* Resource Thumbnail */}
            <div className="relative">
              <img 
                src={resource.thumbnail} 
                alt={resource.title}
                className="w-full h-48 object-cover"
              />
              
              {/* Premium Badge */}
              {resource.isPremium && (
                <Badge className="absolute top-3 right-3 admin-bg-orange text-white">
                  <Star className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
              
              {/* Unlocked Indicator */}
              {resource.isUnlocked && (
                <div className="absolute top-3 left-3">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-white" />
                  </div>
                </div>
              )}
            </div>

            {/* Resource Info */}
            <div className="p-6">
              
              {/* Title & Type */}
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-bold admin-text-blue mb-2 line-clamp-2 flex-1">
                  {resource.title}
                </h3>
                <div className="flex items-center gap-1 ml-2">
                  {getTypeIcon(resource.type)}
                  {getCategoryIcon(resource.category)}
                </div>
              </div>

              {/* Description */}
              <p className="admin-text-smoke text-sm mb-4 line-clamp-3">
                {resource.description}
              </p>

              {/* Resource Meta */}
              <div className="space-y-2 mb-4">
                {resource.fileSize && (
                  <div className="flex items-center justify-between text-xs admin-text-smoke">
                    <span>Tamanho:</span>
                    <span>{resource.fileSize}</span>
                  </div>
                )}
                
                {resource.format && (
                  <div className="flex items-center justify-between text-xs admin-text-smoke">
                    <span>Formato:</span>
                    <span>{resource.format}</span>
                  </div>
                )}
                
                <div className="flex items-center justify-between text-xs admin-text-smoke">
                  <span>Downloads:</span>
                  <span>{resource.downloads.toLocaleString()}</span>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mb-4">
                {resource.tags.slice(0, 3).map((tag) => (
                  <Badge 
                    key={tag} 
                    variant="outline" 
                    className="border-blue-500/20 admin-text-blue text-xs"
                  >
                    #{tag}
                  </Badge>
                ))}
              </div>

              {/* Rating & Tokens */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-medium admin-text-blue">
                    {resource.rating}
                  </span>
                </div>
                
                <div className="flex items-center gap-1">
                  <Zap className="w-4 h-4 admin-text-orange" />
                  <span className="text-sm font-bold admin-text-orange">
                    {resource.tokensRequired} tokens
                  </span>
                </div>
              </div>

              {/* Action Button */}
              {resource.isUnlocked ? (
                <Button 
                  className="w-full admin-bg-blue hover:opacity-90"
                  onClick={() => handleDownloadResource(resource)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Agora
                </Button>
              ) : resource.isPremium ? (
                <Button 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  onClick={() => console.log('Upgrade to premium')}
                >
                  <Lock className="w-4 h-4 mr-2" />
                  Upgrade Premium
                </Button>
              ) : (
                <Button 
                  className="w-full admin-bg-orange hover:opacity-90"
                  onClick={() => handleUnlockResource(resource)}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Desbloquear ({resource.tokensRequired} tokens)
                </Button>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredResources.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-16 h-16 admin-text-smoke mx-auto mb-4" />
          <h3 className="text-xl font-bold admin-text-blue mb-2">
            Nenhum recurso encontrado
          </h3>
          <p className="admin-text-smoke">
            Tente ajustar os filtros de busca
          </p>
        </div>
      )}
    </motion.div>
  );
}