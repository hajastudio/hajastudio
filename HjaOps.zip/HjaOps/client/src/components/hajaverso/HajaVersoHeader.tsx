import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  GraduationCap, 
  Users, 
  Package, 
  Zap, 
  Home,
  Star,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Link } from 'wouter';

interface HajaVersoHeaderProps {
  activeTab: string;
  onTabChange: (tab: 'cursos' | 'comunidade' | 'recursos' | 'tokens') => void;
  userProgress: number;
}

export default function HajaVersoHeader({ activeTab, onTabChange, userProgress }: HajaVersoHeaderProps) {
  const tabs = [
    { id: 'cursos', label: 'Cursos', icon: GraduationCap },
    { id: 'comunidade', label: 'Comunidade', icon: Users },
    { id: 'recursos', label: 'Recursos', icon: Package },
    { id: 'tokens', label: 'Tokens', icon: Zap }
  ];

  const progressPercentage = Math.min((userProgress / 1000) * 100, 100);

  return (
    <header className="admin-sidebar border-b border-blue-500/20 sticky top-0 z-50">
      
      {/* Top Bar */}
      <div className="flex items-center justify-between px-6 py-4">
        
        {/* Left Section - Logo & Title */}
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="admin-text-smoke hover:admin-text-blue">
              <Home className="w-4 h-4" />
            </Button>
          </Link>
          
          <div className="flex items-center gap-3">
            <div className="admin-glow-blue w-12 h-12 rounded-xl flex items-center justify-center admin-pulse">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold admin-text-blue">Haja®Verso</h1>
              <p className="text-sm admin-text-smoke">Comunidade & Cursos</p>
            </div>
          </div>
        </div>

        {/* Center Section - User Progress */}
        <div className="hidden md:flex items-center gap-4 flex-1 max-w-md mx-8">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium admin-text-smoke">Progresso</span>
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 admin-text-orange" />
                <span className="text-sm font-bold admin-text-blue">
                  {userProgress} / 1000 tokens
                </span>
              </div>
            </div>
            <Progress 
              value={progressPercentage} 
              className="h-2 bg-gray-800"
            />
          </div>
        </div>

        {/* Right Section - Stats */}
        <div className="flex items-center gap-6">
          <div className="hidden lg:flex items-center gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-1">
                <TrendingUp className="w-4 h-4 admin-text-blue" />
              </div>
              <p className="text-xs admin-text-smoke">Ranking</p>
              <p className="font-bold admin-text-blue text-sm">#24</p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-1">
                <Users className="w-4 h-4 admin-text-orange" />
              </div>
              <p className="text-xs admin-text-smoke">Comunidade</p>
              <p className="font-bold admin-text-orange text-sm">1.2k</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-6">
        <nav className="flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as any)}
              className={`flex items-center gap-2 pb-4 border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-blue-500 admin-text-blue'
                  : 'border-transparent admin-text-smoke hover:admin-text-blue'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="font-medium">{tab.label}</span>
              
              {/* Badge para algumas abas */}
              {tab.id === 'comunidade' && (
                <span className="admin-bg-orange text-white text-xs px-2 py-0.5 rounded-full">
                  3
                </span>
              )}
              {tab.id === 'recursos' && (
                <span className="admin-bg-blue text-white text-xs px-2 py-0.5 rounded-full">
                  12
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
}