import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  Trophy, 
  Star, 
  Gift, 
  Calendar,
  CheckCircle,
  Play,
  Book,
  MessageSquare,
  Download,
  Target,
  TrendingUp,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  tokens: number;
  isCompleted: boolean;
  progress: number;
  maxProgress: number;
  category: 'cursos' | 'comunidade' | 'recursos' | 'especial';
}

interface TokenHistory {
  id: string;
  action: string;
  tokens: number;
  type: 'earned' | 'spent';
  timestamp: Date;
  description: string;
}

export default function TokensSection() {
  const [userTokens] = useState(1247);
  const [totalEarned] = useState(2891);
  const [currentStreak] = useState(7);

  const [achievements] = useState<Achievement[]>([
    {
      id: '1',
      title: 'Primeira Aula',
      description: 'Assista sua primeira aula completa',
      icon: Play,
      tokens: 10,
      isCompleted: true,
      progress: 1,
      maxProgress: 1,
      category: 'cursos'
    },
    {
      id: '2',
      title: 'Maratonista',
      description: 'Complete 10 aulas em sequência',
      icon: Trophy,
      tokens: 50,
      isCompleted: false,
      progress: 7,
      maxProgress: 10,
      category: 'cursos'
    },
    {
      id: '3',
      title: 'Especialista',
      description: 'Finalize um curso completo',
      icon: Book,
      tokens: 100,
      isCompleted: false,
      progress: 18,
      maxProgress: 24,
      category: 'cursos'
    },
    {
      id: '4',
      title: 'Ativo na Comunidade',
      description: 'Faça 5 publicações na comunidade',
      icon: MessageSquare,
      tokens: 25,
      isCompleted: false,
      progress: 2,
      maxProgress: 5,
      category: 'comunidade'
    },
    {
      id: '5',
      title: 'Influenciador',
      description: 'Receba 100 curtidas nas suas publicações',
      icon: Star,
      tokens: 75,
      isCompleted: false,
      progress: 47,
      maxProgress: 100,
      category: 'comunidade'
    },
    {
      id: '6',
      title: 'Colecionador',
      description: 'Baixe 10 recursos diferentes',
      icon: Download,
      tokens: 30,
      isCompleted: true,
      progress: 12,
      maxProgress: 10,
      category: 'recursos'
    },
    {
      id: '7',
      title: 'Sequência de 30 Dias',
      description: 'Acesse a plataforma por 30 dias consecutivos',
      icon: Calendar,
      tokens: 200,
      isCompleted: false,
      progress: 7,
      maxProgress: 30,
      category: 'especial'
    },
    {
      id: '8',
      title: 'Mentor',
      description: 'Ajude 20 membros com respostas úteis',
      icon: Award,
      tokens: 150,
      isCompleted: false,
      progress: 3,
      maxProgress: 20,
      category: 'comunidade'
    }
  ]);

  const [tokenHistory] = useState<TokenHistory[]>([
    {
      id: '1',
      action: 'Aula Concluída',
      tokens: 10,
      type: 'earned',
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
      description: 'Criação de Vídeos Virais - Aula 3'
    },
    {
      id: '2',
      action: 'Recurso Desbloqueado',
      tokens: -25,
      type: 'spent',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      description: 'Pack Transições Cinematográficas'
    },
    {
      id: '3',
      action: 'Publicação Popular',
      tokens: 15,
      type: 'earned',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      description: 'Sua publicação recebeu 10+ curtidas'
    },
    {
      id: '4',
      action: 'Daily Streak',
      tokens: 5,
      type: 'earned',
      timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      description: 'Sequência de 7 dias consecutivos'
    },
    {
      id: '5',
      action: 'Curso Finalizado',
      tokens: 100,
      type: 'earned',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      description: 'Design System para Criadores'
    }
  ]);

  const dailyTasks = [
    { id: '1', task: 'Assistir 1 aula', tokens: 10, completed: true },
    { id: '2', task: 'Fazer 1 comentário', tokens: 5, completed: true },
    { id: '3', task: 'Curtir 3 publicações', tokens: 3, completed: false },
    { id: '4', task: 'Baixar 1 recurso', tokens: 5, completed: false }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'cursos': return 'admin-bg-blue';
      case 'comunidade': return 'bg-purple-600';
      case 'recursos': return 'admin-bg-orange';
      case 'especial': return 'bg-gradient-to-r from-yellow-500 to-orange-500';
      default: return 'bg-gray-600';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const hours = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'agora';
    if (hours < 24) return `${hours}h atrás`;
    const days = Math.floor(hours / 24);
    return `${days}d atrás`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Sistema de Tokens & Gamificação
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Ganhe tokens participando ativamente e desbloqueie recursos exclusivos
        </p>
      </div>

      {/* Token Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-16 h-16 admin-bg-blue rounded-full flex items-center justify-center mx-auto mb-4 admin-pulse">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <p className="text-3xl font-bold admin-text-blue mb-2">{userTokens.toLocaleString()}</p>
          <p className="admin-text-smoke">Tokens Disponíveis</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-16 h-16 admin-bg-orange rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <p className="text-3xl font-bold admin-text-orange mb-2">{totalEarned.toLocaleString()}</p>
          <p className="admin-text-smoke">Total Ganho</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <p className="text-3xl font-bold text-green-400 mb-2">{currentStreak}</p>
          <p className="admin-text-smoke">Dias Consecutivos</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-card p-6 text-center"
        >
          <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Target className="w-8 h-8 text-white" />
          </div>
          <p className="text-3xl font-bold text-purple-400 mb-2">12</p>
          <p className="admin-text-smoke">Conquistas</p>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Daily Tasks */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold admin-text-blue flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Tarefas Diárias
              </h2>
              <Badge className="admin-bg-blue text-white">
                2/4 Completas
              </Badge>
            </div>
            
            <div className="space-y-4">
              {dailyTasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between p-4 rounded-lg bg-black/30">
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      task.completed ? 'bg-green-500' : 'border-2 border-gray-500'
                    }`}>
                      {task.completed && <CheckCircle className="w-4 h-4 text-white" />}
                    </div>
                    <span className={`${task.completed ? 'admin-text-blue' : 'admin-text-smoke'}`}>
                      {task.task}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 admin-text-orange" />
                    <span className="font-bold admin-text-orange">+{task.tokens}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-green-500/10 rounded-lg border border-green-500/20">
              <div className="flex items-center gap-2 mb-2">
                <Gift className="w-5 h-5 text-green-400" />
                <span className="font-semibold text-green-400">Bônus de Conclusão</span>
              </div>
              <p className="text-sm admin-text-smoke">Complete todas as tarefas diárias e ganhe +10 tokens extras!</p>
            </div>
          </motion.div>

          {/* Achievements */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6 flex items-center gap-2">
              <Trophy className="w-5 h-5" />
              Conquistas & Medalhas
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {achievements.map((achievement) => (
                <div 
                  key={achievement.id} 
                  className={`p-4 rounded-lg border transition-all ${
                    achievement.isCompleted 
                      ? 'bg-green-500/10 border-green-500/30' 
                      : 'bg-black/30 border-blue-500/20 hover:border-blue-500/40'
                  }`}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      achievement.isCompleted ? 'bg-green-500' : getCategoryColor(achievement.category)
                    }`}>
                      <achievement.icon className="w-5 h-5 text-white" />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className={`font-semibold mb-1 ${
                        achievement.isCompleted ? 'text-green-400' : 'admin-text-blue'
                      }`}>
                        {achievement.title}
                      </h3>
                      <p className="text-sm admin-text-smoke mb-2">
                        {achievement.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Zap className="w-4 h-4 admin-text-orange" />
                          <span className="text-sm font-bold admin-text-orange">
                            {achievement.tokens} tokens
                          </span>
                        </div>
                        
                        {achievement.isCompleted ? (
                          <Badge className="bg-green-500 text-white">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Completa
                          </Badge>
                        ) : (
                          <span className="text-xs admin-text-smoke">
                            {achievement.progress}/{achievement.maxProgress}
                          </span>
                        )}
                      </div>
                      
                      {!achievement.isCompleted && (
                        <div className="mt-2">
                          <Progress 
                            value={(achievement.progress / achievement.maxProgress) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          
          {/* Token History */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Histórico Recente
            </h3>
            
            <div className="space-y-3">
              {tokenHistory.map((item) => (
                <div key={item.id} className="flex items-start gap-3 p-3 rounded-lg bg-black/30">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    item.type === 'earned' ? 'bg-green-500' : 'bg-red-500'
                  }`}>
                    <Zap className="w-4 h-4 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium admin-text-blue text-sm">{item.action}</p>
                      <span className={`text-sm font-bold ${
                        item.type === 'earned' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {item.type === 'earned' ? '+' : ''}{item.tokens}
                      </span>
                    </div>
                    <p className="text-xs admin-text-smoke mb-1">{item.description}</p>
                    <p className="text-xs admin-text-smoke opacity-70">
                      {formatTimeAgo(item.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <Button 
              variant="ghost" 
              className="w-full mt-4 admin-text-smoke hover:admin-text-blue"
            >
              Ver Histórico Completo
            </Button>
          </motion.div>

          {/* Token Store Preview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Loja de Tokens</h3>
            
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium admin-text-blue text-sm">Pack Premium</span>
                  <div className="flex items-center gap-1">
                    <Zap className="w-3 h-3 admin-text-orange" />
                    <span className="text-sm font-bold admin-text-orange">50</span>
                  </div>
                </div>
                <p className="text-xs admin-text-smoke">Transições cinematográficas</p>
              </div>
              
              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium admin-text-blue text-sm">Prompts Virais</span>
                  <div className="flex items-center gap-1">
                    <Zap className="w-3 h-3 admin-text-orange" />
                    <span className="text-sm font-bold admin-text-orange">25</span>
                  </div>
                </div>
                <p className="text-xs admin-text-smoke">100+ prompts testados</p>
              </div>
              
              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium admin-text-blue text-sm">Curso Exclusivo</span>
                  <div className="flex items-center gap-1">
                    <Zap className="w-3 h-3 admin-text-orange" />
                    <span className="text-sm font-bold admin-text-orange">100</span>
                  </div>
                </div>
                <p className="text-xs admin-text-smoke">Acesso antecipado</p>
              </div>
            </div>
            
            <Button className="w-full mt-4 admin-bg-orange hover:opacity-90">
              Ver Loja Completa
            </Button>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}