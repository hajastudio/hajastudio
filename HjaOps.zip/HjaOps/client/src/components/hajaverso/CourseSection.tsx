import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Clock, 
  Users, 
  Star, 
  Lock,
  CheckCircle,
  BookOpen,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface Course {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  instructor: string;
  duration: string;
  lessons: number;
  students: number;
  rating: number;
  level: 'iniciante' | 'intermediario' | 'avancado';
  price: number;
  tags: string[];
  progress?: number;
  isEnrolled: boolean;
  isPremium: boolean;
}

export default function CourseSection() {
  const [selectedCategory, setSelectedCategory] = useState('todos');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  const categories = [
    { id: 'todos', label: 'Todos os Cursos' },
    { id: 'video', label: 'Criação de Vídeo' },
    { id: 'design', label: 'Design' },
    { id: 'marketing', label: 'Marketing Digital' },
    { id: 'ia', label: 'Inteligência Artificial' },
    { id: 'business', label: 'Negócios' }
  ];

  const [courses] = useState<Course[]>([
    {
      id: '1',
      title: 'Criação de Vídeos Virais com IA',
      description: 'Aprenda a criar conteúdo viral usando ferramentas de IA e técnicas avançadas de storytelling.',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=225&fit=crop',
      instructor: 'Carlos Mentor',
      duration: '4h 30m',
      lessons: 24,
      students: 1247,
      rating: 4.8,
      level: 'intermediario',
      price: 197,
      tags: ['Vídeo', 'IA', 'Marketing'],
      progress: 65,
      isEnrolled: true,
      isPremium: false
    },
    {
      id: '2',
      title: 'Design System para Criadores',
      description: 'Desenvolva uma identidade visual consistente para todas as suas criações.',
      thumbnail: 'https://images.unsplash.com/photo-1541462608143-67571c6738dd?w=400&h=225&fit=crop',
      instructor: 'Ana Designer',
      duration: '3h 15m',
      lessons: 18,
      students: 892,
      rating: 4.9,
      level: 'iniciante',
      price: 97,
      tags: ['Design', 'Branding'],
      progress: 0,
      isEnrolled: false,
      isPremium: false
    },
    {
      id: '3',
      title: 'IA Generativa para Negócios',
      description: 'Como usar ferramentas de IA para automatizar e escalar seu negócio digital.',
      thumbnail: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=225&fit=crop',
      instructor: 'Pedro Tech',
      duration: '6h 45m',
      lessons: 32,
      students: 2156,
      rating: 4.7,
      level: 'avancado',
      price: 397,
      tags: ['IA', 'Negócios', 'Automação'],
      progress: 0,
      isEnrolled: false,
      isPremium: true
    },
    {
      id: '4',
      title: 'Marketing de Influência 3.0',
      description: 'Estratégias modernas para se tornar uma autoridade digital em sua área.',
      thumbnail: 'https://images.unsplash.com/photo-1611926653458-09294b3142bf?w=400&h=225&fit=crop',
      instructor: 'Maria Influencer',
      duration: '5h 20m',
      lessons: 28,
      students: 3421,
      rating: 4.6,
      level: 'intermediario',
      price: 247,
      tags: ['Marketing', 'Influência', 'Redes Sociais'],
      progress: 30,
      isEnrolled: true,
      isPremium: false
    }
  ]);

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'iniciante': return 'bg-green-500';
      case 'intermediario': return 'admin-bg-orange';
      case 'avancado': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const filteredCourses = selectedCategory === 'todos' 
    ? courses 
    : courses.filter(course => 
        course.tags.some(tag => tag.toLowerCase().includes(selectedCategory))
      );

  if (selectedCourse) {
    // Renderizar sala de aula do curso
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen"
      >
        {/* Course Classroom será implementado posteriormente */}
        <div className="admin-card p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold admin-text-blue">{selectedCourse.title}</h1>
            <Button 
              variant="ghost" 
              onClick={() => setSelectedCourse(null)}
              className="admin-text-smoke hover:admin-text-blue"
            >
              Voltar aos Cursos
            </Button>
          </div>
          <p className="admin-text-smoke mb-4">Sala de aula em desenvolvimento...</p>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Biblioteca de Cursos
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Acelere sua jornada criativa com cursos práticos e projetos reais
        </p>
      </div>

      {/* Categories Filter */}
      <div className="flex flex-wrap gap-3 justify-center mb-8">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            onClick={() => setSelectedCategory(category.id)}
            className={selectedCategory === category.id 
              ? "admin-bg-blue hover:opacity-90" 
              : "border-blue-500/20 admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
            }
            data-testid={`category-${category.id}`}
          >
            {category.label}
          </Button>
        ))}
      </div>

      {/* My Learning Progress */}
      <div className="admin-card p-6 mb-8">
        <h2 className="text-xl font-bold admin-text-blue mb-4">Meu Aprendizado</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          <div className="text-center">
            <div className="w-16 h-16 admin-bg-blue rounded-full flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <p className="text-2xl font-bold admin-text-blue mb-1">2</p>
            <p className="admin-text-smoke text-sm">Cursos Ativos</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 admin-bg-orange rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <p className="text-2xl font-bold admin-text-orange mb-1">15</p>
            <p className="admin-text-smoke text-sm">Aulas Concluídas</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Star className="w-8 h-8 text-white" />
            </div>
            <p className="text-2xl font-bold text-green-400 mb-1">47</p>
            <p className="admin-text-smoke text-sm">Tokens Ganhos</p>
          </div>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredCourses.map((course, index) => (
          <motion.div
            key={course.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card overflow-hidden hover:scale-105 transition-all duration-300 cursor-pointer"
            onClick={() => setSelectedCourse(course)}
            data-testid={`course-card-${course.id}`}
          >
            
            {/* Course Thumbnail */}
            <div className="relative">
              <img 
                src={course.thumbnail} 
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              
              {/* Overlay com Play Button */}
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <div className="w-16 h-16 admin-bg-blue rounded-full flex items-center justify-center">
                  <Play className="w-8 h-8 text-white ml-1" />
                </div>
              </div>
              
              {/* Premium Badge */}
              {course.isPremium && (
                <Badge className="absolute top-3 right-3 admin-bg-orange text-white">
                  <Star className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
              
              {/* Progress Indicator */}
              {course.isEnrolled && course.progress > 0 && (
                <div className="absolute bottom-0 left-0 right-0">
                  <Progress value={course.progress} className="h-1" />
                </div>
              )}
            </div>

            {/* Course Info */}
            <div className="p-4">
              
              {/* Title & Level */}
              <div className="mb-3">
                <h3 className="font-bold admin-text-blue mb-2 line-clamp-2">
                  {course.title}
                </h3>
                <Badge className={`${getLevelColor(course.level)} text-white text-xs`}>
                  {course.level}
                </Badge>
              </div>

              {/* Description */}
              <p className="admin-text-smoke text-sm mb-4 line-clamp-2">
                {course.description}
              </p>

              {/* Course Meta */}
              <div className="flex items-center justify-between text-xs admin-text-smoke mb-4">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {course.duration}
                </div>
                <div className="flex items-center gap-1">
                  <BookOpen className="w-3 h-3" />
                  {course.lessons} aulas
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {course.students}
                </div>
              </div>

              {/* Rating & Price */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-medium admin-text-blue">
                    {course.rating}
                  </span>
                </div>
                
                <div className="text-right">
                  {course.isEnrolled ? (
                    <span className="text-sm font-bold text-green-400">
                      Matriculado
                    </span>
                  ) : (
                    <span className="text-sm font-bold admin-text-blue">
                      R$ {course.price}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Button */}
              <Button 
                className={`w-full mt-4 ${
                  course.isEnrolled 
                    ? 'admin-bg-blue hover:opacity-90' 
                    : 'admin-bg-orange hover:opacity-90'
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  if (course.isEnrolled) {
                    setSelectedCourse(course);
                  } else {
                    console.log('Matricular no curso:', course.id);
                  }
                }}
              >
                {course.isEnrolled ? (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Continuar
                  </>
                ) : course.isPremium ? (
                  <>
                    <Lock className="w-4 h-4 mr-2" />
                    Upgrade Premium
                  </>
                ) : (
                  'Matricular Agora'
                )}
              </Button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredCourses.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="w-16 h-16 admin-text-smoke mx-auto mb-4" />
          <h3 className="text-xl font-bold admin-text-blue mb-2">
            Nenhum curso encontrado
          </h3>
          <p className="admin-text-smoke">
            Tente selecionar uma categoria diferente
          </p>
        </div>
      )}
    </motion.div>
  );
}