import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Settings, 
  LogOut, 
  CreditCard, 
  Zap,
  ChevronDown,
  Menu,
  X,
  Sparkles
} from 'lucide-react';

interface TopbarProps {
  user: {
    name: string;
    email: string;
    plan: string;
    credits: number;
    maxCredits: number;
    avatar?: string;
  };
  onMenuToggle?: () => void;
  isMobileMenuOpen?: boolean;
}

export function Topbar({ user, onMenuToggle, isMobileMenuOpen }: TopbarProps) {
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Calculate progress percentage
  const progressPercentage = (user.credits / user.maxCredits) * 100;
  
  // Get plan color
  const getPlanColor = (plan: string) => {
    const colors = {
      'free': 'var(--smoke)',
      'basic': 'var(--blue)',
      'pro': 'var(--orange)',
      'premium': '#ffd700'
    };
    return colors[plan.toLowerCase() as keyof typeof colors] || 'var(--blue)';
  };

  const handleLogout = () => {
    // TODO: Implement logout logic
    window.location.href = '/api/logout';
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 h-16 glass-morphism-strong z-50 gradient-bg"
    >
      <div className="flex items-center justify-between h-full px-6">
        
        {/* Left Section: Logo + Mobile Menu */}
        <div className="flex items-center space-x-4">
          {/* Mobile Menu Button */}
          <button
            onClick={onMenuToggle}
            className="lg:hidden p-2 rounded-xl hover:bg-[var(--blue)]/10 text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
            data-testid="mobile-menu-button"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center space-x-3 cursor-pointer"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl neon-glow flex items-center justify-center relative">
              <Sparkles className="w-6 h-6 text-white" />
              <div className="absolute inset-0 rounded-2xl border-2 border-[var(--blue)]/30 animate-pulse"></div>
            </div>
            <div className="hidden sm:block">
              <h1 className="font-orbitron font-bold text-xl text-white tracking-tight">
                Hja²Ops
              </h1>
              <div className="text-xs text-[var(--smoke)]/70 -mt-1">
                AI-Powered Creative Suite
              </div>
            </div>
          </motion.div>
        </div>

        {/* Center Section: Token Progress Bar */}
        <div className="hidden md:flex items-center space-x-4 flex-1 max-w-md mx-8">
          <div className="flex items-center gap-3">
            <div className="flex flex-col items-end">
              <span className="text-sm font-semibold text-[var(--blue)]">
                {user.credits.toLocaleString()} tokens
              </span>
              <div className="w-24 h-2 bg-black/60 rounded-full overflow-hidden border border-[var(--blue)]/30">
                <motion.div
                  className="h-full bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercentage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  style={{
                    boxShadow: '0 0 10px var(--blue)',
                  }}
                />
              </div>
            </div>
            <Zap className="w-5 h-5 text-[var(--blue)] pulse-glow" />
          </div>
        </div>

        {/* Right Section: User Info + Dropdown */}
        <div className="flex items-center space-x-4">
          {/* Credits Badge (Mobile) */}
          <div className="md:hidden text-right">
            <div className="text-sm font-bold text-[var(--blue)]">
              {user.credits.toLocaleString()}
            </div>
            <div className="text-xs text-[var(--smoke)]/60">créditos</div>
          </div>

          {/* User Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <motion.button
              onClick={() => setShowDropdown(!showDropdown)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center space-x-3 px-4 py-2 rounded-2xl glass-morphism hover:neon-glow transition-all group"
              data-testid="user-dropdown-button"
            >
              {/* Avatar */}
              <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
                {user.avatar ? (
                  <img 
                    src={user.avatar} 
                    alt={user.name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <span className="text-black font-bold text-sm">
                    {user.name.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>

              {/* User Info (Desktop) */}
              <div className="hidden lg:block text-left">
                <div className="text-sm font-medium text-[var(--smoke)]">
                  {user.name}
                </div>
                <div 
                  className="text-xs font-medium"
                  style={{ color: getPlanColor(user.plan) }}
                >
                  {user.plan.toUpperCase()}
                </div>
              </div>

              <ChevronDown 
                size={16} 
                className={`text-[var(--smoke)] transition-transform duration-200 ${
                  showDropdown ? 'rotate-180' : ''
                }`}
              />
            </motion.button>

            {/* Dropdown Menu */}
            <AnimatePresence>
              {showDropdown && (
                <motion.div
                  initial={{ opacity: 0, y: -10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -10, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-0 top-full mt-2 w-64 glass-morphism border border-[var(--blue)]/30 rounded-xl shadow-2xl shadow-[var(--blue)]/10 overflow-hidden"
                >
                  {/* User Header */}
                  <div className="p-4 border-b border-[var(--blue)]/20 bg-[var(--blue)]/5">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
                        {user.avatar ? (
                          <img 
                            src={user.avatar} 
                            alt={user.name}
                            className="w-full h-full rounded-full object-cover"
                          />
                        ) : (
                          <span className="text-black font-bold">
                            {user.name.charAt(0).toUpperCase()}
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="font-medium text-[var(--smoke)]">{user.name}</div>
                        <div className="text-sm text-[var(--smoke)]/60">{user.email}</div>
                        <div 
                          className="text-xs font-bold px-2 py-1 rounded-full mt-1 inline-block"
                          style={{ 
                            backgroundColor: `${getPlanColor(user.plan)}20`,
                            color: getPlanColor(user.plan)
                          }}
                        >
                          {user.plan.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Menu Items */}
                  <div className="py-2">
                    <motion.button
                      whileHover={{ backgroundColor: 'rgba(0, 243, 255, 0.1)' }}
                      className="w-full px-4 py-3 text-left flex items-center space-x-3 text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
                      data-testid="profile-menu-item"
                    >
                      <User size={16} />
                      <span>Meu Perfil</span>
                    </motion.button>

                    <motion.button
                      whileHover={{ backgroundColor: 'rgba(0, 243, 255, 0.1)' }}
                      className="w-full px-4 py-3 text-left flex items-center space-x-3 text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
                      data-testid="credits-menu-item"
                    >
                      <CreditCard size={16} />
                      <span>Gerenciar Créditos</span>
                      <div className="ml-auto text-xs text-[var(--orange)]">
                        {user.credits.toLocaleString()}
                      </div>
                    </motion.button>

                    <motion.button
                      whileHover={{ backgroundColor: 'rgba(0, 243, 255, 0.1)' }}
                      className="w-full px-4 py-3 text-left flex items-center space-x-3 text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
                      data-testid="settings-menu-item"
                    >
                      <Settings size={16} />
                      <span>Configurações</span>
                    </motion.button>

                    <div className="border-t border-[var(--blue)]/20 mt-2 pt-2">
                      <motion.button
                        onClick={handleLogout}
                        whileHover={{ backgroundColor: 'rgba(255, 107, 0, 0.1)' }}
                        className="w-full px-4 py-3 text-left flex items-center space-x-3 text-[var(--smoke)] hover:text-[var(--orange)] transition-colors"
                        data-testid="logout-menu-item"
                      >
                        <LogOut size={16} />
                        <span>Sair</span>
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.header>
  );
}