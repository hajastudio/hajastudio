import { Card, CardContent } from "@/components/ui/card";
import type { Agent } from "@shared/schema";

interface AgentCardProps {
  agent: Agent;
  onSelect: (agent: Agent) => void;
}

export function AgentCard({ agent, onSelect }: AgentCardProps) {
  const statusColor = agent.active ? "text-green-400" : "text-yellow-400";
  const statusText = agent.active ? "Active" : "Maintenance";

  return (
    <Card 
      className="netflix-card p-6 cursor-pointer" 
      onClick={() => onSelect(agent)}
      data-testid={`agent-card-${agent.id}`}
    >
      <CardContent className="p-0">
        <img 
          src={agent.avatarUrl || "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=80&h=80"} 
          alt={`${agent.name} Avatar`} 
          className="w-16 h-16 rounded-full mx-auto mb-4 object-cover"
          data-testid={`agent-avatar-${agent.id}`}
        />
        <h3 className="text-lg font-semibold text-center mb-2" data-testid={`agent-name-${agent.id}`}>
          {agent.name}
        </h3>
        <p className="text-sm text-muted-foreground text-center mb-4" data-testid={`agent-description-${agent.id}`}>
          {agent.description}
        </p>
        <div className="flex flex-wrap gap-2 justify-center mb-4">
          {agent.tags?.map((tag, index) => (
            <span 
              key={index} 
              className="px-2 py-1 bg-primary/20 text-primary text-xs rounded-full"
              data-testid={`agent-tag-${agent.id}-${index}`}
            >
              {tag}
            </span>
          ))}
        </div>
        <div className="flex items-center justify-center gap-2">
          <div className={`w-2 h-2 rounded-full ${agent.active ? 'bg-green-400 pulse-glow' : 'bg-yellow-400'}`}></div>
          <span className={`text-xs ${statusColor}`} data-testid={`agent-status-${agent.id}`}>
            {statusText}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
