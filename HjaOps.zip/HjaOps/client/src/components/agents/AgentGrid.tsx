import { useQuery } from "@tanstack/react-query";
import { AgentCard } from "./AgentCard";
import { Button } from "@/components/ui/button";
import type { Agent } from "@shared/schema";

interface AgentGridProps {
  onSelectAgent: (agent: Agent) => void;
  onCreateAgent?: () => void;
  showCreateButton?: boolean;
}

export function AgentGrid({ onSelectAgent, onCreateAgent, showCreateButton = false }: AgentGridProps) {
  const { data: agents = [], isLoading } = useQuery({
    queryKey: ["/api/agents"],
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="text-muted-foreground">Loading agents...</div>
      </div>
    );
  }

  return (
    <section id="agents" className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold" data-testid="agents-title">AI Agents</h2>
        {showCreateButton && onCreateAgent && (
          <Button 
            variant="secondary" 
            onClick={onCreateAgent}
            data-testid="button-create-agent"
          >
            <i className="fas fa-plus mr-2"></i>
            Add Agent
          </Button>
        )}
      </div>

      {agents.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground" data-testid="no-agents">
          No agents available
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {agents.map((agent: Agent) => (
            <AgentCard
              key={agent.id}
              agent={agent}
              onSelect={onSelectAgent}
            />
          ))}
        </div>
      )}
    </section>
  );
}
