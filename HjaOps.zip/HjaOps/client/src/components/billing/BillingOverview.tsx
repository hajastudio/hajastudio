import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { CreditPackages } from "./CreditPackages";

export function BillingOverview() {
  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const usedCredits = 4000 - (user?.credits || 0); // Assuming 4000 is the monthly limit
  const usagePercentage = (usedCredits / 4000) * 100;

  const recentTransactions = transactions.slice(0, 5);

  return (
    <section id="billing" className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-3xl font-bold" data-testid="billing-title">Billing & Credits</h2>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Current plan:</span>
          <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm font-medium" data-testid="current-plan">
            {user?.plan || 'Free'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Current Usage */}
        <Card className="netflix-card p-6">
          <CardContent className="p-0">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <i className="fas fa-chart-line text-primary"></i>
              Usage Overview
            </h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Credits Used</span>
                  <span className="text-sm font-medium" data-testid="credits-usage">
                    {usedCredits.toLocaleString()} / 4,000
                  </span>
                </div>
                <div className="w-full bg-secondary h-2 rounded-full">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(usagePercentage, 100)}%` }}
                  ></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm text-muted-foreground">Monthly Limit</span>
                  <span className="text-sm font-medium" data-testid="plan-type">
                    {user?.plan || 'Free'} Plan
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">Resets in 12 days</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Credit Packages */}
        <CreditPackages />

        {/* Transaction History */}
        <Card className="netflix-card p-6">
          <CardContent className="p-0">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <i className="fas fa-receipt text-primary"></i>
              Recent Transactions
            </h3>
            
            <div className="space-y-3">
              {recentTransactions.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground" data-testid="no-transactions">
                  No transactions yet
                </p>
              ) : (
                recentTransactions.map((transaction: any, index: number) => (
                  <div key={index} className="flex items-center justify-between py-2 border-b border-border/50 last:border-b-0" data-testid={`transaction-${index}`}>
                    <div>
                      <p className="text-sm font-medium" data-testid={`transaction-type-${index}`}>
                        {transaction.type === 'credits' ? 'Credit Purchase' : 'Plan Update'}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid={`transaction-details-${index}`}>
                        +{transaction.creditsAdded || 0} credits
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-green-400" data-testid={`transaction-amount-${index}`}>
                        ${transaction.amount}
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid={`transaction-date-${index}`}>
                        {new Date(transaction.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
