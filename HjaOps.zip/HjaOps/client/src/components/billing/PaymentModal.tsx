import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface CreditPackage {
  name: string;
  credits: number;
  price: number;
  savings?: string;
}

interface PaymentModalProps {
  package: CreditPackage;
  onClose: () => void;
}

export function PaymentModal({ package: pkg, onClose }: PaymentModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const tax = pkg.price * 0.09; // 9% tax
  const total = pkg.price + tax;

  const processPurchaseMutation = useMutation({
    mutationFn: async () => {
      // Create a transaction record
      const response = await apiRequest("POST", "/api/transactions", {
        type: "credits",
        amount: total.toString(),
        creditsAdded: pkg.credits,
        provider: "mercadopago",
        status: "completed", // Mock completed for demo
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Purchase Successful!",
        description: `${pkg.credits.toLocaleString()} credits have been added to your account.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      onClose();
    },
    onError: () => {
      toast({
        title: "Purchase Failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsProcessing(false);
    },
  });

  const handlePurchase = () => {
    setIsProcessing(true);
    processPurchaseMutation.mutate();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50" data-testid="payment-modal">
      <div className="netflix-card p-6 rounded-xl w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold" data-testid="modal-title">Purchase Credits</h3>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            data-testid="button-close-modal"
          >
            <i className="fas fa-times"></i>
          </Button>
        </div>

        <div className="mb-6">
          <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 text-center mb-4">
            <h4 className="text-lg font-semibold text-primary" data-testid="selected-package-name">
              {pkg.name}
            </h4>
            <p className="text-sm text-muted-foreground" data-testid="selected-package-credits">
              {pkg.credits.toLocaleString()} Credits
            </p>
            <p className="text-2xl font-bold mt-2" data-testid="selected-package-price">
              ${pkg.price}
            </p>
            {pkg.savings && (
              <p className="text-xs text-green-400" data-testid="selected-package-savings">
                {pkg.savings}
              </p>
            )}
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span>Package:</span>
              <span data-testid="order-package">{pkg.credits.toLocaleString()} Credits</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Price:</span>
              <span data-testid="order-price">${pkg.price}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span>Tax:</span>
              <span data-testid="order-tax">${tax.toFixed(2)}</span>
            </div>
            <div className="border-t border-border pt-2 flex items-center justify-between font-semibold">
              <span>Total:</span>
              <span data-testid="order-total">${total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Payment Method</label>
            <div className="flex gap-2">
              <Button
                variant={paymentMethod === 'card' ? 'default' : 'outline'}
                className="flex-1 flex items-center justify-center gap-2"
                onClick={() => setPaymentMethod('card')}
                data-testid="button-payment-card"
              >
                <i className="fab fa-cc-mastercard"></i>
                <span>Card</span>
              </Button>
              <Button
                variant={paymentMethod === 'paypal' ? 'default' : 'outline'}
                className="flex-1 flex items-center justify-center gap-2"
                onClick={() => setPaymentMethod('paypal')}
                data-testid="button-payment-paypal"
              >
                <i className="fab fa-paypal"></i>
                <span>PayPal</span>
              </Button>
            </div>
          </div>

          <Button 
            className="w-full neon-glow" 
            onClick={handlePurchase}
            disabled={isProcessing}
            data-testid="button-complete-purchase"
          >
            {isProcessing ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Processing...
              </>
            ) : (
              <>
                <i className="fas fa-credit-card mr-2"></i>
                Complete Purchase
              </>
            )}
          </Button>
          
          <p className="text-xs text-muted-foreground text-center">
            Secure payment powered by Mercado Pago
          </p>
        </div>
      </div>
    </div>
  );
}
