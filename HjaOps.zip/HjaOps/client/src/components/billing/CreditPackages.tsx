import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PaymentModal } from "./PaymentModal";

interface CreditPackage {
  name: string;
  credits: number;
  price: number;
  savings?: string;
  popular?: boolean;
}

const packages: CreditPackage[] = [
  {
    name: "Starter Pack",
    credits: 500,
    price: 9.99,
  },
  {
    name: "Popular",
    credits: 1500,
    price: 24.99,
    savings: "Save 17%",
    popular: true,
  },
  {
    name: "Power User",
    credits: 5000,
    price: 79.99,
    savings: "Save 25%",
  },
];

export function CreditPackages() {
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);

  return (
    <>
      <Card className="netflix-card p-6">
        <CardContent className="p-0">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <i className="fas fa-shopping-cart text-primary"></i>
            Buy Credits
          </h3>
          
          <div className="space-y-3">
            {packages.map((pkg, index) => (
              <div 
                key={index}
                className={`p-3 rounded-lg cursor-pointer transition-colors border ${
                  pkg.popular 
                    ? 'bg-secondary/50 border-primary/30 hover:bg-secondary/70' 
                    : 'bg-secondary/50 border-transparent hover:bg-secondary/70 hover:border-primary/30'
                }`}
                onClick={() => setSelectedPackage(pkg)}
                data-testid={`credit-package-${index}`}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium" data-testid={`package-name-${index}`}>
                      {pkg.name}
                    </p>
                    <p className="text-xs text-muted-foreground" data-testid={`package-credits-${index}`}>
                      {pkg.credits.toLocaleString()} credits
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-primary font-bold" data-testid={`package-price-${index}`}>
                      ${pkg.price}
                    </span>
                    {pkg.savings && (
                      <p className="text-xs text-green-400" data-testid={`package-savings-${index}`}>
                        {pkg.savings}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedPackage && (
        <PaymentModal 
          package={selectedPackage}
          onClose={() => setSelectedPackage(null)}
        />
      )}
    </>
  );
}
