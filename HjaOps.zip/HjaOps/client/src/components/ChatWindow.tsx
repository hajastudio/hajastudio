import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Sparkles, AlertCircle } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  agentName?: string;
  timestamp: string;
  tokensUsed?: number;
}

interface ChatWindowProps {
  activeAgent?: {
    id: string;
    name: string;
    icon: React.ElementType;
    description: string;
    category?: string;
    specialty?: string[];
    tokensUsed?: number;
  } | null;
  onAgentSelect?: (agentId: string) => void;
}

export function ChatWindow({ activeAgent, onAgentSelect }: ChatWindowProps) {
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Olá! 👋 Sou seu assistente de IA. Como posso ajudar você hoje?',
      role: 'assistant',
      agentName: 'Assistente Geral',
      timestamp: new Date().toISOString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch user credits
  const { data: creditsData } = useQuery({
    queryKey: ['/api/credits'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Chat mutation
  const chatMutation = useMutation({
    mutationFn: async (payload: { messages: any[], agentId: string, modelId?: string }) => {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: Date.now().toString(),
        content: data.message,
        role: 'assistant',
        agentName: activeAgent?.name || 'Assistente Geral',
        timestamp: new Date().toISOString(),
        tokensUsed: data.tokensUsed
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      
      // Refresh credits
      queryClient.invalidateQueries({ queryKey: ['/api/credits'] });
      
      // Show success toast with usage info
      toast({
        title: "Resposta gerada",
        description: `${data.tokensUsed} tokens usados via ${data.provider}. ${data.creditsRemaining} créditos restantes.`,
        duration: 3000,
      });
      
      setIsTyping(false);
    },
    onError: (error: Error) => {
      console.error('Chat error:', error);
      
      if (error.message.includes('402')) {
        toast({
          title: "Créditos insuficientes",
          description: "Você precisa de mais créditos para continuar. Considere fazer um upgrade do seu plano.",
          variant: "destructive",
          duration: 5000,
        });
      } else if (error.message.includes('503')) {
        toast({
          title: "Serviço temporariamente indisponível",
          description: "Todos os provedores de IA estão indisponíveis. Tente novamente em alguns minutos.",
          variant: "destructive",
          duration: 5000,
        });
      } else {
        toast({
          title: "Erro no chat",
          description: "Ocorreu um erro ao processar sua mensagem. Tente novamente.",
          variant: "destructive",
          duration: 5000,
        });
      }
    }
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || chatMutation.isPending) return;

    // Check credits before sending
    if (creditsData && (creditsData as any).credits < 1) {
      toast({
        title: "Créditos insuficientes",
        description: "Você precisa de pelo menos 1 crédito para enviar uma mensagem.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      role: 'user',
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input.trim();
    setInput('');
    setIsTyping(true);

    // Prepare chat payload
    const chatPayload = {
      messages: [...messages, userMessage].map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      agentId: activeAgent?.id || 'roteirista',
      modelId: undefined // Let backend choose optimal model
    };

    // Send to AI orchestrator
    chatMutation.mutate(chatPayload);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="h-full flex flex-col glass-morphism-strong rounded-3xl animated-border overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="p-4 border-b glass-morphism">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse"></div>
          {activeAgent ? (
            <>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center neon-glow shadow-lg">
                <activeAgent.icon size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-orbitron font-bold text-white text-lg">{activeAgent.name}</h3>
                <p className="text-sm text-[var(--smoke)]/80">{activeAgent.description}</p>
              </div>
            </>
          ) : (
            <>
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center neon-glow shadow-lg">
                <Sparkles size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-orbitron font-bold text-white text-lg">Chat Multi-Agente</h3>
                <p className="text-sm text-[var(--smoke)]/80">Modo Colaborativo Ativo</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`
                  max-w-xs lg:max-w-md xl:max-w-lg p-4 rounded-2xl transition-all duration-300
                  ${message.role === 'user' 
                    ? 'bg-gradient-to-r from-[var(--orange)] to-red-500 text-white ml-4 shadow-lg neon-glow-orange' 
                    : 'bg-gradient-to-r from-[var(--blue)]/20 to-blue-500/20 border glass-morphism text-gray-100 mr-4 shadow-lg'
                  }
                  hover:scale-[1.02] hover:shadow-2xl
                `}
                style={{
                  borderColor: message.role === 'assistant' ? 'rgba(0, 243, 255, 0.3)' : undefined,
                  boxShadow: message.role === 'assistant' ? '0 0 20px rgba(0, 243, 255, 0.1)' : undefined
                }}
              >
                {message.role === 'assistant' && (
                  <div className="flex items-center space-x-2 mb-2">
                    <Sparkles size={16} className="text-[var(--blue)]" />
                    <span className="text-xs font-medium text-[var(--blue)]">{message.agentName}</span>
                    {message.tokensUsed && (
                      <span className="text-xs text-[var(--orange)]">
                        {message.tokensUsed} tokens
                      </span>
                    )}
                  </div>
                )}
                
                {message.role === 'user' && (
                  <div className="flex items-center justify-end space-x-2 mb-2">
                    <span className="text-xs font-medium text-white">Você</span>
                    <User size={16} className="text-white" />
                  </div>
                )}

                <p className="text-sm leading-relaxed">{message.content}</p>
                
                <div className="mt-2 text-xs opacity-60">
                  {new Date(message.timestamp).toLocaleTimeString('pt-BR', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex justify-start"
            >
              <div className="bg-[var(--blue)]/10 border border-[var(--blue)]/30 rounded-2xl p-3 mr-4">
                <div className="flex items-center space-x-2">
                  <Bot size={16} className="text-[var(--blue)]" />
                  <span className="text-xs font-medium text-[var(--blue)]">
                    {activeAgent?.name || 'Assistente'} está digitando...
                  </span>
                </div>
                <div className="flex space-x-1 mt-2">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-2 h-2 bg-[var(--blue)] rounded-full"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ 
                        duration: 0.8, 
                        repeat: Infinity, 
                        delay: i * 0.2 
                      }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-6 border-t glass-morphism">
        <div className="flex gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Digite sua mensagem..."
            className="
              flex-1 px-4 py-3 glass-morphism rounded-2xl 
              text-[var(--smoke)] placeholder-[var(--smoke)]/50 
              focus:outline-none focus:neon-glow
              transition-all duration-300
            "
            data-testid="chat-input"
          />
          <motion.button
            onClick={handleSendMessage}
            disabled={!input.trim() || isTyping || chatMutation.isPending}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="
              px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] 
              rounded-2xl text-white font-medium neon-glow
              hover:shadow-2xl hover:shadow-[var(--blue)]/40
              disabled:opacity-50 disabled:cursor-not-allowed
              transition-all duration-300 flex items-center gap-2
            "
            data-testid="send-button"
          >
            <Send size={16} />
            Enviar
          </motion.button>
        </div>
      </div>
    </div>
  );
}