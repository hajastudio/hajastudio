import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import Sidebar from './Sidebar';
import ChatArea from './ChatArea';
import ContextPanel from './ContextPanel';
import type { Agent, ChatThread } from '@/types/agents';

interface ChatShellProps {
  user: any;
}

export default function ChatShell({ user }: ChatShellProps) {
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [currentThread, setCurrentThread] = useState<ChatThread | null>(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const [showContextPanel, setShowContextPanel] = useState(true);
  const [isMobile, setIsMobile] = useState(false);

  // Responsive check
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 1024;
      setIsMobile(mobile);
      if (mobile) {
        setShowSidebar(false);
        setShowContextPanel(false);
      } else {
        setShowSidebar(true);
        setShowContextPanel(true);
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <div className="h-screen bg-black flex overflow-hidden">
      {/* Mobile Menu Overlay */}
      {isMobile && showSidebar && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          onClick={() => setShowSidebar(false)}
        />
      )}

      {/* Sidebar */}
      <AnimatePresence>
        {showSidebar && (
          <motion.div
            initial={{ x: isMobile ? -300 : 0, opacity: isMobile ? 0 : 1 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: isMobile ? -300 : 0, opacity: isMobile ? 0 : 1 }}
            className={`${
              isMobile ? 'fixed z-50' : 'relative'
            } w-80 h-full glass-morphism border-r border-[var(--smoke)]/20`}
          >
            <Sidebar
              user={user}
              selectedAgent={selectedAgent}
              onAgentSelect={setSelectedAgent}
              currentThread={currentThread}
              onThreadSelect={setCurrentThread}
              isMobile={isMobile}
              onClose={() => setShowSidebar(false)}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-h-0">
        {/* Mobile Toggle */}
        {isMobile && (
          <div className="flex items-center gap-3 p-4 border-b border-[var(--smoke)]/20">
            <button
              onClick={() => setShowSidebar(true)}
              className="p-2 glass-morphism rounded-lg text-[var(--smoke)] hover:text-white transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            {selectedAgent && (
              <div className="flex items-center gap-2">
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                  style={{ backgroundColor: selectedAgent.color }}
                >
                  {selectedAgent.avatar}
                </div>
                <span className="text-white font-medium">{selectedAgent.name}</span>
              </div>
            )}

            {!isMobile && (
              <button
                onClick={() => setShowContextPanel(!showContextPanel)}
                className="ml-auto p-2 glass-morphism rounded-lg text-[var(--smoke)] hover:text-white transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}
          </div>
        )}

        <ChatArea
          selectedAgent={selectedAgent}
          currentThread={currentThread}
          onThreadUpdate={setCurrentThread}
          user={user}
          showContextPanel={!isMobile && showContextPanel}
          onToggleContext={() => setShowContextPanel(!showContextPanel)}
        />
      </div>

      {/* Context Panel */}
      <AnimatePresence>
        {!isMobile && showContextPanel && (
          <motion.div
            initial={{ x: 320, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 320, opacity: 0 }}
            className="w-80 h-full glass-morphism border-l border-[var(--smoke)]/20"
          >
            <ContextPanel
              selectedAgent={selectedAgent}
              currentThread={currentThread}
              user={user}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Context Panel */}
      {isMobile && showContextPanel && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            onClick={() => setShowContextPanel(false)}
          />
          
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed right-0 top-0 w-80 h-full glass-morphism border-l border-[var(--smoke)]/20 z-50"
          >
            <div className="p-4 border-b border-[var(--smoke)]/20 flex items-center justify-between">
              <h3 className="font-orbitron font-semibold text-white">Contexto</h3>
              <button
                onClick={() => setShowContextPanel(false)}
                className="p-2 rounded-lg text-[var(--smoke)] hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <ContextPanel
              selectedAgent={selectedAgent}
              currentThread={currentThread}
              user={user}
            />
          </motion.div>
        </>
      )}
    </div>
  );
}