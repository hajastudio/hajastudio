import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Send, 
  Paperclip, 
  Mic, 
  Command, 
  Image, 
  FileText, 
  Link,
  Zap,
  Loader2
} from 'lucide-react';
import type { Agent } from '@/types/agents';

interface ComposerProps {
  onSendMessage: (content: string, attachments?: any[]) => void;
  placeholder: string;
  disabled?: boolean;
  isLoading?: boolean;
  selectedAgent: Agent | null;
  onEstimateTokens?: (text: string) => void;
}

export default function Composer({
  onSendMessage,
  placeholder,
  disabled = false,
  isLoading = false,
  selectedAgent,
  onEstimateTokens
}: ComposerProps) {
  const [message, setMessage] = useState('');
  const [showTools, setShowTools] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
    }
  }, [message]);

  // Estimate tokens on input change
  useEffect(() => {
    if (message.trim() && onEstimateTokens) {
      const timeoutId = setTimeout(() => {
        onEstimateTokens(message);
      }, 300);
      return () => clearTimeout(timeoutId);
    }
  }, [message, onEstimateTokens]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || disabled || isLoading) return;

    onSendMessage(message.trim(), attachments);
    setMessage('');
    setAttachments([]);
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    } else if (e.key === '/' && message === '') {
      e.preventDefault();
      setShowTools(true);
    }
  };

  const tools = [
    {
      id: 'web-search',
      name: 'Buscar na Web',
      icon: Link,
      description: 'Buscar informações atualizadas'
    },
    {
      id: 'image-upload',
      name: 'Enviar Imagem',
      icon: Image,
      description: 'Analisar ou descrever imagem'
    },
    {
      id: 'doc-parse',
      name: 'Analisar Documento',
      icon: FileText,
      description: 'Extrair texto de PDF/DOC'
    }
  ];

  const availableTools = selectedAgent?.tools || [];

  return (
    <div className="p-4">
      {/* Tools Menu */}
      {showTools && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          className="mb-4 glass-morphism rounded-xl p-3 border border-[var(--blue)]/30"
        >
          <div className="flex items-center gap-2 mb-2">
            <Command className="w-4 h-4 text-[var(--blue)]" />
            <span className="text-sm font-medium text-white">Ferramentas Disponíveis</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            {tools
              .filter(tool => availableTools.includes(tool.id))
              .map((tool) => {
                const Icon = tool.icon;
                return (
                  <button
                    key={tool.id}
                    onClick={() => {
                      setMessage(prev => prev + `/${tool.id} `);
                      setShowTools(false);
                    }}
                    className="flex items-center gap-3 p-3 glass-morphism rounded-lg hover:bg-[var(--smoke)]/5 transition-colors text-left"
                  >
                    <Icon className="w-4 h-4 text-[var(--blue)]" />
                    <div>
                      <p className="text-sm font-medium text-white">{tool.name}</p>
                      <p className="text-xs text-[var(--smoke)]/70">{tool.description}</p>
                    </div>
                  </button>
                );
              })}
          </div>
          
          <button
            onClick={() => setShowTools(false)}
            className="mt-2 text-xs text-[var(--smoke)]/60 hover:text-white transition-colors"
          >
            Fechar ferramentas
          </button>
        </motion.div>
      )}

      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="mb-3 flex flex-wrap gap-2">
          {attachments.map((attachment, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 px-3 py-2 glass-morphism rounded-lg"
            >
              <FileText className="w-4 h-4 text-[var(--blue)]" />
              <span className="text-sm text-white">{attachment.name}</span>
              <button
                onClick={() => setAttachments(prev => prev.filter((_, i) => i !== index))}
                className="text-[var(--smoke)]/60 hover:text-red-400 transition-colors"
              >
                ×
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Main Composer */}
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex items-end gap-3">
          {/* Attachment Button */}
          <button
            type="button"
            onClick={() => {
              // Trigger file upload
              const input = document.createElement('input');
              input.type = 'file';
              input.multiple = true;
              input.accept = 'image/*,.pdf,.doc,.docx,.txt';
              input.click();
            }}
            className="p-3 glass-morphism rounded-xl text-[var(--smoke)]/70 hover:text-[var(--blue)] hover:bg-[var(--blue)]/10 transition-all duration-300"
            disabled={disabled}
          >
            <Paperclip className="w-5 h-5" />
          </button>

          {/* Text Input */}
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              disabled={disabled}
              rows={1}
              className="w-full p-4 pr-12 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50 transition-all duration-300 resize-none"
              style={{ minHeight: '56px' }}
            />

            {/* Command Hint */}
            {message === '' && selectedAgent && (
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[var(--smoke)]/40 text-sm pointer-events-none">
                Digite / para ferramentas
              </div>
            )}

            {/* Character/Token Counter */}
            {message.length > 0 && (
              <div className="absolute bottom-2 right-3 text-xs text-[var(--smoke)]/60">
                {message.length} chars
              </div>
            )}
          </div>

          {/* Voice Input Button */}
          <button
            type="button"
            className="p-3 glass-morphism rounded-xl text-[var(--smoke)]/70 hover:text-[var(--orange)] hover:bg-[var(--orange)]/10 transition-all duration-300"
            disabled={disabled}
          >
            <Mic className="w-5 h-5" />
          </button>

          {/* Send Button */}
          <motion.button
            type="submit"
            disabled={!message.trim() || disabled || isLoading}
            className={`p-3 rounded-xl font-medium transition-all duration-300 ${
              message.trim() && !disabled && !isLoading
                ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white hover:shadow-lg neon-glow'
                : 'glass-morphism text-[var(--smoke)]/40 cursor-not-allowed'
            }`}
            whileHover={message.trim() && !disabled ? { scale: 1.05 } : {}}
            whileTap={message.trim() && !disabled ? { scale: 0.95 } : {}}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </motion.button>
        </div>

        {/* Shortcuts Hint */}
        <div className="flex items-center justify-between mt-2 text-xs text-[var(--smoke)]/50">
          <span>
            {selectedAgent ? (
              <>Conversando com <span className="text-[var(--blue)]">{selectedAgent.name}</span></>
            ) : (
              'Selecione um agente para começar'
            )}
          </span>
          <span>Enter para enviar • Shift+Enter para nova linha</span>
        </div>
      </form>
    </div>
  );
}