import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User,
  Copy,
  Check,
  Download,
  ExternalLink,
  Play,
  RefreshCw,
  Settings,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Clock,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import type { AgentMode } from './AgentModes';

interface Message {
  id: string;
  type: 'text' | 'code' | 'media' | 'table' | 'action-result';
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
  metadata?: {
    model?: string;
    cost?: number;
    executionTime?: number;
    fallback?: boolean;
    language?: string;
    actions?: Array<{
      id: string;
      label: string;
      icon: any;
      color: string;
      action: () => void;
    }>;
  };
}

interface MessageBubbleProps {
  message: Message;
  agent: AgentMode;
  onActionClick: (actionId: string) => void;
}

export default function MessageBubble({ message, agent, onActionClick }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);
  const [showActions, setShowActions] = useState(false);

  const isUser = message.sender === 'user';
  const isLongContent = message.content.length > 1000;

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const renderContent = () => {
    switch (message.type) {
      case 'code':
        return (
          <div className="rounded-lg overflow-hidden border border-blue-500/20">
            <div className="flex items-center justify-between p-3 bg-black/50 border-b border-blue-500/20">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                </div>
                <span className="text-sm admin-text-smoke ml-2">
                  {message.metadata?.language || 'javascript'}
                </span>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopy}
                className="admin-text-smoke hover:admin-text-blue"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            
            <div className="max-h-96 overflow-y-auto">
              <SyntaxHighlighter
                language={message.metadata?.language || 'javascript'}
                style={vscDarkPlus}
                customStyle={{
                  margin: 0,
                  background: 'transparent',
                  fontSize: '14px'
                }}
              >
                {message.content.replace(/```[\w]*\n?|```/g, '')}
              </SyntaxHighlighter>
            </div>
          </div>
        );

      case 'table':
        // Parse markdown table or render structured data
        if (message.content.includes('|')) {
          const lines = message.content.split('\n').filter(line => line.includes('|'));
          const headers = lines[0].split('|').map(h => h.trim()).filter(Boolean);
          const rows = lines.slice(2).map(line => 
            line.split('|').map(cell => cell.trim()).filter(Boolean)
          );

          return (
            <div className="overflow-x-auto">
              <table className="w-full border border-blue-500/20 rounded-lg">
                <thead>
                  <tr className="bg-blue-500/10">
                    {headers.map((header, i) => (
                      <th key={i} className="p-3 text-left admin-text-blue font-semibold border-b border-blue-500/20">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i} className="border-b border-blue-500/10">
                      {row.map((cell, j) => (
                        <td key={j} className="p-3 admin-text-smoke">
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        return <div className="admin-text-smoke whitespace-pre-wrap">{message.content}</div>;

      case 'media':
        return (
          <div className="space-y-3">
            <div className="w-full h-48 bg-black/30 rounded-lg border border-blue-500/20 flex items-center justify-center">
              <div className="text-center">
                <Play className="w-12 h-12 admin-text-smoke mx-auto mb-2" />
                <p className="text-sm admin-text-smoke">Mídia gerada</p>
              </div>
            </div>
            <div className="admin-text-smoke whitespace-pre-wrap text-sm">
              {message.content}
            </div>
          </div>
        );

      case 'action-result':
        return (
          <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Check className="w-5 h-5 text-green-400" />
              <span className="font-semibold text-green-400">Ação Executada</span>
            </div>
            <div className="admin-text-smoke whitespace-pre-wrap">
              {message.content}
            </div>
          </div>
        );

      default: // text
        return (
          <div className={`admin-text-smoke whitespace-pre-wrap ${isLongContent && !isExpanded ? 'line-clamp-6' : ''}`}>
            {message.content}
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
    >
      
      {/* Avatar - Assistant only */}
      {!isUser && (
        <Avatar className="w-8 h-8 border border-blue-500/30 flex-shrink-0">
          <AvatarImage src={agent.avatar} />
          <AvatarFallback className={`${agent.color} text-white text-xs`}>
            {agent.name.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
      )}

      {/* Message Container */}
      <div className={`max-w-2xl ${isUser ? 'order-first' : ''}`}>
        
        {/* Message Bubble */}
        <div
          className={`
            relative p-4 rounded-2xl border-[0.2px]
            ${isUser 
              ? 'admin-bg-blue text-white ml-auto border-blue-400/50 admin-glow-blue-subtle' 
              : 'admin-card border-blue-500/20 admin-glow-subtle'
            }
          `}
          onMouseEnter={() => setShowActions(true)}
          onMouseLeave={() => setShowActions(false)}
        >
          
          {/* Content */}
          <div className="space-y-3">
            {renderContent()}
            
            {/* Expand/Collapse for long content */}
            {isLongContent && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="w-full admin-text-smoke hover:admin-text-blue"
              >
                {isExpanded ? (
                  <>
                    <ChevronUp className="w-4 h-4 mr-2" />
                    Recolher
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-4 h-4 mr-2" />
                    Mostrar mais
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Message Actions - Hover */}
          {showActions && !isUser && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute -top-12 right-4 flex items-center gap-1 admin-card border border-blue-500/20 p-1 rounded-lg"
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopy}
                className="h-8 w-8 p-0 admin-text-smoke hover:admin-text-blue"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onActionClick('regenerate')}
                className="h-8 w-8 p-0 admin-text-smoke hover:admin-text-blue"
              >
                <RefreshCw className="w-3 h-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onActionClick('export')}
                className="h-8 w-8 p-0 admin-text-smoke hover:admin-text-blue"
              >
                <Download className="w-3 h-3" />
              </Button>
            </motion.div>
          )}
        </div>

        {/* Message Metadata */}
        <div className={`flex items-center gap-2 mt-2 px-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
          <span className="text-xs admin-text-smoke">
            {formatTimestamp(message.timestamp)}
          </span>
          
          {/* Assistant metadata */}
          {!isUser && message.metadata && (
            <>
              <Separator orientation="vertical" className="h-3" />
              
              {message.metadata.model && (
                <Badge variant="outline" className="text-xs border-blue-500/20 admin-text-blue">
                  {message.metadata.model.toUpperCase()}
                </Badge>
              )}
              
              {message.metadata.fallback && (
                <Badge variant="outline" className="text-xs border-yellow-500/20 text-yellow-400">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  FALLBACK
                </Badge>
              )}
              
              {message.metadata.cost && (
                <div className="flex items-center gap-1">
                  <Zap className="w-3 h-3 admin-text-orange" />
                  <span className="text-xs admin-text-smoke">
                    {message.metadata.cost.toFixed(3)} créditos
                  </span>
                </div>
              )}
              
              {message.metadata.executionTime && (
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 admin-text-smoke" />
                  <span className="text-xs admin-text-smoke">
                    {message.metadata.executionTime.toFixed(1)}s
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Quick Actions */}
        {!isUser && message.metadata?.actions && message.metadata.actions.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {message.metadata.actions.map((action) => (
              <Button
                key={action.id}
                variant="outline"
                size="sm"
                onClick={action.action}
                className={`${action.color} text-white border-0 hover:opacity-90`}
              >
                <action.icon className="w-3 h-3 mr-2" />
                {action.label}
              </Button>
            ))}
          </div>
        )}
      </div>

      {/* User Avatar */}
      {isUser && (
        <Avatar className="w-8 h-8 border border-blue-500/30 flex-shrink-0">
          <AvatarFallback className="admin-bg-blue text-white text-xs">
            <User className="w-4 h-4" />
          </AvatarFallback>
        </Avatar>
      )}
    </motion.div>
  );
}