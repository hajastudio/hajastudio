import { motion } from 'framer-motion';
import { 
  RefreshCw,
  Download,
  Share2,
  Copy,
  Edit,
  Zap,
  FileText,
  Code,
  Settings,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { AgentMode } from './AgentModes';

interface QuickActionsProps {
  agent: AgentMode;
  messageId: string;
  content: string;
  onAction: (action: string, messageId: string) => void;
}

export default function QuickActions({ agent, messageId, content, onAction }: QuickActionsProps) {
  
  const baseActions = [
    {
      id: 'regenerate',
      label: 'Regenerar',
      icon: RefreshCw,
      color: 'admin-bg-blue',
      description: 'Gerar nova resposta'
    },
    {
      id: 'refine',
      label: 'Refinar',
      icon: Edit,
      color: 'admin-bg-orange',
      description: 'Melhorar resultado'
    },
    {
      id: 'copy',
      label: 'Copiar',
      icon: Copy,
      color: 'bg-gray-600',
      description: 'Copiar conteúdo'
    },
    {
      id: 'export',
      label: 'Exportar',
      icon: Download,
      color: 'bg-green-600',
      description: 'Baixar arquivo'
    },
    {
      id: 'share',
      label: 'Compartilhar',
      icon: Share2,
      color: 'bg-purple-600',
      description: 'Enviar para equipe'
    }
  ];

  const getAgentSpecificActions = () => {
    switch (agent.id) {
      case 'roteiro':
        return [
          {
            id: 'format-screenplay',
            label: 'Formatar',
            icon: FileText,
            color: 'bg-purple-600',
            description: 'Aplicar formato profissional'
          },
          {
            id: 'add-directions',
            label: 'Direções',
            icon: Settings,
            color: 'admin-bg-blue',
            description: 'Adicionar direções de cena'
          },
          {
            id: 'character-arc',
            label: 'Personagens',
            icon: Sparkles,
            color: 'admin-bg-orange',
            description: 'Desenvolver arco narrativo'
          }
        ];

      case 'code':
        return [
          {
            id: 'run-code',
            label: 'Executar',
            icon: Zap,
            color: 'bg-green-600',
            description: 'Testar código'
          },
          {
            id: 'optimize',
            label: 'Otimizar',
            icon: Settings,
            color: 'admin-bg-orange',
            description: 'Melhorar performance'
          },
          {
            id: 'add-tests',
            label: 'Testes',
            icon: Code,
            color: 'admin-bg-blue',
            description: 'Gerar testes unitários'
          }
        ];

      case 'branding':
        return [
          {
            id: 'brand-guidelines',
            label: 'Manual',
            icon: FileText,
            color: 'admin-bg-orange',
            description: 'Criar manual da marca'
          },
          {
            id: 'color-palette',
            label: 'Paleta',
            icon: Sparkles,
            color: 'bg-purple-600',
            description: 'Gerar cores'
          },
          {
            id: 'tone-voice',
            label: 'Tom de Voz',
            icon: Settings,
            color: 'admin-bg-blue',
            description: 'Definir personalidade'
          }
        ];

      case 'youtube':
        return [
          {
            id: 'seo-optimize',
            label: 'SEO',
            icon: Zap,
            color: 'bg-red-600',
            description: 'Otimizar busca'
          },
          {
            id: 'thumbnail-ideas',
            label: 'Thumbnail',
            icon: Sparkles,
            color: 'admin-bg-orange',
            description: 'Sugerir miniaturas'
          },
          {
            id: 'script-breakdown',
            label: 'Roteiro',
            icon: FileText,
            color: 'admin-bg-blue',
            description: 'Estruturar conteúdo'
          }
        ];

      default:
        return [
          {
            id: 'enhance',
            label: 'Melhorar',
            icon: Sparkles,
            color: 'admin-bg-blue',
            description: 'Aprimorar resposta'
          },
          {
            id: 'summarize',
            label: 'Resumir',
            icon: FileText,
            color: 'admin-bg-orange',
            description: 'Versão concisa'
          }
        ];
    }
  };

  const allActions = [...baseActions, ...getAgentSpecificActions()];

  const handleAction = (actionId: string) => {
    onAction(actionId, messageId);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-wrap gap-2 mt-3"
    >
      {allActions.map((action, index) => (
        <motion.div
          key={action.id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.05 }}
        >
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction(action.id)}
            className={`
              ${action.color} text-white border-0 hover:opacity-90
              text-xs px-3 py-1 h-auto gap-2
            `}
            title={action.description}
          >
            <action.icon className="w-3 h-3" />
            {action.label}
          </Button>
        </motion.div>
      ))}
    </motion.div>
  );
}