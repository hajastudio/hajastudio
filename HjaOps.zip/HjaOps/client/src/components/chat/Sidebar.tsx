import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Plus, 
  Folder, 
  Star, 
  Clock, 
  Zap,
  Filter,
  X
} from 'lucide-react';
import AgentPicker from './AgentPicker';
import HistoryPanel from './HistoryPanel';
import TokenBadge from './TokenBadge';
import type { Agent, ChatThread } from '@/types/agents';

interface SidebarProps {
  user: any;
  selectedAgent: Agent | null;
  onAgentSelect: (agent: Agent) => void;
  currentThread: ChatThread | null;
  onThreadSelect: (thread: ChatThread) => void;
  isMobile: boolean;
  onClose: () => void;
}

export default function Sidebar({
  user,
  selectedAgent,
  onAgentSelect,
  currentThread,
  onThreadSelect,
  isMobile,
  onClose
}: SidebarProps) {
  const [activeTab, setActiveTab] = useState<'agents' | 'history'>('agents');
  const [searchQuery, setSearchQuery] = useState('');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'favorites' | 'recent' | 'drafts'>('recent');

  const userCredits = user?.credits || 0;
  const isLowCredits = userCredits < 10;

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-[var(--smoke)]/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-lg flex items-center justify-center neon-glow">
              <span className="text-white font-orbitron font-bold text-sm">H²</span>
            </div>
            <div>
              <h1 className="text-white font-orbitron font-bold text-lg">
                Chat Multi-IA
              </h1>
              <p className="text-[var(--smoke)]/60 text-xs">Agentes Especializados</p>
            </div>
          </div>

          {isMobile && (
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-[var(--smoke)] hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* User & Credits */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
            <span className="text-white font-bold">
              {user?.firstName?.[0] || 'U'}
            </span>
          </div>
          
          <div className="flex-1">
            <p className="text-white font-medium">
              {user?.firstName || 'Usuário'}
            </p>
            <TokenBadge credits={userCredits} isLow={isLowCredits} />
          </div>
        </div>

        {/* New Chat Button */}
        <motion.button
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium neon-glow hover:shadow-lg transition-all duration-300"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => onThreadSelect(null)}
        >
          <Plus className="w-5 h-5" />
          Nova Conversa
        </motion.button>
      </div>

      {/* Tabs */}
      <div className="px-6 py-4 border-b border-[var(--smoke)]/20">
        <div className="flex gap-1 glass-morphism rounded-xl p-1">
          <button
            onClick={() => setActiveTab('agents')}
            className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm transition-all duration-300 ${
              activeTab === 'agents'
                ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white shadow-lg'
                : 'text-[var(--smoke)]/70 hover:text-white'
            }`}
          >
            Agentes
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm transition-all duration-300 ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white shadow-lg'
                : 'text-[var(--smoke)]/70 hover:text-white'
            }`}
          >
            Histórico
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="px-6 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[var(--smoke)]/50" />
          <input
            type="text"
            placeholder={activeTab === 'agents' ? 'Buscar agentes...' : 'Buscar conversas...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 glass-morphism rounded-xl text-[var(--smoke)] placeholder-[var(--smoke)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--blue)]/50 transition-all"
          />
        </div>

        {/* History Filters */}
        {activeTab === 'history' && (
          <div className="flex gap-2 mt-3">
            {[
              { key: 'recent', label: 'Recentes', icon: Clock },
              { key: 'favorites', label: 'Favoritos', icon: Star },
              { key: 'drafts', label: 'Rascunhos', icon: Folder }
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setHistoryFilter(key as any)}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-xs transition-all ${
                  historyFilter === key
                    ? 'bg-[var(--blue)]/20 text-[var(--blue)]'
                    : 'text-[var(--smoke)]/60 hover:text-white hover:bg-[var(--smoke)]/5'
                }`}
              >
                <Icon className="w-3 h-3" />
                {label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'agents' ? (
          <AgentPicker
            selectedAgent={selectedAgent}
            onAgentSelect={onAgentSelect}
            searchQuery={searchQuery}
          />
        ) : (
          <HistoryPanel
            currentThread={currentThread}
            onThreadSelect={onThreadSelect}
            searchQuery={searchQuery}
            filter={historyFilter}
            user={user}
          />
        )}
      </div>
    </div>
  );
}