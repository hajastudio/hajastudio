import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { LoadingDots } from "@/components/ui/loading-dots";
import { MessageBubble } from "./MessageBubble";
import { ChatSidebar } from "./ChatSidebar";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface Agent {
  id: string;
  name: string;
  description: string;
  avatarUrl?: string;
  metadata?: {
    tags: string[];
    category: string;
    active: boolean;
  };
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

interface ChatInterfaceProps {
  selectedAgent?: Agent;
  agentId?: string;
}

// Firebase Cloud Functions integration
const callCloudFunction = async (functionName: string, data: any) => {
  const response = await fetch(`/api/functions/${functionName}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Function call failed');
  }
  
  return response.json();
};

export function ChatInterface({ selectedAgent, agentId }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();

  // Mock agents data - in production this would come from Firebase
  const mockAgents: Agent[] = [
    {
      id: "roteirista",
      name: "Agente Roteirista",
      description: "Cria roteiros envolventes para vídeos curtos e longos com estilo cinematográfico.",
      avatarUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40",
      metadata: { tags: ["vídeo", "storytelling"], category: "criativo", active: true }
    },
    {
      id: "vibe-code",
      name: "Vibe Code Assistant",
      description: "Assistente de código especializado em desenvolvimento web moderno.",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40",
      metadata: { tags: ["código", "javascript"], category: "tecnico", active: true }
    },
    {
      id: "viral",
      name: "Viral Content Master",
      description: "Criador de conteúdo viral para redes sociais com foco em engagement máximo.",
      avatarUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b494?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40",
      metadata: { tags: ["viral", "social media"], category: "viral", active: true }
    }
  ];

  const currentAgent = selectedAgent || mockAgents.find(a => a.id === agentId) || mockAgents[0];

  const sendMessageMutation = useMutation({
    mutationFn: async (messageContent: string) => {
      // Call Firebase Cloud Function onChatSubmit
      return await callCloudFunction('onChatSubmit', {
        userId: user?.id || user?.uid || 'anonymous',
        agentId: currentAgent.id,
        message: messageContent,
        chatId: currentChatId
      });
    },
    onSuccess: (response) => {
      // Add user message
      const userMessage: Message = {
        id: `user_${Date.now()}`,
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
      };
      
      // Add AI response
      const aiMessage: Message = {
        id: `ai_${Date.now()}`,
        role: 'assistant',
        content: response.message,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, userMessage, aiMessage]);
      setCurrentChatId(response.chatId);
      setMessage("");
      setIsLoading(false);

      // Show usage info
      toast({
        title: "Message Sent",
        description: `Used ${response.usage.tokens} tokens (${response.usage.cost.toFixed(3)} credits)`,
        variant: "default",
      });
    },
    onError: (error: any) => {
      setIsLoading(false);
      
      if (error.message.includes("resource-exhausted") || error.message.includes("Insufficient credits")) {
        toast({
          title: "Créditos Insuficientes",
          description: "Você não tem créditos suficientes para enviar esta mensagem. Considere fazer upgrade do seu plano.",
          variant: "destructive",
        });
      } else if (error.message.includes("unauthenticated")) {
        toast({
          title: "Login Necessário",
          description: "Faça login para usar o chat com IA.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro no Chat",
          description: error.message || "Falha ao enviar mensagem. Tente novamente.",
          variant: "destructive",
        });
      }
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!message.trim()) return;
    if (!isAuthenticated) {
      toast({
        title: "Login Necessário",
        description: "Faça login para usar o chat com IA.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    sendMessageMutation.mutate(message);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const estimatedTokens = Math.ceil(message.length / 4) + 200;

  return (
    <section id="chat" className="mb-12">
      <div className="netflix-card rounded-xl overflow-hidden">
        <div className="flex h-[600px]">
          {/* Chat Sidebar removido temporariamente para simplicidade */}

          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-border bg-secondary/20">
              {currentAgent ? (
                <div className="flex items-center gap-3">
                  <img 
                    src={currentAgent.avatarUrl || "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"} 
                    alt={`${currentAgent.name} Agent`} 
                    className="w-10 h-10 rounded-full object-cover"
                    data-testid="current-agent-avatar"
                  />
                  <div>
                    <h4 className="font-semibold" data-testid="current-agent-name">
                      {currentAgent.name}
                    </h4>
                    <p className="text-xs text-muted-foreground" data-testid="current-agent-description">
                      {currentAgent.description}
                    </p>
                  </div>
                  <div className="ml-auto flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Messages:</span>
                    <span className="text-xs font-medium text-primary" data-testid="chat-messages-count">
                      {messages.length}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground" data-testid="no-agent-selected">
                  Select an agent to start chatting
                </div>
              )}
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 space-y-4 overflow-y-auto" data-testid="chat-messages">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-muted-foreground" data-testid="no-messages">
                  {currentAgent ? "Start a conversation!" : "Select an agent to begin"}
                </div>
              ) : (
                <>
                  {messages.map((msg, index) => (
                    <MessageBubble
                      key={index}
                      message={msg}
                      isUser={msg.role === 'user'}
                      userAvatar={user?.profileImageUrl || user?.photoURL || ''}
                      agentAvatar={currentAgent?.avatarUrl}
                    />
                  ))}
                  {isLoading && (
                    <div className="flex items-start gap-3">
                      <img 
                        src={currentAgent?.avatarUrl || "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=32&h=32"} 
                        alt="Agent" 
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div className="chat-bubble agent bg-secondary border border-border rounded-lg p-3">
                        <LoadingDots />
                      </div>
                    </div>
                  )}
                </>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Input */}
            <div className="p-4 border-t border-border bg-secondary/20">
              <div className="flex items-end gap-3">
                <div className="flex-1">
                  <Textarea 
                    placeholder="Type your message here..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="resize-none"
                    rows={2}
                    disabled={!currentAgent || isLoading}
                    data-testid="input-message"
                  />
                </div>
                <Button 
                  className="neon-glow" 
                  onClick={handleSendMessage}
                  disabled={!message.trim() || !currentAgent || isLoading}
                  data-testid="button-send-message"
                >
                  <i className="fas fa-paper-plane"></i>
                </Button>
              </div>
              <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                <span data-testid="estimated-cost">
                  Estimated cost: ~{estimatedTokens} tokens
                </span>
                <span data-testid="credits-remaining">
                  Credits remaining: <span className="text-primary font-medium">{(user as any)?.credits?.toLocaleString() || '50'}</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
