import { motion } from 'framer-motion';
import type { Agent } from '@/types/agents';

interface StreamingIndicatorProps {
  agent: Agent;
}

export default function StreamingIndicator({ agent }: StreamingIndicatorProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex gap-3"
    >
      {/* Avatar */}
      <div 
        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0"
        style={{ backgroundColor: agent.color }}
      >
        {agent.avatar}
      </div>

      {/* Typing Bubble */}
      <div className="glass-morphism border border-[var(--smoke)]/10 rounded-2xl rounded-bl-sm p-4 max-w-[200px]">
        <div className="flex items-center gap-2">
          <div className="flex gap-1">
            <motion.div
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: agent.color }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            <motion.div
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: agent.color }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.2
              }}
            />
            <motion.div
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: agent.color }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.4
              }}
            />
          </div>
          
          <span className="text-sm text-[var(--smoke)]/70">
            {agent.name} está digitando...
          </span>
        </div>

        {/* Typing Animation */}
        <motion.div
          className="mt-2 h-1 rounded-full overflow-hidden"
          style={{ backgroundColor: `${agent.color}20` }}
        >
          <motion.div
            className="h-full rounded-full"
            style={{ backgroundColor: agent.color }}
            animate={{
              width: ['0%', '100%', '0%']
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </motion.div>
      </div>
    </motion.div>
  );
}