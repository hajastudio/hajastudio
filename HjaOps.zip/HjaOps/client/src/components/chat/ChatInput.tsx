import { useState, useRef, forwardRef, useImperativeHandle } from 'react';
import { motion } from 'framer-motion';
import { 
  Send,
  Paperclip,
  Mic,
  MicOff,
  Image,
  Link,
  Loader,
  X,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import type { AgentMode } from './AgentModes';
import { calculateEstimatedCost, calculateEstimatedTime } from './AgentModes';

interface ChatInputProps {
  agent: AgentMode;
  onSendMessage: (content: string, attachments?: File[]) => void;
  onEstimateChange: (cost: number, time: number) => void;
  disabled?: boolean;
}

export interface ChatInputRef {
  focus: () => void;
  clear: () => void;
}

export default forwardRef<ChatInputRef, ChatInputProps>(function ChatInput(
  { agent, onSendMessage, onEstimateChange, disabled = false },
  ref
) {
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useImperativeHandle(ref, () => ({
    focus: () => textareaRef.current?.focus(),
    clear: () => {
      setInput('');
      setAttachments([]);
    }
  }));

  // Calculate estimates when input changes
  const updateEstimates = (text: string) => {
    const cost = calculateEstimatedCost(text.length, agent, 'gpt-4o');
    const time = calculateEstimatedTime(text.length, 'gpt-4o');
    onEstimateChange(cost, time);
  };

  const handleInputChange = (value: string) => {
    if (value.length <= agent.capabilities.maxInputLength) {
      setInput(value);
      updateEstimates(value);
    }
  };

  const handleSend = () => {
    if (!input.trim() && attachments.length === 0) return;
    
    onSendMessage(input.trim(), attachments);
    setInput('');
    setAttachments([]);
    onEstimateChange(0, 0);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      const extension = '.' + file.name.split('.').pop()?.toLowerCase();
      return agent.capabilities.supportedFileTypes.includes(extension);
    });
    
    setAttachments(prev => [...prev, ...validFiles]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => {
      const extension = '.' + file.name.split('.').pop()?.toLowerCase();
      return agent.capabilities.supportedFileTypes.includes(extension);
    });
    
    setAttachments(prev => [...prev, ...validFiles]);
  };

  const toggleRecording = () => {
    if (!agent.capabilities.acceptsAudio) return;
    setIsRecording(!isRecording);
    // Audio recording implementation would go here
  };

  const canSend = (input.trim().length > 0 || attachments.length > 0) && !disabled;
  const remainingChars = agent.capabilities.maxInputLength - input.length;

  return (
    <div className="border-t border-blue-500/20 bg-black/20">
      
      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="p-4 border-b border-blue-500/10">
          <div className="flex flex-wrap gap-2">
            {attachments.map((file, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 px-3 py-2 admin-card rounded-lg"
              >
                <FileText className="w-4 h-4 admin-text-blue" />
                <span className="text-sm admin-text-smoke truncate max-w-32">
                  {file.name}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeAttachment(index)}
                  className="h-6 w-6 p-0 admin-text-smoke hover:text-red-400"
                >
                  <X className="w-3 h-3" />
                </Button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Main Input Area */}
      <div 
        className={`p-4 ${isDragging ? 'bg-blue-500/10 border-blue-500/30' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        
        {/* Agent Mode Indicator */}
        <div className="flex items-center gap-3 mb-3">
          <Badge className={`${agent.color} text-white`}>
            {agent.mode.toUpperCase()}
          </Badge>
          <span className="text-sm admin-text-smoke">
            Modo: {agent.description}
          </span>
        </div>

        {/* Input Container */}
        <div className="relative">
          
          {/* Textarea */}
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={agent.inputPlaceholder}
            disabled={disabled}
            className={`
              min-h-[60px] max-h-40 resize-none pr-32
              bg-black/50 border-blue-500/20 admin-text-smoke placeholder:admin-text-smoke/50
              focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/30
              ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
            `}
            rows={2}
          />

          {/* Input Actions */}
          <div className="absolute bottom-3 right-3 flex items-center gap-2">
            
            {/* File Upload */}
            {agent.capabilities.acceptsFiles && (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept={agent.capabilities.supportedFileTypes.join(',')}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={disabled}
                  className="h-8 w-8 p-0 admin-text-smoke hover:admin-text-blue"
                  title="Anexar arquivo"
                >
                  <Paperclip className="w-4 h-4" />
                </Button>
              </>
            )}

            {/* URL Input (for YouTube, etc.) */}
            {agent.capabilities.acceptsUrls && (
              <Button
                variant="ghost"
                size="sm"
                disabled={disabled}
                className="h-8 w-8 p-0 admin-text-smoke hover:admin-text-blue"
                title="Inserir URL"
              >
                <Link className="w-4 h-4" />
              </Button>
            )}

            {/* Audio Recording */}
            {agent.capabilities.acceptsAudio && (
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleRecording}
                disabled={disabled}
                className={`h-8 w-8 p-0 ${
                  isRecording 
                    ? 'text-red-400 hover:text-red-300' 
                    : 'admin-text-smoke hover:admin-text-blue'
                }`}
                title={isRecording ? "Parar gravação" : "Gravar áudio"}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
            )}

            {/* Send Button */}
            <Button
              onClick={handleSend}
              disabled={!canSend}
              className={`h-8 w-8 p-0 ${
                canSend 
                  ? 'admin-bg-blue hover:opacity-90' 
                  : 'bg-gray-600 cursor-not-allowed'
              }`}
              title="Enviar mensagem"
            >
              {disabled ? (
                <Loader className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Input Stats */}
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-4">
            
            {/* Character Count */}
            <span className={`text-xs ${
              remainingChars < 100 ? 'text-red-400' : 
              remainingChars < 500 ? 'admin-text-orange' : 
              'admin-text-smoke'
            }`}>
              {input.length}/{agent.capabilities.maxInputLength}
            </span>

            {/* File Types Supported */}
            {agent.capabilities.acceptsFiles && (
              <span className="text-xs admin-text-smoke">
                Suporta: {agent.capabilities.supportedFileTypes.join(', ')}
              </span>
            )}
          </div>

          {/* Quick Suggestions */}
          {input.length === 0 && (
            <div className="flex gap-2">
              {agent.suggestions.slice(0, 2).map((suggestion, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleInputChange(suggestion)}
                  className="text-xs admin-text-smoke hover:admin-text-blue px-2 py-1 h-auto"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          )}
        </div>

        {/* Drag & Drop Overlay */}
        {isDragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 bg-blue-500/20 border-2 border-dashed border-blue-500/50 rounded-lg flex items-center justify-center"
          >
            <div className="text-center">
              <Image className="w-12 h-12 admin-text-blue mx-auto mb-2" />
              <p className="text-lg font-semibold admin-text-blue">
                Solte os arquivos aqui
              </p>
              <p className="text-sm admin-text-smoke">
                Tipos suportados: {agent.capabilities.supportedFileTypes.join(', ')}
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
});