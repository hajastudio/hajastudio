import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronDown, 
  Settings,
  MoreVertical,
  Zap,
  Menu
} from 'lucide-react';
import MessageBubble from './MessageBubble';
import Composer from './Composer';
import StreamingIndicator from './StreamingIndicator';
import UpsellModal from './UpsellModal';
import { useChatMessages } from '@/hooks/useChatMessages';
import { useTokenEstimate } from '@/hooks/useTokenEstimate';
import type { Agent, ChatThread, ChatMessage } from '@/types/agents';

interface ChatAreaProps {
  selectedAgent: Agent | null;
  currentThread: ChatThread | null;
  onThreadUpdate: (thread: ChatThread | null) => void;
  user: any;
  showContextPanel: boolean;
  onToggleContext: () => void;
}

export default function ChatArea({
  selectedAgent,
  currentThread,
  onThreadUpdate,
  user,
  showContextPanel,
  onToggleContext
}: ChatAreaProps) {
  const [showUpsell, setShowUpsell] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const {
    messages,
    sendMessage,
    isLoading,
    error,
    retryLastMessage
  } = useChatMessages(currentThread?.id, selectedAgent?.id);

  const {
    estimateTokens,
    estimatedCost,
    isEstimating
  } = useTokenEstimate(selectedAgent?.id);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (content: string, attachments = []) => {
    if (!selectedAgent) return;

    try {
      await sendMessage(content, attachments);
      
      // Update credits after successful message
      // This would normally be handled by the backend
      const creditsUsed = estimatedCost || 1;
      // Update user credits in global state
      
    } catch (error: any) {
      if (error.status === 402) {
        setShowUpsell(true);
      }
    }
  };

  const getPlaceholderMessage = () => {
    if (!selectedAgent) {
      return "Selecione um agente para começar a conversar...";
    }
    
    const placeholders = {
      'design-matrix': 'Descreva sua landing page ou interface que precisa otimizar...',
      'vibe-code': 'Qual código você quer revisar ou funcionalidade implementar?',
      'roteirista': 'Que tipo de vídeo você quer criar? Qual o tema e duração?',
      'youtube-analyst': 'Cole a URL do vídeo do YouTube que quer analisar...',
      'branding-social': 'Conte sobre sua marca e objetivos de comunicação...',
      'viral-agent': 'Que tipo de conteúdo viral você quer criar?'
    };
    
    return placeholders[selectedAgent.id] || `Converse com ${selectedAgent.name}...`;
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Top Bar */}
      <div className="p-4 border-b border-[var(--smoke)]/20 glass-morphism">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {/* Agent Info */}
            {selectedAgent ? (
              <div className="flex items-center gap-3">
                <div 
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-white neon-glow"
                  style={{ backgroundColor: selectedAgent.color }}
                >
                  <span className="font-bold text-sm">{selectedAgent.avatar}</span>
                </div>
                
                <div>
                  <h2 className="font-orbitron font-semibold text-white">
                    {selectedAgent.name}
                  </h2>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-[var(--smoke)]/70">
                      {selectedAgent.defaultModel}
                    </span>
                    <div className="w-1 h-1 bg-[var(--smoke)]/30 rounded-full" />
                    <span className="text-[var(--smoke)]/70 capitalize">
                      {selectedAgent.tone}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[var(--smoke)]/10 rounded-xl flex items-center justify-center">
                  <Zap className="w-5 h-5 text-[var(--smoke)]/30" />
                </div>
                <div>
                  <h2 className="font-orbitron font-semibold text-white">
                    Chat Multi-IA
                  </h2>
                  <p className="text-xs text-[var(--smoke)]/70">
                    Selecione um agente para começar
                  </p>
                </div>
              </div>
            )}

            {/* Thread Info */}
            {currentThread && (
              <div className="ml-4 pl-4 border-l border-[var(--smoke)]/20">
                <p className="text-sm text-white font-medium">
                  {currentThread.title}
                </p>
                <p className="text-xs text-[var(--smoke)]/70">
                  {currentThread.messages.length} mensagens
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3">
            {/* Token Counter */}
            {selectedAgent && (
              <div className="flex items-center gap-2 px-3 py-1 glass-morphism rounded-lg">
                <Zap className="w-4 h-4 text-[var(--orange)]" />
                <span className="text-sm text-white font-medium">
                  {user?.credits || 0}
                </span>
                {isEstimating && estimatedCost && (
                  <span className="text-xs text-[var(--smoke)]/70">
                    (~{estimatedCost})
                  </span>
                )}
              </div>
            )}

            {/* Context Toggle */}
            <button
              onClick={onToggleContext}
              className={`p-2 rounded-lg transition-colors ${
                showContextPanel
                  ? 'bg-[var(--blue)]/20 text-[var(--blue)]'
                  : 'text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5'
              }`}
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* More Options */}
            <button className="p-2 rounded-lg text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Welcome Message */}
        {!selectedAgent && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <div className="w-16 h-16 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center mx-auto mb-6 neon-glow">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-orbitron font-bold text-white mb-2">
              Bem-vindo ao Chat Multi-IA
            </h3>
            <p className="text-[var(--smoke)]/70 mb-6">
              Selecione um agente especializado para começar sua conversa
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
              <div className="glass-morphism p-4 rounded-xl">
                <h4 className="font-medium text-white mb-2">🎨 Design & UI/UX</h4>
                <p className="text-sm text-[var(--smoke)]/70">
                  DesignMatrix para interfaces que convertem
                </p>
              </div>
              <div className="glass-morphism p-4 rounded-xl">
                <h4 className="font-medium text-white mb-2">💻 Desenvolvimento</h4>
                <p className="text-sm text-[var(--smoke)]/70">
                  Vibe Code para arquitetura e código limpo
                </p>
              </div>
              <div className="glass-morphism p-4 rounded-xl">
                <h4 className="font-medium text-white mb-2">🎬 Conteúdo Viral</h4>
                <p className="text-sm text-[var(--smoke)]/70">
                  Roteirista para scripts que engajam
                </p>
              </div>
              <div className="glass-morphism p-4 rounded-xl">
                <h4 className="font-medium text-white mb-2">📊 Análise & SEO</h4>
                <p className="text-sm text-[var(--smoke)]/70">
                  YouTube Analyst para otimização
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Agent Selected but no messages */}
        {selectedAgent && messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-8"
          >
            <div 
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow"
              style={{ backgroundColor: selectedAgent.color }}
            >
              <span className="text-2xl font-bold text-white">
                {selectedAgent.avatar}
              </span>
            </div>
            <h3 className="text-xl font-orbitron font-bold text-white mb-2">
              {selectedAgent.name}
            </h3>
            <p className="text-[var(--smoke)]/70 mb-4">
              {selectedAgent.description}
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {selectedAgent.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 text-xs rounded-full"
                  style={{
                    backgroundColor: `${selectedAgent.color}20`,
                    color: selectedAgent.color
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        )}

        {/* Messages */}
        <AnimatePresence>
          {messages.map((message) => (
            <MessageBubble
              key={message.id}
              message={message}
              agent={selectedAgent}
              onRetry={message.status === 'error' ? retryLastMessage : undefined}
            />
          ))}
        </AnimatePresence>

        {/* Streaming Indicator */}
        {isStreaming && selectedAgent && (
          <StreamingIndicator agent={selectedAgent} />
        )}

        {/* Error State */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center gap-3 p-4 glass-morphism rounded-xl border border-red-500/30 bg-red-500/10"
          >
            <span className="text-red-400 text-sm">
              Erro ao enviar mensagem
            </span>
            <button
              onClick={retryLastMessage}
              className="px-3 py-1 bg-red-500/20 text-red-400 rounded-lg text-sm hover:bg-red-500/30 transition-colors"
            >
              Tentar Novamente
            </button>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Composer */}
      <div className="border-t border-[var(--smoke)]/20">
        <Composer
          onSendMessage={handleSendMessage}
          placeholder={getPlaceholderMessage()}
          disabled={!selectedAgent || isLoading}
          isLoading={isLoading}
          selectedAgent={selectedAgent}
          onEstimateTokens={estimateTokens}
        />
      </div>

      {/* Upsell Modal */}
      <UpsellModal
        isOpen={showUpsell}
        onClose={() => setShowUpsell(false)}
        userCredits={user?.credits || 0}
        requiredCredits={estimatedCost || 1}
      />
    </div>
  );
}