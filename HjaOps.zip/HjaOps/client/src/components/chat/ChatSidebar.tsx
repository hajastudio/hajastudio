import { useQuery } from "@tanstack/react-query";
import type { Chat, Agent } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface ChatSidebarProps {
  onSelectChat: (chat: Chat) => void;
  selectedChatId?: string;
}

export function ChatSidebar({ onSelectChat, selectedChatId }: ChatSidebarProps) {
  const { data: chats = [] } = useQuery({
    queryKey: ["/api/chats"],
  });

  const { data: agents = [] } = useQuery({
    queryKey: ["/api/agents"],
  });

  const getAgentById = (agentId: string) => {
    return agents.find((agent: Agent) => agent.id === agentId);
  };

  return (
    <div className="w-80 border-r border-border bg-secondary/30 p-4" data-testid="chat-sidebar">
      <div className="flex items-center gap-2 mb-6">
        <i className="fas fa-comments text-primary"></i>
        <h3 className="font-semibold">Chat History</h3>
      </div>
      
      <div className="space-y-2">
        {chats.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="no-chats">
            No chats yet
          </div>
        ) : (
          chats.map((chat: Chat) => {
            const agent = getAgentById(chat.agentId);
            const isSelected = chat.id === selectedChatId;
            
            return (
              <div 
                key={chat.id}
                className={`p-3 rounded-lg cursor-pointer transition-colors ${
                  isSelected 
                    ? 'bg-primary/20 border border-primary/30' 
                    : 'bg-secondary/50 hover:bg-secondary/70'
                }`}
                onClick={() => onSelectChat(chat)}
                data-testid={`chat-item-${chat.id}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <img 
                    src={agent?.avatarUrl || "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=24&h=24"} 
                    alt="Agent" 
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <span className="text-sm font-medium" data-testid={`chat-agent-${chat.id}`}>
                    {agent?.name || 'Unknown Agent'}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground truncate" data-testid={`chat-title-${chat.id}`}>
                  {chat.title || 'New conversation'}
                </p>
                <span className="text-xs text-muted-foreground" data-testid={`chat-time-${chat.id}`}>
                  {formatDistanceToNow(new Date(chat.updatedAt), { addSuffix: true })}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
