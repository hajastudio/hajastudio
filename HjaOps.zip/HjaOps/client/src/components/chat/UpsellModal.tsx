import { motion, AnimatePresence } from 'framer-motion';
import { X, Zap, Crown, Star, CheckCircle } from 'lucide-react';

interface UpsellModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCredits: number;
  requiredCredits: number;
}

export default function UpsellModal({
  isOpen,
  onClose,
  userCredits,
  requiredCredits
}: UpsellModalProps) {
  const creditShortfall = requiredCredits - userCredits;

  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      credits: 100,
      price: 9.90,
      popular: false,
      features: ['100 créditos mensais', 'Todos os agentes', 'Suporte básico'],
      icon: Zap,
      color: '#00BFFF'
    },
    {
      id: 'pro',
      name: 'Pro',
      credits: 300,
      bonus: 50,
      price: 24.90,
      popular: true,
      features: ['300 + 50 créditos bônus', 'Acesso prioritário', 'Suporte premium', 'Histórico ilimitado'],
      icon: Star,
      color: '#FF6A00'
    },
    {
      id: 'premium',
      name: 'Premium',
      credits: 1000,
      bonus: 200,
      price: 49.90,
      popular: false,
      features: ['1000 + 200 créditos bônus', 'Acesso antecipado', 'Suporte VIP', 'Relatórios avançados'],
      icon: Crown,
      color: '#9F7AEA'
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="w-full max-w-4xl glass-morphism rounded-2xl border border-[var(--orange)]/30 overflow-hidden">
              {/* Header */}
              <div className="p-6 border-b border-[var(--smoke)]/20 bg-gradient-to-r from-[var(--orange)]/10 to-red-500/10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center">
                      <Zap className="w-6 h-6 text-[var(--orange)]" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-orbitron font-bold text-white">
                        Créditos Insuficientes
                      </h2>
                      <p className="text-[var(--smoke)]/70">
                        Você precisa de mais {creditShortfall} créditos para continuar
                      </p>
                    </div>
                  </div>
                  
                  <button
                    onClick={onClose}
                    className="p-2 rounded-lg text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/10 transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {/* Current Status */}
              <div className="p-6 border-b border-[var(--smoke)]/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[var(--smoke)]/70 mb-1">Seus créditos atuais:</p>
                    <p className="text-2xl font-orbitron font-bold text-white">{userCredits}</p>
                  </div>
                  <div>
                    <p className="text-[var(--smoke)]/70 mb-1">Créditos necessários:</p>
                    <p className="text-2xl font-orbitron font-bold text-[var(--orange)]">{requiredCredits}</p>
                  </div>
                  <div>
                    <p className="text-[var(--smoke)]/70 mb-1">Faltam:</p>
                    <p className="text-2xl font-orbitron font-bold text-red-400">{creditShortfall}</p>
                  </div>
                </div>
              </div>

              {/* Plans */}
              <div className="p-6">
                <h3 className="text-xl font-orbitron font-bold text-white mb-6 text-center">
                  Escolha seu Plano
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {plans.map((plan) => {
                    const Icon = plan.icon;
                    const totalCredits = plan.credits + (plan.bonus || 0);
                    const canCover = totalCredits >= creditShortfall;
                    
                    return (
                      <motion.div
                        key={plan.id}
                        className={`relative p-6 rounded-2xl border transition-all duration-300 cursor-pointer ${
                          plan.popular
                            ? 'border-[var(--orange)] bg-gradient-to-b from-[var(--orange)]/10 to-transparent'
                            : canCover
                            ? 'border-[var(--blue)]/30 hover:border-[var(--blue)]/50'
                            : 'border-[var(--smoke)]/20 opacity-60'
                        }`}
                        whileHover={canCover ? { scale: 1.02 } : {}}
                        whileTap={canCover ? { scale: 0.98 } : {}}
                      >
                        {/* Popular Badge */}
                        {plan.popular && (
                          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                            <span className="bg-[var(--orange)] text-white text-sm font-bold px-4 py-1 rounded-full">
                              MAIS POPULAR
                            </span>
                          </div>
                        )}

                        {/* Can Cover Badge */}
                        {canCover && !plan.popular && (
                          <div className="absolute -top-3 right-4">
                            <div className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" />
                              SUFICIENTE
                            </div>
                          </div>
                        )}

                        {/* Plan Header */}
                        <div className="text-center mb-6">
                          <div 
                            className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
                            style={{ backgroundColor: `${plan.color}20` }}
                          >
                            <Icon 
                              className="w-8 h-8"
                              style={{ color: plan.color }}
                            />
                          </div>
                          
                          <h4 className="text-xl font-orbitron font-bold text-white mb-2">
                            {plan.name}
                          </h4>
                          
                          <div className="mb-2">
                            <span className="text-3xl font-orbitron font-bold text-white">
                              R$ {plan.price.toFixed(2)}
                            </span>
                            <span className="text-[var(--smoke)]/70 text-sm">/mês</span>
                          </div>
                          
                          <p className="text-sm text-[var(--smoke)]/70">
                            {plan.credits} créditos
                            {plan.bonus && (
                              <span className="text-[var(--orange)]"> + {plan.bonus} bônus</span>
                            )}
                          </p>
                        </div>

                        {/* Features */}
                        <div className="space-y-3 mb-6">
                          {plan.features.map((feature, index) => (
                            <div key={index} className="flex items-center gap-3">
                              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                              <span className="text-sm text-[var(--smoke)]/80">{feature}</span>
                            </div>
                          ))}
                        </div>

                        {/* Action Button */}
                        <button
                          disabled={!canCover}
                          className={`w-full py-3 px-4 rounded-xl font-medium transition-all duration-300 ${
                            plan.popular
                              ? 'bg-gradient-to-r from-[var(--orange)] to-orange-600 text-white hover:shadow-lg neon-glow'
                              : canCover
                              ? 'bg-gradient-to-r from-[var(--blue)] to-blue-600 text-white hover:shadow-lg'
                              : 'bg-[var(--smoke)]/10 text-[var(--smoke)]/40 cursor-not-allowed'
                          }`}
                        >
                          {canCover ? 'Escolher Plano' : 'Insuficiente'}
                        </button>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Purchase */}
              <div className="p-6 border-t border-[var(--smoke)]/20">
                <div className="text-center">
                  <p className="text-[var(--smoke)]/70 mb-4">
                    Ou compre apenas os créditos que precisa agora
                  </p>
                  
                  <div className="flex items-center justify-center gap-4">
                    <button className="px-6 py-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors">
                      {creditShortfall} créditos - R$ {(creditShortfall * 0.15).toFixed(2)}
                    </button>
                    
                    <button className="px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white rounded-xl font-medium hover:shadow-lg transition-all duration-300 neon-glow">
                      Comprar Agora
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}