import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Star, 
  Users, 
  Zap,
  Code,
  Video,
  Palette,
  BarChart3,
  Megaphone,
  TrendingUp
} from 'lucide-react';
import agentsData from '@/data/agents.json';
import type { Agent } from '@/types/agents';

interface AgentPickerProps {
  selectedAgent: Agent | null;
  onAgentSelect: (agent: Agent) => void;
  searchQuery: string;
}

const iconMap = {
  'Palette': Palette,
  'Code': Code,
  'Video': Video,
  'BarChart3': BarChart3,
  'Megaphone': Megaphone,
  'TrendingUp': TrendingUp
};

export default function AgentPicker({ 
  selectedAgent, 
  onAgentSelect, 
  searchQuery 
}: AgentPickerProps) {
  const agents = agentsData as Agent[];
  
  const filteredAgents = agents.filter(agent => 
    agent.active &&
    (agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
     agent.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
     agent.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  const getAgentStats = (agentId: string) => {
    // Mock stats - seria vindo do backend
    const mockStats = {
      'design-matrix': { rating: 4.9, conversations: 1250, popularity: 95 },
      'vibe-code': { rating: 4.8, conversations: 890, popularity: 87 },
      'roteirista': { rating: 4.9, conversations: 2100, popularity: 98 },
      'youtube-analyst': { rating: 4.7, conversations: 750, popularity: 82 },
      'branding-social': { rating: 4.6, conversations: 650, popularity: 75 },
      'viral-agent': { rating: 4.8, conversations: 1800, popularity: 92 }
    };
    
    return mockStats[agentId] || { rating: 4.5, conversations: 100, popularity: 50 };
  };

  return (
    <div className="p-4 space-y-3 overflow-y-auto">
      {filteredAgents.map((agent, index) => {
        const stats = getAgentStats(agent.id);
        const IconComponent = iconMap[agent.icon] || Play;
        const isSelected = selectedAgent?.id === agent.id;

        return (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`relative p-4 rounded-xl cursor-pointer transition-all duration-300 ${
              isSelected
                ? 'glass-morphism border border-[var(--blue)]/50 shadow-lg'
                : 'glass-morphism hover:bg-[var(--smoke)]/5'
            }`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onAgentSelect(agent)}
            style={{
              boxShadow: isSelected ? `0 0 20px ${agent.color}30` : undefined
            }}
            data-testid={`agent-${agent.id}`}
          >
            {/* Selected Indicator */}
            {isSelected && (
              <motion.div
                layoutId="selectedAgent"
                className="absolute inset-0 rounded-xl"
                style={{
                  background: `linear-gradient(135deg, ${agent.color}10, transparent)`,
                  border: `1px solid ${agent.color}50`
                }}
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}

            <div className="relative">
              {/* Header */}
              <div className="flex items-center gap-3 mb-3">
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-white neon-glow"
                  style={{ backgroundColor: agent.color }}
                >
                  <IconComponent className="w-6 h-6" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-orbitron font-semibold text-white truncate">
                    {agent.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 text-yellow-400 fill-current" />
                      <span className="text-xs text-[var(--smoke)]/70">{stats.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-3 h-3 text-[var(--smoke)]/70" />
                      <span className="text-xs text-[var(--smoke)]/70">
                        {stats.conversations.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-6 h-6 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: agent.color }}
                  >
                    <Play className="w-3 h-3 text-white fill-current" />
                  </motion.div>
                )}
              </div>

              {/* Description */}
              <p className="text-sm text-[var(--smoke)]/80 mb-3 line-clamp-2">
                {agent.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1 mb-3">
                {agent.tags.slice(0, 3).map((tag) => (
                  <span 
                    key={tag}
                    className="px-2 py-1 text-xs rounded-full"
                    style={{
                      backgroundColor: `${agent.color}20`,
                      color: agent.color
                    }}
                  >
                    {tag}
                  </span>
                ))}
                {agent.tags.length > 3 && (
                  <span className="px-2 py-1 text-xs rounded-full bg-[var(--smoke)]/10 text-[var(--smoke)]/60">
                    +{agent.tags.length - 3}
                  </span>
                )}
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1">
                  <Zap className="w-3 h-3 text-[var(--orange)]" />
                  <span className="text-[var(--smoke)]/60">
                    {stats.popularity}% popularidade
                  </span>
                </div>
                
                <div className="flex items-center gap-1">
                  <div 
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: agent.color }}
                  />
                  <span className="text-[var(--smoke)]/60 capitalize">
                    {agent.tone.split(' ')[0]}
                  </span>
                </div>
              </div>

              {/* Popularity Bar */}
              <div className="mt-2 w-full bg-[var(--smoke)]/10 rounded-full h-1">
                <motion.div
                  className="h-1 rounded-full"
                  style={{ backgroundColor: agent.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${stats.popularity}%` }}
                  transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
                />
              </div>
            </div>
          </motion.div>
        );
      })}

      {filteredAgents.length === 0 && (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-[var(--smoke)]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Play className="w-8 h-8 text-[var(--smoke)]/30" />
          </div>
          <p className="text-[var(--smoke)]/70">
            Nenhum agente encontrado para "{searchQuery}"
          </p>
        </div>
      )}
    </div>
  );
}