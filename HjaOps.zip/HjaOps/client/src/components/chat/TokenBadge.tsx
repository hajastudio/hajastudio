import { motion } from 'framer-motion';
import { Zap, AlertTriangle } from 'lucide-react';

interface TokenBadgeProps {
  credits: number;
  isLow?: boolean;
  className?: string;
  showTooltip?: boolean;
}

export default function TokenBadge({ 
  credits, 
  isLow = false, 
  className = '',
  showTooltip = true 
}: TokenBadgeProps) {
  return (
    <div className={`relative group ${className}`}>
      <motion.div
        className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-all duration-300 ${
          isLow
            ? 'bg-red-500/20 text-red-400 border border-red-500/30'
            : 'bg-[var(--blue)]/20 text-[var(--blue)] border border-[var(--blue)]/30'
        }`}
        animate={isLow ? {
          scale: [1, 1.05, 1],
          opacity: [1, 0.8, 1]
        } : {}}
        transition={isLow ? {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        } : {}}
      >
        {isLow ? (
          <AlertTriangle className="w-4 h-4" />
        ) : (
          <Zap className="w-4 h-4" />
        )}
        
        <span className="font-bold">
          {credits.toLocaleString()}
        </span>
        
        <span className="text-xs opacity-70">
          tokens
        </span>
      </motion.div>

      {/* Tooltip */}
      {showTooltip && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-50">
          <div className="bg-black/90 text-white text-xs px-3 py-2 rounded-lg whitespace-nowrap">
            {isLow ? (
              <>
                <div className="text-red-400 font-medium mb-1">Créditos Baixos!</div>
                <div>~1-3 tokens por mensagem</div>
                <div>Considere recarregar</div>
              </>
            ) : (
              <>
                <div className="font-medium mb-1">Seus Tokens</div>
                <div>~1-3 tokens por mensagem</div>
                <div>Baseado no tamanho do texto</div>
              </>
            )}
            
            {/* Arrow */}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black/90" />
          </div>
        </div>
      )}
    </div>
  );
}