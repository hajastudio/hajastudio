import { 
  FileText, 
  Code, 
  Palette, 
  Youtube, 
  BarChart3,
  Lightbulb,
  Target,
  Zap,
  Camera,
  Music
} from 'lucide-react';

export interface AgentMode {
  id: string;
  name: string;
  description: string;
  mode: string;
  color: string;
  avatar: string;
  welcomeMessage: string;
  instructions: string;
  outputType: 'text' | 'code' | 'media' | 'table' | 'action-result';
  defaultModel: string;
  availableModels: string[];
  inputPlaceholder: string;
  suggestions: string[];
  quickActions?: Array<{
    id: string;
    label: string;
    icon: any;
    color: string;
    action: () => void;
  }>;
  // Capabilities specific to each agent
  capabilities: {
    acceptsFiles: boolean;
    acceptsUrls: boolean;
    acceptsAudio: boolean;
    supportedFileTypes: string[];
    maxInputLength: number;
    costMultiplier: number;
  };
}

export const agentModes: Record<string, AgentMode> = {
  
  // ROTEIRO - Script & Storytelling Agent
  roteiro: {
    id: 'roteiro',
    name: 'Roteirista IA',
    description: 'Especialista em roteiros, storytelling e narrativas',
    mode: 'roteiro',
    color: 'bg-purple-600',
    avatar: '/avatars/roteirista.png',
    welcomeMessage: 'Vamos criar histórias incríveis!',
    instructions: 'Especializado em roteiros cinematográficos, séries, documentários e storytelling para marcas. Forneça o tema ou contexto e criarei uma narrativa envolvente.',
    outputType: 'text',
    defaultModel: 'gpt-4o',
    availableModels: ['gpt-4o', 'claude-3', 'groq'],
    inputPlaceholder: 'Descreva a ideia do seu roteiro, personagens ou tema...',
    suggestions: [
      'Roteiro de 30s para produto tech',
      'Documentário sobre sustentabilidade',
      'Série web sobre empreendedorismo',
      'Vídeo institucional corporativo'
    ],
    quickActions: [
      {
        id: 'format-screenplay',
        label: 'Formatar Roteiro',
        icon: FileText,
        color: 'bg-purple-600',
        action: () => console.log('Formatting screenplay...')
      },
      {
        id: 'character-development',
        label: 'Desenvolver Personagens',
        icon: Target,
        color: 'admin-bg-blue',
        action: () => console.log('Developing characters...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: true,
      acceptsAudio: false,
      supportedFileTypes: ['.pdf', '.docx', '.txt'],
      maxInputLength: 4000,
      costMultiplier: 1.2
    }
  },

  // CODE - Development & Programming Agent  
  code: {
    id: 'code',
    name: 'Vibe Code',
    description: 'Desenvolvedor full-stack especialista em React, Node.js e IA',
    mode: 'código',
    color: 'admin-bg-blue',
    avatar: '/avatars/developer.png',
    welcomeMessage: 'Vamos codar algo incrível!',
    instructions: 'Especialista em desenvolvimento web moderno, React, TypeScript, Node.js, APIs e integração com IA. Posso ajudar com código, arquitetura e debugging.',
    outputType: 'code',
    defaultModel: 'groq',
    availableModels: ['groq', 'gpt-4o', 'claude-3'],
    inputPlaceholder: 'Descreva o componente, função ou problema que precisa resolver...',
    suggestions: [
      'Componente React com TypeScript',
      'API REST com Node.js',
      'Integração com banco de dados',
      'Otimização de performance'
    ],
    quickActions: [
      {
        id: 'run-code',
        label: 'Executar',
        icon: Zap,
        color: 'bg-green-600',
        action: () => console.log('Running code...')
      },
      {
        id: 'optimize',
        label: 'Otimizar',
        icon: Target,
        color: 'admin-bg-orange',
        action: () => console.log('Optimizing code...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: true,
      acceptsAudio: false,
      supportedFileTypes: ['.js', '.ts', '.tsx', '.json', '.css'],
      maxInputLength: 8000,
      costMultiplier: 0.8
    }
  },

  // BRANDING - Brand & Design Agent
  branding: {
    id: 'branding',
    name: 'Brand Expert',
    description: 'Especialista em branding, identidade visual e estratégia de marca',
    mode: 'branding',
    color: 'admin-bg-orange',
    avatar: '/avatars/designer.png',
    welcomeMessage: 'Vamos construir uma marca forte!',
    instructions: 'Especializado em desenvolvimento de marca, identidade visual, posicionamento, tom de voz e estratégias de branding. Forneça informações sobre sua marca ou projeto.',
    outputType: 'text',
    defaultModel: 'gpt-4o',
    availableModels: ['gpt-4o', 'claude-3', 'groq'],
    inputPlaceholder: 'Conte sobre sua marca, público-alvo ou desafio de branding...',
    suggestions: [
      'Identidade visual para startup',
      'Tom de voz para rede social',
      'Posicionamento de produto',
      'Estratégia de rebranding'
    ],
    quickActions: [
      {
        id: 'brand-guidelines',
        label: 'Manual da Marca',
        icon: Palette,
        color: 'admin-bg-orange',
        action: () => console.log('Creating brand guidelines...')
      },
      {
        id: 'competitor-analysis',
        label: 'Análise Competitiva',
        icon: BarChart3,
        color: 'admin-bg-blue',
        action: () => console.log('Analyzing competitors...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: true,
      acceptsAudio: false,
      supportedFileTypes: ['.png', '.jpg', '.pdf', '.ai'],
      maxInputLength: 3000,
      costMultiplier: 1.1
    }
  },

  // YOUTUBE - Video Analysis & Strategy Agent
  youtube: {
    id: 'youtube',
    name: 'YouTube Expert',
    description: 'Analista de vídeos, SEO e estratégias para YouTube',
    mode: 'análise de vídeo',
    color: 'bg-red-600',
    avatar: '/avatars/youtube.png',
    welcomeMessage: 'Vamos analisar e otimizar seus vídeos!',
    instructions: 'Especializado em análise de vídeos do YouTube, otimização de SEO, estratégias de crescimento, thumbnails e engajamento. Cole uma URL ou descreva seu canal.',
    outputType: 'table',
    defaultModel: 'gpt-4o',
    availableModels: ['gpt-4o', 'claude-3'],
    inputPlaceholder: 'Cole a URL do vídeo/canal ou descreva sua estratégia...',
    suggestions: [
      'Analisar performance do vídeo',
      'Otimizar título e descrição',
      'Estratégia de thumbnail',
      'Plano de conteúdo mensal'
    ],
    quickActions: [
      {
        id: 'seo-optimize',
        label: 'Otimizar SEO',
        icon: Target,
        color: 'bg-red-600',
        action: () => console.log('Optimizing SEO...')
      },
      {
        id: 'thumbnail-suggestions',
        label: 'Sugerir Thumbnails',
        icon: Camera,
        color: 'admin-bg-orange',
        action: () => console.log('Suggesting thumbnails...')
      }
    ],
    capabilities: {
      acceptsFiles: false,
      acceptsUrls: true,
      acceptsAudio: true,
      supportedFileTypes: ['.mp4', '.mov'],
      maxInputLength: 2000,
      costMultiplier: 1.5
    }
  },

  // ANALYTICS - Data Analysis Agent
  analytics: {
    id: 'analytics',
    name: 'Data Analyst',
    description: 'Especialista em análise de dados e insights de negócio',
    mode: 'análise',
    color: 'bg-green-600',
    avatar: '/avatars/analyst.png',
    welcomeMessage: 'Vamos descobrir insights nos seus dados!',
    instructions: 'Especializado em análise de dados, métricas de performance, relatórios e insights acionáveis. Envie planilhas, gráficos ou descreva seus KPIs.',
    outputType: 'table',
    defaultModel: 'claude-3',
    availableModels: ['claude-3', 'gpt-4o', 'groq'],
    inputPlaceholder: 'Descreva os dados que precisa analisar ou suas métricas...',
    suggestions: [
      'Análise de vendas mensais',
      'Performance de campanhas',
      'Relatório de engajamento',
      'Previsão de crescimento'
    ],
    quickActions: [
      {
        id: 'generate-chart',
        label: 'Gerar Gráfico',
        icon: BarChart3,
        color: 'bg-green-600',
        action: () => console.log('Generating chart...')
      },
      {
        id: 'export-report',
        label: 'Exportar Relatório',
        icon: FileText,
        color: 'admin-bg-blue',
        action: () => console.log('Exporting report...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: false,
      acceptsAudio: false,
      supportedFileTypes: ['.xlsx', '.csv', '.json'],
      maxInputLength: 5000,
      costMultiplier: 1.0
    }
  },

  // CREATIVE - Creative & Ideation Agent
  creative: {
    id: 'creative',
    name: 'Creative Mind',
    description: 'Gerador de ideias criativas e campanhas inovadoras',
    mode: 'criativo',
    color: 'bg-pink-600',
    avatar: '/avatars/creative.png',
    welcomeMessage: 'Vamos criar algo único e impactante!',
    instructions: 'Especializado em brainstorming, ideação criativa, campanhas publicitárias e conceitos inovadores. Descreva seu briefing ou desafio criativo.',
    outputType: 'text',
    defaultModel: 'gpt-4o',
    availableModels: ['gpt-4o', 'claude-3'],
    inputPlaceholder: 'Descreva seu briefing criativo ou desafio de inovação...',
    suggestions: [
      'Campanha para lançamento',
      'Naming para produto',
      'Conceito de evento',
      'Estratégia viral'
    ],
    quickActions: [
      {
        id: 'brainstorm',
        label: 'Brainstorm',
        icon: Lightbulb,
        color: 'bg-pink-600',
        action: () => console.log('Starting brainstorm...')
      },
      {
        id: 'mood-board',
        label: 'Mood Board',
        icon: Palette,
        color: 'admin-bg-orange',
        action: () => console.log('Creating mood board...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: true,
      acceptsAudio: true,
      supportedFileTypes: ['.png', '.jpg', '.pdf', '.mp3'],
      maxInputLength: 3500,
      costMultiplier: 1.3
    }
  },

  // GENERAL - Default General Purpose Agent
  general: {
    id: 'general',
    name: 'Assistente IA',
    description: 'Assistente versátil para diversas tarefas',
    mode: 'geral',
    color: 'admin-bg-blue',
    avatar: '/avatars/general.png',
    welcomeMessage: 'Como posso ajudar você hoje?',
    instructions: 'Assistente geral capaz de ajudar com diversas tarefas: escrita, pesquisa, análise, planejamento e muito mais. Descreva o que precisa.',
    outputType: 'text',
    defaultModel: 'gpt-4o',
    availableModels: ['gpt-4o', 'claude-3', 'groq'],
    inputPlaceholder: 'No que posso ajudar você hoje?',
    suggestions: [
      'Escrever um artigo',
      'Planejar um projeto',
      'Analisar um problema',
      'Fazer uma pesquisa'
    ],
    quickActions: [
      {
        id: 'summarize',
        label: 'Resumir',
        icon: FileText,
        color: 'admin-bg-blue',
        action: () => console.log('Summarizing...')
      },
      {
        id: 'translate',
        label: 'Traduzir',
        icon: Target,
        color: 'admin-bg-orange',
        action: () => console.log('Translating...')
      }
    ],
    capabilities: {
      acceptsFiles: true,
      acceptsUrls: true,
      acceptsAudio: true,
      supportedFileTypes: ['.pdf', '.docx', '.txt', '.csv'],
      maxInputLength: 6000,
      costMultiplier: 1.0
    }
  }
};

// Utility functions
export const getAgentById = (id: string): AgentMode => {
  return agentModes[id] || agentModes.general;
};

export const calculateEstimatedCost = (
  inputLength: number, 
  agent: AgentMode, 
  model: string
): number => {
  const baseCost = model === 'gpt-4o' ? 0.15 : model === 'groq' ? 0.02 : 0.08;
  const lengthMultiplier = Math.max(1, inputLength / 1000);
  return baseCost * lengthMultiplier * agent.capabilities.costMultiplier;
};

export const calculateEstimatedTime = (
  inputLength: number,
  model: string
): number => {
  const baseTime = model === 'groq' ? 0.5 : model === 'gpt-4o' ? 3.2 : 1.8;
  const lengthMultiplier = Math.max(1, inputLength / 2000);
  return baseTime * lengthMultiplier;
};