import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FileText, 
  Target, 
  TrendingUp, 
  BarChart3, 
  Lightbulb, 
  Settings,
  Download,
  Share,
  Eye,
  Clock,
  Zap,
  DollarSign
} from 'lucide-react';
import type { Agent, ChatThread } from '@/types/agents';

interface ContextPanelProps {
  selectedAgent: Agent | null;
  currentThread: ChatThread | null;
  user: any;
}

export default function ContextPanel({ 
  selectedAgent, 
  currentThread, 
  user 
}: ContextPanelProps) {
  const [activeTab, setActiveTab] = useState<'briefing' | 'tools' | 'results' | 'metrics' | 'suggestions'>('briefing');

  const tabs = [
    { id: 'briefing', label: 'Briefing', icon: Target },
    { id: 'tools', label: 'Tools', icon: Settings },
    { id: 'results', label: 'Resultados', icon: FileText },
    { id: 'metrics', label: 'Métricas', icon: BarChart3 },
    { id: 'suggestions', label: 'Sugestões', icon: Lightbulb }
  ];

  const renderBriefingTab = () => (
    <div className="space-y-4">
      {selectedAgent ? (
        <>
          <div className="glass-morphism rounded-xl p-4">
            <h4 className="font-orbitron font-semibold text-white mb-3">
              Objetivo do {selectedAgent.name}
            </h4>
            <p className="text-sm text-[var(--smoke)]/80 mb-4">
              {selectedAgent.description}
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-[var(--smoke)]/60">Tom:</span>
                <span className="text-xs text-white capitalize">{selectedAgent.tone}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[var(--smoke)]/60">Modelo:</span>
                <span className="text-xs text-[var(--blue)]">{selectedAgent.defaultModel}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[var(--smoke)]/60">Modo:</span>
                <span className="text-xs text-white capitalize">{selectedAgent.uiMode}</span>
              </div>
            </div>
          </div>

          <div className="glass-morphism rounded-xl p-4">
            <h5 className="font-medium text-white mb-3">Especialidades</h5>
            <div className="flex flex-wrap gap-2">
              {selectedAgent.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 text-xs rounded-full"
                  style={{
                    backgroundColor: `${selectedAgent.color}20`,
                    color: selectedAgent.color
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="glass-morphism rounded-xl p-4">
            <h5 className="font-medium text-white mb-3">Configurações de Segurança</h5>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-[var(--smoke)]/70">Permite código:</span>
                <span className={selectedAgent.safety.allow_code ? 'text-green-400' : 'text-red-400'}>
                  {selectedAgent.safety.allow_code ? 'Sim' : 'Não'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--smoke)]/70">Permite imagens:</span>
                <span className={selectedAgent.safety.allow_images ? 'text-green-400' : 'text-red-400'}>
                  {selectedAgent.safety.allow_images ? 'Sim' : 'Não'}
                </span>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-8">
          <Target className="w-12 h-12 text-[var(--smoke)]/30 mx-auto mb-4" />
          <p className="text-[var(--smoke)]/70">
            Selecione um agente para ver o briefing
          </p>
        </div>
      )}
    </div>
  );

  const renderToolsTab = () => (
    <div className="space-y-4">
      {selectedAgent ? (
        <>
          <div className="glass-morphism rounded-xl p-4">
            <h4 className="font-orbitron font-semibold text-white mb-3">
              Ferramentas Disponíveis
            </h4>
            
            <div className="space-y-3">
              {selectedAgent.tools.map((tool) => {
                const toolConfig = {
                  'web-search': { name: 'Busca Web', icon: '🌐', desc: 'Pesquisar informações atualizadas' },
                  'doc-parse': { name: 'Analisar Docs', icon: '📄', desc: 'Extrair texto de documentos' },
                  'image-analysis': { name: 'Análise de Imagem', icon: '🖼️', desc: 'Analisar e descrever imagens' },
                  'code-analysis': { name: 'Análise de Código', icon: '⚡', desc: 'Revisar e otimizar código' },
                  'trend-analysis': { name: 'Análise de Trends', icon: '📈', desc: 'Identificar tendências virais' }
                };
                
                const config = toolConfig[tool] || { name: tool, icon: '🔧', desc: 'Ferramenta personalizada' };
                
                return (
                  <div key={tool} className="flex items-center gap-3 p-3 glass-morphism rounded-lg">
                    <span className="text-lg">{config.icon}</span>
                    <div>
                      <p className="text-sm font-medium text-white">{config.name}</p>
                      <p className="text-xs text-[var(--smoke)]/70">{config.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="glass-morphism rounded-xl p-4">
            <h5 className="font-medium text-white mb-3">Como Usar</h5>
            <div className="space-y-2 text-sm text-[var(--smoke)]/80">
              <p>• Digite <code className="px-1 py-0.5 bg-[var(--smoke)]/10 rounded text-[var(--blue)]">/</code> para ver ferramentas</p>
              <p>• Use <code className="px-1 py-0.5 bg-[var(--smoke)]/10 rounded text-[var(--blue)]">Cmd+Enter</code> para enviar</p>
              <p>• Anexe arquivos com o ícone 📎</p>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-8">
          <Settings className="w-12 h-12 text-[var(--smoke)]/30 mx-auto mb-4" />
          <p className="text-[var(--smoke)]/70">
            Selecione um agente para ver as ferramentas
          </p>
        </div>
      )}
    </div>
  );

  const renderResultsTab = () => (
    <div className="space-y-4">
      {currentThread && currentThread.messages.length > 0 ? (
        <>
          <div className="glass-morphism rounded-xl p-4">
            <h4 className="font-orbitron font-semibold text-white mb-3">
              Arquivos Gerados
            </h4>
            
            <div className="space-y-3">
              {[
                { name: 'roteiro_tiktok_v1.txt', type: 'text', size: '2.1 KB', time: '5 min atrás' },
                { name: 'landing_page_copy.md', type: 'markdown', size: '4.8 KB', time: '15 min atrás' },
                { name: 'component_refactor.jsx', type: 'code', size: '3.2 KB', time: '1h atrás' }
              ].map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 glass-morphism rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-[var(--blue)]" />
                    <div>
                      <p className="text-sm font-medium text-white">{file.name}</p>
                      <p className="text-xs text-[var(--smoke)]/70">{file.size} • {file.time}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button className="p-1 rounded text-[var(--smoke)]/70 hover:text-[var(--blue)] transition-colors">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-1 rounded text-[var(--smoke)]/70 hover:text-[var(--blue)] transition-colors">
                      <Download className="w-4 h-4" />
                    </button>
                    <button className="p-1 rounded text-[var(--smoke)]/70 hover:text-[var(--blue)] transition-colors">
                      <Share className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-morphism rounded-xl p-4">
            <h5 className="font-medium text-white mb-3">Ações Rápidas</h5>
            <div className="grid grid-cols-2 gap-2">
              <button className="p-3 glass-morphism rounded-lg text-center hover:bg-[var(--smoke)]/5 transition-colors">
                <Download className="w-5 h-5 text-[var(--blue)] mx-auto mb-1" />
                <span className="text-xs text-white">Baixar Tudo</span>
              </button>
              <button className="p-3 glass-morphism rounded-lg text-center hover:bg-[var(--smoke)]/5 transition-colors">
                <Share className="w-5 h-5 text-[var(--orange)] mx-auto mb-1" />
                <span className="text-xs text-white">Compartilhar</span>
              </button>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-8">
          <FileText className="w-12 h-12 text-[var(--smoke)]/30 mx-auto mb-4" />
          <p className="text-[var(--smoke)]/70">
            Inicie uma conversa para ver os resultados
          </p>
        </div>
      )}
    </div>
  );

  const renderMetricsTab = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="glass-morphism rounded-xl p-4 text-center">
          <div className="w-8 h-8 bg-[var(--blue)]/20 rounded-lg flex items-center justify-center mx-auto mb-2">
            <Clock className="w-4 h-4 text-[var(--blue)]" />
          </div>
          <p className="text-lg font-orbitron font-bold text-white">2.3s</p>
          <p className="text-xs text-[var(--smoke)]/70">Latência Média</p>
        </div>
        
        <div className="glass-morphism rounded-xl p-4 text-center">
          <div className="w-8 h-8 bg-[var(--orange)]/20 rounded-lg flex items-center justify-center mx-auto mb-2">
            <Zap className="w-4 h-4 text-[var(--orange)]" />
          </div>
          <p className="text-lg font-orbitron font-bold text-white">156</p>
          <p className="text-xs text-[var(--smoke)]/70">Tokens Usados</p>
        </div>
      </div>

      <div className="glass-morphism rounded-xl p-4">
        <h5 className="font-medium text-white mb-3">Uso por Provedor</h5>
        <div className="space-y-3">
          {[
            { name: 'HuggingFace', usage: 75, color: '#FF6A00' },
            { name: 'Groq', usage: 20, color: '#00BFFF' },
            { name: 'OpenAI', usage: 5, color: '#10B981' }
          ].map((provider) => (
            <div key={provider.name} className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-[var(--smoke)]/70">{provider.name}</span>
                <span className="text-white">{provider.usage}%</span>
              </div>
              <div className="w-full bg-[var(--smoke)]/10 rounded-full h-2">
                <div 
                  className="h-2 rounded-full"
                  style={{ 
                    width: `${provider.usage}%`,
                    backgroundColor: provider.color
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-morphism rounded-xl p-4">
        <h5 className="font-medium text-white mb-3">Custo Estimado</h5>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-[var(--orange)]" />
            <span className="text-[var(--smoke)]/70">Esta conversa:</span>
          </div>
          <span className="text-white font-medium">$0.003</span>
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-[var(--smoke)]/70">Tokens restantes:</span>
          <span className="text-[var(--blue)]">{user?.credits || 0}</span>
        </div>
      </div>
    </div>
  );

  const renderSuggestionsTab = () => (
    <div className="space-y-4">
      <div className="glass-morphism rounded-xl p-4">
        <h4 className="font-orbitron font-semibold text-white mb-3">
          Próximas Ações Sugeridas
        </h4>
        
        <div className="space-y-3">
          {[
            {
              title: 'Refinar o roteiro',
              description: 'Adicione mais detalhes sobre o gancho inicial',
              action: 'Melhorar gancho',
              priority: 'high'
            },
            {
              title: 'Testar diferentes abordagens',
              description: 'Experimente variações do script para comparar',
              action: 'Criar variações',
              priority: 'medium'
            },
            {
              title: 'Analisar concorrência',
              description: 'Veja como outros criadores abordam o tema',
              action: 'Pesquisar trends',
              priority: 'low'
            }
          ].map((suggestion, index) => (
            <div key={index} className="p-3 glass-morphism rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <h6 className="text-sm font-medium text-white">{suggestion.title}</h6>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  suggestion.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                  suggestion.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-green-500/20 text-green-400'
                }`}>
                  {suggestion.priority}
                </span>
              </div>
              <p className="text-xs text-[var(--smoke)]/70 mb-3">
                {suggestion.description}
              </p>
              <button className="text-xs text-[var(--blue)] hover:text-white transition-colors">
                {suggestion.action} →
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-morphism rounded-xl p-4">
        <h5 className="font-medium text-white mb-3">Dicas do HVC Core</h5>
        <div className="space-y-2 text-sm text-[var(--smoke)]/80">
          <p>💡 Use comandos específicos para melhores resultados</p>
          <p>⚡ Textos mais focados consomem menos tokens</p>
          <p>🎯 Defina o objetivo antes de começar</p>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'briefing': return renderBriefingTab();
      case 'tools': return renderToolsTab();
      case 'results': return renderResultsTab();
      case 'metrics': return renderMetricsTab();
      case 'suggestions': return renderSuggestionsTab();
      default: return renderBriefingTab();
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Tabs */}
      <div className="p-4 border-b border-[var(--smoke)]/20">
        <div className="flex flex-wrap gap-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white'
                    : 'text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5'
                }`}
              >
                <Icon className="w-3 h-3" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          {renderContent()}
        </motion.div>
      </div>
    </div>
  );
}