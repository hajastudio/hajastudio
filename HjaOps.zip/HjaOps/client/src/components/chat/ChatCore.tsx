import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bot,
  User,
  Paperclip,
  Mic,
  Send,
  Settings,
  CreditCard,
  History,
  FileText,
  Maximize2,
  Minimize2,
  AlertTriangle,
  CheckCircle,
  Loader
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import MessageBubble from './MessageBubble';
import ChatInput, { type ChatInputRef } from './ChatInput';
import SidePanel from './SidePanel';
import CreditDisplay from './CreditDisplay';
import { agentModes, type AgentMode } from './AgentModes';

interface Message {
  id: string;
  type: 'text' | 'code' | 'media' | 'table' | 'action-result';
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
  metadata?: {
    model?: string;
    cost?: number;
    executionTime?: number;
    fallback?: boolean;
    language?: string;
    actions?: QuickAction[];
  };
}

interface QuickAction {
  id: string;
  label: string;
  icon: any;
  color: string;
  action: () => void;
}

interface ChatState {
  status: 'idle' | 'loading' | 'error' | 'streaming';
  error?: string;
  isTyping: boolean;
  estimatedCost: number;
  estimatedTime: number;
}

interface ChatCoreProps {
  agentId: string;
  conversationId?: string;
  className?: string;
}

export default function ChatCore({ agentId, conversationId, className = '' }: ChatCoreProps) {
  const [currentAgent, setCurrentAgent] = useState<AgentMode>(agentModes[agentId] || agentModes.general);
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatState, setChatState] = useState<ChatState>({
    status: 'idle',
    isTyping: false,
    estimatedCost: 0,
    estimatedTime: 0
  });
  const [selectedModel, setSelectedModel] = useState(currentAgent.defaultModel);
  const [userCredits, setUserCredits] = useState(247); // Mock user credits
  const [showSidePanel, setShowSidePanel] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<ChatInputRef>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load agent configuration
  useEffect(() => {
    const agent = agentModes[agentId] || agentModes.general;
    setCurrentAgent(agent);
    setSelectedModel(agent.defaultModel);
  }, [agentId]);

  const handleSendMessage = async (content: string, attachments?: File[]) => {
    const messageId = Date.now().toString();
    
    // Add user message
    const userMessage: Message = {
      id: messageId,
      type: 'text',
      content,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setChatState(prev => ({ ...prev, status: 'loading', isTyping: true }));

    // Simulate AI response with realistic delay
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: currentAgent.outputType,
        content: generateMockResponse(content, currentAgent),
        sender: 'assistant',
        timestamp: new Date(),
        metadata: {
          model: selectedModel,
          cost: chatState.estimatedCost,
          executionTime: chatState.estimatedTime,
          fallback: selectedModel !== currentAgent.defaultModel,
          actions: generateQuickActions(currentAgent)
        }
      };

      setMessages(prev => [...prev, assistantMessage]);
      setChatState(prev => ({ 
        ...prev, 
        status: 'idle', 
        isTyping: false,
        estimatedCost: 0,
        estimatedTime: 0
      }));

      // Deduct credits
      setUserCredits(prev => Math.max(0, prev - chatState.estimatedCost));
    }, 2000 + Math.random() * 2000);
  };

  const generateMockResponse = (input: string, agent: AgentMode): string => {
    switch (agent.id) {
      case 'roteiro':
        return `# ROTEIRO: ${input.toUpperCase()}\n\n## CENA 1 - ABERTURA\n**FADE IN:**\n\nINT. ESTÚDIO - DIA\n\nA câmera revela um ambiente moderno e tecnológico...\n\n**NARRADOR (V.O.)**\nEm um mundo onde a criatividade encontra a tecnologia...`;
      
      case 'code':
        return `\`\`\`typescript\n// Implementação para: ${input}\nfunction createComponent() {\n  const [state, setState] = useState({\n    loading: false,\n    data: null\n  });\n\n  return (\n    <div className="component">\n      {/* Implementação aqui */}\n    </div>\n  );\n}\n\nexport default createComponent;\n\`\`\``;
      
      case 'branding':
        return `## ANÁLISE DE BRANDING: ${input}\n\n### 🎨 Paleta de Cores\n- **Primária**: #0055ff (Confiança, Tecnologia)\n- **Secundária**: #ff6a00 (Energia, Inovação)\n- **Neutra**: #000000 (Elegância, Sofisticação)\n\n### 📝 Tom de Voz\n- Profissional mas acessível\n- Inovador e confiável\n- Focado em resultados`;
      
      case 'youtube':
        return `## ANÁLISE DO VÍDEO\n\n### 📊 Métricas Detectadas\n- **Duração**: 10:45\n- **Engajamento**: Alto (8.2/10)\n- **Temas principais**: Tecnologia, Educação\n\n### 🎯 Insights\n- Momento de maior atenção: 2:34-4:12\n- Call-to-action efetivo aos 8:30\n- Potencial viral: 76%`;
      
      default:
        return `Entendi sua solicitação sobre "${input}". Aqui está minha análise detalhada:\n\n1. **Contexto identificado**: ${input}\n2. **Abordagem recomendada**: Análise sistemática\n3. **Próximos passos**: Implementação gradual\n\nGostaria de detalhar algum aspecto específico?`;
    }
  };

  const generateQuickActions = (agent: AgentMode): QuickAction[] => {
    const baseActions = [
      {
        id: 'refine',
        label: 'Refinar',
        icon: Settings,
        color: 'admin-bg-blue',
        action: () => console.log('Refining...')
      },
      {
        id: 'export',
        label: 'Exportar',
        icon: FileText,
        color: 'admin-bg-orange',
        action: () => console.log('Exporting...')
      }
    ];

    const agentSpecificActions = agent.quickActions || [];
    return [...baseActions, ...agentSpecificActions];
  };

  const handleActionClick = (actionId: string) => {
    console.log('Action clicked:', actionId);
  };

  const startNewConversation = () => {
    setMessages([]);
    setChatState({
      status: 'idle',
      isTyping: false,
      estimatedCost: 0,
      estimatedTime: 0
    });
  };

  const handleModelChange = (model: string) => {
    setSelectedModel(model);
    // Recalculate cost estimation based on new model
    setChatState(prev => ({
      ...prev,
      estimatedCost: model === 'gpt-4o' ? 0.15 : model === 'groq' ? 0.02 : 0.08,
      estimatedTime: model === 'groq' ? 0.5 : model === 'gpt-4o' ? 3.2 : 1.8
    }));
  };

  return (
    <div className={`h-full flex ${isExpanded ? 'fixed inset-0 z-50 admin-sidebar' : ''} ${className}`}>
      
      {/* Main Chat Container */}
      <div className={`flex flex-col ${showSidePanel ? 'flex-1' : 'w-full'} max-w-4xl mx-auto`}>
        
        {/* Header */}
        <motion.header 
          className="admin-sidebar border-b border-blue-500/20 p-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between">
            
            {/* Agent Info */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="w-12 h-12 border-2 border-blue-500/30">
                  <AvatarImage src={currentAgent.avatar} />
                  <AvatarFallback className={`${currentAgent.color} text-white font-bold`}>
                    {currentAgent.name.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-black"></div>
              </div>
              
              <div>
                <h1 className="text-xl font-bold admin-text-blue">{currentAgent.name}</h1>
                <div className="flex items-center gap-2">
                  <p className="text-sm admin-text-smoke">{currentAgent.description}</p>
                  <Badge className={`${currentAgent.color} text-white text-xs`}>
                    {currentAgent.mode.toUpperCase()}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-4">
              
              {/* Model Selector */}
              <select
                value={selectedModel}
                onChange={(e) => handleModelChange(e.target.value)}
                className="px-3 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke text-sm"
              >
                {currentAgent.availableModels.map((model) => (
                  <option key={model} value={model}>
                    {model.toUpperCase()}
                  </option>
                ))}
              </select>

              {/* Credits Display */}
              <CreditDisplay 
                credits={userCredits}
                estimatedCost={chatState.estimatedCost}
                onBuyCredits={() => console.log('Buy credits')}
              />

              {/* Quick Actions */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSidePanel(!showSidePanel)}
                className="admin-text-smoke hover:admin-text-blue"
              >
                <History className="w-4 h-4" />
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsExpanded(!isExpanded)}
                className="admin-text-smoke hover:admin-text-blue"
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>

              <Button
                onClick={startNewConversation}
                className="admin-bg-blue hover:opacity-90"
                size="sm"
              >
                Nova Conversa
              </Button>
            </div>
          </div>
        </motion.header>

        {/* Messages Timeline */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* Welcome Message */}
          {messages.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12"
            >
              <div className={`w-20 h-20 ${currentAgent.color} rounded-full flex items-center justify-center mx-auto mb-4 admin-glow-blue`}>
                <Bot className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-2xl font-bold admin-text-blue mb-2">
                {currentAgent.welcomeMessage}
              </h2>
              <p className="admin-text-smoke max-w-md mx-auto">
                {currentAgent.instructions}
              </p>
              
              {/* Quick Start Suggestions */}
              <div className="flex flex-wrap gap-2 justify-center mt-6">
                {currentAgent.suggestions.map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSendMessage(suggestion)}
                    className="border-blue-500/20 admin-text-blue hover:bg-blue-500/10"
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Message List */}
          <AnimatePresence>
            {messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message}
                agent={currentAgent}
                onActionClick={handleActionClick}
              />
            ))}
          </AnimatePresence>

          {/* Typing Indicator */}
          {chatState.isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex items-center gap-3"
            >
              <Avatar className="w-8 h-8 border border-blue-500/30">
                <AvatarImage src={currentAgent.avatar} />
                <AvatarFallback className={`${currentAgent.color} text-white text-xs`}>
                  {currentAgent.name.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="admin-card p-3 rounded-2xl">
                <div className="flex items-center gap-2">
                  <Loader className="w-4 h-4 admin-text-blue animate-spin" />
                  <span className="text-sm admin-text-smoke">
                    {currentAgent.name} está pensando...
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Status Bar */}
        {chatState.status !== 'idle' && (
          <div className="px-4 py-2 bg-black/20 border-t border-blue-500/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {chatState.status === 'loading' && (
                  <>
                    <Loader className="w-4 h-4 admin-text-blue animate-spin" />
                    <span className="text-sm admin-text-smoke">Processando...</span>
                  </>
                )}
                {chatState.status === 'error' && (
                  <>
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    <span className="text-sm text-red-400">{chatState.error}</span>
                  </>
                )}
              </div>
              
              {chatState.estimatedTime > 0 && (
                <span className="text-xs admin-text-smoke">
                  ~{chatState.estimatedTime.toFixed(1)}s • {chatState.estimatedCost.toFixed(3)} créditos
                </span>
              )}
            </div>
          </div>
        )}

        {/* Input Area */}
        <ChatInput
          agent={currentAgent}
          onSendMessage={handleSendMessage}
          onEstimateChange={(cost, time) => setChatState(prev => ({ 
            ...prev, 
            estimatedCost: cost, 
            estimatedTime: time 
          }))}
          disabled={chatState.status === 'loading'}
          ref={inputRef}
        />
      </div>

      {/* Side Panel */}
      <AnimatePresence>
        {showSidePanel && (
          <SidePanel
            agent={currentAgent}
            messages={messages}
            onClose={() => setShowSidePanel(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}