import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  X,
  FileText,
  History,
  Bookmark,
  BarChart3,
  Settings,
  Download,
  Search,
  Calendar,
  Tag
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import type { AgentMode } from './AgentModes';

interface Message {
  id: string;
  type: 'text' | 'code' | 'media' | 'table' | 'action-result';
  content: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

interface SidePanelProps {
  agent: AgentMode;
  messages: Message[];
  onClose: () => void;
}

type PanelTab = 'briefing' | 'history' | 'references' | 'results';

export default function SidePanel({ agent, messages, onClose }: SidePanelProps) {
  const [activeTab, setActiveTab] = useState<PanelTab>('briefing');
  const [searchTerm, setSearchTerm] = useState('');

  const tabs = [
    { id: 'briefing', label: 'Briefing', icon: FileText },
    { id: 'history', label: 'Histórico', icon: History },
    { id: 'references', label: 'Referências', icon: Bookmark },
    { id: 'results', label: 'Resultados', icon: BarChart3 }
  ];

  const briefingContent = {
    roteiro: [
      'Formato: 30 segundos para redes sociais',
      'Tom: Inspirador e motivacional',
      'Público: 25-45 anos, empreendedores',
      'Call-to-action: Visitar website'
    ],
    code: [
      'Framework: React + TypeScript',
      'Padrões: Hooks, componentes funcionais',
      'Estilo: Tailwind CSS + Shadcn',
      'Testes: Jest + Testing Library'
    ],
    branding: [
      'Segmento: Tecnologia/SaaS',
      'Personalidade: Inovador, confiável',
      'Valores: Simplicidade, eficiência',
      'Diferencial: IA + UX superior'
    ],
    youtube: [
      'Nicho: Tecnologia e educação',
      'Duração: 8-12 minutos',
      'Formato: Tutorial + insights',
      'Métricas: CTR, tempo de retenção'
    ]
  };

  const getCurrentBriefing = () => {
    return briefingContent[agent.id as keyof typeof briefingContent] || [
      'Objetivo: Assistência geral',
      'Abordagem: Prática e objetiva',
      'Formato: Respostas estruturadas',
      'Foco: Soluções acionáveis'
    ];
  };

  const filteredMessages = messages.filter(msg => 
    msg.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'briefing':
        return (
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold admin-text-blue mb-3">
                Configuração do {agent.name}
              </h3>
              
              <div className="space-y-3">
                {getCurrentBriefing().map((item, index) => (
                  <div key={index} className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                    <p className="text-sm admin-text-smoke">{item}</p>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-medium admin-text-blue mb-2">Capacidades</h4>
              <div className="flex flex-wrap gap-2">
                {agent.capabilities.acceptsFiles && (
                  <Badge variant="outline" className="border-blue-500/20 admin-text-blue">
                    Arquivos
                  </Badge>
                )}
                {agent.capabilities.acceptsUrls && (
                  <Badge variant="outline" className="border-blue-500/20 admin-text-blue">
                    URLs
                  </Badge>
                )}
                {agent.capabilities.acceptsAudio && (
                  <Badge variant="outline" className="border-blue-500/20 admin-text-blue">
                    Áudio
                  </Badge>
                )}
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-medium admin-text-blue mb-2">Modelos Disponíveis</h4>
              <div className="space-y-2">
                {agent.availableModels.map((model) => (
                  <div key={model} className="flex items-center justify-between p-2 rounded bg-black/30">
                    <span className="text-sm admin-text-smoke">{model.toUpperCase()}</span>
                    <Badge className={`text-xs ${
                      model === agent.defaultModel ? 'admin-bg-blue' : 'bg-gray-600'
                    } text-white`}>
                      {model === agent.defaultModel ? 'Padrão' : 'Alternativo'}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'history':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 admin-text-smoke" />
              <Input
                type="text"
                placeholder="Buscar no histórico..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-black/50 border-blue-500/20 admin-text-smoke text-sm"
              />
            </div>

            <div className="space-y-3">
              {filteredMessages.length === 0 ? (
                <p className="text-sm admin-text-smoke text-center py-8">
                  {searchTerm ? 'Nenhuma mensagem encontrada' : 'Histórico vazio'}
                </p>
              ) : (
                filteredMessages.map((message) => (
                  <div key={message.id} className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={`text-xs ${
                        message.sender === 'user' ? 'admin-bg-blue' : agent.color
                      } text-white`}>
                        {message.sender === 'user' ? 'Você' : agent.name}
                      </Badge>
                      <span className="text-xs admin-text-smoke">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm admin-text-smoke line-clamp-3">
                      {message.content}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        );

      case 'references':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold admin-text-blue">
              Referências e Recursos
            </h3>

            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Tag className="w-4 h-4 admin-text-blue" />
                  <span className="font-medium admin-text-blue">Documentação</span>
                </div>
                <p className="text-sm admin-text-smoke">
                  Guias e melhores práticas para {agent.mode}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-4 h-4 admin-text-blue" />
                  <span className="font-medium admin-text-blue">Templates</span>
                </div>
                <p className="text-sm admin-text-smoke">
                  Modelos prontos e estruturas reusáveis
                </p>
              </div>

              <div className="p-3 rounded-lg bg-black/30 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Bookmark className="w-4 h-4 admin-text-blue" />
                  <span className="font-medium admin-text-blue">Favoritos</span>
                </div>
                <p className="text-sm admin-text-smoke">
                  Conversas e resultados salvos
                </p>
              </div>
            </div>
          </div>
        );

      case 'results':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold admin-text-blue">
              Resultados da Sessão
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-black/30 text-center">
                <p className="text-lg font-bold admin-text-blue">{messages.length}</p>
                <p className="text-xs admin-text-smoke">Mensagens</p>
              </div>
              
              <div className="p-3 rounded-lg bg-black/30 text-center">
                <p className="text-lg font-bold admin-text-orange">
                  {messages.filter(m => m.type === 'code').length}
                </p>
                <p className="text-xs admin-text-smoke">Códigos</p>
              </div>
            </div>

            <Separator />

            <div className="space-y-3">
              <h4 className="font-medium admin-text-blue">Ações Rápidas</h4>
              
              <Button 
                variant="outline" 
                className="w-full justify-start border-blue-500/20 admin-text-blue"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar Conversa
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start border-blue-500/20 admin-text-blue"
              >
                <FileText className="w-4 h-4 mr-2" />
                Gerar Relatório
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start border-blue-500/20 admin-text-blue"
              >
                <Bookmark className="w-4 h-4 mr-2" />
                Salvar Sessão
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 300 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 300 }}
      className="w-80 admin-sidebar border-l border-blue-500/20 flex flex-col h-full"
    >
      
      {/* Header */}
      <div className="p-4 border-b border-blue-500/20">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold admin-text-blue">
            Painel Lateral
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="admin-text-smoke hover:admin-text-blue"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-blue-500/20">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as PanelTab)}
            className={`flex-1 flex items-center justify-center gap-2 p-3 text-xs border-b-2 transition-all ${
              activeTab === tab.id
                ? 'border-blue-500 admin-text-blue bg-blue-500/10'
                : 'border-transparent admin-text-smoke hover:admin-text-blue hover:bg-blue-500/5'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {renderTabContent()}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-blue-500/20">
        <Button
          variant="outline"
          size="sm"
          className="w-full border-blue-500/20 admin-text-blue"
        >
          <Settings className="w-4 h-4 mr-2" />
          Configurações
        </Button>
      </div>
    </motion.div>
  );
}