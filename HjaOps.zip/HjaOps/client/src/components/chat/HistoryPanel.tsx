import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Star, 
  MoreVertical, 
  Trash2, 
  Edit3, 
  Copy,
  StarOff,
  FolderOpen,
  Calendar
} from 'lucide-react';
import type { ChatThread } from '@/types/agents';

interface HistoryPanelProps {
  currentThread: ChatThread | null;
  onThreadSelect: (thread: ChatThread | null) => void;
  searchQuery: string;
  filter: 'all' | 'favorites' | 'recent' | 'drafts';
  user: any;
}

export default function HistoryPanel({
  currentThread,
  onThreadSelect,
  searchQuery,
  filter,
  user
}: HistoryPanelProps) {
  const [showActions, setShowActions] = useState<string | null>(null);

  // Mock threads data - would come from API
  const mockThreads: ChatThread[] = [
    {
      id: '1',
      title: 'Landing Page para SaaS de IA',
      agentId: 'design-matrix',
      messages: [],
      createdAt: new Date(Date.now() - 1000 * 60 * 30), // 30 min ago
      updatedAt: new Date(Date.now() - 1000 * 60 * 15), // 15 min ago
      isFavorite: true,
      isDraft: false,
      totalTokens: 450,
      totalCredits: 3
    },
    {
      id: '2',
      title: 'Refatoração de componente React',
      agentId: 'vibe-code',
      messages: [],
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2h ago
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 1), // 1h ago
      isFavorite: false,
      isDraft: false,
      totalTokens: 320,
      totalCredits: 2
    },
    {
      id: '3',
      title: 'Script para TikTok sobre produtividade',
      agentId: 'roteirista',
      messages: [],
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4h ago
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3h ago
      isFavorite: false,
      isDraft: true,
      totalTokens: 180,
      totalCredits: 1
    },
    {
      id: '4',
      title: 'Análise de vídeo viral do YouTube',
      agentId: 'youtube-analyst',
      messages: [],
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
      updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 20), // 20h ago
      isFavorite: true,
      isDraft: false,
      totalTokens: 680,
      totalCredits: 4
    }
  ];

  const filteredThreads = mockThreads.filter(thread => {
    const matchesSearch = thread.title.toLowerCase().includes(searchQuery.toLowerCase());
    
    let matchesFilter = true;
    switch (filter) {
      case 'favorites':
        matchesFilter = thread.isFavorite;
        break;
      case 'drafts':
        matchesFilter = thread.isDraft;
        break;
      case 'recent':
        const oneDayAgo = new Date(Date.now() - 1000 * 60 * 60 * 24);
        matchesFilter = thread.updatedAt > oneDayAgo;
        break;
    }
    
    return matchesSearch && matchesFilter;
  });

  const getAgentInfo = (agentId: string) => {
    const agentMap = {
      'design-matrix': { name: 'DesignMatrix', color: '#00BFFF', avatar: 'DM' },
      'vibe-code': { name: 'Vibe Code', color: '#FF6A00', avatar: 'VC' },
      'roteirista': { name: 'Roteirista', color: '#9F7AEA', avatar: 'RV' },
      'youtube-analyst': { name: 'YouTube Analyst', color: '#EF4444', avatar: 'YA' },
      'branding-social': { name: 'Brand & Social', color: '#10B981', avatar: 'BS' },
      'viral-agent': { name: 'Agente Viral', color: '#F59E0B', avatar: 'VA' }
    };
    
    return agentMap[agentId] || { name: 'Agente', color: '#666', avatar: 'A' };
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}min atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  };

  const handleThreadAction = (action: string, threadId: string) => {
    console.log(`Action: ${action}, Thread: ${threadId}`);
    setShowActions(null);
  };

  return (
    <div className="p-4 space-y-3 overflow-y-auto h-full">
      {filteredThreads.map((thread, index) => {
        const agentInfo = getAgentInfo(thread.agentId);
        const isActive = currentThread?.id === thread.id;

        return (
          <motion.div
            key={thread.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`relative p-3 rounded-xl cursor-pointer transition-all duration-300 group ${
              isActive
                ? 'glass-morphism border border-[var(--blue)]/50 shadow-lg'
                : 'glass-morphism hover:bg-[var(--smoke)]/5'
            }`}
            onClick={() => onThreadSelect(thread)}
          >
            {/* Header */}
            <div className="flex items-start gap-3 mb-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                style={{ backgroundColor: agentInfo.color }}
              >
                {agentInfo.avatar}
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-white text-sm line-clamp-2 mb-1">
                  {thread.title}
                </h3>
                
                <div className="flex items-center gap-2 text-xs text-[var(--smoke)]/60">
                  <span>{agentInfo.name}</span>
                  <div className="w-1 h-1 bg-[var(--smoke)]/30 rounded-full" />
                  <span>{formatTimeAgo(thread.updatedAt)}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowActions(showActions === thread.id ? null : thread.id);
                  }}
                  className="p-1 rounded text-[var(--smoke)]/60 hover:text-white hover:bg-[var(--smoke)]/10 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>

                {/* Actions Menu */}
                {showActions === thread.id && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute right-0 top-full mt-1 w-48 glass-morphism rounded-xl border border-[var(--smoke)]/20 py-1 z-10"
                  >
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleThreadAction('rename', thread.id);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                      Renomear
                    </button>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleThreadAction('favorite', thread.id);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors"
                    >
                      {thread.isFavorite ? (
                        <>
                          <StarOff className="w-4 h-4" />
                          Remover dos Favoritos
                        </>
                      ) : (
                        <>
                          <Star className="w-4 h-4" />
                          Adicionar aos Favoritos
                        </>
                      )}
                    </button>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleThreadAction('copy', thread.id);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5 transition-colors"
                    >
                      <Copy className="w-4 h-4" />
                      Duplicar Conversa
                    </button>
                    
                    <div className="border-t border-[var(--smoke)]/20 my-1" />
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleThreadAction('delete', thread.id);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                      Excluir
                    </button>
                  </motion.div>
                )}
              </div>
            </div>

            {/* Status Indicators */}
            <div className="flex items-center gap-2 mb-2">
              {thread.isFavorite && (
                <div className="flex items-center gap-1 px-2 py-1 bg-yellow-400/20 text-yellow-400 rounded-full text-xs">
                  <Star className="w-3 h-3 fill-current" />
                  Favorito
                </div>
              )}
              
              {thread.isDraft && (
                <div className="flex items-center gap-1 px-2 py-1 bg-orange-400/20 text-orange-400 rounded-full text-xs">
                  <Edit3 className="w-3 h-3" />
                  Rascunho
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center justify-between text-xs text-[var(--smoke)]/60">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <MessageSquare className="w-3 h-3" />
                  {thread.messages.length || 0} mensagens
                </div>
                
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 text-[var(--orange)]">💎</div>
                  {thread.totalCredits} créditos
                </div>
              </div>
              
              <span>{formatTimeAgo(thread.createdAt)}</span>
            </div>

            {/* Active Indicator */}
            {isActive && (
              <motion.div
                layoutId="activeThread"
                className="absolute inset-0 border-2 rounded-xl pointer-events-none"
                style={{ borderColor: agentInfo.color }}
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
          </motion.div>
        );
      })}

      {/* Empty State */}
      {filteredThreads.length === 0 && (
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-[var(--smoke)]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
            <MessageSquare className="w-8 h-8 text-[var(--smoke)]/30" />
          </div>
          <p className="text-[var(--smoke)]/70 mb-2">
            {searchQuery 
              ? `Nenhuma conversa encontrada para "${searchQuery}"`
              : filter === 'favorites' 
                ? 'Nenhuma conversa favorita'
                : filter === 'drafts'
                  ? 'Nenhum rascunho salvo'
                  : 'Nenhuma conversa recente'
            }
          </p>
          <button
            onClick={() => onThreadSelect(null)}
            className="text-sm text-[var(--blue)] hover:text-white transition-colors"
          >
            Iniciar nova conversa
          </button>
        </div>
      )}
    </div>
  );
}