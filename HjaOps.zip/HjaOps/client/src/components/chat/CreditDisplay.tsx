import { motion } from 'framer-motion';
import { 
  Zap,
  CreditCard,
  AlertTriangle,
  TrendingUp,
  ShoppingCart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface CreditDisplayProps {
  credits: number;
  estimatedCost: number;
  onBuyCredits: () => void;
}

export default function CreditDisplay({ credits, estimatedCost, onBuyCredits }: CreditDisplayProps) {
  const isLowCredits = credits < 50;
  const canAfford = credits >= estimatedCost;
  const usagePercentage = Math.min(100, (estimatedCost / credits) * 100);

  const getCreditColor = () => {
    if (credits >= 200) return 'text-green-400';
    if (credits >= 100) return 'admin-text-blue';
    if (credits >= 50) return 'admin-text-orange';
    return 'text-red-400';
  };

  const getCreditStatus = () => {
    if (credits >= 200) return 'Ótimo';
    if (credits >= 100) return 'Bom';
    if (credits >= 50) return 'Baixo';
    return 'Crítico';
  };

  return (
    <div className="flex items-center gap-3">
      
      {/* Current Credits */}
      <div className="flex items-center gap-2">
        <div className="relative">
          <Zap className={`w-5 h-5 ${getCreditColor()}`} />
          {isLowCredits && (
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          )}
        </div>
        
        <div className="text-right">
          <p className={`text-sm font-bold ${getCreditColor()}`}>
            {credits.toFixed(0)}
          </p>
          <p className="text-xs admin-text-smoke">
            créditos
          </p>
        </div>
      </div>

      {/* Estimated Cost Preview */}
      {estimatedCost > 0 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center gap-2"
        >
          <div className="text-center">
            <p className={`text-sm font-bold ${canAfford ? 'text-green-400' : 'text-red-400'}`}>
              -{estimatedCost.toFixed(3)}
            </p>
            <p className="text-xs admin-text-smoke">
              estimado
            </p>
          </div>
          
          {/* Affordability Indicator */}
          <div className={`w-2 h-2 rounded-full ${canAfford ? 'bg-green-500' : 'bg-red-500'}`} />
        </motion.div>
      )}

      {/* Status Badge */}
      <Badge 
        className={`text-xs ${
          isLowCredits 
            ? 'bg-red-500 text-white animate-pulse' 
            : credits >= 200 
              ? 'bg-green-500 text-white'
              : 'admin-bg-blue text-white'
        }`}
      >
        {getCreditStatus()}
      </Badge>

      {/* Buy Credits CTA */}
      {isLowCredits && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Button
            onClick={onBuyCredits}
            size="sm"
            className="admin-bg-orange hover:opacity-90 gap-2"
          >
            <CreditCard className="w-4 h-4" />
            Comprar
          </Button>
        </motion.div>
      )}

      {/* Critical Warning */}
      {credits < 10 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-1 p-2 rounded-lg bg-red-500/10 border border-red-500/30"
        >
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span className="text-xs text-red-400 font-medium">
            Créditos insuficientes
          </span>
        </motion.div>
      )}
    </div>
  );
}