import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { sendMagicLink } from '@/lib/firebase';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LoginModal({ isOpen, onClose }: LoginModalProps) {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEmailSent, setIsEmailSent] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    try {
      await sendMagicLink(email);
      setIsEmailSent(true);
      toast({
        title: "Magic Link enviado!",
        description: "Verifique seu email para continuar",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao enviar magic link",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setEmail('');
    setIsEmailSent(false);
    setIsLoading(false);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
            data-testid="modal-backdrop"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="glass-panel bg-black/40 backdrop-blur-xl border border-[#0055ff]/30 rounded-2xl p-8 w-full max-w-md mx-auto shadow-2xl">
              
              {/* Header */}
              <div className="text-center mb-8">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#0055ff] to-[#0077ff] rounded-xl flex items-center justify-center neon-glow-sm">
                    <span className="text-black font-bold text-xl">H</span>
                  </div>
                  <h2 className="text-2xl font-bold gradient-text">Hja²Ops</h2>
                </div>
                <p className="text-[#7a8c99]">Entre na plataforma AI Multi-Agent</p>
              </div>

              {!isEmailSent ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="email" className="text-sm font-medium text-[#c5d1db] mb-2 block">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      className="bg-black/50 border-[#0055ff]/30 text-[#c5d1db] placeholder:text-[#7a8c99] focus:border-[#0055ff] focus:ring-[#0055ff]/20"
                      required
                      data-testid="input-email"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isLoading || !email}
                    className="w-full bg-gradient-to-r from-[#0055ff] to-[#0077ff] hover:from-[#0066ff] hover:to-[#0088ff] text-white font-semibold py-3 rounded-xl neon-glow transition-all duration-300"
                    data-testid="button-magic-link"
                  >
                    {isLoading ? (
                      <div className="flex items-center gap-2">
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                        Enviando...
                      </div>
                    ) : (
                      <>
                        <i className="fas fa-magic mr-2"></i>
                        Entrar com Magic Link
                      </>
                    )}
                  </Button>
                </form>
              ) : (
                <div className="text-center space-y-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#0055ff] to-[#0077ff] rounded-full flex items-center justify-center mx-auto neon-glow">
                    <i className="fas fa-envelope text-white text-xl"></i>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold text-[#c5d1db] mb-2">Magic Link Enviado!</h3>
                    <p className="text-[#7a8c99] mb-4">
                      Verifique seu email <strong className="text-[#0055ff]">{email}</strong> e clique no link para continuar.
                    </p>
                    <p className="text-sm text-[#7a8c99]">
                      Não recebeu? Verifique o spam ou tente novamente.
                    </p>
                  </div>

                  <Button
                    onClick={handleClose}
                    variant="outline"
                    className="w-full border-[#0055ff]/30 text-[#c5d1db] hover:bg-[#0055ff]/10"
                  >
                    Fechar
                  </Button>
                </div>
              )}

              {/* Close button */}
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 text-[#7a8c99] hover:text-[#c5d1db] transition-colors"
                data-testid="button-close-modal"
              >
                <i className="fas fa-times text-lg"></i>
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}