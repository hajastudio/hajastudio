import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface HelpTip {
  title: string;
  content: string;
  context: string;
  actionable?: string[];
}

interface ContextHelpButtonProps {
  context?: string;
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
}

export default function ContextHelpButton({ 
  context = 'general', 
  position = 'bottom-right' 
}: ContextHelpButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentTip, setCurrentTip] = useState<HelpTip | null>(null);
  const { toast } = useToast();

  // Context-aware tips database
  const contextTips: Record<string, HelpTip[]> = {
    general: [
      {
        title: "Bem-vindo ao Hja²Ops",
        content: "Esta é sua plataforma AI Multi-Agent. Use a sidebar para navegar entre diferentes funcionalidades e agentes especializados.",
        context: "general",
        actionable: ["Clique em 'AI Agents' para ver os agentes disponíveis", "Use 'Chat Interface' para iniciar conversas"]
      },
      {
        title: "Navegação Inteligente",
        content: "O sidebar mostra o status de todos os agentes em tempo real. Pontos verdes indicam agentes ativos e prontos para uso.",
        context: "general",
        actionable: ["Verifique os status indicators", "Clique em qualquer item do menu para explorar"]
      }
    ],
    agents: [
      {
        title: "Sistema Multi-Agente",
        content: "Temos 3 agentes especializados: Roteirista (criação de conteúdo), Vibe Code (desenvolvimento técnico) e Agente Viral (marketing).",
        context: "agents",
        actionable: ["Escolha o agente adequado para sua tarefa", "Combine múltiplos agentes para resultados complexos"]
      },
      {
        title: "Otimizando Interações",
        content: "Cada agente tem prompts especializados. Seja específico sobre o que você precisa para obter as melhores respostas.",
        context: "agents",
        actionable: ["Use exemplos concretos nas suas perguntas", "Especifique o formato de saída desejado"]
      }
    ],
    chat: [
      {
        title: "Interface de Chat Inteligente",
        content: "O chat suporta conversas multi-turn com contexto. Os agentes lembram de conversas anteriores para respostas mais precisas.",
        context: "chat",
        actionable: ["Mantenha conversas organizadas por projeto", "Use comandos claros e diretos"]
      },
      {
        title: "Gerenciamento de Créditos",
        content: "Cada interação consome créditos baseados no tamanho da resposta. Monitore seu uso no dashboard de analytics.",
        context: "chat",
        actionable: ["Verifique seu saldo de créditos regularmente", "Otimize perguntas para economizar tokens"]
      }
    ],
    analytics: [
      {
        title: "Dashboard de Performance",
        content: "Acompanhe métricas de uso, tempo de resposta e eficiência dos agentes. Use esses dados para otimizar seu fluxo de trabalho.",
        context: "analytics",
        actionable: ["Analise padrões de uso semanalmente", "Identifique agentes mais eficientes para suas tarefas"]
      }
    ]
  };

  // AI-powered tip generation
  const generateAITip = async (userContext: string): Promise<HelpTip | null> => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/help/generate-tip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: userContext })
      });

      if (!response.ok) {
        throw new Error('Failed to generate tip');
      }

      const aiTip = await response.json();
      return aiTip;
    } catch (error) {
      console.error('Error generating AI tip:', error);
      return null;
    } finally {
      setIsGenerating(false);
    }
  };

  // Get contextual tip
  const getContextualTip = async () => {
    const availableTips = contextTips[context] || contextTips.general;
    
    // Try AI generation first, fallback to predefined tips
    const aiTip = await generateAITip(context);
    if (aiTip) {
      setCurrentTip(aiTip);
    } else {
      // Fallback to predefined tips
      const randomTip = availableTips[Math.floor(Math.random() * availableTips.length)];
      setCurrentTip(randomTip);
    }
  };

  // Handle help button click
  const handleHelpClick = async () => {
    if (!isOpen) {
      await getContextualTip();
    }
    setIsOpen(!isOpen);
  };

  // Position classes
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'top-right': 'top-6 right-6',
    'top-left': 'top-6 left-6'
  };

  const modalPositionClasses = {
    'bottom-right': 'bottom-20 right-6',
    'bottom-left': 'bottom-20 left-6',
    'top-right': 'top-20 right-6',
    'top-left': 'top-20 left-6'
  };

  return (
    <>
      {/* Floating Help Button */}
      <motion.div
        className={`fixed ${positionClasses[position]} z-50`}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, duration: 0.4, type: "spring" }}
      >
        <Button
          onClick={handleHelpClick}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-[#0055ff] to-[#007bff] hover:from-[#0066ff] hover:to-[#0088ff] text-white shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-110 relative group"
          data-testid="help-button"
        >
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            {isGenerating ? (
              <div className="animate-spin w-6 h-6 border-2 border-white border-t-transparent rounded-full"></div>
            ) : (
              <i className="fas fa-question text-xl"></i>
            )}
          </motion.div>
          
          {/* Pulse animation when inactive */}
          {!isOpen && (
            <div className="absolute inset-0 rounded-full bg-[#0055ff] animate-ping opacity-30"></div>
          )}
          
          {/* Tooltip */}
          <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            <div className="bg-black/90 text-white text-sm px-3 py-2 rounded-lg whitespace-nowrap">
              Ajuda Contextual
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black/90"></div>
            </div>
          </div>
        </Button>
      </motion.div>

      {/* Help Modal */}
      <AnimatePresence>
        {isOpen && currentTip && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ duration: 0.3, type: "spring", stiffness: 300 }}
            className={`fixed ${modalPositionClasses[position]} z-40 w-96 max-w-[calc(100vw-2rem)]`}
          >
            <div className="bg-black/95 backdrop-blur-xl border border-[#0055ff]/30 rounded-2xl p-6 shadow-2xl">
              
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#0055ff] to-[#007bff] rounded-xl flex items-center justify-center">
                    <i className="fas fa-lightbulb text-white"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">{currentTip.title}</h3>
                    <p className="text-sm text-gray-400 capitalize">Contexto: {currentTip.context}</p>
                  </div>
                </div>
                
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                  data-testid="close-help"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>

              {/* Content */}
              <div className="space-y-4">
                <p className="text-gray-300 leading-relaxed">
                  {currentTip.content}
                </p>

                {/* Actionable Steps */}
                {currentTip.actionable && currentTip.actionable.length > 0 && (
                  <div>
                    <h4 className="font-semibold text-white mb-2 flex items-center gap-2">
                      <i className="fas fa-tasks text-[#0055ff]"></i>
                      Próximos Passos:
                    </h4>
                    <ul className="space-y-2">
                      {currentTip.actionable.map((step, index) => (
                        <li key={index} className="flex items-start gap-3 text-sm text-gray-300">
                          <div className="w-5 h-5 bg-[#0055ff]/20 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0">
                            <span className="text-[#0055ff] text-xs font-bold">{index + 1}</span>
                          </div>
                          {step}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 mt-6 pt-4 border-t border-white/10">
                <Button
                  onClick={getContextualTip}
                  disabled={isGenerating}
                  variant="outline"
                  size="sm"
                  className="border-[#0055ff]/30 text-[#0055ff] hover:bg-[#0055ff]/10 flex-1"
                  data-testid="new-tip"
                >
                  <i className="fas fa-refresh mr-2"></i>
                  Nova Dica
                </Button>
                
                <Button
                  onClick={() => {
                    toast({
                      title: "Dica salva!",
                      description: "Esta dica foi salva nos seus favoritos.",
                    });
                  }}
                  variant="outline"
                  size="sm"
                  className="border-[#ff6a00]/30 text-[#ff6a00] hover:bg-[#ff6a00]/10"
                  data-testid="save-tip"
                >
                  <i className="fas fa-bookmark mr-2"></i>
                  Salvar
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}