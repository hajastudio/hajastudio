import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Send, 
  Loader2, 
  User, 
  Bot, 
  Copy, 
  ThumbsUp, 
  ThumbsDown,
  Sparkles,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  tokens?: number;
  rating?: 'up' | 'down';
}

interface ChatBoxProps {
  agentName?: string;
  agentIcon?: React.ElementType;
  placeholder?: string;
  disabled?: boolean;
  onSendMessage?: (message: string) => Promise<void>;
  messages?: Message[];
  isLoading?: boolean;
  className?: string;
}

export default function ChatBox({
  agentName = 'Assistente IA',
  agentIcon: AgentIcon = Bot,
  placeholder = 'Digite sua mensagem...',
  disabled = false,
  onSendMessage,
  messages = [],
  isLoading = false,
  className = ''
}: ChatBoxProps) {
  const [inputValue, setInputValue] = useState('');
  const [localMessages, setLocalMessages] = useState<Message[]>(messages);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [localMessages, isLoading]);

  // Update local messages when prop changes
  useEffect(() => {
    setLocalMessages(messages);
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim() || disabled || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setLocalMessages(prev => [...prev, userMessage]);
    setInputValue('');

    try {
      await onSendMessage?.(userMessage.content);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const rateMessage = (messageId: string, rating: 'up' | 'down') => {
    setLocalMessages(prev =>
      prev.map(msg =>
        msg.id === messageId ? { ...msg, rating } : msg
      )
    );
  };

  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Chat Header */}
      <motion.div
        className="flex items-center gap-3 p-4 border-b border-hv-blue/20 bg-hv-black/50"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="w-10 h-10 bg-hv-blue/20 rounded-lg flex items-center justify-center">
          <AgentIcon className="w-6 h-6 text-hv-blue" />
        </div>
        <div>
          <h3 className="font-semibold text-white">{agentName}</h3>
          <p className="text-sm text-hv-smoke/70">Online • Pronto para ajudar</p>
        </div>
        <div className="ml-auto">
          <motion.div
            className="w-3 h-3 bg-green-400 rounded-full"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
          />
        </div>
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence mode="popLayout">
          {localMessages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className={`flex gap-3 ${
                message.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 bg-hv-blue/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <AgentIcon className="w-4 h-4 text-hv-blue" />
                </div>
              )}

              <div className={`max-w-[80%] ${
                message.role === 'user' ? 'order-2' : 'order-1'
              }`}>
                <div className={`
                  p-4 rounded-lg relative group
                  ${message.role === 'user' 
                    ? 'hv-chat-user ml-auto' 
                    : 'hv-chat-assistant'
                  }
                `}>
                  <div className="prose prose-sm max-w-none">
                    <p className="mb-0 leading-relaxed">{message.content}</p>
                  </div>

                  {/* Message Actions */}
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs hover:bg-white/10"
                        onClick={() => copyMessage(message.content)}
                      >
                        <Copy className="w-3 h-3 mr-1" />
                        Copy
                      </Button>

                      {message.role === 'assistant' && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`h-6 px-2 text-xs hover:bg-white/10 ${
                              message.rating === 'up' ? 'text-green-400' : ''
                            }`}
                            onClick={() => rateMessage(message.id, 'up')}
                          >
                            <ThumbsUp className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`h-6 px-2 text-xs hover:bg-white/10 ${
                              message.rating === 'down' ? 'text-red-400' : ''
                            }`}
                            onClick={() => rateMessage(message.id, 'down')}
                          >
                            <ThumbsDown className="w-3 h-3" />
                          </Button>
                        </>
                      )}
                    </div>

                    <div className="flex items-center gap-2 text-xs text-white/50">
                      {message.tokens && (
                        <div className="flex items-center gap-1">
                          <Zap className="w-3 h-3" />
                          <span>{message.tokens}</span>
                        </div>
                      )}
                      <span>
                        {message.timestamp.toLocaleTimeString('pt-BR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {message.role === 'user' && (
                <div className="w-8 h-8 bg-hv-orange/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-hv-orange" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Loading Indicator */}
        {isLoading && (
          <motion.div
            className="flex gap-3 justify-start"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="w-8 h-8 bg-hv-blue/20 rounded-lg flex items-center justify-center">
              <AgentIcon className="w-4 h-4 text-hv-blue" />
            </div>
            <div className="hv-chat-assistant max-w-[200px]">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-hv-blue" />
                <span className="text-sm">Digitando...</span>
                <Sparkles className="w-4 h-4 text-hv-blue animate-pulse" />
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <motion.div
        className="p-4 border-t border-hv-blue/20 bg-hv-black/50"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="flex gap-3 items-end">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={placeholder}
              disabled={disabled || isLoading}
              rows={1}
              className="hv-input w-full resize-none min-h-[44px] max-h-32 py-3 pr-12"
              style={{
                scrollbarWidth: 'thin',
                scrollbarColor: 'rgba(0, 123, 255, 0.5) transparent'
              }}
            />
            
            {/* Character Counter */}
            <div className="absolute bottom-2 right-2 text-xs text-hv-smoke/50">
              {inputValue.length}/1000
            </div>
          </div>

          <Button
            onClick={handleSend}
            disabled={!inputValue.trim() || disabled || isLoading}
            className="hv-btn-primary h-11 px-4"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-2 mt-3">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-hv-smoke hover:text-hv-blue"
            onClick={() => setInputValue('Olá! Como você pode me ajudar?')}
          >
            👋 Saudação
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-hv-smoke hover:text-hv-blue"
            onClick={() => setInputValue('Preciso de ajuda com...')}
          >
            ❓ Ajuda
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-hv-smoke hover:text-hv-blue"
            onClick={() => setInputValue('Explique melhor sobre...')}
          >
            💡 Explicar
          </Button>
        </div>
      </motion.div>
    </div>
  );
}