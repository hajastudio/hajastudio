import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { 
  Brain,
  Code,
  Palette,
  Youtube,
  TrendingUp,
  Zap,
  ArrowRight,
  Star,
  Clock
} from 'lucide-react';

interface AgentCardProps {
  id: string;
  name: string;
  description: string;
  icon: 'brain' | 'code' | 'palette' | 'youtube' | 'trending';
  specialty: string;
  rating: number;
  responseTime: string;
  creditsPerUse: number;
  isPopular?: boolean;
  className?: string;
}

const iconMap = {
  brain: Brain,
  code: Code,
  palette: Palette,
  youtube: Youtube,
  trending: TrendingUp,
};

export default function AgentCard({ 
  id, 
  name, 
  description, 
  icon, 
  specialty, 
  rating, 
  responseTime, 
  creditsPerUse,
  isPopular = false,
  className = '' 
}: AgentCardProps) {
  const IconComponent = iconMap[icon];

  return (
    <motion.div
      className={`hv-card-netflix group cursor-pointer ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ 
        scale: 1.05,
        transition: { duration: 0.2 }
      }}
    >
      <Link href={`/chat?agent=${id}`}>
        <div className="relative p-6 h-full">
          {/* Popular Badge */}
          {isPopular && (
            <motion.div
              className="absolute -top-2 -right-2 bg-hv-orange text-white text-xs font-bold px-3 py-1 rounded-full hv-glow-orange"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              Popular
            </motion.div>
          )}

          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <motion.div
                className="w-12 h-12 bg-hv-blue/20 rounded-xl flex items-center justify-center group-hover:bg-hv-blue/30 transition-colors"
                whileHover={{ rotate: 5 }}
              >
                <IconComponent className="w-6 h-6 text-hv-blue" />
              </motion.div>
              
              <div>
                <h3 className="hv-title text-lg text-white group-hover:text-hv-blue transition-colors">
                  {name}
                </h3>
                <p className="text-sm text-hv-smoke/70">
                  {specialty}
                </p>
              </div>
            </div>

            <motion.div
              className="opacity-0 group-hover:opacity-100 transition-opacity"
              whileHover={{ x: 5 }}
            >
              <ArrowRight className="w-5 h-5 text-hv-blue" />
            </motion.div>
          </div>

          {/* Description */}
          <p className="hv-text text-sm mb-6 leading-relaxed">
            {description}
          </p>

          {/* Stats */}
          <div className="space-y-3 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-hv-smoke">Rating</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-semibold text-white">{rating}</span>
                <span className="text-xs text-hv-smoke">/5.0</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-hv-blue" />
                <span className="text-sm text-hv-smoke">Resposta</span>
              </div>
              <span className="text-sm font-medium text-hv-blue">
                {responseTime}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-hv-orange" />
                <span className="text-sm text-hv-smoke">Custo</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-semibold text-hv-orange">{creditsPerUse}</span>
                <span className="text-xs text-hv-smoke">créditos</span>
              </div>
            </div>
          </div>

          {/* Action Button */}
          <motion.button
            className="w-full hv-btn-primary group-hover:hv-btn-secondary transition-all duration-300"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Conversar Agora
          </motion.button>

          {/* Hover Glow Effect */}
          <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-hv-blue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
        </div>
      </Link>
    </motion.div>
  );
}