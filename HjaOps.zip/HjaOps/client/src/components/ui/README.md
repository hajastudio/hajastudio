# Hja²Ops UI Design System

## Overview

Sistema de design unificado para o Hja²Ops com tema cyberpunk 2025, utilizando preto absoluto #000000, azul caneta luminoso #00BFFF, laranja #FF6A00 para alertas, e tipografia "fumaça" #C5D1DB. Todos os componentes seguem as diretrizes de bordas hairline (0.2px), efeitos glow, e microinterações suaves.

## Cores do Sistema

### Backgrounds
- `hja-bg` - #000000 (Preto absoluto)
- `hja-surface` - #0A141B (Surface principal)
- `hja-surfaceAlt` - #001A23 (Surface alternativa)

### Primary Colors
- `hja-primary` - #00BFFF (Azul caneta luminoso - ações primárias/sistema)
- `hja-accent` - #FF6A00 (Laranja - alertas/upsell/CTAs secundários)

### Text Colors
- `hja-textBase` - #C5D1DB (Texto base "fumaça")
- `hja-textMuted` - #7A8C99 (Texto secundário)

### Semantic Colors
- `hja-success` - #00FF88
- `hja-warning` - #FFB800
- `hja-danger` - #FF4444

## Utilitários CSS

### Classes Base
- `.border-hairline` - Borda de 0.2px com opacidade
- `.smoke-text` - Cor de texto base (#C5D1DB)
- `.smoke-text-muted` - Cor de texto secundário (#7A8C99)
- `.glass` - Efeito vidro com backdrop-blur
- `.glass-strong` - Efeito vidro mais intenso
- `.glow` - Brilho azul sutil
- `.glow-accent` - Brilho laranja sutil
- `.focus-visible-custom` - Foco visível customizado

### Sombras Neon
- `shadow-neon` - Sombra azul sutil
- `shadow-neon-strong` - Sombra azul intensa
- `shadow-neon-accent` - Sombra laranja
- `shadow-glass` - Sombra para efeito vidro

## Componentes

### Button

```tsx
import { Button } from "@/components/ui/button"

// Variantes
<Button variant="primary">Ação Principal</Button>
<Button variant="ghost">Secundário</Button>
<Button variant="accent">Upsell/CTA</Button>
<Button variant="danger">Destrutivo</Button>

// Tamanhos
<Button size="sm">Pequeno</Button>
<Button size="md">Médio</Button>
<Button size="lg">Grande</Button>

// Com efeito glow
<Button glow>Botão com Brilho</Button>
```

### Input & Textarea

```tsx
import { Input, Textarea } from "@/components/ui/input"

<Input placeholder="Digite algo..." />
<Input error={true} />
<Textarea placeholder="Texto longo..." rows={4} />
```

### Card

```tsx
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card"

<Card>
  <CardHeader>
    <CardTitle>Título do Card</CardTitle>
    <CardDescription>Descrição opcional</CardDescription>
  </CardHeader>
  <CardContent>
    Conteúdo principal
  </CardContent>
  <CardFooter>
    Rodapé opcional
  </CardFooter>
</Card>
```

### Tabs

```tsx
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

<Tabs defaultValue="tab1">
  <TabsList>
    <TabsTrigger value="tab1">Tab 1</TabsTrigger>
    <TabsTrigger value="tab2">Tab 2</TabsTrigger>
  </TabsList>
  <TabsContent value="tab1">Conteúdo 1</TabsContent>
  <TabsContent value="tab2">Conteúdo 2</TabsContent>
</Tabs>
```

### Badge

```tsx
import { Badge } from "@/components/ui/badge"

// Estados dos créditos
<Badge variant="credits">💎 150</Badge>

// Outros usos
<Badge variant="primary">Novo</Badge>
<Badge variant="accent">Pro</Badge>
<Badge variant="success">Ativo</Badge>
<Badge variant="warning">Pendente</Badge>
<Badge variant="danger">Erro</Badge>
```

### Modal

```tsx
import { Modal, ModalTrigger, ModalContent, ModalHeader, ModalTitle, ModalDescription, ModalFooter } from "@/components/ui/modal"

<Modal>
  <ModalTrigger>Abrir Modal</ModalTrigger>
  <ModalContent>
    <ModalHeader>
      <ModalTitle>Título</ModalTitle>
      <ModalDescription>Descrição</ModalDescription>
    </ModalHeader>
    <ModalFooter>
      <Button>Ação</Button>
    </ModalFooter>
  </ModalContent>
</Modal>
```

## Diretrizes de Design

### Hierarquia de Cores
1. **Azul (primary)** - Ações primárias, estados do sistema, navegação ativa
2. **Laranja (accent)** - Alertas, upsells, CTAs secundários, badges importantes
3. **Nunca usar bordas grossas** - Apenas 0.2px hairline e efeitos glow

### Tipografia
- **Títulos**: `font-orbitron` (tecnológico, futurista)
- **Texto base**: `font-sans` (Inter - legibilidade)
- **Contraste**: Sempre garantir legibilidade com as cores de fumaça

### Microinterações
- **Hover**: Scale 1.02, transições suaves 300ms
- **Focus**: Outline azul com offset
- **Loading**: Skeleton states com shimmer
- **Feedback**: Toasts para ações de usuário

### Acessibilidade

#### Áreas de Clique
- Mínimo 44px para botões
- Espaçamento adequado entre elementos interativos

#### Navegação por Teclado
- Tab para navegar
- Enter/Space para ativar
- Escape para fechar modais
- Cmd/Ctrl+Enter para enviar forms

#### Contraste
- Texto principal: AAA (>7:1)
- Texto secundário: AA (>4.5:1)
- Estados de foco sempre visíveis

## Padrões de Uso

### Chat Multiagente
```tsx
// Badge de créditos com pulsação quando baixo
<Badge variant="credits" className={credits < 20 ? "animate-pulse" : ""}>
  💎 {credits}
</Badge>

// Cards de agentes
<Card className="hover:glow cursor-pointer">
  <CardContent>
    <Badge variant="primary">{agent.name}</Badge>
  </CardContent>
</Card>
```

### Estados de Loading
```tsx
// Skeleton para mensagens
<div className="glass border-hairline rounded-lg p-4 animate-pulse">
  <div className="w-3/4 h-4 bg-hja-surface rounded mb-2"></div>
  <div className="w-1/2 h-4 bg-hja-surface rounded"></div>
</div>
```

### Modais de Upsell
```tsx
<Modal>
  <ModalContent className="max-w-md">
    <ModalHeader>
      <ModalTitle className="text-hja-accent">Upgrade para Pro</ModalTitle>
      <ModalDescription>
        Desbloqueie recursos avançados e créditos ilimitados
      </ModalDescription>
    </ModalHeader>
    <ModalFooter className="gap-2">
      <Button variant="ghost">Talvez Depois</Button>
      <Button variant="accent" glow>Upgrade Agora</Button>
    </ModalFooter>
  </ModalContent>
</Modal>
```

## Performance

### Otimizações
- Componentes com `React.forwardRef` para refs
- Variantes CSS compiladas em build-time
- Transições CSS em vez de JS quando possível
- Lazy loading para modais e tooltips

### Bundle Size
- Tree-shaking automático
- Imports seletivos: `import { Button } from "@/components/ui/button"`
- Utilitários Tailwind purged em produção