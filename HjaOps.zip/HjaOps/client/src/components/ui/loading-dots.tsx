export function LoadingDots() {
  return (
    <div className="flex gap-1">
      <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.32s]"></span>
      <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce [animation-delay:-0.16s]"></span>
      <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce"></span>
    </div>
  );
}
