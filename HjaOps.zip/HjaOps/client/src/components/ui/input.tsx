import * as React from "react"

import { cn } from "@/lib/utils"

export interface InputProps extends React.ComponentProps<"input"> {
  error?: boolean
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type = 'text', error = false, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          'flex h-10 w-full rounded-lg glass border-hairline px-3 py-2 text-sm smoke-text',
          'placeholder:smoke-text-muted',
          'focus-visible-custom',
          'disabled:cursor-not-allowed disabled:opacity-50',
          'transition-all duration-300',
          'file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground',
          error && 'border-hja-danger shadow-[0_0_10px_rgba(255,68,68,0.2)]',
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Input.displayName = "Input"

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, error = false, ...props }, ref) => {
    return (
      <textarea
        className={cn(
          'flex min-h-[80px] w-full rounded-lg glass border-hairline px-3 py-2 text-sm smoke-text',
          'placeholder:smoke-text-muted',
          'focus-visible-custom',
          'disabled:cursor-not-allowed disabled:opacity-50',
          'transition-all duration-300 resize-none',
          error && 'border-hja-danger shadow-[0_0_10px_rgba(255,68,68,0.2)]',
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);
Textarea.displayName = 'Textarea';

export { Input, Textarea }
