import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { motion } from 'framer-motion'

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-all duration-300 focus-visible-custom disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border-hairline",
  {
    variants: {
      variant: {
        primary: "bg-hja-primary text-white border-hja-primary hover:shadow-neon hover:border-hja-primary/80",
        ghost: "bg-transparent text-hja-textBase border-hja-textMuted/30 hover:bg-hja-surface hover:border-hja-primary/50 hover:text-white",
        danger: "bg-hja-danger text-white border-hja-danger hover:shadow-[0_0_20px_rgba(255,68,68,0.3)]",
        accent: "bg-hja-accent text-white border-hja-accent hover:shadow-neon-accent hover:border-hja-accent/80",
        // Legacy variants for compatibility
        default: "bg-hja-primary text-white border-hja-primary hover:shadow-neon hover:border-hja-primary/80",
        destructive: "bg-hja-danger text-white border-hja-danger hover:shadow-[0_0_20px_rgba(255,68,68,0.3)]",
        outline: "bg-transparent text-hja-textBase border-hja-textMuted/30 hover:bg-hja-surface hover:border-hja-primary/50 hover:text-white",
        secondary: "bg-hja-surface text-hja-textBase border-hja-textMuted/30 hover:bg-hja-surfaceAlt hover:border-hja-primary/50",
        link: "text-hja-primary underline-offset-4 hover:underline border-transparent",
      },
      size: {
        sm: "h-8 px-3 text-sm rounded-md",
        md: "h-10 px-4 text-sm rounded-lg",
        lg: "h-12 px-6 text-base rounded-lg",
        // Legacy size for compatibility
        default: "h-10 px-4 text-sm rounded-lg",
        icon: "h-10 w-10 rounded-lg",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
  glow?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, glow = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    
    const glowEffect = glow && variant === 'primary' ? 'shadow-neon animate-pulse-glow' : '';
    
    if (asChild) {
      return (
        <Comp
          className={cn(buttonVariants({ variant, size }), glowEffect, className)}
          ref={ref}
          {...props}
        />
      )
    }
    
    return (
      <motion.button
        className={cn(buttonVariants({ variant, size }), glowEffect, className)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        transition={{ duration: 0.2 }}
        ref={ref}
        {...(props as any)}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
