import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center rounded-md border-hairline px-2.5 py-0.5 text-xs font-semibold transition-all duration-300 focus-visible-custom",
  {
    variants: {
      variant: {
        default: "border-hja-textMuted/30 bg-hja-surface smoke-text",
        primary: "border-hja-primary bg-hja-primary/10 text-hja-primary glow",
        accent: "border-hja-accent bg-hja-accent/10 text-hja-accent glow-accent",
        success: "border-hja-success bg-hja-success/10 text-hja-success",
        warning: "border-hja-warning bg-hja-warning/10 text-hja-warning",
        danger: "border-hja-danger bg-hja-danger/10 text-hja-danger",
        credits: "border-hja-primary bg-gradient-to-r from-hja-primary/20 to-hja-accent/20 text-white glow animate-pulse",
        outline: "border-hja-textMuted/30 smoke-text-muted",
        // Legacy variants for compatibility
        secondary: "border-hja-textMuted/30 bg-hja-surface smoke-text",
        destructive: "border-hja-danger bg-hja-danger/10 text-hja-danger",
      },
      size: {
        sm: "text-xs px-2 py-0.5",
        md: "text-xs px-2.5 py-0.5", 
        lg: "text-sm px-3 py-1",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, size, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant, size }), className)} {...props} />
  )
}

export { Badge, badgeVariants }
