import { useState } from 'react';
import { 
  Home,
  Video,
  FileText,
  Layout,
  Settings,
  BarChart3,
  Zap,
  PlusCircle,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface SidebarProps {
  isOpen?: boolean;
  currentPath?: string;
  onNavigate?: (path: string) => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon: any;
  path: string;
  badge?: string;
  children?: MenuItem[];
}

export default function Sidebar({ isOpen = true, currentPath = '/', onNavigate }: SidebarProps) {
  const [expandedGroups, setExpandedGroups] = useState<string[]>(['creation']);

  const menuItems: MenuItem[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: Home,
      path: '/'
    },
    {
      id: 'creation',
      label: 'Criação',
      icon: Video,
      path: '/creation',
      children: [
        { id: 'new-project', label: 'Novo Projeto', icon: PlusCircle, path: '/creation/new' },
        { id: 'concepts', label: 'Conceitos', icon: FileText, path: '/creation/concepts' },
        { id: 'scripts', label: 'Roteiros', icon: FileText, path: '/creation/scripts' },
        { id: 'storyboards', label: 'Storyboards', icon: Layout, path: '/creation/storyboards' }
      ]
    },
    {
      id: 'projects',
      label: 'Meus Projetos',
      icon: Video,
      path: '/projects',
      badge: '12'
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: BarChart3,
      path: '/analytics'
    },
    {
      id: 'tokens',
      label: 'Tokens & Créditos',
      icon: Zap,
      path: '/tokens',
      badge: '2.4k'
    },
    {
      id: 'settings',
      label: 'Configurações',
      icon: Settings,
      path: '/settings'
    }
  ];

  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => 
      prev.includes(groupId) 
        ? prev.filter(id => id !== groupId)
        : [...prev, groupId]
    );
  };

  const isActive = (path: string) => currentPath === path;
  const isGroupActive = (item: MenuItem) => {
    if (isActive(item.path)) return true;
    return item.children?.some(child => isActive(child.path)) || false;
  };

  const handleNavigate = (path: string) => {
    onNavigate?.(path);
  };

  if (!isOpen) {
    return (
      <aside className="w-16 lumiere-sidebar">
        <div className="p-4">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              onClick={() => handleNavigate(item.path)}
              className={`w-full mb-2 justify-center ${
                isGroupActive(item) 
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              data-testid={`sidebar-${item.id}`}
            >
              <item.icon className="w-5 h-5" />
            </Button>
          ))}
        </div>
      </aside>
    );
  }

  return (
    <aside className="lumiere-sidebar">
      <div className="p-6">
        
        {/* Header da Sidebar */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-white mb-2">Haja®Verso</h2>
          <p className="text-sm text-slate-400">AI Video Creation Platform</p>
        </div>

        {/* Menu Principal */}
        <nav className="space-y-2">
          {menuItems.map((item) => (
            <div key={item.id}>
              
              {/* Item Principal */}
              <div
                className={`lumiere-sidebar-item ${
                  isGroupActive(item) ? 'active' : ''
                }`}
                onClick={() => {
                  if (item.children) {
                    toggleGroup(item.id);
                  } else {
                    handleNavigate(item.path);
                  }
                }}
                data-testid={`sidebar-${item.id}`}
              >
                <item.icon className="w-5 h-5" />
                <span className="flex-1 font-medium">{item.label}</span>
                
                {item.badge && (
                  <Badge className="lumiere-badge bg-blue-500/20 text-blue-400 border border-blue-500/30">
                    {item.badge}
                  </Badge>
                )}
                
                {item.children && (
                  <div className="ml-auto">
                    {expandedGroups.includes(item.id) ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </div>
                )}
              </div>

              {/* Subitens */}
              {item.children && expandedGroups.includes(item.id) && (
                <div className="ml-6 mt-2 space-y-1 animate-slide-up">
                  {item.children.map((child) => (
                    <div
                      key={child.id}
                      className={`lumiere-sidebar-item ${
                        isActive(child.path) ? 'active' : ''
                      }`}
                      onClick={() => handleNavigate(child.path)}
                      data-testid={`sidebar-${child.id}`}
                    >
                      <child.icon className="w-4 h-4" />
                      <span className="font-medium">{child.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Footer da Sidebar */}
        <div className="mt-12 pt-6 border-t border-slate-800">
          <div className="lumiere-card p-4 bg-gradient-blue-purple">
            <div className="text-center text-white">
              <Zap className="w-8 h-8 mx-auto mb-2" />
              <h3 className="font-bold mb-1">Upgrade para Pro</h3>
              <p className="text-sm mb-3 opacity-90">
                Crie vídeos ilimitados com IA avançada
              </p>
              <Button 
                size="sm" 
                className="w-full bg-white text-blue-600 hover:bg-gray-100 lumiere-button"
              >
                Upgrade Agora
              </Button>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}