import { useState } from 'react';
import { Bell, Search, User, Settings, LogOut, Menu, Sun, Moon } from 'lucide-react';
import { useTheme } from './ThemeProvider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';

interface HeaderProps {
  onToggleSidebar?: () => void;
  user?: {
    name: string;
    email: string;
    avatar?: string;
  };
}

export default function Header({ onToggleSidebar, user }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="lumiere-header sticky top-0 z-50">
      <div className="flex items-center justify-between px-6 py-4">
        
        {/* Logo e Toggle Sidebar */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost" 
            size="sm"
            onClick={onToggleSidebar}
            className="lg:hidden text-slate-400 hover:text-white"
            data-testid="toggle-sidebar"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-blue-purple rounded-xl flex items-center justify-center">
              <span className="text-white font-bold text-sm">H</span>
            </div>
            <div>
              <h1 className="text-xl font-bold gradient-text">Haja®Verso</h1>
              <p className="text-xs text-slate-400">AI Video Creation</p>
            </div>
          </div>
        </div>

        {/* Busca */}
        <div className="hidden md:flex items-center flex-1 max-w-lg mx-8">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar projetos, conceitos, storyboards..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="lumiere-input pl-10 bg-slate-800/50 border-slate-700 text-white placeholder-slate-400"
              data-testid="search-input"
            />
          </div>
        </div>

        {/* Ações do Header */}
        <div className="flex items-center gap-3">
          
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="text-slate-400 hover:text-white"
            data-testid="theme-toggle"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
          
          {/* Notificações */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative text-slate-400 hover:text-white"
                data-testid="notifications-button"
              >
                <Bell className="w-5 h-5" />
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 bg-red-500 text-white text-xs">
                  3
                </Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 bg-slate-900 border-slate-700">
              <div className="p-4 border-b border-slate-700">
                <h3 className="font-semibold text-white">Notificações</h3>
                <p className="text-sm text-slate-400">Você tem 3 notificações não lidas</p>
              </div>
              
              <div className="max-h-64 overflow-y-auto">
                {[
                  { 
                    id: 1, 
                    type: 'success', 
                    title: 'Vídeo finalizado!', 
                    message: 'Seu projeto "Tutorial IA" está pronto',
                    time: '2 min'
                  },
                  { 
                    id: 2, 
                    type: 'info', 
                    title: 'HVC tem uma sugestão', 
                    message: 'Melhore seu storyboard com essas dicas',
                    time: '1h'
                  },
                  { 
                    id: 3, 
                    type: 'warning', 
                    title: 'Tokens em baixa', 
                    message: 'Você tem apenas 50 tokens restantes',
                    time: '3h'
                  }
                ].map((notification) => (
                  <DropdownMenuItem key={notification.id} className="p-4 hover:bg-slate-800">
                    <div className="flex items-start gap-3 w-full">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        notification.type === 'success' ? 'bg-green-500' :
                        notification.type === 'info' ? 'bg-blue-500' : 'bg-amber-500'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white text-sm">{notification.title}</p>
                        <p className="text-slate-400 text-xs">{notification.message}</p>
                        <p className="text-slate-500 text-xs mt-1">{notification.time} atrás</p>
                      </div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </div>
              
              <div className="p-2 border-t border-slate-700">
                <Button variant="ghost" size="sm" className="w-full text-blue-400 hover:text-blue-300">
                  Ver todas as notificações
                </Button>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Perfil do Usuário */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center gap-2 text-slate-400 hover:text-white"
                data-testid="user-menu"
              >
                <div className="w-8 h-8 bg-gradient-blue-purple rounded-full flex items-center justify-center">
                  {user?.avatar ? (
                    <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full" />
                  ) : (
                    <User className="w-4 h-4 text-white" />
                  )}
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-white">{user?.name || 'Usuário'}</p>
                  <p className="text-xs text-slate-400">{user?.email || 'usuario@email.com'}</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-slate-900 border-slate-700">
              <div className="p-4 border-b border-slate-700">
                <p className="font-medium text-white">{user?.name || 'Usuário'}</p>
                <p className="text-sm text-slate-400">{user?.email || 'usuario@email.com'}</p>
              </div>
              
              <DropdownMenuItem className="text-slate-300 hover:text-white hover:bg-slate-800">
                <User className="w-4 h-4 mr-2" />
                Meu Perfil
              </DropdownMenuItem>
              
              <DropdownMenuItem className="text-slate-300 hover:text-white hover:bg-slate-800">
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-slate-700" />
              
              <DropdownMenuItem className="text-red-400 hover:text-red-300 hover:bg-slate-800">
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}