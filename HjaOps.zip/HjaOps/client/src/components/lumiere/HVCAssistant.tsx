import { useState, useEffect } from 'react';
import { X, Lightbulb, Clock, Star, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

interface HVCMessage {
  id: string;
  type: 'suggestion' | 'reminder' | 'upsell';
  title: string;
  content: string;
  actionText?: string;
  onAction?: () => void;
  timestamp: Date;
}

interface HVCAssistantProps {
  isOpen?: boolean;
  onToggle?: () => void;
}

export default function HVCAssistant({ isOpen = true, onToggle }: HVCAssistantProps) {
  const [messages, setMessages] = useState<HVCMessage[]>([]);
  const [isMinimized, setIsMinimized] = useState(false);

  // Simular mensagens do HVC
  useEffect(() => {
    const initialMessages: HVCMessage[] = [
      {
        id: '1',
        type: 'suggestion',
        title: 'Melhore seu Storyboard',
        content: 'Você pode melhorar a transição entre as cenas 2 e 3 adicionando um fade-in suave. Isso criará um fluxo mais natural.',
        actionText: 'Aplicar Sugestão',
        timestamp: new Date()
      },
      {
        id: '2',
        type: 'reminder',
        title: 'Complete seu Perfil',
        content: 'Complete seu cadastro para liberar todos os recursos! Faltam apenas as preferências de estilo de vídeo.',
        actionText: 'Completar Agora',
        timestamp: new Date(Date.now() - 1000 * 60 * 30) // 30 min ago
      },
      {
        id: '3',
        type: 'upsell',
        title: 'Tokens em Baixa',
        content: 'Adquira tokens extras para criar mais projetos! Aproveite 20% de desconto no pacote Pro.',
        actionText: 'Ver Pacotes',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
      }
    ];

    setMessages(initialMessages);
  }, []);

  const getMessageIcon = (type: HVCMessage['type']) => {
    switch (type) {
      case 'suggestion':
        return <Lightbulb className="w-5 h-5" />;
      case 'reminder':
        return <Clock className="w-5 h-5" />;
      case 'upsell':
        return <Star className="w-5 h-5" />;
    }
  };

  const getMessageStyle = (type: HVCMessage['type']) => {
    switch (type) {
      case 'suggestion':
        return 'hvc-suggestion';
      case 'reminder':
        return 'hvc-reminder';
      case 'upsell':
        return 'hvc-upsell';
    }
  };

  const dismissMessage = (messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));

    if (minutes < 1) return 'agora';
    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return date.toLocaleDateString();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed right-6 top-24 w-80 z-40">
      <div className="lumiere-card bg-slate-900/95 backdrop-blur-lg border-slate-700">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-blue-purple rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">HVC</span>
            </div>
            <div>
              <h3 className="font-bold text-white">Assistente HVC</h3>
              <p className="text-xs text-slate-400">IA Proativa • Online</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="text-slate-400 hover:text-white w-8 h-8 p-0"
            >
              {isMinimized ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggle}
              className="text-slate-400 hover:text-white w-8 h-8 p-0"
              data-testid="close-hvc"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Mensagens */}
        <AnimatePresence>
          {!isMinimized && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="max-h-96 overflow-y-auto"
            >
              <div className="p-4 space-y-4">
                {messages.length === 0 ? (
                  <div className="text-center py-8">
                    <Lightbulb className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                    <p className="text-slate-400">Nenhuma mensagem no momento</p>
                    <p className="text-sm text-slate-500">O HVC analisará seu projeto e dará sugestões</p>
                  </div>
                ) : (
                  messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className={`hvc-message ${getMessageStyle(message.type)}`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          message.type === 'suggestion' ? 'bg-blue-500/20 text-blue-400' :
                          message.type === 'reminder' ? 'bg-amber-500/20 text-amber-400' :
                          'bg-purple-500/20 text-purple-400'
                        }`}>
                          {getMessageIcon(message.type)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-semibold text-white text-sm">{message.title}</h4>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => dismissMessage(message.id)}
                              className="text-slate-400 hover:text-white w-6 h-6 p-0"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                          
                          <p className="text-sm text-slate-300 mb-3 leading-relaxed">
                            {message.content}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            {message.actionText && (
                              <Button
                                size="sm"
                                onClick={message.onAction}
                                className={`text-xs lumiere-button ${
                                  message.type === 'suggestion' ? 'lumiere-button-primary' :
                                  message.type === 'reminder' ? 'bg-amber-500 hover:bg-amber-600 text-white' :
                                  'bg-purple-500 hover:bg-purple-600 text-white'
                                }`}
                              >
                                {message.actionText}
                              </Button>
                            )}
                            
                            <span className="text-xs text-slate-500 ml-auto">
                              {formatTime(message.timestamp)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Actions */}
        {!isMinimized && (
          <div className="p-4 border-t border-slate-700">
            <div className="grid grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
              >
                <Lightbulb className="w-3 h-3 mr-1" />
                Dicas
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs border-slate-600 text-slate-300 hover:text-white hover:bg-slate-700"
              >
                <Star className="w-3 h-3 mr-1" />
                Feedback
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}