import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap,
  Plus,
  TrendingDown,
  AlertTriangle,
  CreditCard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Link } from 'wouter';
import { formatCredits } from '@/types/pricing';
import UpsellModal from './UpsellModal';

interface CreditWidgetProps {
  credits: number;
  className?: string;
  showUpgrade?: boolean;
  compact?: boolean;
}

export default function CreditWidget({ 
  credits, 
  className = '',
  showUpgrade = true,
  compact = false 
}: CreditWidgetProps) {
  const [showUpsell, setShowUpsell] = useState(false);
  const [dailyUsage, setDailyUsage] = useState(8.5);
  const [estimatedDays, setEstimatedDays] = useState(0);

  useEffect(() => {
    // Calculate estimated days based on current usage
    if (dailyUsage > 0) {
      setEstimatedDays(Math.floor(credits / dailyUsage));
    }
  }, [credits, dailyUsage]);

  const getStatusConfig = () => {
    if (credits === 0) {
      return {
        status: 'critical',
        color: 'text-red-400',
        bgColor: 'bg-red-500/10',
        borderColor: 'border-red-500/30',
        icon: <AlertTriangle className="w-4 h-4 text-red-400" />,
        message: 'Sem créditos'
      };
    } else if (credits < 10) {
      return {
        status: 'low',
        color: 'admin-text-orange',
        bgColor: 'bg-orange-500/10',
        borderColor: 'border-orange-500/30',
        icon: <TrendingDown className="w-4 h-4 admin-text-orange" />,
        message: 'Créditos baixos'
      };
    } else if (credits < 50) {
      return {
        status: 'medium',
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-500/10',
        borderColor: 'border-yellow-500/30',
        icon: <Zap className="w-4 h-4 text-yellow-400" />,
        message: 'Créditos moderados'
      };
    } else {
      return {
        status: 'good',
        color: 'text-green-400',
        bgColor: 'bg-green-500/10',
        borderColor: 'border-green-500/30',
        icon: <Zap className="w-4 h-4 text-green-400" />,
        message: 'Créditos OK'
      };
    }
  };

  const config = getStatusConfig();
  const progressValue = Math.min((credits / 100) * 100, 100);

  const handleUpgradeClick = () => {
    if (credits === 0) {
      setShowUpsell(true);
    }
  };

  const handleSelectPackage = (packageId: string) => {
    console.log('Selected package:', packageId);
    setShowUpsell(false);
  };

  if (compact) {
    return (
      <>
        <motion.div
          className={`flex items-center gap-2 ${className}`}
          whileHover={{ scale: 1.02 }}
        >
          <div className={`p-2 rounded-lg ${config.bgColor} ${config.borderColor} border`}>
            {config.icon}
          </div>
          
          <div>
            <div className="flex items-center gap-2">
              <span className={`font-bold ${config.color}`}>
                {formatCredits(credits)}
              </span>
              {credits < 10 && (
                <Badge className="bg-red-500 text-white text-xs">
                  Baixo
                </Badge>
              )}
            </div>
            {estimatedDays > 0 && estimatedDays < 7 && (
              <p className="text-xs admin-text-smoke">
                ~{estimatedDays} dias restantes
              </p>
            )}
          </div>

          {showUpgrade && credits < 50 && (
            <Button
              size="sm"
              variant="outline"
              className="border-blue-500/20 admin-text-blue text-xs"
              asChild
            >
              <Link to="/buy-credits">
                <Plus className="w-3 h-3 mr-1" />
                Comprar
              </Link>
            </Button>
          )}
        </motion.div>

        <UpsellModal
          isOpen={showUpsell}
          onClose={() => setShowUpsell(false)}
          currentCredits={credits}
          estimatedCost={dailyUsage}
          trigger={credits === 0 ? 'out_of_credits' : 'low_credits'}
          onSelectPackage={handleSelectPackage}
          onViewPlans={() => {
            setShowUpsell(false);
            // Navigate to plans
          }}
        />
      </>
    );
  }

  return (
    <>
      <motion.div
        className={`admin-card p-4 ${className}`}
        whileHover={{ scale: 1.02 }}
        onClick={handleUpgradeClick}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            {config.icon}
            <span className="font-semibold admin-text-blue">Créditos</span>
          </div>
          
          <Badge 
            className={`${
              config.status === 'critical' ? 'bg-red-500' :
              config.status === 'low' ? 'admin-bg-orange' :
              config.status === 'medium' ? 'bg-yellow-500' :
              'bg-green-500'
            } text-white text-xs`}
          >
            {config.message}
          </Badge>
        </div>

        {/* Credit Display */}
        <div className="mb-4">
          <div className="flex items-baseline gap-2">
            <span className={`text-3xl font-bold ${config.color}`}>
              {formatCredits(credits)}
            </span>
            <span className="text-sm admin-text-smoke">disponíveis</span>
          </div>

          {/* Progress Bar */}
          <div className="mt-2">
            <Progress 
              value={progressValue} 
              className="h-2 bg-black/30" 
            />
            <div className="flex justify-between text-xs admin-text-smoke mt-1">
              <span>0</span>
              <span>100+</span>
            </div>
          </div>
        </div>

        {/* Usage Prediction */}
        {estimatedDays > 0 && (
          <div className="mb-4 p-3 rounded-lg bg-black/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold admin-text-blue">
                  Estimativa de duração
                </p>
                <p className="text-xs admin-text-smoke">
                  Com base no uso médio de {dailyUsage} créditos/dia
                </p>
              </div>
              
              <div className="text-right">
                <p className={`text-lg font-bold ${
                  estimatedDays < 3 ? 'text-red-400' :
                  estimatedDays < 7 ? 'admin-text-orange' :
                  'text-green-400'
                }`}>
                  {estimatedDays}
                </p>
                <p className="text-xs admin-text-smoke">dias</p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2">
          {showUpgrade && (
            <>
              <Button 
                className="w-full admin-bg-blue hover:opacity-90"
                asChild
              >
                <Link to="/buy-credits">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Comprar Créditos
                </Link>
              </Button>

              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue text-sm"
                asChild
              >
                <Link to="/my-credits">
                  Ver histórico completo
                </Link>
              </Button>
            </>
          )}
        </div>

        {/* Low Credit Warning */}
        {credits < 10 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20"
          >
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <div>
                <p className="text-sm font-medium text-red-400">
                  Créditos baixos
                </p>
                <p className="text-xs text-red-300">
                  Compre mais créditos para continuar usando nossos agentes
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>

      <UpsellModal
        isOpen={showUpsell}
        onClose={() => setShowUpsell(false)}
        currentCredits={credits}
        estimatedCost={dailyUsage}
        trigger={credits === 0 ? 'out_of_credits' : 'low_credits'}
        onSelectPackage={handleSelectPackage}
        onViewPlans={() => {
          setShowUpsell(false);
          // Navigate to plans
        }}
      />
    </>
  );
}