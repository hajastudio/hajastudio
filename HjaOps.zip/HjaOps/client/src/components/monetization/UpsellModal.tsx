import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X,
  Zap,
  CreditCard,
  TrendingUp,
  Clock,
  Star,
  ArrowRight,
  Gift
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogOverlay } from '@/components/ui/dialog';
import { CREDIT_PACKAGES, formatPrice, type CreditPackage } from '@/types/pricing';

interface UpsellModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCredits: number;
  estimatedCost: number;
  trigger: 'low_credits' | 'out_of_credits' | 'high_usage';
  onSelectPackage: (packageId: string) => void;
  onViewPlans: () => void;
}

export default function UpsellModal({ 
  isOpen, 
  onClose, 
  currentCredits, 
  estimatedCost, 
  trigger,
  onSelectPackage,
  onViewPlans 
}: UpsellModalProps) {
  const [showDownsell, setShowDownsell] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null);

  const getModalConfig = () => {
    switch (trigger) {
      case 'out_of_credits':
        return {
          title: 'Ops! Créditos esgotados',
          subtitle: 'Você precisa de mais créditos para continuar conversando',
          urgency: 'high',
          icon: <Zap className="w-8 h-8 text-red-400" />,
          color: 'red'
        };
      case 'low_credits':
        return {
          title: 'Créditos acabando',
          subtitle: `Você tem apenas ${currentCredits} créditos restantes`,
          urgency: 'medium',
          icon: <Clock className="w-8 h-8 admin-text-orange" />,
          color: 'orange'
        };
      case 'high_usage':
        return {
          title: 'Upgrade recomendado',
          subtitle: 'Você está usando bastante nossos agentes. Que tal economizar?',
          urgency: 'low',
          icon: <TrendingUp className="w-8 h-8 admin-text-blue" />,
          color: 'blue'
        };
      default:
        return {
          title: 'Comprar Créditos',
          subtitle: 'Escolha o pacote ideal para você',
          urgency: 'low',
          icon: <CreditCard className="w-8 h-8 admin-text-blue" />,
          color: 'blue'
        };
    }
  };

  const config = getModalConfig();

  const getRecommendedPackage = (): CreditPackage => {
    if (estimatedCost > 100) return CREDIT_PACKAGES[3]; // Enterprise
    if (estimatedCost > 50) return CREDIT_PACKAGES[2]; // Professional
    if (estimatedCost > 20) return CREDIT_PACKAGES[1]; // Popular
    return CREDIT_PACKAGES[0]; // Starter
  };

  const recommendedPackage = getRecommendedPackage();

  const handleDecline = () => {
    if (trigger === 'out_of_credits' && !showDownsell) {
      setShowDownsell(true);
    } else {
      onClose();
    }
  };

  const handleSelectPackage = (packageId: string) => {
    setSelectedPackage(packageId);
    onSelectPackage(packageId);
  };

  const downsellPackage = CREDIT_PACKAGES[0]; // Smallest package with special discount

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogOverlay className="bg-black/80 backdrop-blur-sm" />
      <DialogContent className="max-w-2xl p-0 overflow-hidden admin-card border-blue-500/30">
        
        <AnimatePresence mode="wait">
          {!showDownsell ? (
            // Main Upsell Content
            <motion.div
              key="upsell"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-8"
            >
              
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    config.color === 'red' ? 'bg-red-500/20' :
                    config.color === 'orange' ? 'bg-orange-500/20' :
                    'bg-blue-500/20'
                  }`}>
                    {config.icon}
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold admin-text-blue">
                      {config.title}
                    </h1>
                    <p className="admin-text-smoke">
                      {config.subtitle}
                    </p>
                  </div>
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="admin-text-smoke hover:admin-text-blue"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Current Status */}
              <div className="p-4 rounded-lg bg-black/30 border border-blue-500/20 mb-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm admin-text-smoke">Créditos atuais</p>
                    <p className="text-2xl font-bold admin-text-blue">{currentCredits}</p>
                  </div>
                  
                  {estimatedCost > 0 && (
                    <div className="text-right">
                      <p className="text-sm admin-text-smoke">Custo estimado</p>
                      <p className="text-2xl font-bold admin-text-orange">
                        {estimatedCost.toFixed(1)}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Recommended Package Highlight */}
              <div className="mb-6">
                <h2 className="text-lg font-bold admin-text-blue mb-3">
                  📊 Recomendado para você
                </h2>
                
                <motion.div 
                  className="p-6 rounded-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-2 border-blue-500/30 relative overflow-hidden"
                  whileHover={{ scale: 1.02 }}
                >
                  <Badge className="absolute top-4 right-4 bg-green-500 text-white">
                    Melhor valor
                  </Badge>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold admin-text-blue">
                        {recommendedPackage.name}
                      </h3>
                      <p className="admin-text-smoke">{recommendedPackage.description}</p>
                    </div>
                    
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <span className="text-3xl font-bold admin-text-blue">
                          {formatPrice(recommendedPackage.price)}
                        </span>
                        {recommendedPackage.originalPrice && (
                          <span className="text-lg line-through admin-text-smoke">
                            {formatPrice(recommendedPackage.originalPrice)}
                          </span>
                        )}
                      </div>
                      <p className="text-sm admin-text-smoke">
                        {recommendedPackage.credits} créditos
                      </p>
                    </div>
                  </div>

                  {recommendedPackage.bonus && (
                    <div className="flex items-center gap-2 mb-4">
                      <Gift className="w-4 h-4 admin-text-orange" />
                      <span className="text-sm font-bold admin-text-orange">
                        +{recommendedPackage.bonus} créditos bônus inclusos!
                      </span>
                    </div>
                  )}

                  <Button 
                    onClick={() => handleSelectPackage(recommendedPackage.id)}
                    className="w-full admin-bg-blue hover:opacity-90 text-lg py-3"
                    disabled={selectedPackage === recommendedPackage.id}
                  >
                    {selectedPackage === recommendedPackage.id ? 'Processando...' : 'Comprar agora'}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </motion.div>
              </div>

              {/* Other Options */}
              <div className="mb-6">
                <h3 className="text-lg font-bold admin-text-blue mb-3">
                  Outras opções
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {CREDIT_PACKAGES.filter(pkg => pkg.id !== recommendedPackage.id).map((pkg) => (
                    <motion.div
                      key={pkg.id}
                      className="p-4 rounded-lg admin-card border border-blue-500/20 hover:border-blue-500/40 transition-all cursor-pointer"
                      whileHover={{ scale: 1.02 }}
                      onClick={() => handleSelectPackage(pkg.id)}
                    >
                      <div className="text-center">
                        <h4 className="font-bold admin-text-blue">{pkg.name}</h4>
                        <p className="text-2xl font-bold admin-text-blue mt-2">
                          {formatPrice(pkg.price)}
                        </p>
                        <p className="text-sm admin-text-smoke">
                          {pkg.credits} créditos
                        </p>
                        
                        {pkg.bonus && (
                          <Badge className="mt-2 admin-bg-orange text-white text-xs">
                            +{pkg.bonus} bônus
                          </Badge>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4">
                <Button
                  onClick={onViewPlans}
                  variant="outline"
                  className="flex-1 border-blue-500/20 admin-text-blue hover:bg-blue-500/10"
                >
                  Ver Planos Mensais
                </Button>
                
                <Button
                  onClick={handleDecline}
                  variant="ghost"
                  className="admin-text-smoke hover:text-red-400"
                >
                  {trigger === 'out_of_credits' ? 'Não agora' : 'Cancelar'}
                </Button>
              </div>
            </motion.div>
          ) : (
            // Downsell Content
            <motion.div
              key="downsell"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="p-8 text-center"
            >
              <div className="w-16 h-16 bg-orange-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 admin-text-orange" />
              </div>
              
              <h2 className="text-2xl font-bold admin-text-blue mb-2">
                Espera! Oferta especial 🎉
              </h2>
              <p className="admin-text-smoke mb-6">
                Que tal começar pequeno? Pacote starter com <strong>30% de desconto</strong> só hoje!
              </p>

              <div className="p-6 rounded-xl bg-gradient-to-r from-orange-500/10 to-red-500/10 border-2 border-orange-500/30 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold admin-text-blue">{downsellPackage.name}</h3>
                    <p className="admin-text-smoke">{downsellPackage.description}</p>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-green-400">
                        {formatPrice(downsellPackage.price * 0.7)}
                      </span>
                      <span className="text-lg line-through admin-text-smoke">
                        {formatPrice(downsellPackage.price)}
                      </span>
                    </div>
                    <Badge className="bg-red-500 text-white text-xs">
                      30% OFF
                    </Badge>
                  </div>
                </div>

                <Button 
                  onClick={() => handleSelectPackage('credits_50_discount')}
                  className="w-full admin-bg-orange hover:opacity-90"
                >
                  Aproveitar oferta especial
                </Button>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={() => setShowDownsell(false)}
                  variant="outline"
                  className="flex-1 border-blue-500/20 admin-text-blue"
                >
                  ← Voltar
                </Button>
                
                <Button
                  onClick={onClose}
                  variant="ghost"
                  className="admin-text-smoke hover:text-red-400"
                >
                  Fechar
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}