import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  CheckCircle,
  XCircle,
  Clock,
  CreditCard,
  Loader,
  AlertTriangle,
  RefreshCw,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogOverlay } from '@/components/ui/dialog';
import { formatPrice } from '@/types/pricing';

interface PaymentStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  paymentId: string;
  amount: number;
  credits: number;
  status: 'processing' | 'approved' | 'rejected' | 'pending' | 'timeout';
  onRetry?: () => void;
  onCheckStatus?: () => void;
}

export default function PaymentStatusModal({
  isOpen,
  onClose,
  paymentId,
  amount,
  credits,
  status,
  onRetry,
  onCheckStatus
}: PaymentStatusModalProps) {
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [showRetryOptions, setShowRetryOptions] = useState(false);

  useEffect(() => {
    if (status === 'processing') {
      const interval = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
        
        // Show retry options after 2 minutes
        if (timeElapsed >= 120) {
          setShowRetryOptions(true);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [status, timeElapsed]);

  const getStatusConfig = () => {
    switch (status) {
      case 'processing':
        return {
          icon: <Loader className="w-16 h-16 text-blue-400 animate-spin" />,
          title: 'Processando pagamento...',
          subtitle: 'Aguarde enquanto confirmamos seu pagamento',
          color: 'blue',
          bgColor: 'bg-blue-500/10',
          borderColor: 'border-blue-500/30'
        };
      case 'approved':
        return {
          icon: <CheckCircle className="w-16 h-16 text-green-400" />,
          title: 'Pagamento aprovado!',
          subtitle: 'Seus créditos foram adicionados à sua conta',
          color: 'green',
          bgColor: 'bg-green-500/10',
          borderColor: 'border-green-500/30'
        };
      case 'rejected':
        return {
          icon: <XCircle className="w-16 h-16 text-red-400" />,
          title: 'Pagamento rejeitado',
          subtitle: 'Houve um problema com seu pagamento',
          color: 'red',
          bgColor: 'bg-red-500/10',
          borderColor: 'border-red-500/30'
        };
      case 'pending':
        return {
          icon: <Clock className="w-16 h-16 admin-text-orange" />,
          title: 'Pagamento pendente',
          subtitle: 'Aguardando confirmação do banco',
          color: 'orange',
          bgColor: 'bg-orange-500/10',
          borderColor: 'border-orange-500/30'
        };
      case 'timeout':
        return {
          icon: <AlertTriangle className="w-16 h-16 admin-text-orange" />,
          title: 'Tempo esgotado',
          subtitle: 'Não conseguimos confirmar seu pagamento',
          color: 'orange',
          bgColor: 'bg-orange-500/10',
          borderColor: 'border-orange-500/30'
        };
      default:
        return {
          icon: <CreditCard className="w-16 h-16 admin-text-blue" />,
          title: 'Processando...',
          subtitle: '',
          color: 'blue',
          bgColor: 'bg-blue-500/10',
          borderColor: 'border-blue-500/30'
        };
    }
  };

  const config = getStatusConfig();
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogOverlay className="bg-black/80 backdrop-blur-sm" />
      <DialogContent className="max-w-md p-0 overflow-hidden admin-card border-blue-500/30">
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`p-8 text-center ${config.bgColor} ${config.borderColor} border-t-4`}
        >
          
          {/* Status Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="flex justify-center mb-6"
          >
            {config.icon}
          </motion.div>

          {/* Title & Subtitle */}
          <h2 className="text-2xl font-bold admin-text-blue mb-2">
            {config.title}
          </h2>
          <p className="admin-text-smoke mb-6">
            {config.subtitle}
          </p>

          {/* Payment Details */}
          <div className="p-4 rounded-lg bg-black/30 border border-blue-500/20 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-400">
                  {formatPrice(amount)}
                </p>
                <p className="text-xs admin-text-smoke">Valor pago</p>
              </div>
              
              <div className="text-center">
                <p className="text-2xl font-bold admin-text-blue">
                  +{credits}
                </p>
                <p className="text-xs admin-text-smoke">Créditos</p>
              </div>
            </div>

            {paymentId && (
              <div className="mt-3 pt-3 border-t border-blue-500/10">
                <p className="text-xs admin-text-smoke">
                  ID: {paymentId.slice(0, 12)}...
                </p>
              </div>
            )}
          </div>

          {/* Processing Timer */}
          {status === 'processing' && (
            <div className="mb-6">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Clock className="w-4 h-4 admin-text-smoke" />
                <span className="text-sm admin-text-smoke">
                  Tempo decorrido: {formatTime(timeElapsed)}
                </span>
              </div>
              
              {timeElapsed > 60 && (
                <p className="text-xs text-yellow-400">
                  Pagamentos podem levar até 5 minutos para serem confirmados
                </p>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3">
            {status === 'approved' && (
              <>
                <Button
                  onClick={onClose}
                  className="w-full admin-bg-blue hover:opacity-90"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Continuar
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full border-blue-500/20 admin-text-blue"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Baixar comprovante
                </Button>
              </>
            )}

            {status === 'rejected' && (
              <>
                {onRetry && (
                  <Button
                    onClick={onRetry}
                    className="w-full admin-bg-orange hover:opacity-90"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Tentar novamente
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="w-full border-red-500/20 text-red-400"
                >
                  Fechar
                </Button>
              </>
            )}

            {status === 'processing' && (
              <>
                {showRetryOptions || timeElapsed > 120 ? (
                  <div className="space-y-2">
                    {onCheckStatus && (
                      <Button
                        onClick={onCheckStatus}
                        variant="outline"
                        className="w-full border-blue-500/20 admin-text-blue"
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Verificar status
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      onClick={onClose}
                      className="w-full admin-text-smoke"
                    >
                      Fechar e verificar depois
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="ghost"
                    onClick={onClose}
                    className="w-full admin-text-smoke"
                  >
                    Continuar em segundo plano
                  </Button>
                )}
              </>
            )}

            {(status === 'pending' || status === 'timeout') && (
              <>
                {onCheckStatus && (
                  <Button
                    onClick={onCheckStatus}
                    className="w-full admin-bg-blue hover:opacity-90"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Verificar status
                  </Button>
                )}
                
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="w-full border-blue-500/20 admin-text-blue"
                >
                  Fechar
                </Button>
              </>
            )}
          </div>

          {/* Additional Info */}
          {status === 'pending' && (
            <div className="mt-4 p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
              <p className="text-xs text-orange-300">
                <strong>Pagamento pendente:</strong> Alguns métodos de pagamento podem 
                levar até 24h para serem confirmados. Você receberá um email quando 
                o pagamento for aprovado.
              </p>
            </div>
          )}

          {status === 'rejected' && (
            <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <p className="text-xs text-red-300">
                <strong>Possíveis causas:</strong> Saldo insuficiente, dados incorretos 
                ou limite de cartão excedido. Verifique os dados e tente novamente.
              </p>
            </div>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}