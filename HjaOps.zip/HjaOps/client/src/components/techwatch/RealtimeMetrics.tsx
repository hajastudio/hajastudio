import { motion } from 'framer-motion';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Zap,
  Users,
  Server,
  TrendingUp,
  TrendingDown,
  Wifi,
  Database
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';

interface SystemHealth {
  overall: number;
  lastScan: Date;
  activeIncidents: number;
  todayErrors: number;
  avgLatency: number;
  costToday: number;
  tokenUsage: number;
  fallbackRate: number;
}

interface RealtimeMetricsProps {
  data: SystemHealth;
}

export default function RealtimeMetrics({ data }: RealtimeMetricsProps) {
  
  // Provider status data
  const providers = [
    {
      id: 'groq',
      name: 'Groq (Llama 3)',
      status: 'operational',
      uptime: 99.8,
      latency: 120,
      errors: 2,
      requests: 12847,
      cost: 23.40
    },
    {
      id: 'openai',
      name: 'OpenAI GPT-4o',
      status: 'degraded',
      uptime: 97.2,
      latency: 850,
      errors: 8,
      requests: 6234,
      cost: 89.50
    },
    {
      id: 'huggingface',
      name: 'HuggingFace',
      status: 'operational',
      uptime: 99.1,
      latency: 200,
      errors: 1,
      requests: 8956,
      cost: 12.80
    },
    {
      id: 'anthropic',
      name: 'Claude 3',
      status: 'maintenance',
      uptime: 95.0,
      latency: 0,
      errors: 0,
      requests: 0,
      cost: 0
    }
  ];

  // Real-time latency chart
  const latencyData = Array.from({length: 30}, (_, i) => ({
    timestamp: new Date(Date.now() - (29-i) * 60000),
    p95: 300 + Math.random() * 200,
    p99: 500 + Math.random() * 300
  }));

  const latencyChartOptions: ApexOptions = {
    chart: {
      type: 'line',
      height: 300,
      background: 'transparent',
      toolbar: { show: false }
    },
    theme: { mode: 'dark' },
    stroke: {
      curve: 'smooth',
      width: 2,
      colors: ['#0055ff', '#ff6a00']
    },
    xaxis: {
      categories: latencyData.map(d => d.timestamp.toLocaleTimeString().slice(0, 5)),
      labels: { style: { colors: '#c5d1db' } }
    },
    yaxis: {
      labels: { 
        style: { colors: '#c5d1db' },
        formatter: (value: number) => `${value.toFixed(0)}ms`
      }
    },
    legend: {
      labels: { colors: '#c5d1db' }
    },
    grid: {
      borderColor: '#374151',
      strokeDashArray: 3
    },
    colors: ['#0055ff', '#ff6a00']
  };

  const latencyChartSeries = [
    {
      name: 'P95 Latência',
      data: latencyData.map(d => d.p95)
    },
    {
      name: 'P99 Latência',
      data: latencyData.map(d => d.p99)
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'bg-green-500';
      case 'degraded': return 'admin-bg-orange';
      case 'outage': return 'bg-red-500';
      case 'maintenance': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'degraded': return <AlertTriangle className="w-4 h-4 admin-text-orange" />;
      case 'outage': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'maintenance': return <Clock className="w-4 h-4 admin-text-blue" />;
      default: return <Server className="w-4 h-4 admin-text-smoke" />;
    }
  };

  return (
    <div className="space-y-8">
      
      {/* System Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <Badge className="bg-green-500 text-white">
              {data.overall >= 98 ? 'Excelente' : data.overall >= 95 ? 'Bom' : 'Degradado'}
            </Badge>
          </div>
          
          <div>
            <p className="text-3xl font-bold text-green-400 mb-1">{data.overall.toFixed(1)}%</p>
            <p className="admin-text-smoke text-sm">System Health</p>
            <div className="mt-3">
              <Progress value={data.overall} className="h-2" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1">
              {data.avgLatency > 500 ? 
                <TrendingUp className="w-4 h-4 text-red-400" /> : 
                <TrendingDown className="w-4 h-4 text-green-400" />
              }
            </div>
          </div>
          
          <div>
            <p className="text-3xl font-bold admin-text-blue mb-1">{data.avgLatency.toFixed(0)}ms</p>
            <p className="admin-text-smoke text-sm">Latência Média</p>
            <p className="text-xs admin-text-smoke mt-1">P95: 650ms | P99: 1.2s</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <Badge className={`${data.todayErrors > 20 ? 'bg-red-500' : data.todayErrors > 10 ? 'admin-bg-orange' : 'bg-green-500'} text-white`}>
              {data.todayErrors > 20 ? 'Alto' : data.todayErrors > 10 ? 'Médio' : 'Baixo'}
            </Badge>
          </div>
          
          <div>
            <p className="text-3xl font-bold admin-text-orange mb-1">{data.todayErrors}</p>
            <p className="admin-text-smoke text-sm">Erros Hoje</p>
            <p className="text-xs text-green-400 mt-1">-23% vs ontem</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
              <Wifi className="w-6 h-6 text-white" />
            </div>
            <Badge className="bg-purple-500 text-white">
              {data.fallbackRate.toFixed(1)}%
            </Badge>
          </div>
          
          <div>
            <p className="text-3xl font-bold text-purple-400 mb-1">{data.fallbackRate.toFixed(1)}%</p>
            <p className="admin-text-smoke text-sm">Taxa Fallback</p>
            <p className="text-xs admin-text-smoke mt-1">AutoSwitch ativo</p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Provider Status */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Latency Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Latência em Tempo Real</h2>
            
            <Chart
              options={latencyChartOptions}
              series={latencyChartSeries}
              type="line"
              height={300}
            />
          </motion.div>

          {/* Provider Health Matrix */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Status dos Provedores</h2>
            
            <div className="space-y-4">
              {providers.map((provider, index) => (
                <motion.div
                  key={provider.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className="p-4 rounded-lg bg-black/30 border border-blue-500/20"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(provider.status)}`} />
                      <h3 className="font-semibold admin-text-blue">{provider.name}</h3>
                      {getStatusIcon(provider.status)}
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-bold admin-text-blue">{provider.uptime.toFixed(1)}%</p>
                        <p className="text-xs admin-text-smoke">Uptime</p>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-sm font-bold admin-text-orange">
                          {provider.latency > 0 ? `${provider.latency}ms` : '-'}
                        </p>
                        <p className="text-xs admin-text-smoke">Latência</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mt-3">
                    <div className="text-center p-2 rounded bg-black/30">
                      <p className="text-lg font-bold text-red-400">{provider.errors}</p>
                      <p className="text-xs admin-text-smoke">Erros/h</p>
                    </div>
                    
                    <div className="text-center p-2 rounded bg-black/30">
                      <p className="text-lg font-bold admin-text-blue">{provider.requests.toLocaleString()}</p>
                      <p className="text-xs admin-text-smoke">Requests</p>
                    </div>
                    
                    <div className="text-center p-2 rounded bg-black/30">
                      <p className="text-lg font-bold text-green-400">R$ {provider.cost.toFixed(2)}</p>
                      <p className="text-xs admin-text-smoke">Custo</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Real-time Stats Sidebar */}
        <div className="space-y-6">
          
          {/* Active Monitoring */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Monitoramento Ativo</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Checks/min</span>
                <span className="text-sm font-bold admin-text-blue">720</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Endpoints</span>
                <span className="text-sm font-bold admin-text-blue">24</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Alerts 24h</span>
                <span className="text-sm font-bold admin-text-orange">7</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Auto-healing</span>
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-sm font-bold text-green-400">Ativo</span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span className="text-sm font-semibold text-green-400">Sistema Estável</span>
              </div>
              <p className="text-xs text-green-300">
                Todos os serviços operacionais há 6h 32m
              </p>
            </div>
          </motion.div>

          {/* Quick Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Métricas Rápidas</h3>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between p-2 rounded bg-black/30">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 admin-text-blue" />
                  <span className="text-sm admin-text-smoke">Usuários Online</span>
                </div>
                <span className="text-sm font-bold admin-text-blue">247</span>
              </div>
              
              <div className="flex items-center justify-between p-2 rounded bg-black/30">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 admin-text-orange" />
                  <span className="text-sm admin-text-smoke">Req/min</span>
                </div>
                <span className="text-sm font-bold admin-text-orange">1,247</span>
              </div>
              
              <div className="flex items-center justify-between p-2 rounded bg-black/30">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-green-400" />
                  <span className="text-sm admin-text-smoke">DB Queries</span>
                </div>
                <span className="text-sm font-bold text-green-400">892/min</span>
              </div>
              
              <div className="flex items-center justify-between p-2 rounded bg-black/30">
                <div className="flex items-center gap-2">
                  <Server className="w-4 h-4 text-purple-400" />
                  <span className="text-sm admin-text-smoke">CPU Load</span>
                </div>
                <span className="text-sm font-bold text-purple-400">23%</span>
              </div>
            </div>
          </motion.div>

          {/* Performance Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Indicadores SLA</h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Uptime 30d</span>
                  <span className="text-sm font-bold text-green-400">99.97%</span>
                </div>
                <Progress value={99.97} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">MTTR</span>
                  <span className="text-sm font-bold admin-text-blue">4.2min</span>
                </div>
                <Progress value={85} className="h-2" />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm admin-text-smoke">Error Rate</span>
                  <span className="text-sm font-bold admin-text-orange">0.05%</span>
                </div>
                <Progress value={95} className="h-2" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}