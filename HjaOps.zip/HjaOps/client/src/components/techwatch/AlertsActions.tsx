import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  AlertTriangle,
  Bell,
  Play,
  Pause,
  Shield,
  Zap,
  Users,
  Mail,
  MessageSquare,
  Phone,
  CheckCircle,
  XCircle,
  Clock,
  Target,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';

interface SystemHealth {
  overall: number;
  lastScan: Date;
  activeIncidents: number;
  todayErrors: number;
  avgLatency: number;
  costToday: number;
  tokenUsage: number;
  fallbackRate: number;
}

interface AlertsActionsProps {
  data: SystemHealth;
}

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'warning' | 'info';
  type: 'performance' | 'cost' | 'error' | 'security' | 'capacity';
  timestamp: Date;
  isActive: boolean;
  autoResolved: boolean;
  affectedUsers?: number;
  actions: QuickAction[];
}

interface QuickAction {
  id: string;
  label: string;
  description: string;
  icon: any;
  color: string;
  isDestructive: boolean;
  estimatedImpact: string;
  executionTime: string;
}

interface AutomationRule {
  id: string;
  name: string;
  description: string;
  trigger: string;
  action: string;
  isActive: boolean;
  triggeredCount: number;
  lastTriggered?: Date;
}

export default function AlertsActions({ data }: AlertsActionsProps) {
  const [selectedAlert, setSelectedAlert] = useState<string | null>(null);

  const alerts: Alert[] = [
    {
      id: '1',
      title: 'OpenAI Latência Crítica',
      description: 'P95 latência excedeu 4s por 15 minutos consecutivos. Impactando 23% dos usuários.',
      severity: 'critical',
      type: 'performance',
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      isActive: true,
      autoResolved: false,
      affectedUsers: 57,
      actions: [
        {
          id: 'fallback-openai',
          label: 'Ativar Fallback',
          description: 'Redirecionar tráfego OpenAI para Groq',
          icon: Shield,
          color: 'admin-bg-blue',
          isDestructive: false,
          estimatedImpact: 'Redução 80% latência',
          executionTime: '30s'
        },
        {
          id: 'limit-tokens',
          label: 'Limitar Tokens',
          description: 'Reduzir max_tokens para 2k temporariamente',
          icon: Target,
          color: 'admin-bg-orange',
          isDestructive: false,
          estimatedImpact: 'Melhoria 40% latência',
          executionTime: '10s'
        }
      ]
    },
    {
      id: '2',
      title: 'Custo Diário Excedido',
      description: 'Gasto atual R$ 67.45 ultrapassou meta de R$ 65/dia.',
      severity: 'warning',
      type: 'cost',
      timestamp: new Date(Date.now() - 25 * 60 * 1000),
      isActive: true,
      autoResolved: false,
      actions: [
        {
          id: 'economy-mode',
          label: 'Modo Economia',
          description: 'Priorizar modelos baratos (Groq/HF)',
          icon: Zap,
          color: 'bg-green-600',
          isDestructive: false,
          estimatedImpact: 'Economia 60%',
          executionTime: '15s'
        },
        {
          id: 'pause-premium',
          label: 'Pausar Premium Free',
          description: 'Limitar modelos caros para usuários gratuitos',
          icon: Pause,
          color: 'admin-bg-orange',
          isDestructive: true,
          estimatedImpact: 'Economia 40%',
          executionTime: '5s'
        }
      ]
    },
    {
      id: '3',
      title: 'Pico de Erros HuggingFace',
      description: 'Taxa de erro aumentou para 12% nas últimas 2 horas.',
      severity: 'warning',
      type: 'error',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      isActive: true,
      autoResolved: false,
      actions: [
        {
          id: 'disable-hf',
          label: 'Desabilitar HF',
          description: 'Pausar roteamento para HuggingFace',
          icon: XCircle,
          color: 'bg-red-600',
          isDestructive: true,
          estimatedImpact: 'Redução erros 100%',
          executionTime: '5s'
        }
      ]
    },
    {
      id: '4',
      title: 'Sistema Recuperado',
      description: 'Groq voltou ao normal após 23 minutos de instabilidade.',
      severity: 'info',
      type: 'performance',
      timestamp: new Date(Date.now() - 60 * 60 * 1000),
      isActive: false,
      autoResolved: true,
      actions: []
    }
  ];

  const automationRules: AutomationRule[] = [
    {
      id: '1',
      name: 'Fallback Automático',
      description: 'Se erros > 10% por 10min → ativar fallback',
      trigger: 'Error rate > 10% for 10min',
      action: 'Redirect to backup provider',
      isActive: true,
      triggeredCount: 3,
      lastTriggered: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      name: 'Controle de Custo',
      description: 'Se custo > meta diária → ativar economia',
      trigger: 'Daily cost > target',
      action: 'Enable economy mode',
      isActive: true,
      triggeredCount: 7,
      lastTriggered: new Date(Date.now() - 1 * 60 * 60 * 1000)
    },
    {
      id: '3',
      name: 'Alertas de Latência',
      description: 'Se P95 > 4s por 15min → alertar admins',
      trigger: 'P95 latency > 4s for 15min',
      action: 'Send admin notifications',
      isActive: true,
      triggeredCount: 2,
      lastTriggered: new Date(Date.now() - 15 * 60 * 1000)
    },
    {
      id: '4',
      name: 'Compensação Automática',
      description: 'Se downtime > 5min → créditos automáticos',
      trigger: 'Service downtime > 5min',
      action: 'Grant compensation credits',
      isActive: false,
      triggeredCount: 0
    }
  ];

  const quickActions: QuickAction[] = [
    {
      id: 'global-fallback',
      label: 'Fallback Global',
      description: 'Ativar fallback para todos os provedores instáveis',
      icon: Shield,
      color: 'admin-bg-blue',
      isDestructive: false,
      estimatedImpact: 'Estabilização sistema',
      executionTime: '60s'
    },
    {
      id: 'emergency-credits',
      label: 'Créditos Emergência',
      description: 'Conceder +50 créditos para usuários impactados',
      icon: Zap,
      color: 'admin-bg-orange',
      isDestructive: false,
      estimatedImpact: 'Compensação 200 usuários',
      executionTime: '30s'
    },
    {
      id: 'notify-discord',
      label: 'Notificar Discord',
      description: 'Enviar update no canal #status',
      icon: MessageSquare,
      color: 'bg-purple-600',
      isDestructive: false,
      estimatedImpact: 'Transparência comunidade',
      executionTime: '10s'
    },
    {
      id: 'email-blast',
      label: 'Email em Massa',
      description: 'Alertar usuários sobre instabilidade',
      icon: Mail,
      color: 'bg-red-600',
      isDestructive: true,
      estimatedImpact: 'Notificação 1543 usuários',
      executionTime: '5min'
    }
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500/10 border-red-500/30 text-red-400';
      case 'warning': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
      case 'info': return 'bg-green-500/10 border-green-500/30 text-green-400';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return <AlertTriangle className="w-5 h-5 text-red-400" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'info': return <CheckCircle className="w-5 h-5 text-green-400" />;
      default: return <Bell className="w-5 h-5" />;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const minutes = Math.floor((Date.now() - date.getTime()) / (1000 * 60));
    if (minutes < 1) return 'agora';
    if (minutes < 60) return `${minutes}min atrás`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h atrás`;
  };

  const executeAction = (actionId: string) => {
    console.log('Executing action:', actionId);
    // Here would be the actual implementation
  };

  const toggleAutomationRule = (ruleId: string) => {
    console.log('Toggling automation rule:', ruleId);
  };

  const activeAlerts = alerts.filter(alert => alert.isActive);
  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical' && alert.isActive);

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Alertas & Ações Rápidas
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Monitoramento ativo com resposta automatizada e ações manuais 1-click
        </p>
      </div>

      {/* Critical Status Banner */}
      {criticalAlerts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6 bg-red-500/10 border-red-500/30"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center animate-pulse">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-red-400 mb-1">
                {criticalAlerts.length} ALERTA{criticalAlerts.length > 1 ? 'S' : ''} CRÍTICO{criticalAlerts.length > 1 ? 'S' : ''}
              </h2>
              <p className="text-red-300">
                Ação imediata requerida • Impacto em usuários detectado
              </p>
            </div>
            <Button className="bg-red-600 hover:bg-red-700">
              Resolver Críticos
            </Button>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Active Alerts */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Alert Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Alertas Ativos</h2>
            
            <div className="space-y-4">
              {alerts.map((alert, index) => (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  className={`p-4 rounded-lg border cursor-pointer transition-all ${
                    getSeverityColor(alert.severity)
                  } ${selectedAlert === alert.id ? 'ring-2 ring-blue-500' : ''}`}
                  onClick={() => setSelectedAlert(selectedAlert === alert.id ? null : alert.id)}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {getSeverityIcon(alert.severity)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-semibold">{alert.title}</h3>
                        <div className="flex items-center gap-2">
                          {alert.autoResolved && (
                            <Badge className="bg-green-500 text-white text-xs">
                              AUTO-RESOLVIDO
                            </Badge>
                          )}
                          <Badge className={`text-xs ${
                            alert.isActive ? 'bg-red-500 text-white' : 'bg-gray-500 text-white'
                          }`}>
                            {alert.isActive ? 'ATIVO' : 'RESOLVIDO'}
                          </Badge>
                        </div>
                      </div>
                      
                      <p className="text-sm mb-3">{alert.description}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span className="text-xs">{formatTimeAgo(alert.timestamp)}</span>
                          </div>
                          
                          {alert.affectedUsers && (
                            <div className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              <span className="text-xs">{alert.affectedUsers} usuários</span>
                            </div>
                          )}
                        </div>
                        
                        {alert.actions.length > 0 && alert.isActive && (
                          <span className="text-xs font-bold">
                            {alert.actions.length} ação{alert.actions.length > 1 ? 'ões' : ''} disponível{alert.actions.length > 1 ? 'eis' : ''}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Expanded Actions */}
                  {selectedAlert === alert.id && alert.actions.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 pt-4 border-t border-current/20"
                    >
                      <h4 className="font-semibold mb-3">Ações Recomendadas:</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {alert.actions.map((action) => (
                          <div
                            key={action.id}
                            className="p-3 rounded-lg bg-black/30 border border-blue-500/20"
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <action.icon className="w-4 h-4" />
                              <span className="font-medium text-sm">{action.label}</span>
                              {action.isDestructive && (
                                <Badge className="bg-red-500 text-white text-xs">
                                  DESTRUTIVO
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs admin-text-smoke mb-2">{action.description}</p>
                            <div className="text-xs admin-text-smoke mb-3">
                              <span>Impacto: {action.estimatedImpact}</span> • 
                              <span>Tempo: {action.executionTime}</span>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => executeAction(action.id)}
                              className={`w-full ${action.color} hover:opacity-90`}
                            >
                              Executar
                            </Button>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Quick Actions Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Ações Rápidas</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {quickActions.map((action) => (
                <div
                  key={action.id}
                  className="p-4 rounded-lg bg-black/30 border border-blue-500/20 hover:border-blue-500/40 transition-all"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-10 h-10 ${action.color} rounded-xl flex items-center justify-center`}>
                      <action.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold admin-text-blue">{action.label}</h3>
                      {action.isDestructive && (
                        <Badge className="bg-red-500 text-white text-xs mt-1">
                          IMPACTO ALTO
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-sm admin-text-smoke mb-3">{action.description}</p>
                  
                  <div className="text-xs admin-text-smoke mb-3">
                    <div>Impacto: {action.estimatedImpact}</div>
                    <div>Tempo execução: {action.executionTime}</div>
                  </div>
                  
                  <Button
                    onClick={() => executeAction(action.id)}
                    className={`w-full ${action.color} hover:opacity-90`}
                    size="sm"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Executar Agora
                  </Button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar - Automation & Stats */}
        <div className="space-y-6">
          
          {/* Alert Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Estatísticas 24h</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Alertas Críticos</span>
                <span className="text-lg font-bold text-red-400">
                  {alerts.filter(a => a.severity === 'critical').length}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Avisos</span>
                <span className="text-lg font-bold admin-text-orange">
                  {alerts.filter(a => a.severity === 'warning').length}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Auto-Resolvidos</span>
                <span className="text-lg font-bold text-green-400">
                  {alerts.filter(a => a.autoResolved).length}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">MTTR Médio</span>
                <span className="text-lg font-bold admin-text-blue">4.2min</span>
              </div>
            </div>
          </motion.div>

          {/* Automation Rules */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Regras de Automação</h3>
            
            <div className="space-y-4">
              {automationRules.map((rule) => (
                <div key={rule.id} className="p-3 rounded-lg bg-black/30">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium admin-text-blue text-sm">{rule.name}</h4>
                    <Switch 
                      checked={rule.isActive}
                      onCheckedChange={() => toggleAutomationRule(rule.id)}
                      className="data-[state=checked]:bg-blue-500"
                    />
                  </div>
                  
                  <p className="text-xs admin-text-smoke mb-2">{rule.description}</p>
                  
                  <div className="flex items-center justify-between text-xs admin-text-smoke">
                    <span>Disparos: {rule.triggeredCount}</span>
                    {rule.lastTriggered && (
                      <span>Último: {formatTimeAgo(rule.lastTriggered)}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Communication Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Comunicação</h3>
            
            <div className="space-y-3">
              <Button 
                className="w-full bg-purple-600 hover:bg-purple-700 justify-start"
                size="sm"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Update Discord
              </Button>
              
              <Button 
                className="w-full admin-bg-blue hover:opacity-90 justify-start"
                size="sm"
              >
                <Mail className="w-4 h-4 mr-2" />
                Email Admins
              </Button>
              
              <Button 
                className="w-full admin-bg-orange hover:opacity-90 justify-start"
                size="sm"
              >
                <Phone className="w-4 h-4 mr-2" />
                SMS Crítico
              </Button>
              
              <Button 
                variant="outline"
                className="w-full border-blue-500/20 admin-text-blue hover:bg-blue-500/10 justify-start"
                size="sm"
              >
                <Settings className="w-4 h-4 mr-2" />
                Config Notificações
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}