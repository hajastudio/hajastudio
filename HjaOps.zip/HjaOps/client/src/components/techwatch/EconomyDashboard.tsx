import { motion } from 'framer-motion';
import { 
  DollarSign,
  TrendingUp,
  TrendingDown,
  Users,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Calculator,
  PiggyBank,
  CreditCard,
  BarChart3
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';

export default function EconomyDashboard() {
  
  // Financial metrics
  const economyMetrics = {
    monthlyRevenue: 12847.50,
    monthlyCosts: 1652.30,
    profitMargin: 87.2,
    cac: 23.50, // Customer Acquisition Cost
    ltv: 247.80, // Lifetime Value
    ltvToCac: 10.5,
    conversionRate: 8.7,
    churnRate: 2.3,
    arpu: 34.20, // Average Revenue Per User
    mrr: 8945.60, // Monthly Recurring Revenue
    growth: 23.8
  };

  const planMetrics = [
    {
      plan: 'Gratuito',
      users: 1416,
      revenue: 0,
      cost: 142.40,
      margin: -100,
      conversionTo: 'Básico',
      conversionRate: 4.2
    },
    {
      plan: 'Básico',
      users: 76,
      revenue: 2272.40,
      cost: 91.20,
      margin: 96.0,
      conversionTo: 'Pro',
      conversionRate: 12.5
    },
    {
      plan: 'Pro',
      users: 38,
      revenue: 2276.20,
      cost: 68.40,
      margin: 97.0,
      conversionTo: 'Enterprise',
      conversionRate: 8.3
    },
    {
      plan: 'Enterprise',
      users: 13,
      revenue: 1948.70,
      cost: 78.20,
      margin: 96.0,
      conversionTo: null,
      conversionRate: 0
    }
  ];

  // Revenue trend chart
  const revenueData = Array.from({length: 30}, (_, i) => ({
    day: i + 1,
    revenue: 400 + Math.random() * 200,
    cost: 50 + Math.random() * 30,
    margin: 85 + Math.random() * 10
  }));

  const revenueChartOptions: ApexOptions = {
    chart: {
      type: 'area',
      height: 350,
      background: 'transparent',
      toolbar: { show: false },
      stacked: false
    },
    theme: { mode: 'dark' },
    stroke: {
      curve: 'smooth',
      width: 2,
      colors: ['#22c55e', '#ef4444', '#0055ff']
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.4,
        opacityTo: 0.1,
        stops: [0, 100]
      }
    },
    xaxis: {
      categories: revenueData.map(d => d.day.toString()),
      labels: { style: { colors: '#c5d1db' } }
    },
    yaxis: [
      {
        title: { text: 'Receita/Custo (R$)', style: { color: '#c5d1db' } },
        labels: { style: { colors: '#c5d1db' } }
      },
      {
        opposite: true,
        title: { text: 'Margem (%)', style: { color: '#c5d1db' } },
        labels: { style: { colors: '#c5d1db' } }
      }
    ],
    legend: { labels: { colors: '#c5d1db' } },
    grid: { borderColor: '#374151', strokeDashArray: 3 },
    colors: ['#22c55e', '#ef4444', '#0055ff']
  };

  const revenueChartSeries = [
    {
      name: 'Receita',
      type: 'area',
      data: revenueData.map(d => d.revenue)
    },
    {
      name: 'Custo',
      type: 'area',
      data: revenueData.map(d => d.cost)
    },
    {
      name: 'Margem %',
      type: 'line',
      data: revenueData.map(d => d.margin)
    }
  ];

  // Conversion funnel
  const conversionFunnel = [
    { stage: 'Visitantes', users: 12847, rate: 100 },
    { stage: 'Cadastros', users: 3245, rate: 25.3 },
    { stage: 'Ativações', users: 1847, rate: 56.9 },
    { stage: 'Conversões', users: 156, rate: 8.5 },
    { stage: 'Retenção 30d', users: 134, rate: 85.9 }
  ];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'Gratuito': return 'bg-gray-500';
      case 'Básico': return 'admin-bg-blue';
      case 'Pro': return 'admin-bg-orange';
      case 'Enterprise': return 'bg-purple-600';
      default: return 'bg-gray-500';
    }
  };

  const getMarginColor = (margin: number) => {
    if (margin >= 90) return 'text-green-400';
    if (margin >= 80) return 'admin-text-blue';
    if (margin >= 70) return 'admin-text-orange';
    if (margin >= 0) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          Dashboard de Economia
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Análise financeira completa: margem, CAC/LTV, conversões e crescimento
        </p>
      </div>

      {/* Key Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-sm font-bold text-green-400">+{economyMetrics.growth}%</span>
            </div>
          </div>
          
          <div>
            <p className="text-3xl font-bold text-green-400 mb-1">
              {formatCurrency(economyMetrics.monthlyRevenue)}
            </p>
            <p className="admin-text-smoke text-sm">Receita Mensal</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <Badge className="bg-green-500 text-white">
              {economyMetrics.profitMargin >= 80 ? 'Excelente' : 'Bom'}
            </Badge>
          </div>
          
          <div>
            <p className="text-3xl font-bold admin-text-blue mb-1">
              {economyMetrics.profitMargin.toFixed(1)}%
            </p>
            <p className="admin-text-smoke text-sm">Margem de Lucro</p>
            <div className="mt-2">
              <Progress value={economyMetrics.profitMargin} className="h-2" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1">
              <span className="text-sm font-bold admin-text-orange">
                {economyMetrics.ltvToCac.toFixed(1)}x
              </span>
            </div>
          </div>
          
          <div>
            <p className="text-lg font-bold admin-text-orange mb-1">
              {formatCurrency(economyMetrics.ltv)} / {formatCurrency(economyMetrics.cac)}
            </p>
            <p className="admin-text-smoke text-sm">LTV / CAC</p>
            <p className="text-xs admin-text-smoke mt-1">
              Ratio ideal: 3:1 ou superior
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-card p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
              <ArrowUpRight className="w-6 h-6 text-white" />
            </div>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span className="text-sm font-bold text-green-400">+2.1%</span>
            </div>
          </div>
          
          <div>
            <p className="text-3xl font-bold text-purple-400 mb-1">
              {economyMetrics.conversionRate.toFixed(1)}%
            </p>
            <p className="admin-text-smoke text-sm">Taxa Conversão</p>
            <p className="text-xs text-green-400 mt-1">
              Meta: 8%+ alcançada
            </p>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Revenue Trend */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Financial Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Tendência Financeira (30 dias)</h2>
            
            <Chart
              options={revenueChartOptions}
              series={revenueChartSeries}
              type="line"
              height={350}
            />
          </motion.div>

          {/* Plan Performance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <h2 className="text-xl font-bold admin-text-blue mb-6">Performance por Plano</h2>
            
            <div className="space-y-4">
              {planMetrics.map((plan, index) => (
                <motion.div
                  key={plan.plan}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className="p-4 rounded-lg bg-black/30 border border-blue-500/20"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Badge className={`${getPlanColor(plan.plan)} text-white`}>
                        {plan.plan}
                      </Badge>
                      <span className="font-medium admin-text-blue">{plan.users} usuários</span>
                    </div>
                    
                    <div className="text-right">
                      <p className={`text-lg font-bold ${getMarginColor(plan.margin)}`}>
                        {plan.margin > 0 ? '+' : ''}{plan.margin.toFixed(1)}%
                      </p>
                      <p className="text-xs admin-text-smoke">Margem</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <p className="text-lg font-bold text-green-400">
                        {formatCurrency(plan.revenue)}
                      </p>
                      <p className="text-xs admin-text-smoke">Receita</p>
                    </div>
                    
                    <div className="text-center">
                      <p className="text-lg font-bold text-red-400">
                        {formatCurrency(plan.cost)}
                      </p>
                      <p className="text-xs admin-text-smoke">Custo</p>
                    </div>
                    
                    <div className="text-center">
                      <p className="text-lg font-bold admin-text-blue">
                        {plan.conversionRate > 0 ? `${plan.conversionRate.toFixed(1)}%` : '-'}
                      </p>
                      <p className="text-xs admin-text-smoke">
                        {plan.conversionTo ? `→ ${plan.conversionTo}` : 'Topo'}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Sidebar - Metrics & Analysis */}
        <div className="space-y-6">
          
          {/* Additional Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Métricas Adicionais</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">ARPU (Receita/Usuário)</span>
                <span className="text-sm font-bold text-green-400">
                  {formatCurrency(economyMetrics.arpu)}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">MRR</span>
                <span className="text-sm font-bold admin-text-blue">
                  {formatCurrency(economyMetrics.mrr)}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Churn Rate</span>
                <span className="text-sm font-bold admin-text-orange">
                  {economyMetrics.churnRate.toFixed(1)}%
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm admin-text-smoke">Crescimento MoM</span>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-green-400" />
                  <span className="text-sm font-bold text-green-400">
                    +{economyMetrics.growth.toFixed(1)}%
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Conversion Funnel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Funil de Conversão</h3>
            
            <div className="space-y-3">
              {conversionFunnel.map((stage, index) => (
                <div key={stage.stage} className="relative">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm admin-text-smoke">{stage.stage}</span>
                    <span className="text-sm font-bold admin-text-blue">
                      {stage.users.toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Progress value={stage.rate} className="flex-1 h-2" />
                    <span className="text-xs admin-text-smoke w-12">
                      {stage.rate.toFixed(1)}%
                    </span>
                  </div>
                  
                  {index < conversionFunnel.length - 1 && (
                    <div className="flex justify-center my-1">
                      <ArrowDownRight className="w-4 h-4 admin-text-smoke" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Economic Health */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Saúde Econômica</h3>
            
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <PiggyBank className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-semibold text-green-400">Margem Saudável</span>
                </div>
                <p className="text-xs text-green-300">
                  87.2% acima da meta de 80%
                </p>
              </div>
              
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 admin-text-blue" />
                  <span className="text-sm font-semibold admin-text-blue">LTV/CAC Excelente</span>
                </div>
                <p className="text-xs text-blue-300">
                  10.5x ratio indica crescimento sustentável
                </p>
              </div>
              
              <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <div className="flex items-center gap-2 mb-1">
                  <BarChart3 className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-semibold text-yellow-400">Otimização</span>
                </div>
                <p className="text-xs text-yellow-300">
                  Melhorar conversão free → básico (4.2%)
                </p>
              </div>
            </div>
          </motion.div>

          {/* Recommendations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="admin-card p-6"
          >
            <h3 className="font-bold admin-text-blue mb-4">Recomendações</h3>
            
            <div className="space-y-2">
              <div className="p-2 rounded bg-black/30">
                <p className="text-sm admin-text-blue font-medium">Aumentar Conversão</p>
                <p className="text-xs admin-text-smoke">
                  Implementar trial de 7 dias para usuários gratuitos
                </p>
              </div>
              
              <div className="p-2 rounded bg-black/30">
                <p className="text-sm admin-text-blue font-medium">Reduzir Churn</p>
                <p className="text-xs admin-text-smoke">
                  Programa de onboarding melhorado
                </p>
              </div>
              
              <div className="p-2 rounded bg-black/30">
                <p className="text-sm admin-text-blue font-medium">Upsell</p>
                <p className="text-xs admin-text-smoke">
                  Oferecer upgrade automático ao atingir 80% uso
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}