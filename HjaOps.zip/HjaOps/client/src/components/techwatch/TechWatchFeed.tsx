import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Satellite,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Zap,
  Brain,
  Filter,
  ExternalLink,
  Clock,
  Target,
  ArrowRight,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';

interface TechWatchItem {
  id: string;
  title: string;
  type: 'model_update' | 'price_change' | 'outage' | 'feature' | 'limit_change' | 'security';
  source: string;
  provider: 'openai' | 'groq' | 'huggingface' | 'anthropic' | 'google' | 'general';
  impact: 'low' | 'medium' | 'high';
  description: string;
  recommendation: string;
  actionRequired: boolean;
  timestamp: Date;
  url?: string;
  tags: string[];
}

export default function TechWatchFeed() {
  const [selectedImpact, setSelectedImpact] = useState<string>('all');
  const [selectedProvider, setSelectedProvider] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const techWatchItems: TechWatchItem[] = [
    {
      id: '1',
      title: 'OpenAI GPT-4o Preço Reduzido em 25%',
      type: 'price_change',
      source: 'OpenAI Official',
      provider: 'openai',
      impact: 'high',
      description: 'OpenAI anunciou redução de preços do GPT-4o de $0.03/1k tokens para $0.0225/1k tokens, efetivo imediatamente.',
      recommendation: 'Reavaliar distribuição de tráfego. Considerar aumentar quota de GPT-4o para usuários Pro.',
      actionRequired: true,
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      url: 'https://openai.com/pricing',
      tags: ['pricing', 'gpt-4o', 'cost-optimization']
    },
    {
      id: '2',
      title: 'Groq Llama 3.1 405B Disponível',
      type: 'model_update',
      source: 'Groq Blog',
      provider: 'groq',
      impact: 'medium',
      description: 'Nova versão do Llama 3.1 405B com melhor performance em raciocínio e código. Latência mantida em ~100ms.',
      recommendation: 'Testar modelo em sandbox. Performance pode superar GPT-4o em alguns casos específicos.',
      actionRequired: false,
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      url: 'https://groq.com/models',
      tags: ['llama', 'performance', 'reasoning']
    },
    {
      id: '3',
      title: 'HuggingFace Rate Limit Aumentado',
      type: 'limit_change',
      source: 'HF Status Page',
      provider: 'huggingface',
      impact: 'low',
      description: 'Limite de requisições aumentado de 1000/min para 2000/min para contas Pro.',
      recommendation: 'Aproveitar para migrar mais tráfego básico para HF, reduzindo custos.',
      actionRequired: false,
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      tags: ['rate-limits', 'capacity']
    },
    {
      id: '4',
      title: 'Claude 3.5 Sonnet Instabilidade Relatada',
      type: 'outage',
      source: 'Anthropic Status',
      provider: 'anthropic',
      impact: 'medium',
      description: 'Usuários reportam timeouts intermitentes (15-20% das requests) nas últimas 2 horas.',
      recommendation: 'Ativar fallback automático para Claude. Monitorar próximas 4 horas.',
      actionRequired: true,
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
      url: 'https://status.anthropic.com',
      tags: ['outage', 'reliability', 'fallback']
    },
    {
      id: '5',
      title: 'Google Gemini 2.0 Flash Preview',
      type: 'model_update',
      source: 'Google AI Blog',
      provider: 'google',
      impact: 'high',
      description: 'Google lançou preview do Gemini 2.0 Flash com latência 50% menor e preço competitivo.',
      recommendation: 'Avaliar integração como novo provedor. Potencial substituto do GPT-4o.',
      actionRequired: true,
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
      url: 'https://ai.google.dev',
      tags: ['gemini', 'competition', 'evaluation']
    },
    {
      id: '6',
      title: 'Falha de Segurança em Modelos OSS',
      type: 'security',
      source: 'Security Research',
      provider: 'general',
      impact: 'medium',
      description: 'Pesquisa revelou vulnerabilidade de prompt injection em modelos Llama 3.x.',
      recommendation: 'Implementar filtros adicionais para prompts de usuários em modelos Llama.',
      actionRequired: true,
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
      tags: ['security', 'llama', 'prompt-injection']
    }
  ];

  const impactFilters = [
    { id: 'all', label: 'Todos', count: techWatchItems.length },
    { id: 'high', label: 'Alto Impacto', count: techWatchItems.filter(i => i.impact === 'high').length },
    { id: 'medium', label: 'Médio Impacto', count: techWatchItems.filter(i => i.impact === 'medium').length },
    { id: 'low', label: 'Baixo Impacto', count: techWatchItems.filter(i => i.impact === 'low').length }
  ];

  const providerFilters = [
    { id: 'all', label: 'Todos Provedores' },
    { id: 'openai', label: 'OpenAI' },
    { id: 'groq', label: 'Groq' },
    { id: 'huggingface', label: 'HuggingFace' },
    { id: 'anthropic', label: 'Anthropic' },
    { id: 'google', label: 'Google' }
  ];

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500/10 border-red-500/30 text-red-400';
      case 'medium': return 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400';
      case 'low': return 'bg-green-500/10 border-green-500/30 text-green-400';
      default: return 'bg-gray-500/10 border-gray-500/30 text-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'model_update': return <Brain className="w-5 h-5" />;
      case 'price_change': return <DollarSign className="w-5 h-5" />;
      case 'outage': return <AlertTriangle className="w-5 h-5" />;
      case 'feature': return <Zap className="w-5 h-5" />;
      case 'limit_change': return <Target className="w-5 h-5" />;
      case 'security': return <AlertTriangle className="w-5 h-5" />;
      default: return <Satellite className="w-5 h-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'model_update': return 'Modelo';
      case 'price_change': return 'Preço';
      case 'outage': return 'Incidente';
      case 'feature': return 'Feature';
      case 'limit_change': return 'Limite';
      case 'security': return 'Segurança';
      default: return 'Geral';
    }
  };

  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'openai': return 'bg-green-600';
      case 'groq': return 'admin-bg-blue';
      case 'huggingface': return 'admin-bg-orange';
      case 'anthropic': return 'bg-purple-600';
      case 'google': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const hours = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'agora';
    if (hours < 24) return `${hours}h atrás`;
    const days = Math.floor(hours / 24);
    return `${days}d atrás`;
  };

  const filteredItems = techWatchItems.filter(item => {
    const matchesImpact = selectedImpact === 'all' || item.impact === selectedImpact;
    const matchesProvider = selectedProvider === 'all' || item.provider === selectedProvider;
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesImpact && matchesProvider && matchesSearch;
  });

  const actionRequiredCount = techWatchItems.filter(item => item.actionRequired).length;

  const handleTakeAction = (item: TechWatchItem) => {
    console.log('Taking action for:', item.id, item.recommendation);
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold admin-text-blue mb-4">
          TechWatch • Vigilância IA 24/7
        </h1>
        <p className="text-lg admin-text-smoke max-w-2xl mx-auto">
          Monitoramento automatizado de novidades, atualizações e incidentes do ecossistema IA
        </p>
      </div>

      {/* Status Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="admin-card p-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center admin-pulse">
              <Satellite className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold admin-text-blue mb-1">
                Scan Automático Ativo
              </h2>
              <p className="admin-text-smoke">
                Última varredura: {new Date().toLocaleTimeString()} • Próxima em 47 min
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-2xl font-bold admin-text-blue">{techWatchItems.length}</p>
              <p className="text-xs admin-text-smoke">Itens 24h</p>
            </div>
            
            <div className="text-center">
              <p className="text-2xl font-bold admin-text-orange">{actionRequiredCount}</p>
              <p className="text-xs admin-text-smoke">Ação Requerida</p>
            </div>
            
            <div className="text-center">
              <p className="text-2xl font-bold text-green-400">98.5%</p>
              <p className="text-xs admin-text-smoke">Precisão IA</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="admin-card p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          
          {/* Search */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Buscar novidades..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-black/50 border-blue-500/20 admin-text-smoke"
            />
          </div>

          {/* Impact Filter */}
          <select
            value={selectedImpact}
            onChange={(e) => setSelectedImpact(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            {impactFilters.map((filter) => (
              <option key={filter.id} value={filter.id}>
                {filter.label} {filter.count !== undefined && `(${filter.count})`}
              </option>
            ))}
          </select>

          {/* Provider Filter */}
          <select
            value={selectedProvider}
            onChange={(e) => setSelectedProvider(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            {providerFilters.map((filter) => (
              <option key={filter.id} value={filter.id}>
                {filter.label}
              </option>
            ))}
          </select>
        </div>

        {/* Quick Stats */}
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-red-500 rounded-full" />
            <span className="text-sm admin-text-smoke">
              Alto Impacto: <span className="font-bold text-red-400">{techWatchItems.filter(i => i.impact === 'high').length}</span>
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 admin-bg-orange rounded-full" />
            <span className="text-sm admin-text-smoke">
              Médio Impacto: <span className="font-bold admin-text-orange">{techWatchItems.filter(i => i.impact === 'medium').length}</span>
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full" />
            <span className="text-sm admin-text-smoke">
              Baixo Impacto: <span className="font-bold text-green-400">{techWatchItems.filter(i => i.impact === 'low').length}</span>
            </span>
          </div>
        </div>
      </div>

      {/* TechWatch Feed */}
      <div className="space-y-4">
        {filteredItems.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`admin-card p-6 border-l-4 ${
              item.impact === 'high' ? 'border-l-red-500' :
              item.impact === 'medium' ? 'border-l-yellow-500' :
              'border-l-green-500'
            }`}
          >
            <div className="flex items-start gap-4">
              
              {/* Icon & Type */}
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                item.impact === 'high' ? 'bg-red-500/20' :
                item.impact === 'medium' ? 'bg-yellow-500/20' :
                'bg-green-500/20'
              }`}>
                {getTypeIcon(item.type)}
              </div>

              {/* Content */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold admin-text-blue">{item.title}</h3>
                      <Badge className={`${getProviderColor(item.provider)} text-white text-xs`}>
                        {item.provider.toUpperCase()}
                      </Badge>
                      <Badge className={getImpactColor(item.impact)}>
                        {item.impact.toUpperCase()}
                      </Badge>
                      {item.actionRequired && (
                        <Badge className="bg-red-500 text-white text-xs animate-pulse">
                          AÇÃO REQUERIDA
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-4 mb-3">
                      <span className="text-sm admin-text-smoke">
                        {getTypeLabel(item.type)} • {item.source}
                      </span>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 admin-text-smoke" />
                        <span className="text-sm admin-text-smoke">{formatTimeAgo(item.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                  
                  {item.url && (
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="admin-text-smoke hover:admin-text-blue"
                      onClick={() => window.open(item.url, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <p className="admin-text-smoke mb-4 leading-relaxed">
                  {item.description}
                </p>

                {/* Recommendation */}
                <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20 mb-4">
                  <div className="flex items-start gap-3">
                    <Target className="w-5 h-5 admin-text-blue mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold admin-text-blue mb-1">Recomendação do Sistema</h4>
                      <p className="text-sm admin-text-smoke">{item.recommendation}</p>
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    {item.tags.map((tag) => (
                      <Badge 
                        key={tag} 
                        variant="outline" 
                        className="border-blue-500/20 admin-text-blue text-xs"
                      >
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                  
                  {item.actionRequired && (
                    <Button 
                      onClick={() => handleTakeAction(item)}
                      className="admin-bg-orange hover:opacity-90"
                      size="sm"
                    >
                      Executar Ação
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <div className="text-center py-12">
          <Satellite className="w-16 h-16 admin-text-smoke mx-auto mb-4" />
          <h3 className="text-xl font-bold admin-text-blue mb-2">
            Nenhuma novidade encontrada
          </h3>
          <p className="admin-text-smoke">
            Tente ajustar os filtros ou aguarde o próximo scan
          </p>
        </div>
      )}
    </div>
  );
}