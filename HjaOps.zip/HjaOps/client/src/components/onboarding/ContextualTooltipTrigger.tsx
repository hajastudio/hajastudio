import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, Sparkles } from 'lucide-react';
import { useOnboarding } from '@/hooks/useOnboarding';

interface ContextualTooltipTriggerProps {
  element: string;
  children: React.ReactNode;
  className?: string;
  showHint?: boolean;
  hintDelay?: number;
}

export default function ContextualTooltipTrigger({
  element,
  children,
  className = '',
  showHint = true,
  hintDelay = 3000
}: ContextualTooltipTriggerProps) {
  const [showHintIcon, setShowHintIcon] = useState(false);
  const [hasShownTooltip, setHasShownTooltip] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);
  const hintTimeoutRef = useRef<NodeJS.Timeout>();
  
  const { showContextualTooltip, userProgress } = useOnboarding('current_user', 'content-creator');

  // Show hint after delay if user hovers/focuses
  useEffect(() => {
    if (!showHint || !userProgress?.preferences?.showTooltips || hasShownTooltip) return;

    const element = elementRef.current;
    if (!element) return;

    const handleMouseEnter = () => {
      hintTimeoutRef.current = setTimeout(() => {
        setShowHintIcon(true);
      }, hintDelay);
    };

    const handleMouseLeave = () => {
      if (hintTimeoutRef.current) {
        clearTimeout(hintTimeoutRef.current);
      }
      setShowHintIcon(false);
    };

    const handleClick = () => {
      if (showHintIcon) {
        setHasShownTooltip(true);
        setShowHintIcon(false);
        showContextualTooltip(element, elementRef);
      }
    };

    element.addEventListener('mouseenter', handleMouseEnter);
    element.addEventListener('mouseleave', handleMouseLeave);
    element.addEventListener('click', handleClick);

    return () => {
      element.removeEventListener('mouseenter', handleMouseEnter);
      element.removeEventListener('mouseleave', handleMouseLeave);
      element.removeEventListener('click', handleClick);
      if (hintTimeoutRef.current) {
        clearTimeout(hintTimeoutRef.current);
      }
    };
  }, [element, showHint, hintDelay, showContextualTooltip, userProgress, hasShownTooltip]);

  return (
    <div 
      ref={elementRef}
      className={`relative ${className}`}
      data-onboarding-element={element}
    >
      {children}
      
      {/* Contextual Hint */}
      {showHintIcon && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className="absolute -top-2 -right-2 z-50"
        >
          <motion.div
            className="w-8 h-8 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center cursor-pointer shadow-lg"
            animate={{
              scale: [1, 1.1, 1],
              opacity: [1, 0.8, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            onClick={() => {
              setHasShownTooltip(true);
              setShowHintIcon(false);
              showContextualTooltip(element, elementRef);
            }}
          >
            <Sparkles className="w-4 h-4 text-white" />
          </motion.div>
          
          {/* Pulse rings */}
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-[var(--blue)]"
            animate={{
              scale: [1, 1.5, 2],
              opacity: [0.8, 0.3, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeOut"
            }}
          />
        </motion.div>
      )}
      
      {/* Smart Help Button */}
      {userProgress?.preferences?.showTooltips && !hasShownTooltip && (
        <button
          className="absolute top-2 right-2 p-1 rounded-full bg-[var(--blue)]/20 text-[var(--blue)] hover:bg-[var(--blue)]/30 transition-colors opacity-0 group-hover:opacity-100 z-10"
          onClick={(e) => {
            e.stopPropagation();
            setHasShownTooltip(true);
            showContextualTooltip(element, elementRef);
          }}
          title="Obter ajuda contextual"
        >
          <HelpCircle className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}