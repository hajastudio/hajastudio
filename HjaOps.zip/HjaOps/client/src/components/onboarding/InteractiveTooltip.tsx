import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Play, 
  BookOpen, 
  Lightbulb,
  Target,
  Zap,
  ArrowRight,
  SkipForward
} from 'lucide-react';
import type { OnboardingStep, OnboardingAction } from '@/types/onboarding';

interface InteractiveTooltipProps {
  step: OnboardingStep;
  isVisible: boolean;
  onAction: (actionId: string) => void;
  onClose: () => void;
  targetRef?: React.RefObject<HTMLElement>;
  progress?: {
    current: number;
    total: number;
  };
}

export default function InteractiveTooltip({
  step,
  isVisible,
  onAction,
  onClose,
  targetRef,
  progress
}: InteractiveTooltipProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const tooltipRef = useRef<HTMLDivElement>(null);

  // Calculate position relative to target element
  useEffect(() => {
    if (!isVisible || !targetRef?.current || !tooltipRef.current) return;

    const targetRect = targetRef.current.getBoundingClientRect();
    const tooltipRect = tooltipRef.current.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    let x = 0;
    let y = 0;

    switch (step.position) {
      case 'top':
        x = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
        y = targetRect.top - tooltipRect.height - 12;
        break;
      case 'bottom':
        x = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
        y = targetRect.bottom + 12;
        break;
      case 'left':
        x = targetRect.left - tooltipRect.width - 12;
        y = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
        break;
      case 'right':
        x = targetRect.right + 12;
        y = targetRect.top + (targetRect.height / 2) - (tooltipRect.height / 2);
        break;
      case 'center':
        x = (viewportWidth / 2) - (tooltipRect.width / 2);
        y = (viewportHeight / 2) - (tooltipRect.height / 2);
        break;
    }

    // Ensure tooltip stays within viewport
    x = Math.max(12, Math.min(x, viewportWidth - tooltipRect.width - 12));
    y = Math.max(12, Math.min(y, viewportHeight - tooltipRect.height - 12));

    setPosition({ x, y });
  }, [isVisible, step.position, targetRef]);

  const getStepIcon = () => {
    if (step.aiGenerated) return <Zap className="w-5 h-5 text-[var(--orange)]" />;
    
    switch (step.type) {
      case 'tooltip': return <Lightbulb className="w-5 h-5 text-[var(--blue)]" />;
      case 'modal': return <BookOpen className="w-5 h-5 text-[var(--blue)]" />;
      case 'spotlight': return <Target className="w-5 h-5 text-[var(--blue)]" />;
      default: return <Play className="w-5 h-5 text-[var(--blue)]" />;
    }
  };

  const getActionIcon = (action: OnboardingAction) => {
    switch (action.type) {
      case 'next': return <ChevronRight className="w-4 h-4" />;
      case 'skip': return <SkipForward className="w-4 h-4" />;
      case 'link': return <ArrowRight className="w-4 h-4" />;
      case 'demo': return <Play className="w-4 h-4" />;
      default: return null;
    }
  };

  const getActionStyle = (action: OnboardingAction) => {
    const baseClasses = "flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-300";
    
    switch (action.style) {
      case 'primary':
        return `${baseClasses} bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] text-white hover:shadow-lg neon-glow`;
      case 'secondary':
        return `${baseClasses} glass-morphism text-white hover:bg-[var(--smoke)]/10`;
      case 'ghost':
        return `${baseClasses} text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/5`;
      case 'danger':
        return `${baseClasses} bg-red-500/20 text-red-400 hover:bg-red-500/30`;
      default:
        return `${baseClasses} glass-morphism text-white`;
    }
  };

  if (!isVisible) return null;

  return (
    <>
      {/* Backdrop for center position */}
      {step.position === 'center' && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          onClick={onClose}
        />
      )}

      {/* Spotlight effect for target element */}
      {step.type === 'spotlight' && targetRef?.current && (
        <div className="fixed inset-0 pointer-events-none z-30">
          <div 
            className="absolute bg-white/10 rounded-lg"
            style={{
              left: targetRef.current.getBoundingClientRect().left - 4,
              top: targetRef.current.getBoundingClientRect().top - 4,
              width: targetRef.current.getBoundingClientRect().width + 8,
              height: targetRef.current.getBoundingClientRect().height + 8,
              boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)'
            }}
          />
        </div>
      )}

      {/* Tooltip */}
      <AnimatePresence>
        <motion.div
          ref={tooltipRef}
          initial={{ 
            opacity: 0, 
            scale: 0.8,
            y: step.position === 'top' ? 10 : step.position === 'bottom' ? -10 : 0,
            x: step.position === 'left' ? 10 : step.position === 'right' ? -10 : 0
          }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            y: 0,
            x: 0
          }}
          exit={{ 
            opacity: 0, 
            scale: 0.8,
            y: step.position === 'top' ? 10 : step.position === 'bottom' ? -10 : 0,
            x: step.position === 'left' ? 10 : step.position === 'right' ? -10 : 0
          }}
          className={`fixed z-50 w-full max-w-sm ${step.position === 'center' ? 'z-50' : 'z-40'}`}
          style={{
            left: position.x,
            top: position.y
          }}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div className="glass-morphism rounded-2xl border border-[var(--blue)]/30 shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-[var(--smoke)]/20 bg-gradient-to-r from-[var(--blue)]/10 to-[var(--orange)]/10">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[var(--blue)]/20 flex items-center justify-center">
                    {getStepIcon()}
                  </div>
                  <div>
                    <h3 className="font-orbitron font-semibold text-white">
                      {step.title}
                    </h3>
                    {step.aiGenerated && (
                      <span className="text-xs text-[var(--orange)] flex items-center gap-1 mt-1">
                        <Zap className="w-3 h-3" />
                        AI Personalizado
                      </span>
                    )}
                  </div>
                </div>
                
                <button
                  onClick={onClose}
                  className="p-1 rounded-lg text-[var(--smoke)]/60 hover:text-white hover:bg-[var(--smoke)]/10 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Progress */}
              {progress && (
                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs text-[var(--smoke)]/70 mb-1">
                    <span>Progresso</span>
                    <span>{progress.current} de {progress.total}</span>
                  </div>
                  <div className="w-full bg-[var(--smoke)]/10 rounded-full h-1">
                    <motion.div
                      className="h-1 rounded-full bg-gradient-to-r from-[var(--blue)] to-[var(--orange)]"
                      initial={{ width: 0 }}
                      animate={{ width: `${(progress.current / progress.total) * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Content */}
            <div className="p-4">
              <div 
                className="text-sm text-[var(--smoke)]/80 leading-relaxed"
                dangerouslySetInnerHTML={{ __html: step.content }}
              />
            </div>

            {/* Actions */}
            {step.actions.length > 0 && (
              <div className="p-4 pt-0">
                <div className="flex flex-wrap gap-2">
                  {step.actions.map((action) => (
                    <motion.button
                      key={action.id}
                      className={getActionStyle(action)}
                      onClick={() => onAction(action.id)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {action.label}
                      {getActionIcon(action)}
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Arrow pointer for positioned tooltips */}
            {step.position !== 'center' && (
              <div 
                className={`absolute w-3 h-3 bg-[var(--blue)]/30 border border-[var(--blue)]/30 transform rotate-45 ${
                  step.position === 'top' ? 'bottom-[-6px] left-1/2 -translate-x-1/2' :
                  step.position === 'bottom' ? 'top-[-6px] left-1/2 -translate-x-1/2' :
                  step.position === 'left' ? 'right-[-6px] top-1/2 -translate-y-1/2' :
                  step.position === 'right' ? 'left-[-6px] top-1/2 -translate-y-1/2' : ''
                }`}
              />
            )}

            {/* Pulse animation on hover */}
            <AnimatePresence>
              {isHovered && (
                <motion.div
                  initial={{ opacity: 0, scale: 1 }}
                  animate={{ 
                    opacity: [0, 0.5, 0], 
                    scale: [1, 1.05, 1] 
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0 rounded-2xl border-2 border-[var(--blue)]/50 pointer-events-none"
                />
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </AnimatePresence>
    </>
  );
}