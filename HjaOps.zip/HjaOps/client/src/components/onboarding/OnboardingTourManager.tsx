import { useEffect, useRef } from 'react';
import { AnimatePresence } from 'framer-motion';
import InteractiveTooltip from './InteractiveTooltip';
import { useOnboarding } from '@/hooks/useOnboarding';

interface OnboardingTourManagerProps {
  userId: string;
  userRole: string;
}

export default function OnboardingTourManager({ 
  userId, 
  userRole 
}: OnboardingTourManagerProps) {
  const {
    currentStep,
    isTooltipVisible,
    handleStepAction,
    closeTooltip,
    updateContext,
    currentProgress
  } = useOnboarding(userId, userRole);

  const targetRefs = useRef<Record<string, HTMLElement | null>>({});

  // Update context when page changes
  useEffect(() => {
    updateContext({
      currentPage: window.location.pathname,
      timeOnPlatform: Date.now() - (Date.now() - 1000 * 60 * 5) // Mock 5 minutes
    });
  }, [updateContext]);

  // Find target element for current step
  useEffect(() => {
    if (!currentStep?.targetSelector) return;

    const element = document.querySelector(currentStep.targetSelector) as HTMLElement;
    if (element) {
      targetRefs.current[currentStep.id] = element;
      
      // Scroll element into view if needed
      element.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center',
        inline: 'center'
      });
      
      // Add highlight class
      element.classList.add('onboarding-highlight');
      
      return () => {
        element.classList.remove('onboarding-highlight');
      };
    }
  }, [currentStep]);

  // Handle demo actions
  const handleDemoAction = async (actionId: string) => {
    switch (actionId) {
      case 'try-chat':
      case 'chat-with-roteirista':
        // Simulate opening chat with roteirista
        const chatSection = document.querySelector('[data-testid="sidebar-chat"]') as HTMLElement;
        if (chatSection) {
          chatSection.click();
          // Wait for animation then select roteirista
          setTimeout(() => {
            const roteirista = document.querySelector('[data-testid="agent-roteirista"]') as HTMLElement;
            if (roteirista) {
              roteirista.click();
            }
          }, 500);
        }
        break;
        
      case 'demo-analysis':
        // Show YouTube analyst demo
        updateContext({ 
          featuresUsed: ['youtube-analysis'] 
        });
        break;
        
      case 'create-tiktok':
      case 'create-youtube': 
      case 'create-instagram':
        // Demo content creation
        const composer = document.querySelector('[data-testid="chat-composer"]') as HTMLInputElement;
        if (composer) {
          const prompts = {
            'create-tiktok': 'Crie um roteiro viral para TikTok sobre produtividade de 30 segundos',
            'create-youtube': 'Faça um script para YouTube Short sobre IA que prende a atenção',
            'create-instagram': 'Desenvolva um Reel do Instagram sobre empreendedorismo'
          };
          
          composer.value = prompts[actionId] || '';
          composer.focus();
          
          // Simulate typing effect
          const event = new Event('input', { bubbles: true });
          composer.dispatchEvent(event);
        }
        break;
    }
    
    // Continue with normal action handling
    handleStepAction(actionId);
  };

  if (!currentStep) return null;

  const targetRef = targetRefs.current[currentStep.id] ? 
    { current: targetRefs.current[currentStep.id] } : 
    undefined;

  return (
    <AnimatePresence>
      {isTooltipVisible && (
        <InteractiveTooltip
          step={currentStep}
          isVisible={isTooltipVisible}
          onAction={currentStep.actions.some(a => a.type === 'demo') ? handleDemoAction : handleStepAction}
          onClose={closeTooltip}
          targetRef={targetRef}
          progress={currentProgress || undefined}
        />
      )}
    </AnimatePresence>
  );
}