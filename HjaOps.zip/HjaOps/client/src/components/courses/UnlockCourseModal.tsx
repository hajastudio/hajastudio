import { motion, AnimatePresence } from 'framer-motion';
import { X, Lock, Zap, Star, Clock, Users } from 'lucide-react';
import type { Course } from '@/types/courses';

interface UnlockCourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  course: Course | null;
  userTokens: number;
  onConfirmUnlock: () => void;
}

export default function UnlockCourseModal({
  isOpen,
  onClose,
  course,
  userTokens,
  onConfirmUnlock
}: UnlockCourseModalProps) {
  if (!course) return null;

  const canAfford = userTokens >= (course.cost || 0);
  const tokensAfterPurchase = userTokens - (course.cost || 0);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <div className="w-full max-w-md glass-morphism rounded-2xl border border-[var(--orange)]/30 overflow-hidden">
              {/* Header */}
              <div className="p-6 border-b border-[var(--smoke)]/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[var(--orange)]/20 rounded-xl flex items-center justify-center">
                      <Lock className="w-5 h-5 text-[var(--orange)]" />
                    </div>
                    <h2 className="text-xl font-orbitron font-bold text-white">
                      Desbloquear Curso
                    </h2>
                  </div>
                  
                  <button
                    onClick={onClose}
                    className="p-2 rounded-lg text-[var(--smoke)]/70 hover:text-white hover:bg-[var(--smoke)]/10 transition-colors"
                    data-testid="close-modal"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Course Info */}
              <div className="p-6">
                <div className="mb-6">
                  <h3 className="text-lg font-orbitron font-semibold text-white mb-2">
                    {course.title}
                  </h3>
                  <p className="text-sm text-[var(--smoke)]/70 mb-4">
                    {course.description}
                  </p>

                  {/* Course Stats */}
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-white">{course.totalLessons}</div>
                      <div className="text-xs text-[var(--smoke)]/60">Aulas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-white">{course.duration}</div>
                      <div className="text-xs text-[var(--smoke)]/60">Duração</div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400" />
                        <span className="text-lg font-bold text-white">{course.rating}</span>
                      </div>
                      <div className="text-xs text-[var(--smoke)]/60">Avaliação</div>
                    </div>
                  </div>
                </div>

                {/* Token Info */}
                <div className="glass-morphism rounded-xl p-4 mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-[var(--smoke)]/70">Custo do curso:</span>
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[var(--orange)]" />
                      <span className="font-bold text-[var(--orange)]">{course.cost} tokens</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-[var(--smoke)]/70">Seus tokens:</span>
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-[var(--blue)]" />
                      <span className="font-bold text-white">{userTokens} tokens</span>
                    </div>
                  </div>

                  <div className="border-t border-[var(--smoke)]/20 pt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-[var(--smoke)]/70">Após a compra:</span>
                      <div className="flex items-center gap-2">
                        <Zap className={`w-4 h-4 ${canAfford ? 'text-green-400' : 'text-red-400'}`} />
                        <span className={`font-bold ${canAfford ? 'text-green-400' : 'text-red-400'}`}>
                          {tokensAfterPurchase} tokens
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Warning if can't afford */}
                {!canAfford && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-500/20 rounded-lg flex items-center justify-center">
                        <Zap className="w-4 h-4 text-red-400" />
                      </div>
                      <div>
                        <h4 className="font-medium text-red-400 mb-1">Tokens Insuficientes</h4>
                        <p className="text-sm text-red-400/70">
                          Você precisa de mais {(course.cost || 0) - userTokens} tokens para desbloquear este curso.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={onClose}
                    className="flex-1 py-3 px-4 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors"
                    data-testid="cancel-unlock"
                  >
                    Cancelar
                  </button>
                  
                  <motion.button
                    onClick={onConfirmUnlock}
                    disabled={!canAfford}
                    className={`flex-1 py-3 px-4 rounded-xl font-medium text-white transition-all duration-300 ${
                      canAfford
                        ? 'bg-gradient-to-r from-[var(--orange)] to-orange-600 hover:from-orange-600 hover:to-orange-700 neon-glow'
                        : 'bg-gray-600 cursor-not-allowed opacity-50'
                    }`}
                    whileHover={canAfford ? { scale: 1.02 } : {}}
                    whileTap={canAfford ? { scale: 0.98 } : {}}
                    data-testid="confirm-unlock"
                  >
                    {canAfford ? 'Desbloquear Curso' : 'Tokens Insuficientes'}
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}