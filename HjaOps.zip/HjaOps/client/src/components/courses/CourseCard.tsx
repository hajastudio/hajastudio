import { motion } from 'framer-motion';
import { Play, Lock, Star, Users, Clock, CheckCircle } from 'lucide-react';
import type { Course } from '@/types/courses';

interface CourseCardProps {
  course: Course;
  onClick: () => void;
  onUnlock?: () => void;
}

export default function CourseCard({ course, onClick, onUnlock }: CourseCardProps) {
  const getStatusConfig = () => {
    switch (course.status) {
      case 'free':
        return {
          icon: Play,
          iconColor: 'text-green-400',
          buttonText: 'Começar Curso',
          buttonClass: 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700',
          canAccess: true
        };
      case 'premium':
        return {
          icon: Lock,
          iconColor: 'text-[var(--orange)]',
          buttonText: `Desbloquear (${course.cost} tokens)`,
          buttonClass: 'bg-gradient-to-r from-[var(--orange)] to-orange-600 hover:from-orange-600 hover:to-orange-700',
          canAccess: false
        };
      case 'unlocked':
        return {
          icon: CheckCircle,
          iconColor: 'text-[var(--blue)]',
          buttonText: course.progress > 0 ? 'Continuar' : 'Começar Curso',
          buttonClass: 'bg-gradient-to-r from-[var(--blue)] to-blue-600 hover:from-blue-600 hover:to-blue-700',
          canAccess: true
        };
      default:
        return {
          icon: Play,
          iconColor: 'text-gray-400',
          buttonText: 'Ver Curso',
          buttonClass: 'bg-gray-600 hover:bg-gray-700',
          canAccess: true
        };
    }
  };

  const statusConfig = getStatusConfig();
  const StatusIcon = statusConfig.icon;

  const handleClick = () => {
    if (course.status === 'premium' && onUnlock) {
      onUnlock();
    } else if (statusConfig.canAccess) {
      onClick();
    }
  };

  return (
    <motion.div
      className="group relative min-w-[320px] max-w-[320px] bg-gradient-to-b from-[var(--smoke)]/5 to-[var(--smoke)]/10 rounded-2xl overflow-hidden cursor-pointer"
      whileHover={{ 
        scale: 1.05,
        boxShadow: course.status === 'premium' 
          ? '0 0 30px rgba(255, 107, 0, 0.3)' 
          : '0 0 30px rgba(0, 243, 255, 0.3)'
      }}
      whileTap={{ scale: 0.98 }}
      onClick={handleClick}
      data-testid={`course-card-${course.id}`}
    >
      {/* Thumbnail */}
      <div className="relative h-48 bg-gradient-to-br from-[var(--blue)]/20 to-[var(--orange)]/20 overflow-hidden">
        {/* Status Badge */}
        <div className="absolute top-3 left-3 z-10">
          <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
            course.status === 'free' ? 'bg-green-500/20 text-green-400' :
            course.status === 'premium' ? 'bg-[var(--orange)]/20 text-[var(--orange)]' :
            'bg-[var(--blue)]/20 text-[var(--blue)]'
          }`}>
            <StatusIcon className="w-3 h-3" />
            {course.status === 'free' ? 'Gratuito' : 
             course.status === 'premium' ? 'Premium' : 
             'Desbloqueado'}
          </div>
        </div>

        {/* Level Badge */}
        <div className="absolute top-3 right-3 z-10">
          <span className="px-2 py-1 bg-black/50 text-white text-xs rounded-full">
            {course.level}
          </span>
        </div>

        {/* Thumbnail Placeholder */}
        <div className="w-full h-full flex items-center justify-center">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
            course.status === 'premium' ? 'bg-[var(--orange)]/20' : 'bg-[var(--blue)]/20'
          }`}>
            <StatusIcon className={`w-8 h-8 ${statusConfig.iconColor}`} />
          </div>
        </div>

        {/* Progress Overlay */}
        {course.progress > 0 && (
          <div className="absolute bottom-0 left-0 w-full h-1 bg-black/30">
            <motion.div
              className="h-full bg-gradient-to-r from-[var(--blue)] to-[var(--orange)]"
              initial={{ width: 0 }}
              animate={{ width: `${course.progress}%` }}
              transition={{ duration: 1, delay: 0.3 }}
            />
          </div>
        )}

        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <motion.div
            initial={{ scale: 0 }}
            whileHover={{ scale: 1 }}
            className={`w-16 h-16 rounded-full flex items-center justify-center ${
              course.status === 'premium' ? 'bg-[var(--orange)]' : 'bg-[var(--blue)]'
            } neon-glow`}
          >
            <StatusIcon className="w-8 h-8 text-white" />
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Title */}
        <h3 className="text-lg font-orbitron font-bold text-white mb-2 line-clamp-2">
          {course.title}
        </h3>

        {/* Description */}
        <p className="text-sm text-[var(--smoke)]/70 mb-4 line-clamp-2">
          {course.description}
        </p>

        {/* Instructor */}
        <p className="text-xs text-[var(--smoke)]/60 mb-3">
          Por {course.instructor}
        </p>

        {/* Stats */}
        <div className="flex items-center gap-4 text-xs text-[var(--smoke)]/60 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {course.duration}
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-yellow-400" />
            {course.rating}
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-3 h-3" />
            {course.studentsCount.toLocaleString()}
          </div>
        </div>

        {/* Progress Info */}
        {course.progress > 0 && (
          <div className="mb-4">
            <div className="flex justify-between text-xs text-[var(--smoke)]/70 mb-1">
              <span>Progresso</span>
              <span>{course.progress}% concluído</span>
            </div>
            <div className="text-xs text-[var(--smoke)]/60">
              {course.completedLessons} de {course.totalLessons} aulas
            </div>
          </div>
        )}

        {/* Action Button */}
        <motion.button
          className={`w-full py-3 px-4 rounded-xl font-medium text-white transition-all duration-300 ${statusConfig.buttonClass}`}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          data-testid={`course-button-${course.id}`}
        >
          {statusConfig.buttonText}
        </motion.button>
      </div>
    </motion.div>
  );
}