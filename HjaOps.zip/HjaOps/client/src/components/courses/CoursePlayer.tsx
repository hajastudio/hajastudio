import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  Maximize2,
  CheckCircle,
  Clock,
  FileText,
  Download,
  ArrowLeft
} from 'lucide-react';
import type { Course, Lesson } from '@/types/courses';

interface CoursePlayerProps {
  course: Course;
  currentLesson: Lesson;
  onLessonComplete: (lessonId: string) => void;
  onLessonChange: (lessonId: string) => void;
  onBack: () => void;
}

export default function CoursePlayer({ 
  course, 
  currentLesson, 
  onLessonComplete, 
  onLessonChange,
  onBack
}: CoursePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [watchTime, setWatchTime] = useState(0);
  const [lessonProgress, setLessonProgress] = useState(0);

  // Auto-hide controls
  useEffect(() => {
    const timer = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, [isPlaying, showControls]);

  // Simulate lesson progress
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setWatchTime(prev => prev + 1);
        setLessonProgress(prev => {
          const newProgress = prev + (100 / 300); // Complete in 5 minutes (300 seconds)
          if (newProgress >= 100 && !currentLesson.isCompleted) {
            onLessonComplete(currentLesson.id);
          }
          return Math.min(newProgress, 100);
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isPlaying, currentLesson.id, currentLesson.isCompleted, onLessonComplete]);

  const currentLessonIndex = course.lessons.findIndex(l => l.id === currentLesson.id);
  const nextLesson = course.lessons[currentLessonIndex + 1];
  const prevLesson = course.lessons[currentLessonIndex - 1];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-black">
      {/* Video Player */}
      <div className="flex-1 relative bg-gradient-to-br from-[var(--blue)]/10 to-[var(--orange)]/10">
        {/* Back Button */}
        <motion.button
          onClick={onBack}
          className="absolute top-4 left-4 z-20 p-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-white transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          data-testid="back-to-courses"
        >
          <ArrowLeft className="w-5 h-5" />
        </motion.button>

        {/* Video Container */}
        <div 
          className="relative w-full h-full flex items-center justify-center cursor-pointer"
          onClick={() => setShowControls(true)}
          onMouseMove={() => setShowControls(true)}
        >
          {/* Video Placeholder */}
          <div className="w-full h-full max-w-4xl max-h-[70vh] bg-black rounded-2xl border border-[var(--smoke)]/20 neon-glow-subtle overflow-hidden">
            <iframe
              src={currentLesson.videoUrl}
              title={currentLesson.title}
              className="w-full h-full"
              frameBorder="0"
              allowFullScreen
            />
          </div>

          {/* Custom Controls Overlay */}
          <AnimatePresence>
            {showControls && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 flex flex-col justify-between p-6"
              >
                {/* Top Info */}
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-orbitron font-bold text-white mb-1">
                      {currentLesson.title}
                    </h2>
                    <p className="text-sm text-[var(--smoke)]/70">
                      {course.title} • Aula {currentLessonIndex + 1} de {course.lessons.length}
                    </p>
                  </div>

                  {currentLesson.isCompleted && (
                    <div className="flex items-center gap-2 px-3 py-1 bg-green-500/20 rounded-full">
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      <span className="text-sm text-green-400">Concluída</span>
                    </div>
                  )}
                </div>

                {/* Bottom Controls */}
                <div className="space-y-4">
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="w-full bg-white/20 rounded-full h-1">
                      <motion.div
                        className="h-full bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${lessonProgress}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-white/70">
                      <span>{formatTime(watchTime)}</span>
                      <span>{currentLesson.duration}</span>
                    </div>
                  </div>

                  {/* Control Buttons */}
                  <div className="flex items-center justify-center gap-6">
                    <button
                      onClick={() => prevLesson && onLessonChange(prevLesson.id)}
                      disabled={!prevLesson}
                      className={`p-3 rounded-full transition-colors ${
                        prevLesson 
                          ? 'text-white hover:bg-white/20' 
                          : 'text-white/30 cursor-not-allowed'
                      }`}
                    >
                      <SkipBack className="w-6 h-6" />
                    </button>

                    <motion.button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="p-4 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full text-white neon-glow"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      {isPlaying ? (
                        <Pause className="w-8 h-8" />
                      ) : (
                        <Play className="w-8 h-8 ml-1" />
                      )}
                    </motion.button>

                    <button
                      onClick={() => nextLesson && onLessonChange(nextLesson.id)}
                      disabled={!nextLesson}
                      className={`p-3 rounded-full transition-colors ${
                        nextLesson 
                          ? 'text-white hover:bg-white/20' 
                          : 'text-white/30 cursor-not-allowed'
                      }`}
                    >
                      <SkipForward className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Course Sidebar */}
      <div className="w-full lg:w-96 glass-morphism border-l border-[var(--smoke)]/20 flex flex-col">
        {/* Course Header */}
        <div className="p-6 border-b border-[var(--smoke)]/20">
          <h3 className="text-lg font-orbitron font-bold text-white mb-2">
            Conteúdo do Curso
          </h3>
          <div className="flex items-center gap-4 text-sm text-[var(--smoke)]/70">
            <div className="flex items-center gap-1">
              <CheckCircle className="w-4 h-4" />
              {course.completedLessons}/{course.totalLessons} aulas
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {course.duration}
            </div>
          </div>
        </div>

        {/* Lessons List */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-4 space-y-2">
            {course.lessons.map((lesson, index) => (
              <motion.button
                key={lesson.id}
                onClick={() => !lesson.isLocked && onLessonChange(lesson.id)}
                disabled={lesson.isLocked}
                className={`w-full text-left p-4 rounded-xl transition-all duration-300 ${
                  lesson.id === currentLesson.id
                    ? 'bg-gradient-to-r from-[var(--blue)]/20 to-[var(--orange)]/20 border border-[var(--blue)]/30'
                    : lesson.isLocked
                    ? 'opacity-50 cursor-not-allowed'
                    : 'hover:bg-[var(--smoke)]/5'
                }`}
                whileHover={!lesson.isLocked ? { scale: 1.02 } : {}}
                data-testid={`lesson-${lesson.id}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    lesson.isCompleted
                      ? 'bg-green-500/20 text-green-400'
                      : lesson.id === currentLesson.id
                      ? 'bg-[var(--blue)]/20 text-[var(--blue)]'
                      : lesson.isLocked
                      ? 'bg-[var(--smoke)]/10 text-[var(--smoke)]/40'
                      : 'bg-[var(--smoke)]/10 text-[var(--smoke)]/70'
                  }`}>
                    {lesson.isCompleted ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : lesson.isLocked ? (
                      <span className="text-xs">{index + 1}</span>
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </div>

                  <div className="flex-1">
                    <h4 className={`font-medium mb-1 ${
                      lesson.isLocked ? 'text-[var(--smoke)]/40' : 'text-white'
                    }`}>
                      {lesson.title}
                    </h4>
                    <div className="flex items-center gap-3 text-xs text-[var(--smoke)]/60">
                      <span>{lesson.duration}</span>
                      {lesson.tokensReward > 0 && (
                        <div className="flex items-center gap-1">
                          <span>+{lesson.tokensReward}</span>
                          <div className="w-3 h-3 text-[var(--orange)]">⚡</div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Attachments */}
        {currentLesson.attachments && currentLesson.attachments.length > 0 && (
          <div className="border-t border-[var(--smoke)]/20 p-4">
            <h4 className="font-medium text-white mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Materiais da Aula
            </h4>
            <div className="space-y-2">
              {currentLesson.attachments.map((attachment) => (
                <button
                  key={attachment.id}
                  className="w-full flex items-center justify-between p-3 glass-morphism rounded-xl hover:bg-[var(--smoke)]/5 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-[var(--blue)]" />
                    <div className="text-left">
                      <p className="text-sm font-medium text-white">{attachment.title}</p>
                      {attachment.size && (
                        <p className="text-xs text-[var(--smoke)]/60">{attachment.size}</p>
                      )}
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-[var(--smoke)]/70" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}