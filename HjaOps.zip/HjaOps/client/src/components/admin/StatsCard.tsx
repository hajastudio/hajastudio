import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  progress?: {
    value: number;
    max: number;
  };
  className?: string;
}

export function StatsCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  progress,
  className = ""
}: StatsCardProps) {
  const formatValue = (val: string | number) => {
    if (typeof val === 'number') {
      return val.toLocaleString();
    }
    return val;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02, y: -5 }}
      transition={{ duration: 0.3 }}
      className={`glass-morphism-strong rounded-3xl p-6 animated-border hover:neon-glow transition-all duration-300 ${className}`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-sm font-medium text-[var(--smoke)]/70 uppercase tracking-wide mb-2">
            {title}
          </h3>
          <div className="text-2xl font-orbitron font-bold text-white mb-1">
            {formatValue(value)}
          </div>
          {subtitle && (
            <p className="text-sm text-[var(--smoke)]/60">{subtitle}</p>
          )}
        </div>
        
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--blue)] to-blue-600 flex items-center justify-center neon-glow">
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>

      {/* Trend Indicator */}
      {trend && (
        <div className="flex items-center gap-2 mb-3">
          <span className={`text-sm font-medium ${
            trend.isPositive ? 'text-green-400' : 'text-red-400'
          }`}>
            {trend.isPositive ? '↗' : '↘'} {Math.abs(trend.value)}%
          </span>
          <span className="text-xs text-[var(--smoke)]/60">vs. mês anterior</span>
        </div>
      )}

      {/* Progress Bar */}
      {progress && (
        <div className="mt-4">
          <div className="flex justify-between text-xs text-[var(--smoke)]/60 mb-2">
            <span>Progresso</span>
            <span>{progress.value}/{progress.max}</span>
          </div>
          <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(progress.value / progress.max) * 100}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              style={{
                boxShadow: '0 0 10px var(--blue)',
              }}
            />
          </div>
        </div>
      )}
    </motion.div>
  );
}