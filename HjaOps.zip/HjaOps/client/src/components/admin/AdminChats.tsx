import { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Search, Filter, Eye, Download, Clock, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface Chat {
  id: string;
  userId: string;
  userName: string;
  agentId: string;
  agentName: string;
  title: string;
  messageCount: number;
  tokensUsed: number;
  startTime: Date;
  lastActivity: Date;
  status: 'active' | 'completed' | 'abandoned';
}

export default function AdminChats() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const [chats] = useState<Chat[]>([
    {
      id: 'CHT001',
      userId: '1',
      userName: 'Carlos Silva',
      agentId: 'AGT001',
      agentName: 'Agente Viral',
      title: 'Estratégias para Instagram',
      messageCount: 15,
      tokensUsed: 245,
      startTime: new Date(Date.now() - 2 * 60 * 1000),
      lastActivity: new Date(Date.now() - 30 * 1000),
      status: 'active'
    },
    {
      id: 'CHT002',
      userId: '2',
      userName: 'Maria Santos',
      agentId: 'AGT002',
      agentName: 'Agente Criativo',
      title: 'Ideias para campanha publicitária',
      messageCount: 8,
      tokensUsed: 156,
      startTime: new Date(Date.now() - 1 * 60 * 60 * 1000),
      lastActivity: new Date(Date.now() - 45 * 60 * 1000),
      status: 'completed'
    },
    {
      id: 'CHT003',
      userId: '3',
      userName: 'João Oliveira',
      agentId: 'AGT003',
      agentName: 'Agente Técnico',
      title: 'Suporte para integração API',
      messageCount: 23,
      tokensUsed: 387,
      startTime: new Date(Date.now() - 2 * 60 * 60 * 1000),
      lastActivity: new Date(Date.now() - 30 * 60 * 1000),
      status: 'active'
    },
    {
      id: 'CHT004',
      userId: '4',
      userName: 'Ana Costa',
      agentId: 'AGT004',
      agentName: 'Agente Marketing',
      title: 'Análise de concorrência',
      messageCount: 5,
      tokensUsed: 89,
      startTime: new Date(Date.now() - 3 * 60 * 60 * 1000),
      lastActivity: new Date(Date.now() - 2 * 60 * 60 * 1000),
      status: 'abandoned'
    },
    {
      id: 'CHT005',
      userId: '1',
      userName: 'Carlos Silva',
      agentId: 'AGT001',
      agentName: 'Agente Viral',
      title: 'Conteúdo para TikTok',
      messageCount: 12,
      tokensUsed: 198,
      startTime: new Date(Date.now() - 4 * 60 * 60 * 1000),
      lastActivity: new Date(Date.now() - 3 * 60 * 60 * 1000),
      status: 'completed'
    },
    {
      id: 'CHT006',
      userId: '5',
      userName: 'Pedro Lima',
      agentId: 'AGT002',
      agentName: 'Agente Criativo',
      title: 'Brainstorm produto inovador',
      messageCount: 18,
      tokensUsed: 267,
      startTime: new Date(Date.now() - 5 * 60 * 60 * 1000),
      lastActivity: new Date(Date.now() - 10 * 60 * 1000),
      status: 'active'
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'completed': return 'admin-bg-blue';
      case 'abandoned': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />;
      case 'completed': return <div className="w-2 h-2 bg-blue-400 rounded-full" />;
      case 'abandoned': return <div className="w-2 h-2 bg-red-400 rounded-full" />;
      default: return null;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  };

  const formatDuration = (start: Date, end: Date) => {
    const diff = end.getTime() - start.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));

    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    return `${minutes}m`;
  };

  const filteredChats = chats.filter(chat => {
    const matchesSearch = chat.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         chat.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         chat.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAgent = selectedAgent === 'all' || chat.agentId === selectedAgent;
    const matchesStatus = selectedStatus === 'all' || chat.status === selectedStatus;
    return matchesSearch && matchesAgent && matchesStatus;
  });

  // Estatísticas
  const totalTokens = chats.reduce((sum, chat) => sum + chat.tokensUsed, 0);
  const activeChats = chats.filter(chat => chat.status === 'active').length;
  const avgMessagesPerChat = Math.round(chats.reduce((sum, chat) => sum + chat.messageCount, 0) / chats.length);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold admin-text-blue mb-2">
          Histórico Global de Chats
        </h1>
        <p className="admin-text-smoke text-lg">
          Monitoramento completo de conversas e interações
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl admin-bg-blue flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Total de Chats</h3>
          <p className="text-2xl font-bold admin-text-blue">{chats.length}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Chats Ativos</h3>
          <p className="text-2xl font-bold text-green-400">{activeChats}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl admin-bg-orange flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Tokens Totais</h3>
          <p className="text-2xl font-bold admin-text-orange">{totalTokens.toLocaleString()}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-purple-600 flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Média Msgs/Chat</h3>
          <p className="text-2xl font-bold text-purple-400">{avgMessagesPerChat}</p>
        </motion.div>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="admin-card p-6"
      >
        <div className="flex flex-col md:flex-row gap-4">
          
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar por título, usuário ou ID do chat..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
            />
          </div>

          {/* Agent Filter */}
          <select
            value={selectedAgent}
            onChange={(e) => setSelectedAgent(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            <option value="all">Todos os Agentes</option>
            <option value="AGT001">Agente Viral</option>
            <option value="AGT002">Agente Criativo</option>
            <option value="AGT003">Agente Técnico</option>
            <option value="AGT004">Agente Marketing</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            <option value="all">Todos os Status</option>
            <option value="active">Ativo</option>
            <option value="completed">Concluído</option>
            <option value="abandoned">Abandonado</option>
          </select>

          <Button className="admin-bg-blue hover:opacity-90">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </motion.div>

      {/* Chats Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="admin-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-blue-500/20">
              <tr>
                <th className="text-left p-4 admin-text-blue font-semibold">Chat ID</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Título</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Usuário</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Agente</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Mensagens</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Tokens</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Status</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Duração</th>
                <th className="text-center p-4 admin-text-blue font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredChats.map((chat, index) => (
                <motion.tr
                  key={chat.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-blue-500/10 hover:bg-blue-500/5"
                >
                  
                  {/* Chat ID */}
                  <td className="p-4">
                    <span className="font-mono text-sm admin-text-blue">
                      {chat.id}
                    </span>
                  </td>

                  {/* Title */}
                  <td className="p-4">
                    <div className="max-w-xs">
                      <p className="admin-text-blue font-medium truncate">
                        {chat.title}
                      </p>
                      <p className="text-xs admin-text-smoke">
                        Iniciado {formatTimeAgo(chat.startTime)}
                      </p>
                    </div>
                  </td>

                  {/* User */}
                  <td className="p-4">
                    <span className="admin-text-blue font-medium">
                      {chat.userName}
                    </span>
                  </td>

                  {/* Agent */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <Bot className="w-4 h-4 admin-text-blue" />
                      <span className="admin-text-smoke text-sm">
                        {chat.agentName}
                      </span>
                    </div>
                  </td>

                  {/* Messages */}
                  <td className="p-4">
                    <span className="admin-text-blue font-bold">
                      {chat.messageCount}
                    </span>
                  </td>

                  {/* Tokens */}
                  <td className="p-4">
                    <span className="admin-text-orange font-bold">
                      {chat.tokensUsed.toLocaleString()}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(chat.status)}
                      <Badge className={`${getStatusColor(chat.status)} text-white`}>
                        {chat.status === 'active' ? 'Ativo' :
                         chat.status === 'completed' ? 'Concluído' : 'Abandonado'}
                      </Badge>
                    </div>
                  </td>

                  {/* Duration */}
                  <td className="p-4">
                    <span className="admin-text-smoke text-sm">
                      {formatDuration(chat.startTime, chat.lastActivity)}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="p-4">
                    <div className="flex items-center justify-center gap-2">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="admin-text-blue hover:bg-blue-500/10"
                        title="Visualizar chat"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        className="admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
                        title="Exportar chat"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 border-t border-blue-500/20">
          <div className="flex items-center justify-between">
            <span className="admin-text-smoke text-sm">
              Mostrando {filteredChats.length} de {chats.length} chats
            </span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Anterior
              </Button>
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Próximo
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}