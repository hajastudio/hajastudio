import { useState } from 'react';
import { 
  Menu, 
  CreditCard, 
  User, 
  Settings, 
  LogOut,
  Zap,
  Bell
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface AdminHeaderProps {
  onToggleSidebar?: () => void;
}

export default function AdminHeader({ onToggleSidebar }: AdminHeaderProps) {
  const [userCredits] = useState(25000);
  const [maxCredits] = useState(50000);
  const [notifications] = useState(5);

  const creditPercentage = (userCredits / maxCredits) * 100;

  return (
    <header className="admin-sidebar border-b border-blue-500/20 sticky top-0 z-50">
      <div className="flex items-center justify-between px-6 py-4">
        
        {/* Left Section - Logo & Toggle */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleSidebar}
            className="lg:hidden admin-text-smoke hover:admin-text-blue"
            data-testid="toggle-sidebar"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          <div className="flex items-center gap-3">
            <div className="admin-glow-blue w-10 h-10 rounded-xl flex items-center justify-center admin-pulse">
              <span className="text-white font-bold text-lg">H</span>
            </div>
            <div>
              <h1 className="text-xl font-bold admin-text-blue">Haja²Ops</h1>
              <p className="text-xs admin-text-smoke">Admin Dashboard</p>
            </div>
          </div>
        </div>

        {/* Center Section - Credits */}
        <div className="hidden md:flex items-center gap-4 flex-1 max-w-md mx-8">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium admin-text-smoke">Créditos</span>
              <span className="text-sm font-bold admin-text-blue">
                {userCredits.toLocaleString()} / {maxCredits.toLocaleString()}
              </span>
            </div>
            <Progress 
              value={creditPercentage} 
              className="h-2 bg-gray-800"
            />
          </div>
          <Zap className="w-5 h-5 admin-text-blue" />
        </div>

        {/* Right Section - Actions */}
        <div className="flex items-center gap-3">
          
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="relative admin-text-smoke hover:admin-text-blue"
                data-testid="notifications-button"
              >
                <Bell className="w-5 h-5" />
                {notifications > 0 && (
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 admin-bg-orange text-white text-xs">
                    {notifications}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 bg-black border-blue-500/20">
              <div className="p-4 border-b border-blue-500/20">
                <h3 className="font-semibold admin-text-blue">Alertas do Sistema</h3>
                <p className="text-sm admin-text-smoke">
                  {notifications} alertas pendentes
                </p>
              </div>
              
              <div className="max-h-64 overflow-y-auto">
                {[
                  { type: 'high', title: 'Usuário com consumo anômalo', time: '2 min' },
                  { type: 'medium', title: 'Créditos críticos - João Silva', time: '15 min' },
                  { type: 'low', title: 'Modelo HF temporariamente indisponível', time: '1h' },
                  { type: 'medium', title: 'Pico de uso detectado', time: '2h' }
                ].map((alert, index) => (
                  <DropdownMenuItem key={index} className="p-4 hover:bg-blue-500/10">
                    <div className="flex items-start gap-3 w-full">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        alert.type === 'high' ? 'bg-red-500' :
                        alert.type === 'medium' ? 'bg-orange-500' : 'bg-green-500'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium admin-text-blue text-sm">{alert.title}</p>
                        <p className="admin-text-smoke text-xs mt-1">{alert.time} atrás</p>
                      </div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Recarregar Créditos CTA */}
          <Button 
            className="admin-bg-orange hover:opacity-90 text-white font-semibold admin-glow-orange"
            data-testid="recharge-credits"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            Recarregar
          </Button>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center gap-2 admin-text-smoke hover:admin-text-blue"
                data-testid="user-menu"
              >
                <div className="w-8 h-8 admin-bg-blue rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium admin-text-blue">Admin</p>
                  <p className="text-xs admin-text-smoke">Sistema</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-black border-blue-500/20">
              <div className="p-4 border-b border-blue-500/20">
                <p className="font-medium admin-text-blue">Administrador</p>
                <p className="text-sm admin-text-smoke">admin@haja2ops.com</p>
              </div>
              
              <DropdownMenuItem className="admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10">
                <User className="w-4 h-4 mr-2" />
                Perfil Admin
              </DropdownMenuItem>
              
              <DropdownMenuItem className="admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10">
                <Settings className="w-4 h-4 mr-2" />
                Configurações
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-blue-500/20" />
              
              <DropdownMenuItem className="text-red-400 hover:text-red-300 hover:bg-red-500/10">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}