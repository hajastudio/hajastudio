import { 
  BarChart3,
  MessageSquare,
  Bot,
  Users,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AdminSidebarProps {
  isOpen?: boolean;
  activeSection?: string;
  onSectionChange?: (section: string) => void;
}

interface MenuItem {
  id: string;
  label: string;
  icon: any;
  badge?: string;
}

export default function AdminSidebar({ 
  isOpen = true, 
  activeSection = 'overview',
  onSectionChange 
}: AdminSidebarProps) {
  
  const menuItems: MenuItem[] = [
    {
      id: 'overview',
      label: 'Dashboard',
      icon: BarChart3
    },
    {
      id: 'chats',
      label: 'Chats',
      icon: MessageSquare,
      badge: '1.2k'
    },
    {
      id: 'agents',
      label: 'Agentes',
      icon: Bot,
      badge: '8'
    },
    {
      id: 'users',
      label: 'Usuários',
      icon: Users,
      badge: '247'
    },
    {
      id: 'transactions',
      label: 'Transações',
      icon: CreditCard
    },
    {
      id: 'affiliates',
      label: 'Afiliados',
      icon: ShoppingBag,
      badge: 'Novo'
    },
    {
      id: 'reports',
      label: 'Relatórios',
      icon: FileText,
      badge: 'CSV'
    },
    {
      id: 'settings',
      label: 'Configurações',
      icon: Settings
    }
  ];

  const handleSectionClick = (sectionId: string) => {
    onSectionChange?.(sectionId);
  };

  if (!isOpen) {
    return (
      <aside className="w-16 admin-sidebar fixed left-0 top-16 h-[calc(100vh-64px)] z-40">
        <div className="p-2">
          {menuItems.map((item) => (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              onClick={() => handleSectionClick(item.id)}
              className={`w-full mb-2 justify-center relative ${
                activeSection === item.id 
                  ? 'admin-sidebar-item active' 
                  : 'admin-sidebar-item'
              }`}
              data-testid={`sidebar-${item.id}`}
            >
              <item.icon className="w-5 h-5" />
              {item.badge && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-orange-500 text-white text-xs rounded-full flex items-center justify-center">
                  {item.badge.length > 2 ? '!' : item.badge}
                </span>
              )}
            </Button>
          ))}
        </div>
      </aside>
    );
  }

  return (
    <aside className="w-64 admin-sidebar fixed left-0 top-16 h-[calc(100vh-64px)] z-40">
      <div className="p-6">
        
        {/* Header da Sidebar */}
        <div className="mb-8">
          <h2 className="text-lg font-bold admin-text-blue mb-2">Control Center</h2>
          <p className="text-sm admin-text-smoke">Gestão completa da plataforma</p>
        </div>

        {/* Menu Principal */}
        <nav className="space-y-2">
          {menuItems.map((item) => (
            <div
              key={item.id}
              className={`admin-sidebar-item ${
                activeSection === item.id ? 'active' : ''
              }`}
              onClick={() => handleSectionClick(item.id)}
              data-testid={`sidebar-${item.id}`}
            >
              <item.icon className="w-5 h-5" />
              <span className="flex-1 font-medium">{item.label}</span>
              
              {item.badge && (
                <span className="admin-bg-orange text-white text-xs px-2 py-1 rounded-full">
                  {item.badge}
                </span>
              )}
            </div>
          ))}
        </nav>

        {/* Status do Sistema */}
        <div className="mt-12 pt-6 border-t border-blue-500/20">
          <div className="admin-card p-4">
            <div className="text-center">
              <div className="w-3 h-3 bg-green-500 rounded-full mx-auto mb-2 animate-pulse"></div>
              <h3 className="font-bold admin-text-blue mb-1">Sistema Online</h3>
              <p className="text-xs admin-text-smoke mb-3">
                Todos os serviços operacionais
              </p>
              <div className="text-xs admin-text-smoke">
                <p>Uptime: 99.9%</p>
                <p>Última verificação: agora</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="mt-6">
          <div className="admin-card p-4">
            <h3 className="font-semibold admin-text-blue mb-3 text-sm">Stats em Tempo Real</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-xs admin-text-smoke">Usuários Online</span>
                <span className="text-xs admin-text-blue font-bold">142</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs admin-text-smoke">Tokens/min</span>
                <span className="text-xs admin-text-blue font-bold">1.2k</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs admin-text-smoke">Requests/s</span>
                <span className="text-xs admin-text-blue font-bold">47</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}