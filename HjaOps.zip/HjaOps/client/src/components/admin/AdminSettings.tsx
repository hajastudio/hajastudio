import { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Save, RefreshCw, Shield, Database, Bell, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';

export default function AdminSettings() {
  const [settings, setSettings] = useState({
    // Sistema
    systemName: 'Haja²Ops',
    maintenanceMode: false,
    maxTokensPerRequest: 1000,
    maxRequestsPerMinute: 60,
    
    // Notificações
    emailNotifications: true,
    systemAlerts: true,
    lowCreditThreshold: 100,
    anomalyDetection: true,
    
    // Modelos
    defaultModel: 'groq',
    groqApiKey: '••••••••••••••••',
    openaiApiKey: '••••••••••••••••',
    huggingfaceApiKey: '••••••••••••••••',
    
    // Segurança
    sessionTimeout: 24,
    requireTwoFactor: false,
    adminLogging: true,
    rateLimitStrict: false
  });

  const handleSaveSettings = () => {
    console.log('Salvando configurações:', settings);
    // Implementar salvamento das configurações
  };

  const handleInputChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold admin-text-blue mb-2">
          Configurações do Sistema
        </h1>
        <p className="admin-text-smoke text-lg">
          Configurações gerais e preferências da plataforma
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Configurações Gerais */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-card p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Settings className="w-6 h-6 admin-text-blue" />
            <h2 className="text-xl font-bold admin-text-blue">
              Configurações Gerais
            </h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Nome do Sistema
              </label>
              <Input 
                value={settings.systemName}
                onChange={(e) => handleInputChange('systemName', e.target.value)}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Modo Manutenção</p>
                <p className="text-sm admin-text-smoke">
                  Ativa modo de manutenção para todos os usuários
                </p>
              </div>
              <Switch
                checked={settings.maintenanceMode}
                onCheckedChange={(checked) => handleInputChange('maintenanceMode', checked)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Máximo de Tokens por Requisição
              </label>
              <Input 
                type="number"
                value={settings.maxTokensPerRequest}
                onChange={(e) => handleInputChange('maxTokensPerRequest', parseInt(e.target.value))}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Máximo de Requisições por Minuto
              </label>
              <Input 
                type="number"
                value={settings.maxRequestsPerMinute}
                onChange={(e) => handleInputChange('maxRequestsPerMinute', parseInt(e.target.value))}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
              />
            </div>
          </div>
        </motion.div>

        {/* Configurações de Notificações */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-card p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Bell className="w-6 h-6 admin-text-blue" />
            <h2 className="text-xl font-bold admin-text-blue">
              Notificações & Alertas
            </h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Notificações por Email</p>
                <p className="text-sm admin-text-smoke">
                  Enviar alertas importantes por email
                </p>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => handleInputChange('emailNotifications', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Alertas do Sistema</p>
                <p className="text-sm admin-text-smoke">
                  Mostrar alertas em tempo real
                </p>
              </div>
              <Switch
                checked={settings.systemAlerts}
                onCheckedChange={(checked) => handleInputChange('systemAlerts', checked)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Limiar de Créditos Baixos
              </label>
              <Input 
                type="number"
                value={settings.lowCreditThreshold}
                onChange={(e) => handleInputChange('lowCreditThreshold', parseInt(e.target.value))}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
              />
              <p className="text-xs admin-text-smoke mt-1">
                Alerta quando usuário tem menos créditos que este valor
              </p>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Detecção de Anomalias</p>
                <p className="text-sm admin-text-smoke">
                  Detectar uso anômalo automaticamente
                </p>
              </div>
              <Switch
                checked={settings.anomalyDetection}
                onCheckedChange={(checked) => handleInputChange('anomalyDetection', checked)}
              />
            </div>
          </div>
        </motion.div>

        {/* Configurações de Modelos */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-card p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Zap className="w-6 h-6 admin-text-blue" />
            <h2 className="text-xl font-bold admin-text-blue">
              Modelos de IA
            </h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Modelo Padrão
              </label>
              <select 
                value={settings.defaultModel}
                onChange={(e) => handleInputChange('defaultModel', e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
              >
                <option value="groq">Groq Llama</option>
                <option value="openai">OpenAI GPT</option>
                <option value="huggingface">HuggingFace</option>
                <option value="replit">Replit AI</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Chave API Groq
              </label>
              <Input 
                type="password"
                value={settings.groqApiKey}
                onChange={(e) => handleInputChange('groqApiKey', e.target.value)}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
                placeholder="Insira a chave API do Groq"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Chave API OpenAI
              </label>
              <Input 
                type="password"
                value={settings.openaiApiKey}
                onChange={(e) => handleInputChange('openaiApiKey', e.target.value)}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
                placeholder="Insira a chave API do OpenAI"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Chave API HuggingFace
              </label>
              <Input 
                type="password"
                value={settings.huggingfaceApiKey}
                onChange={(e) => handleInputChange('huggingfaceApiKey', e.target.value)}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
                placeholder="Insira a chave API do HuggingFace"
              />
            </div>
          </div>
        </motion.div>

        {/* Configurações de Segurança */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-card p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6 admin-text-blue" />
            <h2 className="text-xl font-bold admin-text-blue">
              Segurança
            </h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Timeout de Sessão (horas)
              </label>
              <Input 
                type="number"
                value={settings.sessionTimeout}
                onChange={(e) => handleInputChange('sessionTimeout', parseInt(e.target.value))}
                className="bg-black/50 border-blue-500/20 admin-text-smoke"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Autenticação 2FA</p>
                <p className="text-sm admin-text-smoke">
                  Exigir autenticação de dois fatores para admins
                </p>
              </div>
              <Switch
                checked={settings.requireTwoFactor}
                onCheckedChange={(checked) => handleInputChange('requireTwoFactor', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Log de Ações Admin</p>
                <p className="text-sm admin-text-smoke">
                  Registrar todas as ações administrativas
                </p>
              </div>
              <Switch
                checked={settings.adminLogging}
                onCheckedChange={(checked) => handleInputChange('adminLogging', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium admin-text-blue">Rate Limiting Rígido</p>
                <p className="text-sm admin-text-smoke">
                  Aplicar limits mais restritivos
                </p>
              </div>
              <Switch
                checked={settings.rateLimitStrict}
                onCheckedChange={(checked) => handleInputChange('rateLimitStrict', checked)}
              />
            </div>
          </div>
        </motion.div>
      </div>

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="admin-card p-6"
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold admin-text-blue mb-1">Ações do Sistema</h3>
            <p className="admin-text-smoke text-sm">
              Salvar configurações e operações administrativas
            </p>
          </div>
          
          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              className="border-blue-500/20 admin-text-smoke hover:admin-text-blue"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Resetar
            </Button>
            
            <Button 
              onClick={handleSaveSettings}
              className="admin-bg-blue hover:opacity-90"
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar Configurações
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}