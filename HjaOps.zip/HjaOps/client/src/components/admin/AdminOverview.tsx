import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  Zap, 
  DollarSign, 
  Activity,
  Users,
  MessageSquare,
  Bot,
  AlertTriangle
} from 'lucide-react';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';

interface MetricCard {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: any;
  color: string;
}

interface ActivityItem {
  id: string;
  user: string;
  action: string;
  agent: string;
  tokens: number;
  timestamp: Date;
}

export default function AdminOverview() {
  const [metrics] = useState<MetricCard[]>([
    {
      title: 'Tokens Usados Hoje',
      value: '47.2k',
      change: '+12%',
      trend: 'up',
      icon: Zap,
      color: 'blue'
    },
    {
      title: 'Modelo Mais Usado',
      value: 'Groq Llama',
      change: '68% share',
      trend: 'up',
      icon: Bot,
      color: 'purple'
    },
    {
      title: 'Receita Mensal',
      value: 'R$ 12.4k',
      change: '+24%',
      trend: 'up',
      icon: DollarSign,
      color: 'green'
    },
    {
      title: 'Status Sistema',
      value: 'Estável',
      change: '99.9% uptime',
      trend: 'up',
      icon: Activity,
      color: 'blue'
    }
  ]);

  const [activities] = useState<ActivityItem[]>([
    {
      id: '1',
      user: 'Carlos Silva',
      action: 'usou',
      agent: 'Agente Viral',
      tokens: 12,
      timestamp: new Date(Date.now() - 2 * 60 * 1000)
    },
    {
      id: '2',
      user: 'Maria Santos',
      action: 'criou chat com',
      agent: 'Agente Criativo',
      tokens: 8,
      timestamp: new Date(Date.now() - 5 * 60 * 1000)
    },
    {
      id: '3',
      user: 'João Oliveira',
      action: 'finalizou sessão',
      agent: 'Agente Técnico',
      tokens: 25,
      timestamp: new Date(Date.now() - 12 * 60 * 1000)
    },
    {
      id: '4',
      user: 'Ana Costa',
      action: 'iniciou conversa',
      agent: 'Agente Marketing',
      tokens: 6,
      timestamp: new Date(Date.now() - 18 * 60 * 1000)
    },
    {
      id: '5',
      user: 'Pedro Lima',
      action: 'usou',
      agent: 'Agente Suporte',
      tokens: 15,
      timestamp: new Date(Date.now() - 25 * 60 * 1000)
    }
  ]);

  // Dados para o gráfico de consumo de tokens
  const chartOptions: ApexOptions = {
    chart: {
      type: 'area',
      height: 300,
      background: 'transparent',
      toolbar: {
        show: false
      }
    },
    theme: {
      mode: 'dark'
    },
    colors: ['#0055ff', '#ff6a00'],
    stroke: {
      curve: 'smooth',
      width: 2
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.7,
        opacityTo: 0.1,
        stops: [0, 90, 100]
      }
    },
    grid: {
      borderColor: 'rgba(0, 85, 255, 0.1)',
      strokeDashArray: 3
    },
    xaxis: {
      categories: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
      labels: {
        style: {
          colors: '#c5d1db'
        }
      }
    },
    yaxis: {
      labels: {
        style: {
          colors: '#c5d1db'
        }
      }
    },
    tooltip: {
      theme: 'dark',
      style: {
        fontSize: '12px'
      }
    },
    legend: {
      labels: {
        colors: '#c5d1db'
      }
    }
  };

  const chartSeries = [
    {
      name: 'Tokens Consumidos',
      data: [1200, 800, 1800, 2400, 3200, 2800, 2100]
    },
    {
      name: 'Picos de Uso',
      data: [800, 600, 1200, 1800, 2400, 2000, 1500]
    }
  ];

  const formatTimeAgo = (date: Date) => {
    const minutes = Math.floor((Date.now() - date.getTime()) / (1000 * 60));
    if (minutes < 1) return 'agora';
    if (minutes < 60) return `${minutes}m atrás`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h atrás`;
  };

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold admin-text-blue mb-2">
          Dashboard Administrativo
        </h1>
        <p className="admin-text-smoke text-lg">
          Visão geral completa da plataforma Haja²Ops
        </p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-metric-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                metric.color === 'blue' ? 'admin-bg-blue' :
                metric.color === 'purple' ? 'bg-purple-600' :
                metric.color === 'green' ? 'bg-green-600' : 'admin-bg-orange'
              }`}>
                <metric.icon className="w-6 h-6 text-white" />
              </div>
              <span className={`text-sm font-semibold ${
                metric.trend === 'up' ? 'text-green-400' : 'text-red-400'
              }`}>
                {metric.change}
              </span>
            </div>
            
            <h3 className="admin-text-smoke text-sm font-medium mb-1">{metric.title}</h3>
            <p className="text-2xl font-bold admin-text-blue">{metric.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Gráfico Principal */}
        <div className="lg:col-span-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="admin-card p-6"
          >
            <div className="mb-6">
              <h2 className="text-xl font-bold admin-text-blue mb-2">
                Consumo de Tokens - Últimas 24h
              </h2>
              <p className="admin-text-smoke text-sm">
                Análise detalhada do uso por horário e picos de demanda
              </p>
            </div>
            
            <Chart
              options={chartOptions}
              series={chartSeries}
              type="area"
              height={300}
            />
          </motion.div>
        </div>

        {/* Atividades Recentes */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="admin-card p-6"
          >
            <div className="mb-6">
              <h2 className="text-xl font-bold admin-text-blue mb-2">
                Atividades Recentes
              </h2>
              <p className="admin-text-smoke text-sm">
                Últimas interações dos usuários
              </p>
            </div>
            
            <div className="space-y-4">
              {activities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg bg-black/30 border border-blue-500/10">
                  <div className="w-8 h-8 admin-bg-blue rounded-full flex items-center justify-center flex-shrink-0">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm admin-text-blue font-medium">
                      {activity.user}
                    </p>
                    <p className="text-xs admin-text-smoke">
                      {activity.action} <span className="admin-text-blue">{activity.agent}</span>
                    </p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs admin-text-smoke">
                        {formatTimeAgo(activity.timestamp)}
                      </span>
                      <span className="text-xs admin-text-orange font-bold">
                        {activity.tokens} tokens
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <button className="w-full mt-4 p-2 rounded-lg border border-blue-500/20 admin-text-blue hover:bg-blue-500/10 transition-colors text-sm">
              Ver Todas as Atividades
            </button>
          </motion.div>
        </div>
      </div>

      {/* Alertas do Sistema */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="admin-card p-6"
      >
        <div className="mb-6">
          <h2 className="text-xl font-bold admin-text-blue mb-2">
            Alertas & Notificações HVC Core
          </h2>
          <p className="admin-text-smoke text-sm">
            Monitoramento automático e alertas inteligentes
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            {
              level: 'high',
              title: 'Usuário com Uso Anômalo',
              message: 'João Silva consumiu 5x mais tokens que a média',
              time: '2 min atrás'
            },
            {
              level: 'medium',
              title: 'Créditos Críticos',
              message: '3 usuários com menos de 100 tokens restantes',
              time: '15 min atrás'
            },
            {
              level: 'low',
              title: 'Modelo HF Lento',
              message: 'Tempo de resposta 2x maior que normal',
              time: '1h atrás'
            }
          ].map((alert, index) => (
            <div key={index} className={`p-4 rounded-lg admin-alert-${alert.level}`}>
              <div className="flex items-start gap-3">
                <AlertTriangle className={`w-5 h-5 mt-0.5 ${
                  alert.level === 'high' ? 'text-red-400' :
                  alert.level === 'medium' ? 'admin-text-orange' : 'text-green-400'
                }`} />
                <div className="flex-1">
                  <h3 className="font-semibold admin-text-blue text-sm mb-1">
                    {alert.title}
                  </h3>
                  <p className="admin-text-smoke text-xs mb-2">
                    {alert.message}
                  </p>
                  <span className="text-xs admin-text-smoke opacity-70">
                    {alert.time}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}