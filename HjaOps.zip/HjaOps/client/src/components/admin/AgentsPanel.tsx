import { useState } from 'react';
import { motion } from 'framer-motion';
import { Bot, Cpu, Zap, MoreVertical, AlertTriangle } from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  model: string;
  usage: number;
  fallback: string;
  enabled: boolean;
  cost: number;
  latency: number;
}

interface AgentsPanelProps {
  agents?: Agent[];
}

const mockAgents: Agent[] = [
  {
    id: '1',
    name: 'Criador de Vídeos',
    model: 'GPT-5',
    usage: 87,
    fallback: 'Groq Llama 3.1',
    enabled: true,
    cost: 0.12,
    latency: 240
  },
  {
    id: '2',
    name: 'Analista de Dados',
    model: 'GPT-5',
    usage: 65,
    fallback: 'HuggingFace',
    enabled: true,
    cost: 0.08,
    latency: 180
  },
  {
    id: '3',
    name: 'Editor de Texto',
    model: 'GPT-5',
    usage: 43,
    fallback: 'Groq Llama 3.1',
    enabled: false,
    cost: 0.06,
    latency: 320
  },
  {
    id: '4',
    name: 'Assistente Marketing',
    model: 'GPT-5',
    usage: 78,
    fallback: 'HuggingFace',
    enabled: true,
    cost: 0.15,
    latency: 190
  }
];

export function AgentsPanel({ agents = mockAgents }: AgentsPanelProps) {
  const [agentStates, setAgentStates] = useState(agents);

  const toggleAgent = (id: string) => {
    setAgentStates(prev => 
      prev.map(agent => 
        agent.id === id ? { ...agent, enabled: !agent.enabled } : agent
      )
    );
  };

  const getUsageColor = (usage: number) => {
    if (usage >= 80) return 'text-red-400';
    if (usage >= 60) return 'text-yellow-400';
    return 'text-green-400';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="glass-morphism-strong rounded-3xl p-6 animated-border"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[var(--blue)] to-blue-600 flex items-center justify-center neon-glow">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-orbitron font-bold text-white">Agentes & Modelos</h2>
            <p className="text-sm text-[var(--smoke)]/70">Monitoramento em tempo real</p>
          </div>
        </div>
        <span className="text-xs px-3 py-1 bg-green-500/20 text-green-400 rounded-full border border-green-500/30">
          {agentStates.filter(a => a.enabled).length} ativos
        </span>
      </div>

      <div className="space-y-4">
        {agentStates.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-4 rounded-2xl border transition-all duration-300 ${
              agent.enabled 
                ? 'bg-[var(--blue)]/10 border-[var(--blue)]/30' 
                : 'bg-gray-500/10 border-gray-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 flex-1">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    agent.enabled ? 'bg-green-400 animate-pulse' : 'bg-gray-500'
                  }`} />
                  <div>
                    <h3 className="font-medium text-white">{agent.name}</h3>
                    <div className="flex items-center gap-2 text-xs text-[var(--smoke)]/60">
                      <Cpu className="w-3 h-3" />
                      <span>{agent.model}</span>
                      <span>→</span>
                      <span>{agent.fallback}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-center">
                    <div className={`text-sm font-medium ${getUsageColor(agent.usage)}`}>
                      {agent.usage}%
                    </div>
                    <div className="text-xs text-[var(--smoke)]/60">Uso</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm font-medium text-[var(--orange)]">
                      R$ {agent.cost.toFixed(2)}
                    </div>
                    <div className="text-xs text-[var(--smoke)]/60">Custo/msg</div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm font-medium text-[var(--smoke)]">
                      {agent.latency}ms
                    </div>
                    <div className="text-xs text-[var(--smoke)]/60">Latência</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {agent.usage > 85 && (
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                )}
                
                <motion.button
                  onClick={() => toggleAgent(agent.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`w-12 h-6 rounded-full transition-colors duration-300 relative ${
                    agent.enabled ? 'bg-[var(--blue)]' : 'bg-gray-600'
                  }`}
                  data-testid={`toggle-agent-${agent.id}`}
                >
                  <motion.div
                    className="w-5 h-5 bg-white rounded-full absolute top-0.5"
                    animate={{ x: agent.enabled ? 26 : 2 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  />
                </motion.button>
              </div>
            </div>

            {/* Usage Progress Bar */}
            <div className="mt-3">
              <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full rounded-full ${
                    agent.usage >= 80 ? 'bg-red-400' :
                    agent.usage >= 60 ? 'bg-yellow-400' : 'bg-green-400'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${agent.usage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}