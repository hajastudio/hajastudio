import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ShoppingCart,
  ExternalLink,
  Eye,
  Mouse,
  Plus,
  Edit,
  Trash2,
  TrendingUp,
  BarChart3,
  DollarSign
} from "lucide-react";
import Chart from "react-apexcharts";
import type { AffiliateProduct } from "@shared/schema";

export default function AdminAffiliates() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState<string>("");

  // Fetch all affiliate products
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/admin/affiliate/products"],
    retry: false,
  });

  // Fetch affiliate metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/admin/affiliate/metrics", selectedProduct],
    retry: false,
  });

  // Delete product mutation
  const deleteMutation = useMutation({
    mutationFn: async (productId: string) => {
      const response = await fetch(`/api/admin/affiliate/products/${productId}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "✅ Produto Removido",
        description: "Produto afiliado removido com sucesso",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/affiliate/products"] });
    },
    onError: (error: any) => {
      toast({
        title: "❌ Erro",
        description: error.message || "Erro ao remover produto",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    return numPrice.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  const calculateCTR = (clicks: number, impressions: number) => {
    if (impressions === 0) return 0;
    return ((clicks / impressions) * 100).toFixed(2);
  };

  // Chart configurations
  const chartOptions = {
    chart: {
      type: 'bar' as const,
      background: 'transparent',
      toolbar: { show: false },
    },
    colors: ['#00CCFF', '#FF740B'],
    theme: { mode: 'dark' as const },
    xaxis: {
      categories: (products as AffiliateProduct[])?.slice(0, 10).map((p: AffiliateProduct) => 
        p.title.length > 15 ? p.title.substring(0, 15) + '...' : p.title
      ) || [],
      labels: { style: { colors: '#9CA3AF' } },
    },
    yaxis: {
      labels: { style: { colors: '#9CA3AF' } },
    },
    dataLabels: { enabled: false },
    grid: {
      borderColor: '#374151',
      strokeDashArray: 3,
    },
  };

  const chartSeries = [
    {
      name: 'Impressões',
      data: (products as AffiliateProduct[])?.slice(0, 10).map((p: AffiliateProduct) => p.impressions || 0) || [],
    },
    {
      name: 'Cliques',
      data: (products as AffiliateProduct[])?.slice(0, 10).map((p: AffiliateProduct) => p.clicks || 0) || [],
    }
  ];

  const ProductCard = ({ product }: { product: AffiliateProduct }) => (
    <Card className="bg-black/40 border-[#00CCFF]/30 backdrop-blur-md hover:border-[#00CCFF]/60 transition-all duration-300">
      <div className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-bold text-white text-lg line-clamp-2 mb-2">
              {product.title}
            </h3>
            <p className="text-gray-300 text-sm line-clamp-2">
              {product.description}
            </p>
          </div>
          
          {/* Actions */}
          <div className="flex space-x-2 ml-4">
            <Button size="sm" variant="outline" className="border-gray-600">
              <Edit className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="border-red-500 text-red-400 hover:bg-red-500/20"
              onClick={() => deleteMutation.mutate(product.id)}
              disabled={deleteMutation.isPending}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Price and Status */}
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-[#FF740B]">
            {formatPrice(product.price)}
          </div>
          <div className="flex space-x-2">
            <Badge variant={product.active ? "default" : "secondary"} className={product.active ? "bg-green-600" : ""}>
              {product.active ? "Ativo" : "Inativo"}
            </Badge>
            {product.featured && (
              <Badge className="bg-[#FF740B]">
                <TrendingUp className="w-3 h-3 mr-1" />
                Destaque
              </Badge>
            )}
          </div>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-700">
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Eye className="w-4 h-4 text-[#00CCFF] mr-1" />
            </div>
            <div className="text-lg font-bold text-[#00CCFF]">{product.impressions || 0}</div>
            <div className="text-xs text-gray-400">Impressões</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Mouse className="w-4 h-4 text-[#FF740B] mr-1" />
            </div>
            <div className="text-lg font-bold text-[#FF740B]">{product.clicks || 0}</div>
            <div className="text-xs text-gray-400">Cliques</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <BarChart3 className="w-4 h-4 text-green-400 mr-1" />
            </div>
            <div className="text-lg font-bold text-green-400">
              {calculateCTR(product.clicks || 0, product.impressions || 0)}%
            </div>
            <div className="text-xs text-gray-400">CTR</div>
          </div>
        </div>

        {/* Category and Tags */}
        <div className="space-y-2">
          <Badge variant="outline" className="border-gray-600 text-gray-300">
            {product.category}
          </Badge>
          
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {product.tags.slice(0, 3).map((tag, index) => (
                <Badge 
                  key={index}
                  variant="outline" 
                  className="text-xs border-[#00CCFF]/50 text-[#00CCFF] bg-black/30">
                  {tag}
                </Badge>
              ))}
              {product.tags.length > 3 && (
                <Badge variant="outline" className="text-xs border-gray-600 text-gray-400">
                  +{product.tags.length - 3}
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Link to product */}
        <Button 
          className="w-full hv-btn-outline"
          onClick={() => window.open(product.affiliateUrl, '_blank')}>
          <ExternalLink className="w-4 h-4 mr-2" />
          Ver no Mercado Livre
        </Button>
      </div>
    </Card>
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">
            🛒 Produtos Afiliados
          </h1>
          <p className="text-gray-400">
            Gerencie produtos afiliados e visualize métricas de performance
          </p>
        </div>
        
        <Button className="hv-btn-primary text-black">
          <Plus className="w-4 h-4 mr-2" />
          Adicionar Produto
        </Button>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-black/40 border-[#00CCFF]/30 backdrop-blur-md">
          <div className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-[#00CCFF]/20 rounded-full flex items-center justify-center">
              <ShoppingCart className="w-6 h-6 text-[#00CCFF]" />
            </div>
            <div className="text-2xl font-bold text-white">
              {metrics?.totalProducts || (products as AffiliateProduct[])?.length || 0}
            </div>
            <div className="text-sm text-gray-400">Total de Produtos</div>
          </div>
        </Card>

        <Card className="bg-black/40 border-[#FF740B]/30 backdrop-blur-md">
          <div className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-[#FF740B]/20 rounded-full flex items-center justify-center">
              <Mouse className="w-6 h-6 text-[#FF740B]" />
            </div>
            <div className="text-2xl font-bold text-white">
              {metrics?.totalClicks || 0}
            </div>
            <div className="text-sm text-gray-400">Total de Cliques</div>
          </div>
        </Card>

        <Card className="bg-black/40 border-blue-500/30 backdrop-blur-md">
          <div className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-blue-500/20 rounded-full flex items-center justify-center">
              <Eye className="w-6 h-6 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-white">
              {metrics?.totalImpressions || 0}
            </div>
            <div className="text-sm text-gray-400">Total de Impressões</div>
          </div>
        </Card>

        <Card className="bg-black/40 border-green-500/30 backdrop-blur-md">
          <div className="p-6 text-center">
            <div className="w-12 h-12 mx-auto mb-4 bg-green-500/20 rounded-full flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-white">
              {metrics?.globalCtr || '0.00'}%
            </div>
            <div className="text-sm text-gray-400">CTR Global</div>
          </div>
        </Card>
      </div>

      {/* Performance Chart */}
      {!metricsLoading && products && (products as AffiliateProduct[]).length > 0 && (
        <Card className="bg-black/40 border-[#00CCFF]/30 backdrop-blur-md">
          <div className="p-6">
            <h3 className="text-xl font-bold text-white mb-6">
              📊 Performance dos Produtos
            </h3>
            <div className="h-80">
              <Chart
                options={chartOptions}
                series={chartSeries}
                type="bar"
                height="100%"
              />
            </div>
          </div>
        </Card>
      )}

      {/* Products Grid */}
      {productsLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-80 bg-gray-700 rounded-lg animate-pulse"></div>
          ))}
        </div>
      ) : products && (products as AffiliateProduct[]).length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {(products as AffiliateProduct[]).map((product: AffiliateProduct) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <Card className="bg-black/40 border-gray-600 backdrop-blur-md">
          <div className="p-12 text-center">
            <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-gray-500" />
            <h3 className="text-xl font-bold text-white mb-2">
              Nenhum produto afiliado
            </h3>
            <p className="text-gray-400 mb-6">
              Adicione produtos afiliados para começar a ganhar comissões
            </p>
            <Button className="hv-btn-primary text-black">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Primeiro Produto
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}