import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { UserManagement } from "./UserManagement";
import { AgentManagement } from "./AgentManagement";
import { AlertsPanel } from "./AlertsPanel";

export function AdminPanel() {
  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
  });

  const systemStats = [
    {
      label: "Total Users",
      value: stats?.totalUsers?.toLocaleString() || "0",
    },
    {
      label: "Active Chats",
      value: stats?.activeChats?.toString() || "0",
    },
    {
      label: "Tokens Today",
      value: stats?.tokensToday ? `${(stats.tokensToday / 1000).toFixed(1)}K` : "0",
    },
    {
      label: "Revenue MTD",
      value: stats?.revenue ? `$${stats.revenue.toLocaleString()}` : "$0",
    },
  ];

  const modelStatus = [
    { name: "OpenAI GPT-5", status: "operational", color: "text-green-400" },
    { name: "Groq Fallback", status: "operational", color: "text-green-400" },
    { name: "HuggingFace", status: "degraded", color: "text-yellow-400" },
  ];

  return (
    <section id="admin" className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-3xl font-bold text-red-400" data-testid="admin-title">Admin Panel</h2>
          <p className="text-sm text-muted-foreground">System management and monitoring</p>
        </div>
        <div className="flex items-center gap-2">
          <i className="fas fa-shield-alt text-red-400"></i>
          <span className="text-sm text-red-400 font-medium">Administrator Access</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* System Stats */}
        <Card className="netflix-card p-6">
          <CardContent className="p-0">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <i className="fas fa-server text-primary"></i>
              System Statistics
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              {systemStats.map((stat, index) => (
                <div key={index} className="text-center p-3 bg-secondary/30 rounded-lg" data-testid={`system-stat-${index}`}>
                  <p className="text-2xl font-bold text-primary" data-testid={`system-stat-value-${index}`}>
                    {stat.value}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`system-stat-label-${index}`}>
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AI Model Status */}
        <Card className="netflix-card p-6">
          <CardContent className="p-0">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <i className="fas fa-microchip text-primary"></i>
              AI Model Status
            </h3>
            
            <div className="space-y-3">
              {modelStatus.map((model, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg" data-testid={`model-status-${index}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${model.status === 'operational' ? 'bg-green-400 pulse-glow' : 'bg-yellow-400'}`}></div>
                    <span className="font-medium" data-testid={`model-name-${index}`}>
                      {model.name}
                    </span>
                  </div>
                  <span className={`text-xs ${model.color}`} data-testid={`model-status-text-${index}`}>
                    {model.status.charAt(0).toUpperCase() + model.status.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* HVC Core Alerts System */}
      <AlertsPanel />

      {/* User Management */}
      <UserManagement />

      {/* Agent Management */}
      <AgentManagement />
    </section>
  );
}
