import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileSpreadsheet, Calendar, TrendingUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface ExportData {
  totalClicks: number;
  totalImpressions: number;
  totalUsers: number;
  tokensAwarded: number;
  totalConversions: number;
  ctr: number;
  conversionRate: number;
  topProducts: Array<{
    productId: string;
    title: string;
    clicks: number;
    tokensAwarded: number;
  }>;
  dailyStats: Array<{
    date: string;
    clicks: number;
    tokens: number;
  }>;
}

export default function ExportReports() {
  const [isExporting, setIsExporting] = useState(false);

  const { data: stats } = useQuery<ExportData>({
    queryKey: ["/api/admin/affiliate/stats"],
    staleTime: 30000,
  });

  const exportToCSV = async (type: 'summary' | 'products' | 'daily') => {
    if (!stats) return;
    
    setIsExporting(true);
    
    try {
      let csvContent = '';
      let filename = '';

      switch (type) {
        case 'summary':
          csvContent = generateSummaryCSV(stats);
          filename = `mercadolivre-vitrine-resumo-${new Date().toISOString().split('T')[0]}.csv`;
          break;
        case 'products':
          csvContent = generateProductsCSV(stats.topProducts);
          filename = `mercadolivre-vitrine-produtos-${new Date().toISOString().split('T')[0]}.csv`;
          break;
        case 'daily':
          csvContent = generateDailyCSV(stats.dailyStats);
          filename = `mercadolivre-vitrine-diario-${new Date().toISOString().split('T')[0]}.csv`;
          break;
      }

      // Create and trigger download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting CSV:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const generateSummaryCSV = (data: ExportData): string => {
    const headers = [
      'Métrica',
      'Valor',
      'Porcentagem',
      'Data de Geração'
    ];

    const rows = [
      ['Total de Cliques', data.totalClicks.toString(), '', new Date().toISOString()],
      ['Total de Impressões', data.totalImpressions.toString(), '', ''],
      ['CTR (Taxa de Cliques)', data.ctr.toFixed(2) + '%', '', ''],
      ['Usuários Únicos', data.totalUsers.toString(), '', ''],
      ['Tokens Haja® Distribuídos', data.tokensAwarded.toString(), '', ''],
      ['Total de Conversões', data.totalConversions.toString(), '', ''],
      ['Taxa de Conversão', data.conversionRate.toFixed(2) + '%', '', ''],
    ];

    return [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
  };

  const generateProductsCSV = (products: ExportData['topProducts']): string => {
    const headers = [
      'ID do Produto',
      'Nome do Produto',
      'Total de Cliques',
      'Tokens Haja® Dados',
      'CTR Relativo (%)',
      'Ranking'
    ];

    const totalClicks = products.reduce((sum, p) => sum + p.clicks, 0);
    
    const rows = products.map((product, index) => [
      product.productId,
      product.title,
      product.clicks.toString(),
      product.tokensAwarded.toString(),
      ((product.clicks / Math.max(totalClicks, 1)) * 100).toFixed(2),
      (index + 1).toString()
    ]);

    return [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
  };

  const generateDailyCSV = (dailyData: ExportData['dailyStats']): string => {
    const headers = [
      'Data',
      'Cliques',
      'Tokens Dados',
      'Dia da Semana'
    ];

    const rows = dailyData.map(day => [
      day.date,
      day.clicks.toString(),
      day.tokens.toString(),
      new Date(day.date).toLocaleDateString('pt-BR', { weekday: 'long' })
    ]);

    return [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');
  };

  if (!stats) {
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-white">Relatórios de Exportação</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-48 bg-gray-700 rounded-lg animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white">Relatórios de Exportação</h2>
          <p className="text-gray-400 mt-1">
            Exporte dados da Vitrine Mercado Livre em formato CSV para análise externa
          </p>
        </div>
        
        <Badge className="bg-[#00CCFF]/20 text-[#00CCFF] border-[#00CCFF]/50">
          {stats.totalClicks.toLocaleString()} cliques totais
        </Badge>
      </div>

      {/* Export Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Summary Report */}
        <Card className="admin-card">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-500/20 p-3 rounded-full">
                <TrendingUp className="w-8 h-8 text-blue-400" />
              </div>
              <Badge className="bg-blue-500/20 text-blue-400">
                Resumo Geral
              </Badge>
            </div>
            
            <h3 className="text-xl font-semibold text-white mb-2">
              Relatório de Resumo
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Métricas consolidadas: CTR ({stats.ctr.toFixed(1)}%), conversões ({stats.conversionRate.toFixed(1)}%) e tokens distribuídos
            </p>
            
            <Button 
              onClick={() => exportToCSV('summary')}
              disabled={isExporting}
              className="w-full bg-blue-600 hover:bg-blue-700">
              <Download className="w-4 h-4 mr-2" />
              Exportar Resumo
            </Button>
          </div>
        </Card>

        {/* Products Report */}
        <Card className="admin-card">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-[#00CCFF]/20 p-3 rounded-full">
                <FileSpreadsheet className="w-8 h-8 text-[#00CCFF]" />
              </div>
              <Badge className="bg-[#00CCFF]/20 text-[#00CCFF]">
                Por Produto
              </Badge>
            </div>
            
            <h3 className="text-xl font-semibold text-white mb-2">
              Ranking de Produtos
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Performance individual de cada produto: cliques, tokens e posição no ranking
            </p>
            
            <Button 
              onClick={() => exportToCSV('products')}
              disabled={isExporting}
              className="w-full bg-[#00CCFF] text-black hover:bg-[#FF740B] hover:text-white">
              <Download className="w-4 h-4 mr-2" />
              Exportar Produtos
            </Button>
          </div>
        </Card>

        {/* Daily Report */}
        <Card className="admin-card">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-[#FF740B]/20 p-3 rounded-full">
                <Calendar className="w-8 h-8 text-[#FF740B]" />
              </div>
              <Badge className="bg-[#FF740B]/20 text-[#FF740B]">
                Evolução Diária
              </Badge>
            </div>
            
            <h3 className="text-xl font-semibold text-white mb-2">
              Evolução Diária
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              Histórico dos últimos 7 dias: cliques e tokens distribuídos por dia
            </p>
            
            <Button 
              onClick={() => exportToCSV('daily')}
              disabled={isExporting}
              className="w-full bg-[#FF740B] hover:bg-orange-600 text-white">
              <Download className="w-4 h-4 mr-2" />
              Exportar Histórico
            </Button>
          </div>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-black/30 border border-[#00CCFF]/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-[#00CCFF]">
            {stats.totalImpressions.toLocaleString()}
          </div>
          <div className="text-sm text-gray-400">Impressões</div>
        </div>
        
        <div className="bg-black/30 border border-[#FF740B]/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-[#FF740B]">
            {stats.ctr.toFixed(1)}%
          </div>
          <div className="text-sm text-gray-400">CTR Médio</div>
        </div>
        
        <div className="bg-black/30 border border-yellow-500/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-yellow-400">
            {stats.tokensAwarded.toLocaleString()}
          </div>
          <div className="text-sm text-gray-400">Tokens Dados</div>
        </div>
        
        <div className="bg-black/30 border border-green-500/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-400">
            {stats.conversionRate.toFixed(1)}%
          </div>
          <div className="text-sm text-gray-400">Conversões</div>
        </div>
      </div>

      {/* Info */}
      <Card className="admin-card">
        <div className="p-6">
          <h3 className="text-lg font-semibold text-white mb-2">
            Informações sobre os Relatórios
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-400">
            <div>
              <h4 className="text-[#00CCFF] font-medium mb-1">Formato</h4>
              <p>Arquivos CSV compatíveis com Excel, Google Sheets e outras ferramentas de análise</p>
            </div>
            <div>
              <h4 className="text-[#FF740B] font-medium mb-1">Frequência</h4>
              <p>Dados atualizados em tempo real. Exporte quantas vezes precisar</p>
            </div>
            <div>
              <h4 className="text-yellow-400 font-medium mb-1">Encoding</h4>
              <p>UTF-8 com suporte completo a caracteres especiais e acentos</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}