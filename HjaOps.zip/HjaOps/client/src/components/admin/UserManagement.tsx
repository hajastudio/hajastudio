import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

// Mock user data - would come from API in real implementation
const mockUsers = [
  {
    id: "1",
    firstName: "Alex",
    lastName: "Johnson",
    email: "alex@example.com",
    plan: "Pro",
    credits: 2450,
    lastActive: "2 hours ago",
    profileImageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=32&h=32",
  },
  {
    id: "2",
    firstName: "Sarah",
    lastName: "Williams",
    email: "sarah@example.com",
    plan: "Basic",
    credits: 850,
    lastActive: "1 day ago",
    profileImageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=32&h=32",
  },
];

export function UserManagement() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredUsers = mockUsers.filter(user =>
    `${user.firstName} ${user.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Card className="netflix-card p-6 mb-6">
      <CardContent className="p-0">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <i className="fas fa-users text-primary"></i>
            User Management
          </h3>
          <div className="flex gap-2">
            <Input 
              type="search" 
              placeholder="Search users..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-64"
              data-testid="input-search-users"
            />
            <Button variant="outline" data-testid="button-export-users">
              Export
            </Button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-2">User</th>
                <th className="text-left py-3 px-2">Plan</th>
                <th className="text-left py-3 px-2">Credits</th>
                <th className="text-left py-3 px-2">Last Active</th>
                <th className="text-left py-3 px-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-muted-foreground" data-testid="no-users-found">
                    No users found
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-border/50" data-testid={`user-row-${user.id}`}>
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-2">
                        <img 
                          src={user.profileImageUrl} 
                          alt="User" 
                          className="w-6 h-6 rounded-full object-cover"
                          data-testid={`user-avatar-${user.id}`}
                        />
                        <div>
                          <p className="font-medium" data-testid={`user-name-${user.id}`}>
                            {user.firstName} {user.lastName}
                          </p>
                          <p className="text-xs text-muted-foreground" data-testid={`user-email-${user.id}`}>
                            {user.email}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-2">
                      <span className="bg-primary/20 text-primary px-2 py-1 rounded-full text-xs" data-testid={`user-plan-${user.id}`}>
                        {user.plan}
                      </span>
                    </td>
                    <td className="py-3 px-2 font-medium" data-testid={`user-credits-${user.id}`}>
                      {user.credits.toLocaleString()}
                    </td>
                    <td className="py-3 px-2 text-muted-foreground" data-testid={`user-last-active-${user.id}`}>
                      {user.lastActive}
                    </td>
                    <td className="py-3 px-2">
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-primary hover:text-primary/80"
                          data-testid={`button-view-user-${user.id}`}
                        >
                          <i className="fas fa-eye"></i>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-yellow-400 hover:text-yellow-400/80"
                          data-testid={`button-edit-user-${user.id}`}
                        >
                          <i className="fas fa-edit"></i>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-red-400 hover:text-red-400/80"
                          data-testid={`button-suspend-user-${user.id}`}
                        >
                          <i className="fas fa-ban"></i>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
