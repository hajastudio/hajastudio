import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface Alert {
  id: string;
  type: "lowCredits" | "apiFailure" | "highUsage" | "systemError" | "securityWarning";
  title: string;
  message: string;
  severity: "low" | "medium" | "high" | "critical";
  timestamp: string;
  userId?: string;
  resolved: boolean;
  assignedTo?: string;
}

// Mock data baseada no Firebase seed
const mockAlerts: Alert[] = [
  {
    id: "alert001",
    type: "lowCredits",
    title: "Usuário com Créditos Baixos",
    message: "Usuário johndoe123 tem apenas 15 créditos restantes",
    severity: "medium",
    timestamp: "2025-09-05T10:30:00Z",
    userId: "johndoe123",
    resolved: false,
    assignedTo: "admin123"
  },
  {
    id: "alert002", 
    type: "apiFailure",
    title: "Falha na API OpenAI",
    message: "Rate limit atingido - switching to Groq fallback",
    severity: "high",
    timestamp: "2025-09-05T09:45:00Z",
    resolved: true,
    assignedTo: "admin123"
  },
  {
    id: "alert003",
    type: "highUsage",
    title: "Uso Elevado Detectado",
    message: "Sistema processou 50.000+ tokens na última hora",
    severity: "low",
    timestamp: "2025-09-05T11:00:00Z",
    resolved: false
  },
  {
    id: "alert004",
    type: "securityWarning",
    title: "Tentativas de Login Suspeitas",
    message: "Múltiplas tentativas de login falharam para IP 192.168.1.100",
    severity: "critical",
    timestamp: "2025-09-05T08:15:00Z",
    resolved: false,
    assignedTo: "admin123"
  }
];

const getSeverityColor = (severity: Alert['severity']) => {
  switch (severity) {
    case 'low': return 'text-blue-400 bg-blue-400/20';
    case 'medium': return 'text-yellow-400 bg-yellow-400/20';
    case 'high': return 'text-orange-400 bg-orange-400/20';
    case 'critical': return 'text-red-400 bg-red-400/20';
  }
};

const getTypeIcon = (type: Alert['type']) => {
  switch (type) {
    case 'lowCredits': return 'fas fa-credit-card';
    case 'apiFailure': return 'fas fa-exclamation-triangle';
    case 'highUsage': return 'fas fa-chart-line';
    case 'systemError': return 'fas fa-bug';
    case 'securityWarning': return 'fas fa-shield-alt';
  }
};

export function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);
  const [filter, setFilter] = useState<'all' | Alert['severity']>('all');
  const { toast } = useToast();

  const filteredAlerts = alerts.filter(alert => {
    if (filter === 'all') return true;
    return alert.severity === filter;
  });

  const unresolved = alerts.filter(a => !a.resolved);
  const critical = alerts.filter(a => a.severity === 'critical' && !a.resolved);

  const markAsResolved = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, resolved: true } : alert
    ));
    
    toast({
      title: "Alert Resolved",
      description: "Alert has been marked as resolved.",
      variant: "default"
    });
  };

  const assignToMe = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, assignedTo: 'admin123' } : alert
    ));
    
    toast({
      title: "Alert Assigned",
      description: "Alert has been assigned to you.",
      variant: "default"
    });
  };

  return (
    <Card className="netflix-card p-6 mb-6">
      <CardContent className="p-0">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <i className="fas fa-bell text-primary"></i>
              HVC Core Alerts
              {critical.length > 0 && (
                <span className="bg-red-400/20 text-red-400 px-2 py-1 rounded-full text-xs font-medium pulse-glow">
                  {critical.length} Critical
                </span>
              )}
            </h3>
            <p className="text-sm text-muted-foreground">
              {unresolved.length} alertas não resolvidos de {alerts.length} total
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
              data-testid="filter-all"
            >
              All ({alerts.length})
            </Button>
            <Button
              variant={filter === 'critical' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('critical')}
              data-testid="filter-critical"
            >
              Critical ({alerts.filter(a => a.severity === 'critical').length})
            </Button>
            <Button
              variant={filter === 'high' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('high')}
              data-testid="filter-high"
            >
              High ({alerts.filter(a => a.severity === 'high').length})
            </Button>
          </div>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground" data-testid="no-alerts">
              No alerts match the current filter
            </div>
          ) : (
            filteredAlerts.map((alert) => (
              <div 
                key={alert.id}
                className={`p-4 rounded-lg border border-border bg-secondary/10 ${
                  alert.resolved ? 'opacity-60' : ''
                }`}
                data-testid={`alert-${alert.id}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                      <i className={`${getTypeIcon(alert.type)} text-sm`}></i>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium" data-testid={`alert-title-${alert.id}`}>
                          {alert.title}
                        </h4>
                        <span 
                          className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alert.severity)}`}
                          data-testid={`alert-severity-${alert.id}`}
                        >
                          {alert.severity.toUpperCase()}
                        </span>
                        {alert.resolved && (
                          <span className="px-2 py-1 rounded-full text-xs font-medium text-green-400 bg-green-400/20">
                            RESOLVED
                          </span>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2" data-testid={`alert-message-${alert.id}`}>
                        {alert.message}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span data-testid={`alert-timestamp-${alert.id}`}>
                          {new Date(alert.timestamp).toLocaleString('pt-BR')}
                        </span>
                        {alert.userId && (
                          <span>User: {alert.userId}</span>
                        )}
                        {alert.assignedTo && (
                          <span>Assigned: {alert.assignedTo}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 ml-4">
                    {!alert.resolved && (
                      <>
                        {!alert.assignedTo && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => assignToMe(alert.id)}
                            data-testid={`button-assign-${alert.id}`}
                          >
                            Assign to Me
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => markAsResolved(alert.id)}
                          className="text-green-400 hover:text-green-300"
                          data-testid={`button-resolve-${alert.id}`}
                        >
                          Resolve
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mt-6 pt-4 border-t border-border">
          <div className="text-center">
            <p className="text-xl font-bold text-primary" data-testid="stats-total">
              {alerts.length}
            </p>
            <p className="text-xs text-muted-foreground">Total Alerts</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-red-400" data-testid="stats-critical">
              {alerts.filter(a => a.severity === 'critical').length}
            </p>
            <p className="text-xs text-muted-foreground">Critical</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-yellow-400" data-testid="stats-unresolved">
              {unresolved.length}
            </p>
            <p className="text-xs text-muted-foreground">Unresolved</p>
          </div>
          <div className="text-center">
            <p className="text-xl font-bold text-green-400" data-testid="stats-resolved">
              {alerts.filter(a => a.resolved).length}
            </p>
            <p className="text-xs text-muted-foreground">Resolved</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}