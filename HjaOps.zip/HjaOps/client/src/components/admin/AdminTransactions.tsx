import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Download, 
  CreditCard, 
  Plus,
  Minus,
  Calendar,
  DollarSign,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface Transaction {
  id: string;
  userId: string;
  userName: string;
  type: 'purchase' | 'refund' | 'adjustment';
  amount: number;
  credits: number;
  status: 'completed' | 'pending' | 'failed';
  paymentMethod: 'credit_card' | 'pix' | 'boleto' | 'admin';
  date: Date;
  description: string;
}

export default function AdminTransactions() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const [transactions] = useState<Transaction[]>([
    {
      id: 'TXN001',
      userId: '1',
      userName: 'Carlos Silva',
      type: 'purchase',
      amount: 49.90,
      credits: 1000,
      status: 'completed',
      paymentMethod: 'credit_card',
      date: new Date(Date.now() - 2 * 60 * 1000),
      description: 'Compra de pacote Pro'
    },
    {
      id: 'TXN002',
      userId: '2',
      userName: 'Maria Santos',
      type: 'purchase',
      amount: 19.90,
      credits: 500,
      status: 'completed',
      paymentMethod: 'pix',
      date: new Date(Date.now() - 1 * 60 * 60 * 1000),
      description: 'Compra de pacote Basic'
    },
    {
      id: 'TXN003',
      userId: '3',
      userName: 'João Oliveira',
      type: 'purchase',
      amount: 99.90,
      credits: 2500,
      status: 'pending',
      paymentMethod: 'boleto',
      date: new Date(Date.now() - 2 * 60 * 60 * 1000),
      description: 'Compra de pacote Premium'
    },
    {
      id: 'TXN004',
      userId: '4',
      userName: 'Ana Costa',
      type: 'refund',
      amount: -19.90,
      credits: -500,
      status: 'completed',
      paymentMethod: 'credit_card',
      date: new Date(Date.now() - 3 * 60 * 60 * 1000),
      description: 'Reembolso de compra'
    },
    {
      id: 'TXN005',
      userId: '1',
      userName: 'Carlos Silva',
      type: 'adjustment',
      amount: 0,
      credits: 100,
      status: 'completed',
      paymentMethod: 'admin',
      date: new Date(Date.now() - 4 * 60 * 60 * 1000),
      description: 'Ajuste administrativo - compensação por falha'
    },
    {
      id: 'TXN006',
      userId: '5',
      userName: 'Pedro Lima',
      type: 'purchase',
      amount: 29.90,
      credits: 750,
      status: 'failed',
      paymentMethod: 'credit_card',
      date: new Date(Date.now() - 5 * 60 * 60 * 1000),
      description: 'Compra de pacote Intermediário'
    }
  ]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'purchase': return <Plus className="w-4 h-4 text-green-400" />;
      case 'refund': return <Minus className="w-4 h-4 text-red-400" />;
      case 'adjustment': return <CreditCard className="w-4 h-4 admin-text-blue" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'pending': return 'admin-bg-orange';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getPaymentMethodName = (method: string) => {
    switch (method) {
      case 'credit_card': return 'Cartão';
      case 'pix': return 'PIX';
      case 'boleto': return 'Boleto';
      case 'admin': return 'Admin';
      default: return method;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = transaction.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         transaction.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'all' || transaction.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || transaction.status === selectedStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  // Cálculos para resumo
  const totalRevenue = transactions
    .filter(t => t.type === 'purchase' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalRefunds = transactions
    .filter(t => t.type === 'refund' && t.status === 'completed')
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const pendingAmount = transactions
    .filter(t => t.status === 'pending')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold admin-text-blue mb-2">
          Gestão de Transações
        </h1>
        <p className="admin-text-smoke text-lg">
          Monitoramento completo de pagamentos e transações
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-green-600 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-400" />
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Receita Total</h3>
          <p className="text-2xl font-bold text-green-400">
            R$ {totalRevenue.toFixed(2)}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center">
              <Minus className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Reembolsos</h3>
          <p className="text-2xl font-bold text-red-400">
            R$ {totalRefunds.toFixed(2)}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl admin-bg-orange flex items-center justify-center">
              <Calendar className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Pendentes</h3>
          <p className="text-2xl font-bold admin-text-orange">
            R$ {pendingAmount.toFixed(2)}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="admin-metric-card"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl admin-bg-blue flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
          </div>
          <h3 className="admin-text-smoke text-sm font-medium mb-1">Transações</h3>
          <p className="text-2xl font-bold admin-text-blue">
            {transactions.length}
          </p>
        </motion.div>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="admin-card p-6"
      >
        <div className="flex flex-col md:flex-row gap-4">
          
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar por usuário ou ID da transação..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
            />
          </div>

          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            <option value="all">Todos os Tipos</option>
            <option value="purchase">Compras</option>
            <option value="refund">Reembolsos</option>
            <option value="adjustment">Ajustes</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            <option value="all">Todos os Status</option>
            <option value="completed">Concluídas</option>
            <option value="pending">Pendentes</option>
            <option value="failed">Falharam</option>
          </select>

          <Button className="admin-bg-blue hover:opacity-90">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
        </div>
      </motion.div>

      {/* Transactions Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="admin-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-blue-500/20">
              <tr>
                <th className="text-left p-4 admin-text-blue font-semibold">ID</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Usuário</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Tipo</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Valor</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Créditos</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Status</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Pagamento</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Data</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((transaction, index) => (
                <motion.tr
                  key={transaction.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-blue-500/10 hover:bg-blue-500/5"
                >
                  
                  {/* ID */}
                  <td className="p-4">
                    <span className="font-mono text-sm admin-text-blue">
                      {transaction.id}
                    </span>
                  </td>

                  {/* User */}
                  <td className="p-4">
                    <span className="admin-text-blue font-medium">
                      {transaction.userName}
                    </span>
                  </td>

                  {/* Type */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {getTypeIcon(transaction.type)}
                      <span className="capitalize admin-text-smoke">
                        {transaction.type === 'purchase' ? 'Compra' :
                         transaction.type === 'refund' ? 'Reembolso' : 'Ajuste'}
                      </span>
                    </div>
                  </td>

                  {/* Amount */}
                  <td className="p-4">
                    <span className={`font-bold ${
                      transaction.amount > 0 ? 'text-green-400' : 
                      transaction.amount < 0 ? 'text-red-400' : 'admin-text-smoke'
                    }`}>
                      {transaction.amount === 0 ? '-' : `R$ ${Math.abs(transaction.amount).toFixed(2)}`}
                    </span>
                  </td>

                  {/* Credits */}
                  <td className="p-4">
                    <span className={`font-bold ${
                      transaction.credits > 0 ? 'admin-text-blue' : 
                      transaction.credits < 0 ? 'text-red-400' : 'admin-text-smoke'
                    }`}>
                      {transaction.credits > 0 ? '+' : ''}{transaction.credits.toLocaleString()}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="p-4">
                    <Badge className={`${getStatusColor(transaction.status)} text-white`}>
                      {transaction.status === 'completed' ? 'Concluída' :
                       transaction.status === 'pending' ? 'Pendente' : 'Falha'}
                    </Badge>
                  </td>

                  {/* Payment Method */}
                  <td className="p-4">
                    <span className="admin-text-smoke">
                      {getPaymentMethodName(transaction.paymentMethod)}
                    </span>
                  </td>

                  {/* Date */}
                  <td className="p-4">
                    <span className="admin-text-smoke text-sm">
                      {formatTimeAgo(transaction.date)}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 border-t border-blue-500/20">
          <div className="flex items-center justify-between">
            <span className="admin-text-smoke text-sm">
              Mostrando {filteredTransactions.length} de {transactions.length} transações
            </span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Anterior
              </Button>
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Próximo
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}