import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { Agent } from "@shared/schema";

export function AgentManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: agents = [], isLoading } = useQuery({
    queryKey: ["/api/agents/all"],
  });

  const toggleAgentMutation = useMutation({
    mutationFn: async ({ agentId, active }: { agentId: string; active: boolean }) => {
      const response = await apiRequest("PUT", `/api/agents/${agentId}`, { active });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Agent Updated",
        description: "Agent status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agents"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update agent status.",
        variant: "destructive",
      });
    },
  });

  const deleteAgentMutation = useMutation({
    mutationFn: async (agentId: string) => {
      const response = await apiRequest("DELETE", `/api/agents/${agentId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Agent Deleted",
        description: "Agent has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agents"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete agent.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <Card className="netflix-card p-6">
        <CardContent className="p-0">
          <div className="text-center py-8 text-muted-foreground">
            Loading agents...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="netflix-card p-6">
      <CardContent className="p-0">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <i className="fas fa-robot text-primary"></i>
            Agent Management
          </h3>
          <Button className="neon-glow" data-testid="button-create-agent">
            <i className="fas fa-plus mr-2"></i>
            Create Agent
          </Button>
        </div>
        
        {agents.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="no-agents-admin">
            No agents found
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((agent: Agent) => (
              <div key={agent.id} className="bg-secondary/30 p-4 rounded-lg border border-border" data-testid={`admin-agent-card-${agent.id}`}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold" data-testid={`admin-agent-name-${agent.id}`}>
                    {agent.name}
                  </h4>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${agent.active ? 'bg-green-400 pulse-glow' : 'bg-yellow-400'}`}></div>
                    <span className={`text-xs ${agent.active ? 'text-green-400' : 'text-yellow-400'}`} data-testid={`admin-agent-status-${agent.id}`}>
                      {agent.active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3" data-testid={`admin-agent-description-${agent.id}`}>
                  {agent.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">
                    Model: {agent.defaultModel}
                  </span>
                  <div className="flex gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-primary hover:text-primary/80"
                      data-testid={`button-edit-agent-${agent.id}`}
                    >
                      <i className="fas fa-edit"></i>
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-yellow-400 hover:text-yellow-400/80"
                      onClick={() => toggleAgentMutation.mutate({ 
                        agentId: agent.id, 
                        active: !agent.active 
                      })}
                      disabled={toggleAgentMutation.isPending}
                      data-testid={`button-toggle-agent-${agent.id}`}
                    >
                      <i className="fas fa-power-off"></i>
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-red-400 hover:text-red-400/80"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${agent.name}?`)) {
                          deleteAgentMutation.mutate(agent.id);
                        }
                      }}
                      disabled={deleteAgentMutation.isPending}
                      data-testid={`button-delete-agent-${agent.id}`}
                    >
                      <i className="fas fa-trash"></i>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
