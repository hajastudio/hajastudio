import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Bot, 
  Plus, 
  Edit, 
  Trash2, 
  ToggleLeft, 
  ToggleRight,
  Settings,
  Activity,
  Users,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';

interface Agent {
  id: string;
  name: string;
  description: string;
  prompt: string;
  model: 'groq' | 'huggingface' | 'replit' | 'openai';
  active: boolean;
  usageCount: number;
  lastUsed: Date;
  averageTokens: number;
  createdAt: Date;
}

export default function AdminAgents() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);

  const [agents, setAgents] = useState<Agent[]>([
    {
      id: '1',
      name: 'Agente Viral',
      description: 'Especialista em criar conteúdo viral para redes sociais',
      prompt: 'Você é um especialista em marketing viral. Crie conteúdo engajante...',
      model: 'groq',
      active: true,
      usageCount: 1547,
      lastUsed: new Date(Date.now() - 2 * 60 * 1000),
      averageTokens: 145,
      createdAt: new Date('2024-01-15')
    },
    {
      id: '2',
      name: 'Agente Criativo',
      description: 'Assistente para brainstorming e ideias criativas',
      prompt: 'Você é um diretor criativo experiente. Ajude com ideias inovadoras...',
      model: 'openai',
      active: true,
      usageCount: 892,
      lastUsed: new Date(Date.now() - 1 * 60 * 60 * 1000),
      averageTokens: 178,
      createdAt: new Date('2024-02-10')
    },
    {
      id: '3',
      name: 'Agente Técnico',
      description: 'Suporte técnico e resolução de problemas',
      prompt: 'Você é um especialista técnico. Forneça soluções precisas...',
      model: 'huggingface',
      active: false,
      usageCount: 324,
      lastUsed: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      averageTokens: 203,
      createdAt: new Date('2024-01-20')
    },
    {
      id: '4',
      name: 'Agente Marketing',
      description: 'Estratégias de marketing e growth hacking',
      prompt: 'Você é um consultor de marketing digital. Desenvolva estratégias...',
      model: 'groq',
      active: true,
      usageCount: 675,
      lastUsed: new Date(Date.now() - 6 * 60 * 60 * 1000),
      averageTokens: 156,
      createdAt: new Date('2024-02-05')
    }
  ]);

  const getModelColor = (model: string) => {
    switch (model) {
      case 'groq': return 'bg-green-500';
      case 'openai': return 'bg-blue-500';
      case 'huggingface': return 'admin-bg-orange';
      case 'replit': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getModelName = (model: string) => {
    switch (model) {
      case 'groq': return 'Groq Llama';
      case 'openai': return 'OpenAI GPT';
      case 'huggingface': return 'HuggingFace';
      case 'replit': return 'Replit AI';
      default: return model;
    }
  };

  const handleToggleAgent = (agentId: string) => {
    setAgents(prev => prev.map(agent => 
      agent.id === agentId 
        ? { ...agent, active: !agent.active }
        : agent
    ));
  };

  const handleDeleteAgent = (agentId: string) => {
    setAgents(prev => prev.filter(agent => agent.id !== agentId));
  };

  const formatTimeAgo = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold admin-text-blue mb-2">
            Gestão de Agentes
          </h1>
          <p className="admin-text-smoke text-lg">
            Configure e monitore todos os agentes IA da plataforma
          </p>
        </div>
        
        <Button 
          onClick={() => setShowCreateForm(!showCreateForm)}
          className="admin-bg-blue hover:opacity-90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Criar Agente
        </Button>
      </div>

      {/* Create Agent Form */}
      {showCreateForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="admin-card p-6"
        >
          <h2 className="text-xl font-bold admin-text-blue mb-4">
            Criar Novo Agente
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium admin-text-smoke mb-2">
                  Nome do Agente
                </label>
                <Input 
                  placeholder="Ex: Agente de Vendas"
                  className="bg-black/50 border-blue-500/20 admin-text-smoke"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium admin-text-smoke mb-2">
                  Descrição
                </label>
                <Input 
                  placeholder="Breve descrição do agente"
                  className="bg-black/50 border-blue-500/20 admin-text-smoke"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium admin-text-smoke mb-2">
                  Modelo
                </label>
                <select className="w-full px-3 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke">
                  <option value="groq">Groq Llama</option>
                  <option value="openai">OpenAI GPT</option>
                  <option value="huggingface">HuggingFace</option>
                  <option value="replit">Replit AI</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium admin-text-smoke mb-2">
                Prompt Base (Instruções)
              </label>
              <Textarea 
                placeholder="Você é um especialista em... Suas principais funções são..."
                rows={8}
                className="bg-black/50 border-blue-500/20 admin-text-smoke resize-none"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-end gap-3 mt-6">
            <Button 
              variant="ghost" 
              onClick={() => setShowCreateForm(false)}
              className="admin-text-smoke hover:admin-text-blue"
            >
              Cancelar
            </Button>
            <Button className="admin-bg-blue hover:opacity-90">
              Criar Agente
            </Button>
          </div>
        </motion.div>
      )}

      {/* Agents Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {agents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="admin-card p-6"
          >
            
            {/* Agent Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  agent.active ? 'admin-bg-blue' : 'bg-gray-600'
                }`}>
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold admin-text-blue">{agent.name}</h3>
                  <Badge className={`${getModelColor(agent.model)} text-white text-xs`}>
                    {getModelName(agent.model)}
                  </Badge>
                </div>
              </div>
              
              <Switch
                checked={agent.active}
                onCheckedChange={() => handleToggleAgent(agent.id)}
              />
            </div>

            {/* Agent Description */}
            <p className="admin-text-smoke text-sm mb-4 line-clamp-2">
              {agent.description}
            </p>

            {/* Agent Stats */}
            <div className="grid grid-cols-3 gap-4 mb-4 p-3 rounded-lg bg-black/30">
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <Users className="w-4 h-4 admin-text-blue" />
                </div>
                <p className="text-xs admin-text-smoke">Usos</p>
                <p className="font-bold admin-text-blue text-sm">
                  {agent.usageCount.toLocaleString()}
                </p>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <MessageSquare className="w-4 h-4 admin-text-orange" />
                </div>
                <p className="text-xs admin-text-smoke">Tokens Médios</p>
                <p className="font-bold admin-text-orange text-sm">
                  {agent.averageTokens}
                </p>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center mb-1">
                  <Activity className="w-4 h-4 text-green-400" />
                </div>
                <p className="text-xs admin-text-smoke">Último Uso</p>
                <p className="font-bold text-green-400 text-sm">
                  {formatTimeAgo(agent.lastUsed)}
                </p>
              </div>
            </div>

            {/* Agent Prompt Preview */}
            <div className="mb-4">
              <p className="text-xs admin-text-smoke mb-2">Prompt Base:</p>
              <div className="bg-black/30 p-3 rounded-lg">
                <p className="admin-text-smoke text-xs line-clamp-3">
                  {agent.prompt}
                </p>
              </div>
            </div>

            {/* Agent Actions */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button 
                  size="sm" 
                  variant="ghost"
                  onClick={() => setEditingAgent(agent)}
                  className="admin-text-blue hover:bg-blue-500/10"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                
                <Button 
                  size="sm" 
                  variant="ghost"
                  className="admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
                >
                  <Settings className="w-4 h-4" />
                </Button>
                
                <Button 
                  size="sm" 
                  variant="ghost"
                  onClick={() => handleDeleteAgent(agent.id)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${
                  agent.active ? 'bg-green-400' : 'bg-gray-500'
                }`}></div>
                <span className="text-xs admin-text-smoke">
                  {agent.active ? 'Ativo' : 'Inativo'}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Stats Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="admin-card p-6"
      >
        <h2 className="text-xl font-bold admin-text-blue mb-4">
          Resumo dos Agentes
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <p className="text-2xl font-bold admin-text-blue mb-1">
              {agents.length}
            </p>
            <p className="admin-text-smoke text-sm">Total de Agentes</p>
          </div>
          
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400 mb-1">
              {agents.filter(a => a.active).length}
            </p>
            <p className="admin-text-smoke text-sm">Agentes Ativos</p>
          </div>
          
          <div className="text-center">
            <p className="text-2xl font-bold admin-text-orange mb-1">
              {agents.reduce((sum, a) => sum + a.usageCount, 0).toLocaleString()}
            </p>
            <p className="admin-text-smoke text-sm">Total de Usos</p>
          </div>
          
          <div className="text-center">
            <p className="text-2xl font-bold admin-text-blue mb-1">
              {Math.round(agents.reduce((sum, a) => sum + a.averageTokens, 0) / agents.length)}
            </p>
            <p className="admin-text-smoke text-sm">Tokens Médios</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}