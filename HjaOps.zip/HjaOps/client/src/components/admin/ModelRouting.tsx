import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Settings,
  Zap,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  DollarSign,
  BarChart3,
  RefreshCw,
  Play,
  Pause,
  Eye,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { 
  AGENT_ROUTING_MATRIX, 
  PROVIDER_SLA_TARGETS, 
  USER_TIER_POLICIES,
  type Provider,
  type AgentType,
  type UserTier 
} from '@/types/routing';

export default function ModelRouting() {
  const [selectedAgent, setSelectedAgent] = useState<AgentType>('roteirista');
  const [routingMetrics, setRoutingMetrics] = useState<any>(null);
  const [providerHealth, setProviderHealth] = useState<Record<Provider, any>>({});
  const [abTests, setAbTests] = useState<any[]>([]);
  const [costOptimizations, setCostOptimizations] = useState<any[]>([]);

  useEffect(() => {
    loadRoutingData();
    const interval = setInterval(loadRoutingData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadRoutingData = async () => {
    // Mock data - em produção, viria da API
    setRoutingMetrics({
      totalRequests: 1247,
      successfulRoutes: 1198,
      fallbackActivations: 49,
      avgRoutingTime: 12,
      costSavings: 156.78,
      providerDistribution: {
        groq: 45,
        huggingface: 25,
        replit: 20,
        openai: 10
      }
    });

    setProviderHealth({
      groq: { status: 'healthy', latency: 1200, errorRate: 2.1, uptime: 99.8 },
      huggingface: { status: 'degraded', latency: 3200, errorRate: 8.5, uptime: 97.2 },
      replit: { status: 'healthy', latency: 800, errorRate: 1.2, uptime: 99.9 },
      openai: { status: 'healthy', latency: 4500, errorRate: 0.8, uptime: 99.5 }
    });

    setAbTests([
      {
        id: 'test-1',
        name: 'Groq vs OpenAI para Roteirista',
        agentType: 'roteirista',
        status: 'running',
        progress: 68,
        significant: false,
        estimatedCompletion: '3 dias'
      },
      {
        id: 'test-2',
        name: 'DeepSeek R1 Performance',
        agentType: 'data-analyst',
        status: 'completed',
        progress: 100,
        significant: true,
        winner: 'experiment'
      }
    ]);

    setCostOptimizations([
      {
        agent: 'roteirista',
        currentCost: 0.045,
        optimizedCost: 0.032,
        saving: 28.9,
        recommendation: 'Usar Groq Llama 3.1 8B para 80% dos requests'
      },
      {
        agent: 'branding',
        currentCost: 0.038,
        optimizedCost: 0.025,
        saving: 34.2,
        recommendation: 'Migrar para HuggingFace Mistral 7B'
      }
    ]);
  };

  // Configuração do gráfico de distribuição
  const distributionChartOptions: ApexOptions = {
    chart: { type: 'donut', background: 'transparent' },
    theme: { mode: 'dark' },
    labels: ['Groq', 'HuggingFace', 'Replit', 'OpenAI'],
    colors: ['#0055ff', '#ff6a00', '#00ff55', '#ff0055'],
    legend: { 
      position: 'bottom',
      labels: { colors: '#c5d1db' }
    },
    plotOptions: {
      pie: {
        donut: {
          size: '60%',
          labels: {
            show: true,
            total: {
              show: true,
              label: 'Total Requests',
              color: '#c5d1db'
            }
          }
        }
      }
    }
  };

  const distributionSeries = routingMetrics ? [
    routingMetrics.providerDistribution.groq,
    routingMetrics.providerDistribution.huggingface,
    routingMetrics.providerDistribution.replit,
    routingMetrics.providerDistribution.openai
  ] : [];

  const getProviderStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-400';
      case 'degraded': return 'admin-text-orange';
      case 'unhealthy': return 'text-red-400';
      default: return 'admin-text-smoke';
    }
  };

  const getProviderStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'degraded': return <AlertTriangle className="w-4 h-4 admin-text-orange" />;
      case 'unhealthy': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default: return <Clock className="w-4 h-4 admin-text-smoke" />;
    }
  };

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header */}
      <header className="admin-sidebar border-b border-blue-500/20 p-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 admin-bg-blue rounded-2xl flex items-center justify-center admin-glow-blue">
                <Settings className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold admin-text-blue">Model Routing</h1>
                <p className="text-lg admin-text-smoke">Sistema inteligente de roteamento de modelos</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Button variant="outline" className="border-blue-500/20 admin-text-blue">
                <RefreshCw className="w-4 h-4 mr-2" />
                Atualizar
              </Button>
              
              <Badge className="bg-green-500 text-white">
                Sistema Ativo
              </Badge>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-8">
        <div className="max-w-7xl mx-auto">

          {/* Overview Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-500 text-white">+12%</Badge>
              </div>
              
              <div>
                <p className="text-3xl font-bold admin-text-blue">{routingMetrics?.totalRequests || 0}</p>
                <p className="admin-text-smoke text-sm">Requests roteados hoje</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-500 text-white">
                  {routingMetrics ? ((routingMetrics.successfulRoutes / routingMetrics.totalRequests) * 100).toFixed(1) : 0}%
                </Badge>
              </div>
              
              <div>
                <p className="text-3xl font-bold admin-text-orange">{routingMetrics?.fallbackActivations || 0}</p>
                <p className="admin-text-smoke text-sm">Fallbacks ativados</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
              </div>
              
              <div>
                <p className="text-3xl font-bold text-purple-400">{routingMetrics?.avgRoutingTime || 0}ms</p>
                <p className="admin-text-smoke text-sm">Tempo médio de roteamento</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-500 text-white">-23%</Badge>
              </div>
              
              <div>
                <p className="text-3xl font-bold text-green-400">${routingMetrics?.costSavings || 0}</p>
                <p className="admin-text-smoke text-sm">Economia hoje</p>
              </div>
            </motion.div>
          </div>

          <Tabs defaultValue="routing" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-black/30">
              <TabsTrigger value="routing" className="data-[state=active]:admin-text-blue">
                Configuração
              </TabsTrigger>
              <TabsTrigger value="health" className="data-[state=active]:admin-text-blue">
                Saúde Providers
              </TabsTrigger>
              <TabsTrigger value="abtests" className="data-[state=active]:admin-text-blue">
                A/B Tests
              </TabsTrigger>
              <TabsTrigger value="analytics" className="data-[state=active]:admin-text-blue">
                Analytics
              </TabsTrigger>
              <TabsTrigger value="optimization" className="data-[state=active]:admin-text-blue">
                Otimizações
              </TabsTrigger>
            </TabsList>

            {/* Routing Configuration */}
            <TabsContent value="routing">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Agent Selection & Rules */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="admin-card p-6"
                >
                  <h3 className="text-lg font-bold admin-text-blue mb-4">Configuração por Agente</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium admin-text-blue">Selecionar Agente</label>
                      <Select value={selectedAgent} onValueChange={(value) => setSelectedAgent(value as AgentType)}>
                        <SelectTrigger className="bg-black/50 border-blue-500/20 admin-text-smoke">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="roteirista">🎬 Roteirista IA</SelectItem>
                          <SelectItem value="vibe-code">⚡ Vibe Code</SelectItem>
                          <SelectItem value="branding">🎨 Brand Expert</SelectItem>
                          <SelectItem value="youtube">📺 YouTube Analyzer</SelectItem>
                          <SelectItem value="data-analyst">📊 Data Analyst</SelectItem>
                          <SelectItem value="creative-mind">🧠 Creative Mind</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Routing Rules for Selected Agent */}
                    {selectedAgent && AGENT_ROUTING_MATRIX[selectedAgent] && (
                      <div className="space-y-4">
                        <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                          <h4 className="font-semibold admin-text-blue mb-2">Modelo Primário</h4>
                          <div className="flex items-center justify-between">
                            <span className="text-sm admin-text-smoke">
                              {AGENT_ROUTING_MATRIX[selectedAgent].primary.modelId}
                            </span>
                            <Badge className="bg-blue-500 text-white">Primário</Badge>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <h4 className="font-semibold admin-text-blue">Fallbacks</h4>
                          {AGENT_ROUTING_MATRIX[selectedAgent].fallbacks.map((fallback, index) => (
                            <div key={index} className="p-3 rounded-lg bg-black/30 border border-blue-500/10">
                              <div className="flex items-center justify-between">
                                <span className="text-sm admin-text-smoke">{fallback.modelId}</span>
                                <Badge variant="outline" className="border-orange-500/20 text-orange-400">
                                  Prioridade {fallback.priority}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>

                        {AGENT_ROUTING_MATRIX[selectedAgent].premiumOverride && (
                          <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                            <h4 className="font-semibold text-green-400 mb-2">Override Premium</h4>
                            <div className="flex items-center justify-between">
                              <span className="text-sm admin-text-smoke">
                                {AGENT_ROUTING_MATRIX[selectedAgent].premiumOverride?.modelId}
                              </span>
                              <Badge className="bg-green-500 text-white">
                                {AGENT_ROUTING_MATRIX[selectedAgent].premiumOverride?.minTier}+
                              </Badge>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </motion.div>

                {/* Provider Distribution */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="admin-card p-6"
                >
                  <h3 className="text-lg font-bold admin-text-blue mb-4">Distribuição de Providers</h3>
                  
                  {routingMetrics && (
                    <Chart
                      options={distributionChartOptions}
                      series={distributionSeries}
                      type="donut"
                      height={300}
                    />
                  )}

                  <div className="mt-4 space-y-2">
                    {Object.entries(routingMetrics?.providerDistribution || {}).map(([provider, percentage]) => (
                      <div key={provider} className="flex items-center justify-between">
                        <span className="text-sm admin-text-smoke capitalize">{provider}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={percentage as number} className="w-24 h-2" />
                          <span className="text-sm admin-text-blue">{percentage}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            {/* Provider Health */}
            <TabsContent value="health">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(providerHealth).map(([provider, health]) => (
                  <motion.div
                    key={provider}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="admin-card p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-bold admin-text-blue capitalize">{provider}</h3>
                      <div className="flex items-center gap-2">
                        {getProviderStatusIcon(health.status)}
                        <span className={`text-sm font-medium ${getProviderStatusColor(health.status)}`}>
                          {health.status}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm admin-text-smoke">Latência Média</p>
                          <p className="text-2xl font-bold admin-text-blue">{health.latency}ms</p>
                        </div>
                        
                        <div>
                          <p className="text-sm admin-text-smoke">Taxa de Erro</p>
                          <p className="text-2xl font-bold admin-text-orange">{health.errorRate}%</p>
                        </div>
                        
                        <div className="col-span-2">
                          <p className="text-sm admin-text-smoke">Uptime</p>
                          <div className="flex items-center gap-2">
                            <Progress value={health.uptime} className="flex-1 h-2" />
                            <span className="text-sm font-bold text-green-400">{health.uptime}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-blue-500/20 admin-text-blue">
                          <Eye className="w-3 h-3 mr-1" />
                          Detalhes
                        </Button>
                        
                        <Button size="sm" variant="outline" className="border-orange-500/20 text-orange-400">
                          <Settings className="w-3 h-3 mr-1" />
                          Configurar
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* A/B Tests */}
            <TabsContent value="abtests">
              <div className="space-y-6">
                
                {/* A/B Test Creation */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="admin-card p-6"
                >
                  <h3 className="text-lg font-bold admin-text-blue mb-4">Criar Novo A/B Test</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <Select>
                      <SelectTrigger className="bg-black/50 border-blue-500/20">
                        <SelectValue placeholder="Agente" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="roteirista">Roteirista</SelectItem>
                        <SelectItem value="vibe-code">Vibe Code</SelectItem>
                        <SelectItem value="branding">Branding</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger className="bg-black/50 border-blue-500/20">
                        <SelectValue placeholder="Modelo Controle" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="groq-llama-70b">Groq Llama 70B</SelectItem>
                        <SelectItem value="openai-gpt-4o">OpenAI GPT-4o</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger className="bg-black/50 border-blue-500/20">
                        <SelectValue placeholder="Modelo Experimento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="groq-deepseek-r1">Groq DeepSeek R1</SelectItem>
                        <SelectItem value="huggingface-mistral">HF Mistral</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Button className="admin-bg-blue hover:opacity-90">
                      <Play className="w-4 h-4 mr-2" />
                      Iniciar Teste
                    </Button>
                  </div>
                </motion.div>

                {/* Active A/B Tests */}
                <div className="space-y-4">
                  {abTests.map((test) => (
                    <motion.div
                      key={test.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="admin-card p-6"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h4 className="font-bold admin-text-blue">{test.name}</h4>
                          <p className="text-sm admin-text-smoke">Agente: {test.agentType}</p>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <Badge className={`${
                            test.status === 'running' ? 'bg-blue-500' :
                            test.status === 'completed' ? 'bg-green-500' :
                            'bg-gray-500'
                          } text-white`}>
                            {test.status}
                          </Badge>
                          
                          {test.significant && (
                            <Badge className="bg-green-500 text-white">
                              Significativo
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="admin-text-smoke">Progresso</span>
                            <span className="admin-text-blue">{test.progress}%</span>
                          </div>
                          <Progress value={test.progress} className="h-2" />
                        </div>

                        {test.status === 'running' && (
                          <p className="text-sm admin-text-smoke">
                            Conclusão estimada: {test.estimatedCompletion}
                          </p>
                        )}

                        {test.status === 'completed' && test.winner && (
                          <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                            <p className="text-sm text-green-400">
                              🏆 Vencedor: {test.winner === 'experiment' ? 'Modelo Experimento' : 'Modelo Controle'}
                            </p>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="border-blue-500/20 admin-text-blue">
                            <BarChart3 className="w-3 h-3 mr-1" />
                            Resultados
                          </Button>
                          
                          {test.status === 'running' && (
                            <Button size="sm" variant="outline" className="border-orange-500/20 text-orange-400">
                              <Pause className="w-3 h-3 mr-1" />
                              Pausar
                            </Button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Analytics */}
            <TabsContent value="analytics">
              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="admin-card p-6"
                >
                  <h3 className="text-lg font-bold admin-text-blue mb-4">Métricas de Performance</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <p className="text-3xl font-bold admin-text-blue">96.2%</p>
                      <p className="text-sm admin-text-smoke">Taxa de Sucesso</p>
                    </div>
                    
                    <div className="text-center">
                      <p className="text-3xl font-bold admin-text-orange">2.1s</p>
                      <p className="text-sm admin-text-smoke">Latência P95</p>
                    </div>
                    
                    <div className="text-center">
                      <p className="text-3xl font-bold text-green-400">$0.034</p>
                      <p className="text-sm admin-text-smoke">Custo Médio/Request</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            {/* Cost Optimization */}
            <TabsContent value="optimization">
              <div className="space-y-6">
                {costOptimizations.map((opt, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="admin-card p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold admin-text-blue capitalize">{opt.agent}</h4>
                      <Badge className="bg-green-500 text-white">
                        -{opt.saving}% custo
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-sm admin-text-smoke">Custo Atual</p>
                        <p className="text-xl font-bold admin-text-orange">${opt.currentCost}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm admin-text-smoke">Custo Otimizado</p>
                        <p className="text-xl font-bold text-green-400">${opt.optimizedCost}</p>
                      </div>
                      
                      <div>
                        <p className="text-sm admin-text-smoke">Economia Mensal</p>
                        <p className="text-xl font-bold admin-text-blue">
                          ${((opt.currentCost - opt.optimizedCost) * 1000).toFixed(0)}
                        </p>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 mb-4">
                      <p className="text-sm admin-text-blue">💡 {opt.recommendation}</p>
                    </div>

                    <Button className="admin-bg-blue hover:opacity-90">
                      Aplicar Otimização
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}