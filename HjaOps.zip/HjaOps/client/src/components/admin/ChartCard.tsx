import { motion } from 'framer-motion';
import ReactApexChart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';

interface ChartCardProps {
  title: string;
  subtitle?: string;
  type: 'line' | 'bar' | 'area' | 'donut';
  data: any[];
  series: any[];
  height?: number;
  className?: string;
}

export function ChartCard({
  title,
  subtitle,
  type,
  data,
  series,
  height = 300,
  className = ""
}: ChartCardProps) {
  const getChartOptions = (): ApexOptions => {
    const baseOptions: ApexOptions = {
      chart: {
        background: 'transparent',
        foreColor: '#c5d1db',
        toolbar: {
          show: false
        },
        animations: {
          enabled: true,
          speed: 800
        }
      },
      theme: {
        mode: 'dark'
      },
      grid: {
        borderColor: 'rgba(0, 243, 255, 0.1)',
        strokeDashArray: 3
      },
      colors: ['#00f3ff', '#ff6b00', '#c5d1db', '#10b981'],
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          type: 'vertical',
          shadeIntensity: 0.3,
          gradientToColors: ['#ff6b00', '#00f3ff'],
          inverseColors: false,
          opacityFrom: 0.8,
          opacityTo: 0.3,
          stops: [0, 100]
        }
      }
    };

    switch (type) {
      case 'line':
        return {
          ...baseOptions,
          stroke: {
            curve: 'smooth',
            width: 3
          },
          markers: {
            size: 4,
            colors: ['#00f3ff'],
            strokeColors: '#fff',
            strokeWidth: 2,
            hover: {
              size: 6
            }
          },
          xaxis: {
            categories: data,
            axisBorder: {
              show: false
            },
            axisTicks: {
              show: false
            }
          },
          yaxis: {
            labels: {
              formatter: (value) => `${value.toFixed(0)}`
            }
          }
        };

      case 'bar':
        return {
          ...baseOptions,
          plotOptions: {
            bar: {
              borderRadius: 8,
              horizontal: false,
              columnWidth: '60%'
            }
          },
          xaxis: {
            categories: data,
            axisBorder: {
              show: false
            },
            axisTicks: {
              show: false
            }
          },
          yaxis: {
            labels: {
              formatter: (value) => `${value}ms`
            }
          }
        };

      case 'area':
        return {
          ...baseOptions,
          stroke: {
            curve: 'smooth',
            width: 2
          },
          xaxis: {
            categories: data,
            axisBorder: {
              show: false
            },
            axisTicks: {
              show: false
            }
          },
          yaxis: {
            labels: {
              formatter: (value) => `R$ ${value.toFixed(2)}`
            }
          }
        };

      case 'donut':
        return {
          ...baseOptions,
          labels: data,
          plotOptions: {
            pie: {
              donut: {
                size: '70%',
                labels: {
                  show: true,
                  total: {
                    show: true,
                    color: '#c5d1db',
                    fontSize: '16px',
                    fontWeight: 600
                  }
                }
              }
            }
          },
          legend: {
            position: 'bottom',
            horizontalAlign: 'center',
            fontSize: '12px'
          }
        };

      default:
        return baseOptions;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02, y: -5 }}
      transition={{ duration: 0.3 }}
      className={`glass-morphism-strong rounded-3xl p-6 animated-border hover:neon-glow transition-all duration-300 ${className}`}
    >
      <div className="mb-4">
        <h3 className="text-lg font-orbitron font-bold text-white mb-1">
          {title}
        </h3>
        {subtitle && (
          <p className="text-sm text-[var(--smoke)]/70">{subtitle}</p>
        )}
      </div>
      
      <div className="w-full">
        <ReactApexChart
          options={getChartOptions()}
          series={series}
          type={type}
          height={height}
        />
      </div>
    </motion.div>
  );
}