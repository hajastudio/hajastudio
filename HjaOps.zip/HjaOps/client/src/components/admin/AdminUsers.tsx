import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Plus, 
  Minus, 
  Edit, 
  Ban, 
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface User {
  id: string;
  name: string;
  email: string;
  plan: 'free' | 'basic' | 'pro' | 'premium';
  credits: number;
  status: 'active' | 'inactive' | 'blocked';
  lastLogin: Date;
  totalUsage: number;
  joinDate: Date;
}

export default function AdminUsers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<string>('all');

  const [users] = useState<User[]>([
    {
      id: '1',
      name: 'Carlos Silva',
      email: 'carlos@email.com',
      plan: 'pro',
      credits: 2450,
      status: 'active',
      lastLogin: new Date(Date.now() - 2 * 60 * 1000),
      totalUsage: 15420,
      joinDate: new Date('2024-01-15')
    },
    {
      id: '2',
      name: 'Maria Santos',
      email: 'maria@email.com',
      plan: 'basic',
      credits: 89,
      status: 'active',
      lastLogin: new Date(Date.now() - 1 * 60 * 60 * 1000),
      totalUsage: 8750,
      joinDate: new Date('2024-02-20')
    },
    {
      id: '3',
      name: 'João Oliveira',
      email: 'joao@email.com',
      plan: 'premium',
      credits: 8920,
      status: 'active',
      lastLogin: new Date(Date.now() - 3 * 60 * 60 * 1000),
      totalUsage: 42300,
      joinDate: new Date('2023-11-10')
    },
    {
      id: '4',
      name: 'Ana Costa',
      email: 'ana@email.com',
      plan: 'free',
      credits: 15,
      status: 'inactive',
      lastLogin: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      totalUsage: 450,
      joinDate: new Date('2024-03-05')
    },
    {
      id: '5',
      name: 'Pedro Lima',
      email: 'pedro@email.com',
      plan: 'basic',
      credits: 1250,
      status: 'blocked',
      lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      totalUsage: 5200,
      joinDate: new Date('2024-01-30')
    }
  ]);

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'free': return 'bg-gray-500';
      case 'basic': return 'bg-blue-500';
      case 'pro': return 'bg-purple-500';
      case 'premium': return 'admin-bg-orange';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'inactive': return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'blocked': return <AlertCircle className="w-4 h-4 text-red-400" />;
      default: return null;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const diff = Date.now() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return `${days}d atrás`;
  };

  const handleCreditAdjustment = (userId: string, amount: number) => {
    console.log(`Adjusting credits for user ${userId}: ${amount}`);
    // Implementar lógica de ajuste de créditos
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlan = selectedPlan === 'all' || user.plan === selectedPlan;
    return matchesSearch && matchesPlan;
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold admin-text-blue mb-2">
          Gestão de Usuários
        </h1>
        <p className="admin-text-smoke text-lg">
          Controle completo de usuários, créditos e planos
        </p>
      </div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="admin-card p-6"
      >
        <div className="flex flex-col md:flex-row gap-4">
          
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar usuários por nome ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
            />
          </div>

          {/* Plan Filter */}
          <select
            value={selectedPlan}
            onChange={(e) => setSelectedPlan(e.target.value)}
            className="px-4 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke"
          >
            <option value="all">Todos os Planos</option>
            <option value="free">Free</option>
            <option value="basic">Basic</option>
            <option value="pro">Pro</option>
            <option value="premium">Premium</option>
          </select>

          <Button className="admin-bg-blue hover:opacity-90">
            <Filter className="w-4 h-4 mr-2" />
            Filtrar
          </Button>
        </div>
      </motion.div>

      {/* Users Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="admin-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-blue-500/20">
              <tr>
                <th className="text-left p-4 admin-text-blue font-semibold">Usuário</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Plano</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Créditos</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Status</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Último Login</th>
                <th className="text-left p-4 admin-text-blue font-semibold">Uso Total</th>
                <th className="text-center p-4 admin-text-blue font-semibold">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user, index) => (
                <motion.tr
                  key={user.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="border-b border-blue-500/10 hover:bg-blue-500/5"
                >
                  
                  {/* User Info */}
                  <td className="p-4">
                    <div>
                      <p className="font-medium admin-text-blue">{user.name}</p>
                      <p className="text-sm admin-text-smoke">{user.email}</p>
                    </div>
                  </td>

                  {/* Plan */}
                  <td className="p-4">
                    <Badge className={`${getPlanColor(user.plan)} text-white capitalize`}>
                      {user.plan}
                    </Badge>
                  </td>

                  {/* Credits */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${
                        user.credits < 100 ? 'text-red-400' :
                        user.credits < 500 ? 'admin-text-orange' : 'admin-text-blue'
                      }`}>
                        {user.credits.toLocaleString()}
                      </span>
                      {user.credits < 100 && (
                        <AlertCircle className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                  </td>

                  {/* Status */}
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(user.status)}
                      <span className="capitalize admin-text-smoke">{user.status}</span>
                    </div>
                  </td>

                  {/* Last Login */}
                  <td className="p-4">
                    <span className="admin-text-smoke text-sm">
                      {formatTimeAgo(user.lastLogin)}
                    </span>
                  </td>

                  {/* Total Usage */}
                  <td className="p-4">
                    <span className="admin-text-blue font-medium">
                      {user.totalUsage.toLocaleString()}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="p-4">
                    <div className="flex items-center justify-center gap-2">
                      
                      {/* Add Credits */}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCreditAdjustment(user.id, 100)}
                        className="admin-text-blue hover:bg-blue-500/10"
                        title="Adicionar 100 créditos"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>

                      {/* Remove Credits */}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCreditAdjustment(user.id, -100)}
                        className="admin-text-orange hover:bg-orange-500/10"
                        title="Remover 100 créditos"
                      >
                        <Minus className="w-4 h-4" />
                      </Button>

                      {/* Edit User */}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="admin-text-smoke hover:admin-text-blue hover:bg-blue-500/10"
                        title="Editar usuário"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>

                      {/* Block/Unblock User */}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        title={user.status === 'blocked' ? 'Desbloquear usuário' : 'Bloquear usuário'}
                      >
                        <Ban className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-4 border-t border-blue-500/20">
          <div className="flex items-center justify-between">
            <span className="admin-text-smoke text-sm">
              Mostrando {filteredUsers.length} de {users.length} usuários
            </span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Anterior
              </Button>
              <Button size="sm" variant="ghost" className="admin-text-smoke hover:admin-text-blue">
                Próximo
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}