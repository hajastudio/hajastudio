import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Target, Trophy, Star, Flame, Award } from 'lucide-react';

interface GamePanelProps {
  tokens?: number;
  maxTokens?: number;
  level?: number;
  rank?: string;
  dailyMission?: string;
  onTokensUpdate?: (newTokens: number) => void;
}

export function GamePanel({ 
  tokens = 1250, 
  maxTokens = 2000,
  level = 2,
  rank = "Explorador",
  dailyMission = "Complete 5 conversas com agentes diferentes",
  onTokensUpdate 
}: GamePanelProps) {
  const [animatedTokens, setAnimatedTokens] = useState(tokens);
  const [showTokenGain, setShowTokenGain] = useState(false);
  const [missionProgress, setMissionProgress] = useState(2); // 2/5 conversas
  const [streakDays, setStreakDays] = useState(7);

  // Simular ganho de tokens
  const gainTokens = (amount: number) => {
    setAnimatedTokens(prev => prev + amount);
    setShowTokenGain(true);
    onTokensUpdate?.(animatedTokens + amount);
    
    setTimeout(() => setShowTokenGain(false), 2000);
  };

  // Calcular porcentagem de progresso
  const tokenPercentage = (animatedTokens / maxTokens) * 100;
  const missionPercentage = (missionProgress / 5) * 100;

  // Configuração do rank
  const getRankConfig = (rank: string) => {
    const configs = {
      'Iniciante': { icon: Star, color: 'var(--smoke)', emoji: '⭐' },
      'Explorador': { icon: Target, color: 'var(--blue)', emoji: '🔹' },
      'Especialista': { icon: Flame, color: 'var(--orange)', emoji: '🔥' },
      'Mestre': { icon: Trophy, color: '#ffd700', emoji: '👑' },
      'Lenda': { icon: Award, color: '#ff6b00', emoji: '💎' }
    };
    return configs[rank as keyof typeof configs] || configs.Explorador;
  };

  const rankConfig = getRankConfig(rank);
  const RankIcon = rankConfig.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-morphism-strong rounded-3xl p-6 relative overflow-hidden shadow-2xl animated-border"
    >
      {/* Background Glow Effect */}
      <div className="absolute inset-0 gradient-bg pointer-events-none" />

      {/* Token Gain Animation */}
      <AnimatePresence>
        {showTokenGain && (
          <motion.div
            initial={{ opacity: 0, y: 0, scale: 1 }}
            animate={{ opacity: 1, y: -50, scale: 1.2 }}
            exit={{ opacity: 0, y: -100, scale: 0.8 }}
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10"
          >
            <div className="bg-[var(--orange)] text-black px-4 py-2 rounded-full font-bold text-lg neon-glow">
              +50 tokens! ⚡
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 relative z-10">
        
        {/* Tokens Section */}
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-[var(--blue)] to-blue-600 shadow-lg mb-4 neon-glow">
            <Zap className="w-8 h-8 text-white" />
            <div className="absolute inset-0 rounded-full border-4 border-[var(--blue)]/30 animate-pulse"></div>
          </div>
          <h3 className="text-2xl font-bold text-white mb-1 font-orbitron">{animatedTokens.toLocaleString()}</h3>
          <p className="text-[var(--smoke)]/70 text-sm">Tokens Restantes</p>

          {/* Token Actions */}
          <motion.button
            onClick={() => gainTokens(50)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="
              px-4 py-2 bg-[var(--blue)]/20 border border-[var(--blue)]/40 
              rounded-xl text-[var(--blue)] text-sm font-medium
              hover:bg-[var(--blue)]/30 transition-all duration-200
              neon-glow
            "
            data-testid="gain-tokens-button"
          >
            <Zap size={16} className="inline mr-2" />
            Ganhar Tokens
          </motion.button>
        </div>

        {/* Rank & Level Section */}
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg mb-4 neon-glow-orange">
            <Trophy className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-1 font-orbitron">{rank}</h3>
          <div className="flex items-center justify-center gap-2">
            <Star className="w-4 h-4 text-yellow-400" />
            <span className="text-[var(--smoke)]/70 text-sm">Nível {level}</span>
          </div>
        </div>

        {/* Daily Mission Section */}
        <div className="text-center">
          <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-[var(--orange)] to-red-600 shadow-lg mb-4 neon-glow-orange">
            <Target className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-1 font-orbitron">Missão Diária</h3>
          <p className="text-[var(--smoke)]/70 text-sm">Criar 3 vídeos</p>
          <div className="mt-3">
            <div className="w-full h-3 bg-black/60 rounded-full overflow-hidden border border-[var(--orange)]/30">
              <motion.div
                className="h-full bg-gradient-to-r from-[var(--orange)] to-red-600 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${missionPercentage}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                style={{
                  boxShadow: '0 0 10px var(--orange)',
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-[var(--smoke)]/60 mt-1">
              <span>Progresso</span>
              <span>{missionProgress}/5</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Stats */}
      <div className="mt-6 pt-4 border-t border-[var(--blue)]/20">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-bold text-[var(--blue)]">47</div>
            <div className="text-xs text-[var(--smoke)]/60">Conversas Hoje</div>
          </div>
          <div>
            <div className="text-lg font-bold text-[var(--orange)]">12</div>
            <div className="text-xs text-[var(--smoke)]/60">Agentes Usados</div>
          </div>
          <div>
            <div className="text-lg font-bold text-[var(--blue)]">3.2k</div>
            <div className="text-xs text-[var(--smoke)]/60">Tokens Gastos</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}