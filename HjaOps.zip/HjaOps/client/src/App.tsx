import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { ThemeProvider } from "@/components/lumiere/ThemeProvider";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Chat from "@/pages/Chat";
import { Dashboard } from "@/pages/Dashboard";
import UserDashboard from "@/pages/UserDashboard";
import HajaVersoDashboard from "@/pages/HajaVersoDashboard";
import HajaVerso from "@/pages/HajaVerso";
import Admin from "@/pages/Admin";
import AdminNew from "@/pages/AdminNew";
import AdminDashboard from "@/pages/AdminDashboard";
import TokenManagement from "@/pages/TokenManagement";
import TechWatch from "@/pages/TechWatch";
import ChatDemo from "@/pages/ChatDemo";
import BuyCredits from "@/pages/BuyCredits";
import MyCredits from "@/pages/MyCredits";
import Checkout from "@/pages/Checkout";
import CheckoutSuccess from "@/pages/CheckoutSuccess";
import TransactionHistory from "@/pages/TransactionHistory";
import Vitrine from "@/pages/Vitrine";
import Blog from "@/pages/Blog";
import BlogPost from "@/pages/BlogPost";
import ModelRouting from "@/components/admin/ModelRouting";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={HajaVersoDashboard} />
          <Route path="/home" component={Home} />
          <Route path="/chat" component={Chat} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/user-dashboard" component={UserDashboard} />
          <Route path="/haja-verso" component={HajaVerso} />
          <Route path="/token-management" component={TokenManagement} />
          <Route path="/techwatch" component={TechWatch} />
          <Route path="/chat-demo" component={ChatDemo} />
          <Route path="/buy-credits" component={BuyCredits} />
          <Route path="/my-credits" component={MyCredits} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/checkout/success" component={CheckoutSuccess} />
          <Route path="/checkout/failure" component={CheckoutSuccess} />
          <Route path="/checkout/pending" component={CheckoutSuccess} />
          <Route path="/transactions" component={TransactionHistory} />
          <Route path="/vitrine" component={Vitrine} />
          <Route path="/blog" component={Blog} />
          <Route path="/blog/:slug" component={BlogPost} />
          {(user as any)?.role === 'admin' && (
            <>
              <Route path="/admin" component={Admin} />
              <Route path="/admin-new" component={AdminNew} />
              <Route path="/admin-dashboard" component={AdminDashboard} />
              <Route path="/model-routing" component={ModelRouting} />
            </>
          )}
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
