import { useState } from 'react';
import { Topbar } from '../components/Topbar';
import { ChatWindow } from '../components/ChatWindow';
import { GamePanel } from '../components/GamePanel';
import { AgentCard } from '../components/AgentCard';
import { 
  Sparkles, 
  Code, 
  Video, 
  Users, 
  Shield, 
  Palette,
  TrendingUp,
  BookOpen
} from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  category: string;
  specialty: string[];
  tokensUsed: number;
}

const availableAgents: Agent[] = [
  {
    id: 'creative-writer',
    name: 'Roteirista Viral',
    description: 'Especialista em criar roteiros virais para TikTok, Instagram e YouTube com técnicas de storytelling avançadas.',
    icon: Video,
    category: 'Criação',
    specialty: ['Roteiros Virais', 'Storytelling', 'Hooks Persuasivos', 'Trending Topics'],
    tokensUsed: 1240
  },
  {
    id: 'code-assistant',
    name: 'Dev Expert',
    description: 'Desenvolvedor sênior especializado em React, Python, APIs e arquitetura de software moderna.',
    icon: Code,
    category: 'Desenvolvimento',
    specialty: ['React/Next.js', 'Python/FastAPI', 'Arquitetura', 'DevOps'],
    tokensUsed: 890
  },
  {
    id: 'design-pro',
    name: 'Design Master',
    description: 'Designer UX/UI especialista em interfaces modernas, sistemas de design e prototipagem avançada.',
    icon: Palette,
    category: 'Design',
    specialty: ['UX/UI Design', 'Figma', 'Design Systems', 'Prototyping'],
    tokensUsed: 567
  },
  {
    id: 'marketing-guru',
    name: 'Growth Hacker',
    description: 'Especialista em marketing digital, growth hacking e estratégias de conversão para startups.',
    icon: TrendingUp,
    category: 'Marketing',
    specialty: ['Growth Hacking', 'Ads Facebook/Google', 'Funnel Marketing', 'Analytics'],
    tokensUsed: 1120
  },
  {
    id: 'community-manager',
    name: 'Community Pro',
    description: 'Gestor de comunidades expert em engajamento, moderação e construção de audiências fiéis.',
    icon: Users,
    category: 'Comunidade',
    specialty: ['Engajamento', 'Moderação', 'Eventos Online', 'Discord/Telegram'],
    tokensUsed: 340
  },
  {
    id: 'research-analyst',
    name: 'Research Bot',
    description: 'Analista de pesquisas especializado em coleta de dados, relatórios e insights de mercado.',
    icon: BookOpen,
    category: 'Pesquisa',
    specialty: ['Market Research', 'Data Analysis', 'Relatórios', 'Trends'],
    tokensUsed: 780
  }
];

export function Dashboard() {
  const [activeAgent, setActiveAgent] = useState<Agent | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [tokens, setTokens] = useState(1250);

  // Mock user data
  const user = {
    name: 'João Silva',
    email: 'joao@hjaps.com',
    plan: 'pro',
    credits: tokens,
    maxCredits: 2000,
    avatar: ''
  };

  const handleAgentActivate = (agentId: string) => {
    const agent = availableAgents.find(a => a.id === agentId);
    setActiveAgent(agent || null);
  };

  const handleTokensUpdate = (newTokens: number) => {
    setTokens(newTokens);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-black text-[var(--smoke)] relative overflow-hidden">
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-blue-900/20"></div>
      
      {/* Topbar */}
      <Topbar 
        user={user}
        onMenuToggle={toggleMobileMenu}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Main Content */}
      <main className="pt-16 min-h-screen relative z-10">
        <div className="max-w-7xl mx-auto p-6 space-y-8">
          
          {/* Section 1: Chat Multi-Agente */}
          <section>
            <div className="mb-6">
              <h2 className="text-3xl font-orbitron font-bold text-white mb-2 text-gradient">
                Chat Multi-Agente
              </h2>
              <p className="text-[var(--smoke)]/80">
                Converse com agentes especializados ou escolha um da seção abaixo
              </p>
            </div>
            
            <div className="h-[600px]">
              <ChatWindow 
                activeAgent={activeAgent}
                onAgentSelect={handleAgentActivate}
              />
            </div>
          </section>

          {/* Section 2: Gamificação */}
          <section>
            <div className="mb-6">
              <h2 className="text-3xl font-orbitron font-bold text-white mb-2 text-gradient">
                Painel de Gamificação
              </h2>
              <p className="text-[var(--smoke)]/80">
                Acompanhe seu progresso, tokens e conquistas
              </p>
            </div>
            
            <GamePanel 
              tokens={tokens}
              maxTokens={2000}
              level={2}
              rank="Explorador"
              dailyMission="Complete 5 conversas com agentes diferentes"
              onTokensUpdate={handleTokensUpdate}
            />
          </section>

          {/* Section 3: Agentes Inteligentes */}
          <section>
            <div className="mb-6">
              <h2 className="text-3xl font-orbitron font-bold text-white mb-2 text-gradient">
                Agentes Inteligentes
              </h2>
              <p className="text-[var(--smoke)]/80">
                Escolha um agente especializado para otimizar suas conversas
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {availableAgents.map((agent) => (
                <AgentCard
                  key={agent.id}
                  id={agent.id}
                  name={agent.name}
                  description={agent.description}
                  icon={agent.icon}
                  category={agent.category}
                  specialty={agent.specialty}
                  tokensUsed={agent.tokensUsed}
                  isActive={activeAgent?.id === agent.id}
                  onActivate={handleAgentActivate}
                />
              ))}
            </div>
          </section>

          {/* Footer */}
          <footer className="text-center py-8 border-t border-[var(--blue)]/20 glass-morphism rounded-t-3xl mt-8">
            <p className="text-[var(--smoke)]/70 text-sm">
              ⚡ Powered by <span className="font-orbitron font-bold text-gradient">Hja²Ops Core</span> 
              - AI-Powered Creative Suite
            </p>
          </footer>
        </div>
      </main>
    </div>
  );
}