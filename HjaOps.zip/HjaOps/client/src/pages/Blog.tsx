import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Clock, Eye, Star, CreditCard } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import type { Post } from "@shared/schema";

export default function Blog() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts, isLoading } = useQuery({
    queryKey: ["/api/posts"],
  });

  const [selectedPost, setSelectedPost] = useState<string | null>(null);

  const { data: postContent, isLoading: isLoadingPost } = useQuery({
    queryKey: ["/api/posts", selectedPost],
    enabled: !!selectedPost,
  });

  const unlockMutation = useMutation({
    mutationFn: async (postId: string) => {
      const response = await fetch(`/api/posts/${postId}/unlock`, {
        method: 'POST',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Post desbloqueado!",
        description: "Você pode agora ler o conteúdo completo.",
      });
      // Invalidate and refetch the post content
      queryClient.invalidateQueries({ queryKey: ["/api/posts", selectedPost] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao desbloquear",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };

  const getLevelBadgeColor = (level: string) => {
    switch (level) {
      case 'free': return 'bg-green-600 text-white';
      case 'pro': return 'bg-blue-600 text-white';
      case 'vip': return 'bg-purple-600 text-white';
      case 'token-5': return 'bg-orange-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getLevelText = (level: string) => {
    switch (level) {
      case 'free': return 'Grátis';
      case 'pro': return 'Pro';
      case 'vip': return 'VIP';
      case 'token-5': return '5 Créditos';
      default: return level;
    }
  };

  const PostCard = ({ post }: { post: Post }) => (
    <Card className="group cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-xl bg-black/20 border-cyan-500/30 backdrop-blur-sm"
          onClick={() => setSelectedPost(post.slug)}
          data-testid={`card-post-${post.id}`}>
      <div className="p-0">
        {/* Cover Image */}
        {post.coverImage && (
          <div className="relative overflow-hidden rounded-t-lg">
            <img 
              src={post.coverImage} 
              alt={post.title}
              className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
              data-testid={`img-cover-${post.id}`}
            />
            <Badge className={`absolute top-2 right-2 ${getLevelBadgeColor(post.requiredLevel)} border-0`}
                   data-testid={`badge-level-${post.id}`}>
              {post.requiredLevel === 'token-5' ? (
                <CreditCard className="w-3 h-3 mr-1" />
              ) : post.requiredLevel !== 'free' ? (
                <Star className="w-3 h-3 mr-1" />
              ) : null}
              {getLevelText(post.requiredLevel)}
            </Badge>
          </div>
        )}

        {/* Content */}
        <div className="p-6 space-y-4">
          <h2 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors line-clamp-2"
              data-testid={`text-title-${post.id}`}>
            {post.title}
          </h2>
          
          <p className="text-gray-300 text-sm line-clamp-3"
             data-testid={`text-excerpt-${post.id}`}>
            {post.excerpt}
          </p>

          {/* Meta Info */}
          <div className="flex items-center justify-between text-sm text-gray-400">
            <div className="flex items-center space-x-4">
              <div className="flex items-center"
                   data-testid={`text-read-time-${post.id}`}>
                <Clock className="w-4 h-4 mr-1" />
                {post.readTime} min
              </div>
              <div className="flex items-center"
                   data-testid={`text-views-${post.id}`}>
                <Eye className="w-4 h-4 mr-1" />
                {post.views} views
              </div>
            </div>
            <span data-testid={`text-date-${post.id}`}>
              {formatDate(post.publishedAt?.toString() || post.createdAt?.toString())}
            </span>
          </div>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {post.tags.slice(0, 3).map((tag, index) => (
                <Badge 
                  key={index}
                  variant="outline" 
                  className="text-xs border-gray-600 text-gray-300"
                  data-testid={`badge-tag-${post.id}-${index}`}>
                  {tag}
                </Badge>
              ))}
              {post.tags.length > 3 && (
                <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                  +{post.tags.length - 3}
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
    </Card>
  );

  const PostModal = () => {
    if (!selectedPost || !postContent) return null;

    const canUnlock = (postContent as any).requiresUnlock && isAuthenticated;
    const needsLogin = (postContent as any).loginRequired;

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-start justify-center p-4 overflow-y-auto"
           onClick={(e) => e.target === e.currentTarget && setSelectedPost(null)}>
        <div className="bg-gray-900 border border-cyan-500/30 rounded-xl max-w-4xl w-full my-8 shadow-2xl">
          {/* Header */}
          <div className="p-6 border-b border-gray-700">
            <div className="flex items-start justify-between">
              <div className="space-y-2 flex-1">
                <h1 className="text-3xl font-bold text-white"
                    data-testid="text-modal-title">
                  {(postContent as any).title}
                </h1>
                <div className="flex items-center space-x-4 text-sm text-gray-400">
                  <span data-testid="text-modal-date">
                    {formatDate((postContent as any).publishedAt || (postContent as any).createdAt)}
                  </span>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {(postContent as any).readTime} min
                  </div>
                  <div className="flex items-center">
                    <Eye className="w-4 h-4 mr-1" />
                    {(postContent as any).views} views
                  </div>
                </div>
              </div>
              <Button
                variant="ghost"
                onClick={() => setSelectedPost(null)}
                className="text-gray-400 hover:text-white"
                data-testid="button-close-modal">
                ✕
              </Button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {(postContent as any).coverImage && (
              <img 
                src={(postContent as any).coverImage} 
                alt={(postContent as any).title}
                className="w-full h-64 object-cover rounded-lg mb-6"
                data-testid="img-modal-cover"
              />
            )}

            <div className="prose prose-invert max-w-none">
              <div 
                className="text-gray-300 leading-relaxed"
                dangerouslySetInnerHTML={{ __html: (postContent as any).content }}
                data-testid="text-modal-content"
              />
            </div>

            {/* Paywall */}
            {(postContent as any).locked && (
              <div className="mt-8 text-center">
                <div className="bg-black/40 backdrop-blur-sm border border-orange-500/30 rounded-xl p-8 space-y-4">
                  <Lock className="w-12 h-12 mx-auto text-orange-500" />
                  <h3 className="text-2xl font-bold text-white">
                    Conteúdo Premium
                  </h3>
                  <p className="text-gray-300 max-w-md mx-auto">
                    Este artigo contém {(postContent as any).fullContentLength - (postContent as any).excerptLength} caracteres adicionais de conteúdo exclusivo.
                  </p>
                  
                  {needsLogin && (
                    <div className="space-y-3">
                      <p className="text-orange-400 font-medium">
                        Faça login para continuar lendo
                      </p>
                      <Button 
                        onClick={() => window.location.href = '/api/login'}
                        className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white border-0"
                        data-testid="button-login">
                        Fazer Login
                      </Button>
                    </div>
                  )}

                  {canUnlock && (
                    <div className="space-y-3">
                      <p className="text-orange-400 font-medium">
                        Desbloqueie por apenas 5 créditos
                      </p>
                      <p className="text-sm text-gray-400">
                        Você tem {(user as any)?.credits || 0} créditos disponíveis
                      </p>
                      <Button 
                        onClick={() => unlockMutation.mutate(selectedPost)}
                        disabled={unlockMutation.isPending || ((user as any)?.credits || 0) < 5}
                        className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white border-0"
                        data-testid="button-unlock">
                        <CreditCard className="w-4 h-4 mr-2" />
                        {unlockMutation.isPending ? "Desbloqueando..." : "Desbloquear por 5 créditos"}
                      </Button>
                    </div>
                  )}

                  {isAuthenticated && !canUnlock && (postContent as any).requiresUnlock && (
                    <div className="space-y-3">
                      <p className="text-red-400 font-medium">
                        Créditos insuficientes
                      </p>
                      <p className="text-sm text-gray-400">
                        Você precisa de 5 créditos para desbloquear este post
                      </p>
                      <Button 
                        onClick={() => setSelectedPost(null)}
                        className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white border-0"
                        data-testid="button-buy-credits">
                        Comprar Créditos
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <div className="h-12 bg-gray-700 rounded-lg animate-pulse mx-auto max-w-md"></div>
            <div className="h-6 bg-gray-700 rounded-lg animate-pulse mx-auto max-w-2xl"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-80 bg-gray-700 rounded-lg animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center space-y-4 mb-12">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent"
                data-testid="text-blog-title">
              📝 Blog & Newsletter
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto"
               data-testid="text-blog-description">
              Conteúdo exclusivo sobre IA, tecnologia e inovação. 
              Alguns artigos são premium e podem ser desbloqueados com créditos.
            </p>
          </div>

          {/* Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(posts as Post[])?.map((post: Post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>

          {/* Empty State */}
          {(posts as Post[])?.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="text-2xl font-bold text-white mb-2">
                Nenhum post publicado ainda
              </h3>
              <p className="text-gray-400">
                Em breve teremos conteúdo incrível para você!
              </p>
            </div>
          )}

          {/* Access Levels Info */}
          <div className="mt-16">
            <div className="bg-black/40 backdrop-blur-sm border border-cyan-500/30 rounded-xl p-6 max-w-4xl mx-auto">
              <h3 className="text-xl font-bold text-cyan-400 mb-4 text-center">
                💎 Níveis de Acesso
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <Badge className="bg-green-600 text-white mb-2">Grátis</Badge>
                  <p className="text-sm text-gray-300">Acesso livre para todos</p>
                </div>
                <div className="text-center">
                  <Badge className="bg-blue-600 text-white mb-2">Pro</Badge>
                  <p className="text-sm text-gray-300">Conteúdo para assinantes Pro</p>
                </div>
                <div className="text-center">
                  <Badge className="bg-purple-600 text-white mb-2">VIP</Badge>
                  <p className="text-sm text-gray-300">Conteúdo exclusivo VIP</p>
                </div>
                <div className="text-center">
                  <Badge className="bg-orange-600 text-white mb-2">5 Créditos</Badge>
                  <p className="text-sm text-gray-300">Pay-per-read premium</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Post Modal */}
      {selectedPost && (
        <>
          {isLoadingPost ? (
            <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
              <div className="text-white">Carregando...</div>
            </div>
          ) : (
            <PostModal />
          )}
        </>
      )}
    </>
  );
}