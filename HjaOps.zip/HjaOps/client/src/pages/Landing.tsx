import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import LoginModal from '@/components/LoginModal';
import ContextHelpButton from '@/components/ContextHelpButton';
import { completeMagicLinkSignIn } from '@/lib/firebase';
import { useToast } from '@/hooks/use-toast';

export default function Landing() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const { toast } = useToast();

  // Handle magic link signin on page load
  useEffect(() => {
    const handleMagicLink = async () => {
      try {
        const result = await completeMagicLinkSignIn();
        if (result) {
          toast({
            title: "Login realizado com sucesso!",
            description: "Redirecionando para a plataforma...",
          });
          setTimeout(() => {
            window.location.href = '/';
          }, 1000);
        }
      } catch (error: any) {
        toast({
          title: "Erro no login",
          description: error.message || "Tente novamente",
          variant: "destructive",
        });
      }
    };

    handleMagicLink();
  }, [toast]);

  return (
    <div className="min-h-screen bg-black text-white">
      
      {/* Modern Dashboard-style Layout */}
      <div className="flex h-screen">
        
        {/* Sidebar Navigation */}
        <motion.aside 
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-72 bg-gradient-to-b from-black/90 to-black/70 backdrop-blur-xl border-r border-white/10"
        >
          <div className="p-8">
            {/* Logo */}
            <div className="flex items-center gap-4 mb-12">
              <div className="w-12 h-12 bg-gradient-to-br from-[#0055ff] to-[#007bff] rounded-2xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-xl">H</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                  Hja²Ops
                </h1>
                <p className="text-sm text-gray-400">AI Multi-Agent Platform</p>
              </div>
            </div>

            {/* Navigation Menu */}
            <nav className="space-y-2">
              {[
                { icon: "fas fa-home", label: "Home", active: true },
                { icon: "fas fa-robot", label: "AI Agents" },
                { icon: "fas fa-comments", label: "Chat Interface" },
                { icon: "fas fa-chart-bar", label: "Analytics" },
                { icon: "fas fa-credit-card", label: "Credits" },
                { icon: "fas fa-cog", label: "Settings" }
              ].map((item, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * index, duration: 0.4 }}
                  className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-300 group ${
                    item.active 
                      ? 'bg-gradient-to-r from-[#0055ff]/20 to-[#007bff]/20 border border-[#0055ff]/30 text-white shadow-lg' 
                      : 'hover:bg-white/5 text-gray-400 hover:text-white'
                  }`}
                >
                  <i className={`${item.icon} w-5`}></i>
                  <span className="font-medium">{item.label}</span>
                  {item.active && (
                    <div className="w-2 h-2 bg-[#0055ff] rounded-full ml-auto animate-pulse"></div>
                  )}
                </motion.button>
              ))}
            </nav>

            {/* Bottom CTA */}
            <div className="mt-12">
              <div className="bg-gradient-to-br from-[#ff6a00]/10 to-[#ff8533]/10 border border-[#ff6a00]/20 rounded-2xl p-6 backdrop-blur-sm">
                <h3 className="font-bold text-white mb-2">Ready to Start?</h3>
                <p className="text-sm text-gray-400 mb-4">
                  Get full access to all AI agents
                </p>
                <Button
                  onClick={() => setIsLoginModalOpen(true)}
                  className="w-full bg-gradient-to-r from-[#ff6a00] to-[#ff8533] hover:from-[#ff7a10] hover:to-[#ff9543] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                  data-testid="sidebar-get-started"
                >
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </motion.aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          
          {/* Top Header */}
          <motion.header 
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="sticky top-0 z-10 bg-black/80 backdrop-blur-xl border-b border-white/10"
          >
            <div className="px-8 py-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
                    Welcome to the Future of AI
                  </h2>
                  <p className="text-gray-400 mt-1">
                    Professional AI Multi-Agent Platform
                  </p>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 bg-white/5 rounded-xl px-4 py-2 border border-white/10">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-gray-300">Online</span>
                  </div>
                  <Button
                    onClick={() => setIsLoginModalOpen(true)}
                    className="bg-gradient-to-r from-[#0055ff] to-[#007bff] hover:from-[#0066ff] hover:to-[#0088ff] text-white px-6 py-2 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                    data-testid="header-login"
                  >
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    Login
                  </Button>
                </div>
              </div>
            </div>
          </motion.header>

          {/* Dashboard Content */}
          <div className="p-8">
            
            {/* Stats Cards */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
            >
              {[
                { 
                  title: "Active Users", 
                  value: "12,547", 
                  growth: "+23%", 
                  icon: "fas fa-users",
                  color: "#0055ff"
                },
                { 
                  title: "AI Interactions", 
                  value: "2.4M", 
                  growth: "+48%", 
                  icon: "fas fa-robot",
                  color: "#ff6a00"
                },
                { 
                  title: "Success Rate", 
                  value: "99.8%", 
                  growth: "+2.1%", 
                  icon: "fas fa-check-circle",
                  color: "#10b981"
                }
              ].map((stat, index) => (
                <div 
                  key={index}
                  className="professional-card bg-gradient-to-br from-white/5 to-white/2 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all duration-300"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${stat.color}15` }}
                    >
                      <i className={`${stat.icon} text-xl`} style={{ color: stat.color }}></i>
                    </div>
                    <span 
                      className="text-sm font-semibold px-2 py-1 rounded-lg"
                      style={{ backgroundColor: `${stat.color}20`, color: stat.color }}
                    >
                      {stat.growth}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
                  <p className="text-gray-400 text-sm">{stat.title}</p>
                </div>
              ))}
            </motion.div>

            {/* Main Feature Cards */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8"
            >
              
              {/* AI Agents Card */}
              <div className="professional-card bg-gradient-to-br from-[#0055ff]/10 to-[#007bff]/5 backdrop-blur-xl border border-[#0055ff]/20 rounded-3xl p-8 hover:border-[#0055ff]/40 transition-all duration-500">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#0055ff] to-[#007bff] rounded-2xl flex items-center justify-center shadow-lg">
                    <i className="fas fa-robot text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">AI Multi-Agent System</h3>
                    <p className="text-gray-400">3 Specialized Agents Ready</p>
                  </div>
                </div>
                
                <div className="space-y-4 mb-6">
                  {[
                    { name: "Roteirista", desc: "Content & Script Creation", status: "active" },
                    { name: "Vibe Code", desc: "Technical Development", status: "active" },
                    { name: "Agente Viral", desc: "Marketing & Growth", status: "active" }
                  ].map((agent, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-white/5 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-[#0055ff]/20 rounded-lg flex items-center justify-center">
                          <i className="fas fa-brain text-[#0055ff] text-sm"></i>
                        </div>
                        <div>
                          <p className="text-white font-medium">{agent.name}</p>
                          <p className="text-gray-400 text-sm">{agent.desc}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-green-400 text-sm">Active</span>
                      </div>
                    </div>
                  ))}
                </div>

                <Button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="w-full bg-gradient-to-r from-[#0055ff] to-[#007bff] hover:from-[#0066ff] hover:to-[#0088ff] text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                  data-testid="agents-card-cta"
                >
                  <i className="fas fa-play mr-2"></i>
                  Start Conversation
                </Button>
              </div>

              {/* Analytics Card */}
              <div className="professional-card bg-gradient-to-br from-[#ff6a00]/10 to-[#ff8533]/5 backdrop-blur-xl border border-[#ff6a00]/20 rounded-3xl p-8 hover:border-[#ff6a00]/40 transition-all duration-500">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#ff6a00] to-[#ff8533] rounded-2xl flex items-center justify-center shadow-lg">
                    <i className="fas fa-chart-line text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Advanced Analytics</h3>
                    <p className="text-gray-400">Real-time Insights</p>
                  </div>
                </div>

                {/* Mock Chart */}
                <div className="h-48 bg-white/5 rounded-2xl p-6 mb-6 flex items-end gap-2">
                  {[65, 45, 78, 52, 89, 67, 91, 58, 76, 82, 69, 94].map((height, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ height: 0 }}
                      animate={{ height: `${height}%` }}
                      transition={{ delay: 0.8 + idx * 0.1, duration: 0.6, ease: "easeOut" }}
                      className="flex-1 bg-gradient-to-t from-[#ff6a00] to-[#ff8533] rounded-t-lg opacity-80"
                    />
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">847K</p>
                    <p className="text-gray-400 text-sm">Total Queries</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-white">23ms</p>
                    <p className="text-gray-400 text-sm">Avg Response</p>
                  </div>
                </div>

                <Button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="w-full bg-gradient-to-r from-[#ff6a00] to-[#ff8533] hover:from-[#ff7a10] hover:to-[#ff9543] text-white font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                  data-testid="analytics-card-cta"
                >
                  <i className="fas fa-eye mr-2"></i>
                  View Dashboard
                </Button>
              </div>
            </motion.div>

            {/* Bottom CTA Section */}
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.8 }}
              className="text-center bg-gradient-to-r from-black/40 to-black/20 backdrop-blur-xl border border-white/10 rounded-3xl p-12"
            >
              <h2 className="text-4xl font-bold bg-gradient-to-r from-white via-[#0055ff] to-[#ff6a00] bg-clip-text text-transparent mb-4">
                Ready to Transform Your Workflow?
              </h2>
              <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
                Join thousands of professionals using our AI Multi-Agent Platform to accelerate their productivity and unlock new possibilities.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button 
                  onClick={() => setIsLoginModalOpen(true)}
                  size="lg"
                  className="bg-gradient-to-r from-[#ff6a00] to-[#ff8533] hover:from-[#ff7a10] hover:to-[#ff9543] text-white font-bold px-8 py-4 rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105"
                  data-testid="main-cta"
                >
                  <i className="fas fa-rocket mr-3"></i>
                  Start Free Trial
                </Button>
                <Button 
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10 px-8 py-4 rounded-2xl transition-all duration-300"
                >
                  <i className="fas fa-play mr-3"></i>
                  Watch Demo
                </Button>
              </div>

              <div className="flex items-center justify-center gap-8 mt-8 text-sm text-gray-400">
                <span className="flex items-center gap-2">
                  <i className="fas fa-check text-green-500"></i>
                  No credit card required
                </span>
                <span className="flex items-center gap-2">
                  <i className="fas fa-check text-green-500"></i>
                  Full access trial
                </span>
                <span className="flex items-center gap-2">
                  <i className="fas fa-check text-green-500"></i>
                  Cancel anytime
                </span>
              </div>
            </motion.div>

          </div>
        </main>
      </div>

      {/* Login Modal */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />

      {/* Context Help Button */}
      <ContextHelpButton 
        context="general" 
        position="bottom-right"
      />
    </div>
  );
}
