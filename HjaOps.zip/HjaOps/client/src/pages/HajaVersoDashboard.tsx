import MainDashboard from '@/components/layout/MainDashboard';

export default function HajaVersoDashboard() {
  return <MainDashboard />;
}