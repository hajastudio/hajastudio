import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { 
  ArrowRight, 
  Brain, 
  Shield,
  Clock,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Layout from '@/components/layout/Layout';

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, ease: 'easeOut' }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.2
    }
  }
};

export default function Home() {

  const benefits = [
    {
      icon: Brain,
      title: 'Specialized AI Agents',
      description: 'Access multiple AI agents, each trained for specific tasks and domains'
    },
    {
      icon: Shield,
      title: 'Enterprise Security',
      description: 'Your data protected with end-to-end encryption and privacy guarantees'
    },
    {
      icon: Clock,
      title: 'Lightning Fast',
      description: 'Optimized processing for responses in seconds, not minutes'
    },
    {
      icon: BarChart3,
      title: 'Smart Analytics',
      description: 'Track usage, optimize costs, and improve performance with detailed insights'
    }
  ];


  return (
    <Layout showNavbar={true}>
      <div className="bg-hv-black min-h-screen">
        
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <motion.div 
              className="absolute top-1/4 left-1/4 w-96 h-96 bg-hv-blue/10 rounded-full blur-3xl"
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            <motion.div 
              className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-hv-orange/10 rounded-full blur-3xl"
              animate={{ 
                scale: [1.2, 1, 1.2],
                opacity: [0.2, 0.5, 0.2]
              }}
              transition={{ duration: 10, repeat: Infinity }}
            />
          </div>

          <div className="relative z-10 max-w-6xl mx-auto px-4 text-center">
            <motion.div
              variants={staggerContainer}
              initial="initial"
              animate="animate"
              className="space-y-8"
            >
              {/* Main Title */}
              <motion.h1 
                variants={fadeInUp}
                className="font-outfit text-5xl md:text-7xl lg:text-8xl font-bold mb-6 text-white"
              >
                Hja²Ops – <span className="hv-gradient-text">AI Multi-Agent Platform</span>
              </motion.h1>

              {/* Subtitle */}
              <motion.p 
                variants={fadeInUp}
                className="text-xl md:text-2xl font-inter text-hv-smoke max-w-3xl mx-auto leading-relaxed mb-12"
              >
                Harness the power of multiple AI agents
              </motion.p>

              {/* CTA Buttons */}
              <motion.div 
                variants={fadeInUp}
                className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8"
              >
                <Link href="/dashboard">
                  <Button className="hv-btn-primary text-xl px-12 py-6 group hv-glow-blue">
                    Get Started
                    <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </motion.div>

            </motion.div>
          </div>

          {/* Scroll Indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-1 h-8 bg-hv-blue/50 rounded-full" />
          </motion.div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 px-4">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid md:grid-cols-2 gap-8"
            >
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -40 : 40 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="hv-card p-8 group hover:scale-105 transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-hv-blue/20 rounded-lg flex items-center justify-center group-hover:bg-hv-blue/30 transition-colors flex-shrink-0">
                      <benefit.icon className="w-6 h-6 text-hv-blue" />
                    </div>
                    <div>
                      <h3 className="font-outfit text-xl font-semibold text-white mb-3 group-hover:text-hv-blue transition-colors">
                        {benefit.title}
                      </h3>
                      <p className="font-inter text-hv-smoke leading-relaxed">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12 px-4 border-t border-hv-blue/20">
          <div className="max-w-6xl mx-auto text-center">
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="font-inter text-hv-smoke/70"
            >
              © Haja®Verso 2025
            </motion.p>
          </div>
        </footer>
      </div>
    </Layout>
  );
}
