import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Check, CreditCard, ArrowRight, Sparkles } from 'lucide-react';

export default function CheckoutSuccess() {
  const { data: user } = useQuery({
    queryKey: ['/api/auth/user'],
  });

  useEffect(() => {
    // Celebrate with confetti effect (you could add a confetti library here)
    console.log('🎉 Payment successful!');
  }, []);

  return (
    <div className="min-h-screen bg-hja-bg flex items-center justify-center py-12 px-4" data-testid="checkout-success-page">
      <motion.div
        className="max-w-2xl mx-auto text-center"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, type: 'spring' }}
      >
        <Card className="glass border-hairline overflow-hidden">
          <CardHeader className="pb-4">
            <motion.div
              className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-hja-primary to-hja-accent rounded-full flex items-center justify-center"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Check className="w-10 h-10 text-white" />
            </motion.div>

            <CardTitle className="text-3xl font-orbitron smoke-text">
              Pagamento Confirmado!
            </CardTitle>
          </CardHeader>

          <CardContent className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <p className="text-lg smoke-text-muted mb-6">
                Sua compra foi processada com sucesso. Os créditos já foram adicionados à sua conta!
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="glass border-hairline rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <CreditCard className="w-5 h-5 text-hja-primary" />
                    <span className="font-semibold smoke-text">Créditos Atuais</span>
                  </div>
                  <div className="text-2xl font-bold text-hja-primary">
                    {(user as any)?.credits?.toLocaleString() || '---'}
                  </div>
                </div>

                <div className="glass border-hairline rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <Sparkles className="w-5 h-5 text-hja-accent" />
                    <span className="font-semibold smoke-text">Status</span>
                  </div>
                  <div className="text-2xl font-bold text-hja-accent">
                    Ativo
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              className="space-y-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <h3 className="text-lg font-semibold smoke-text mb-4">
                O que você pode fazer agora:
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-hja-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-medium smoke-text">Conversar com Agentes</div>
                    <div className="text-sm smoke-text-muted">Acesse todos os agentes especializados</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-hja-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-medium smoke-text">Explorar Cursos</div>
                    <div className="text-sm smoke-text-muted">Acesse conteúdo premium exclusivo</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-hja-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-medium smoke-text">Acompanhar Uso</div>
                    <div className="text-sm smoke-text-muted">Monitore seus créditos em tempo real</div>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-hja-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <div className="font-medium smoke-text">Suporte Premium</div>
                    <div className="text-sm smoke-text-muted">Acesso a suporte prioritário</div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              className="flex flex-col sm:flex-row gap-4 pt-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              <Link href="/" className="flex-1">
                <Button variant="primary" size="lg" className="w-full group" data-testid="button-go-dashboard">
                  Ir para Dashboard
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>

              <Link href="/chat" className="flex-1">
                <Button variant="ghost" size="lg" className="w-full" data-testid="button-start-chat">
                  Começar a Conversar
                </Button>
              </Link>
            </motion.div>

            <motion.div
              className="pt-6 border-t border-hja-border"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 1 }}
            >
              <p className="text-sm smoke-text-muted">
                Você receberá um email de confirmação em breve.
                <br />
                Dúvidas? Entre em contato com nosso suporte.
              </p>
            </motion.div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}