import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Calendar, Clock, Eye, Lock, Star, ArrowLeft, CreditCard } from "lucide-react";
import type { Post } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface BlogPostProps {
  slug: string;
}

export default function BlogPost(params: { slug: string }) {
  const { slug } = params;
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: post, isLoading } = useQuery({
    queryKey: ["/api/posts", slug],
    staleTime: 60000,
  });

  const unlockMutation = useMutation({
    mutationFn: async (postId: string) => {
      const response = await fetch(`/api/posts/${postId}/unlock`, {
        method: 'POST',
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message);
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "✅ Post Desbloqueado!",
        description: "Agora você pode ler o conteúdo completo.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/posts", slug] });
    },
    onError: (error: any) => {
      toast({
        title: "❌ Erro ao Desbloquear",
        description: error.message || "Não foi possível desbloquear o post",
        variant: "destructive",
      });
    },
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getLevelBadge = (requiredLevel: string, tokenCost?: number) => {
    const levels = {
      free: { color: "bg-green-500/20 text-green-400 border-green-500/50", label: "Gratuito" },
      pro: { color: "bg-[#00CCFF]/20 text-[#00CCFF] border-[#00CCFF]/50", label: "Pro" },
      vip: { color: "bg-[#FF740B]/20 text-[#FF740B] border-[#FF740B]/50", label: "VIP" },
    };
    
    if (requiredLevel.startsWith('token-') || tokenCost) {
      const cost = tokenCost || parseInt(requiredLevel.replace('token-', ''));
      return (
        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/50">
          <CreditCard className="w-3 h-3 mr-1" />
          {cost} Tokens
        </Badge>
      );
    }
    
    const level = levels[requiredLevel as keyof typeof levels] || levels.free;
    return (
      <Badge className={level.color}>
        <Star className="w-3 h-3 mr-1" />
        {level.label}
      </Badge>
    );
  };

  const renderContent = (content: string) => {
    // Simple markdown-like rendering for demonstration
    const formattedContent = content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>');
    
    return `<p>${formattedContent}</p>`;
  };

  const renderPaywall = () => {
    const tokenCost = (post as any)?.tokenCost || 0;
    const userCredits = (user as any)?.credits || 0;
    const canAfford = userCredits >= tokenCost;

    return (
      <div className="relative mt-8">
        {/* Blur overlay effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/80 backdrop-blur-sm z-10"></div>
        
        {/* Blurred content preview */}
        <div className="filter blur-sm opacity-50 select-none pointer-events-none">
          <div className="hv-text leading-relaxed space-y-4">
            <p>Este é um preview do conteúdo premium. O artigo continua com insights valiosos sobre...</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt...</p>
            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip...</p>
          </div>
        </div>

        {/* Paywall CTA */}
        <div className="absolute inset-0 flex items-center justify-center z-20">
          <Card className="bg-black/90 border-[#FF740B]/50 backdrop-blur-md max-w-md w-full mx-4">
            <div className="p-8 text-center space-y-6">
              <div className="w-16 h-16 mx-auto bg-[#FF740B]/20 rounded-full flex items-center justify-center">
                <Lock className="w-8 h-8 text-[#FF740B]" />
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white hv-title">
                  Conteúdo Premium
                </h3>
                <p className="text-gray-300 hv-text">
                  Continue lendo este artigo exclusivo
                </p>
              </div>

              {!isAuthenticated ? (
                <div className="space-y-4">
                  <p className="text-[#00CCFF] font-medium">
                    👋 Faça login para continuar
                  </p>
                  <Button 
                    onClick={() => window.location.href = '/api/login'}
                    className="w-full hv-btn-primary text-black font-semibold"
                    data-testid="button-login">
                    Fazer Login
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-center space-x-2">
                    {getLevelBadge((post as any)?.requiredLevel, tokenCost)}
                  </div>
                  
                  <div className="text-sm text-gray-400">
                    <div>Você tem <span className="text-yellow-400 font-bold">{userCredits} tokens</span></div>
                    <div>Necessário: <span className="text-[#FF740B] font-bold">{tokenCost} tokens</span></div>
                  </div>

                  {canAfford ? (
                    <Button 
                      onClick={() => unlockMutation.mutate((post as any)?.id)}
                      disabled={unlockMutation.isPending}
                      className="w-full hv-btn-primary text-black font-semibold hover:scale-105 transform transition-all"
                      data-testid="button-unlock">
                      <CreditCard className="w-4 h-4 mr-2" />
                      {unlockMutation.isPending ? "Desbloqueando..." : `Desbloquear por ${tokenCost} tokens`}
                    </Button>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-red-400 font-medium">
                        ❌ Tokens insuficientes
                      </p>
                      <Button 
                        className="w-full bg-gradient-to-r from-[#00CCFF] to-blue-600 hover:from-[#FF740B] hover:to-orange-600 text-white"
                        data-testid="button-buy-tokens">
                        💰 Comprar Tokens
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="space-y-6">
            <div className="h-8 bg-gray-700 rounded animate-pulse w-32"></div>
            <div className="h-12 bg-gray-700 rounded animate-pulse"></div>
            <div className="h-64 bg-gray-700 rounded animate-pulse"></div>
            <div className="space-y-3">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-4 bg-gray-700 rounded animate-pulse"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-6xl">📝</div>
          <h2 className="text-2xl font-bold text-white">Post não encontrado</h2>
          <p className="text-gray-400">O artigo que você procura não existe ou foi removido.</p>
          <Link href="/blog">
            <Button className="hv-btn-primary text-black">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const typedPost = post as any;
  const isLocked = typedPost.locked;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Back to Blog */}
        <div className="mb-6">
          <Link href="/blog">
            <Button variant="ghost" className="text-[#00CCFF] hover:text-white hover:bg-[#00CCFF]/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Blog
            </Button>
          </Link>
        </div>

        {/* Article Header */}
        <div className="space-y-6 mb-8">
          <div className="flex flex-wrap items-center gap-3">
            {getLevelBadge(typedPost.requiredLevel, typedPost.tokenCost)}
            <div className="flex items-center text-sm text-gray-400 space-x-4">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {formatDate(typedPost.publishedAt || typedPost.createdAt)}
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {typedPost.readTime || 5} min
              </div>
              <div className="flex items-center">
                <Eye className="w-4 h-4 mr-1" />
                {typedPost.views || 0} visualizações
              </div>
            </div>
          </div>

          <h1 className="hv-title text-4xl md:text-5xl font-bold bg-gradient-to-r from-white via-[#00CCFF] to-[#FF740B] bg-clip-text text-transparent leading-tight"
              data-testid="text-post-title">
            {typedPost.title}
          </h1>

          {/* Cover Image */}
          {typedPost.coverImage && (
            <div className="relative rounded-xl overflow-hidden">
              <img 
                src={typedPost.coverImage}
                alt={typedPost.title}
                className="w-full h-64 md:h-96 object-cover"
                data-testid="img-post-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          )}

          {/* Tags */}
          {typedPost.tags && typedPost.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {typedPost.tags.map((tag: string, index: number) => (
                <Badge 
                  key={index}
                  variant="outline" 
                  className="border-[#00CCFF]/50 text-[#00CCFF] bg-black/30"
                  data-testid={`badge-tag-${index}`}>
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Article Content */}
        <Card className="bg-black/30 border-[#00CCFF]/30 backdrop-blur-md">
          <div className="p-8">
            <div 
              className="hv-text text-gray-300 leading-relaxed prose prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: renderContent(typedPost.content) }}
              data-testid="text-post-content"
            />

            {/* Paywall for locked content */}
            {isLocked && renderPaywall()}
          </div>
        </Card>

        {/* Related Actions */}
        <div className="mt-8 text-center">
          <Link href="/blog">
            <Button className="hv-btn-primary text-black">
              📖 Ver Mais Artigos
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}