import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Bot,
  Code,
  Palette,
  Youtube,
  BarChart3,
  Lightbulb,
  FileText,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import ChatCore from '@/components/chat/ChatCore';
import { agentModes } from '@/components/chat/AgentModes';

export default function ChatDemo() {
  const [selectedAgent, setSelectedAgent] = useState('general');
  const [showChat, setShowChat] = useState(false);

  const agentCards = [
    {
      id: 'roteiro',
      name: 'Roteirista IA',
      description: 'Roteiros, storytelling e narrativas',
      icon: FileText,
      color: 'bg-purple-600',
      examples: ['Roteiro publicitário', 'Documentário', 'Série web']
    },
    {
      id: 'code',
      name: 'Vibe Code',
      description: 'Desenvolvimento full-stack e IA',
      icon: Code,
      color: 'admin-bg-blue',
      examples: ['Componente React', 'API REST', 'Otimização']
    },
    {
      id: 'branding',
      name: 'Brand Expert',
      description: 'Branding e identidade visual',
      icon: Palette,
      color: 'admin-bg-orange',
      examples: ['Identidade visual', 'Tom de voz', 'Posicionamento']
    },
    {
      id: 'youtube',
      name: 'YouTube Expert',
      description: 'Análise e estratégia para vídeos',
      icon: Youtube,
      color: 'bg-red-600',
      examples: ['SEO de vídeo', 'Thumbnail', 'Estratégia']
    },
    {
      id: 'analytics',
      name: 'Data Analyst',
      description: 'Análise de dados e insights',
      icon: BarChart3,
      color: 'bg-green-600',
      examples: ['Relatórios', 'Métricas', 'Previsões']
    },
    {
      id: 'creative',
      name: 'Creative Mind',
      description: 'Ideação criativa e campanhas',
      icon: Lightbulb,
      color: 'bg-pink-600',
      examples: ['Brainstorm', 'Campanhas', 'Conceitos']
    }
  ];

  const handleSelectAgent = (agentId: string) => {
    setSelectedAgent(agentId);
    setShowChat(true);
  };

  if (showChat) {
    return (
      <div className="h-screen admin-theme">
        <div className="h-full relative">
          <ChatCore agentId={selectedAgent} />
          
          {/* Back Button */}
          <Button
            onClick={() => setShowChat(false)}
            variant="outline"
            className="absolute top-4 left-4 border-blue-500/20 admin-text-blue hover:bg-blue-500/10"
          >
            ← Voltar aos Agentes
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header */}
      <header className="admin-sidebar border-b border-blue-500/20 p-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center gap-4 mb-6"
          >
            <div className="w-16 h-16 admin-bg-blue rounded-2xl flex items-center justify-center admin-glow-blue">
              <Bot className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold admin-text-blue">Chat Core</h1>
              <p className="text-lg admin-text-smoke">Sistema Universal de Agentes IA</p>
            </div>
          </motion.div>
          
          <p className="text-xl admin-text-smoke max-w-2xl mx-auto">
            Escolha seu agente especializado e comece a conversar. 
            Cada agente tem sua própria personalidade, capabilities e expertise.
          </p>
        </div>
      </header>

      {/* Agent Selection */}
      <main className="p-8">
        <div className="max-w-6xl mx-auto">
          
          {/* Page Title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold admin-text-blue mb-4">
              Selecione seu Agente Especialista
            </h2>
            <p className="text-lg admin-text-smoke">
              Cada agente foi treinado com expertise específica para entregar os melhores resultados
            </p>
          </motion.div>

          {/* Agent Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {agentCards.map((agent, index) => (
              <motion.div
                key={agent.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="admin-card p-6 hover:border-blue-500/40 transition-all cursor-pointer group"
                onClick={() => handleSelectAgent(agent.id)}
              >
                
                {/* Agent Icon & Name */}
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-12 h-12 ${agent.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <agent.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold admin-text-blue group-hover:text-blue-400 transition-colors">
                      {agent.name}
                    </h3>
                    <p className="text-sm admin-text-smoke">
                      {agent.description}
                    </p>
                  </div>
                </div>

                {/* Examples */}
                <div className="space-y-3 mb-6">
                  <h4 className="font-medium admin-text-blue text-sm">Especialidades:</h4>
                  <div className="flex flex-wrap gap-2">
                    {agent.examples.map((example, i) => (
                      <Badge
                        key={i}
                        variant="outline"
                        className="border-blue-500/20 admin-text-smoke text-xs"
                      >
                        {example}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <Button
                  className={`w-full ${agent.color} hover:opacity-90 group-hover:scale-105 transition-all`}
                >
                  Conversar com {agent.name.split(' ')[0]}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                {/* Agent Capabilities */}
                <div className="mt-4 pt-4 border-t border-blue-500/10">
                  <div className="flex items-center gap-2">
                    <span className="text-xs admin-text-smoke">Capacidades:</span>
                    {agentModes[agent.id]?.capabilities.acceptsFiles && (
                      <Badge className="bg-green-500/20 text-green-400 text-xs border-0">
                        Arquivos
                      </Badge>
                    )}
                    {agentModes[agent.id]?.capabilities.acceptsUrls && (
                      <Badge className="bg-blue-500/20 admin-text-blue text-xs border-0">
                        URLs
                      </Badge>
                    )}
                    {agentModes[agent.id]?.capabilities.acceptsAudio && (
                      <Badge className="bg-purple-500/20 text-purple-400 text-xs border-0">
                        Áudio
                      </Badge>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Features Overview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mt-16 admin-card p-8"
          >
            <h3 className="text-2xl font-bold admin-text-blue mb-6 text-center">
              Recursos do Chat Core
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold admin-text-blue mb-2">Agentes Especializados</h4>
                <p className="text-sm admin-text-smoke">
                  Cada agente tem expertise específica e modo de resposta otimizado
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center mx-auto mb-3">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold admin-text-blue mb-2">Créditos Inteligentes</h4>
                <p className="text-sm admin-text-smoke">
                  Sistema de custo transparente com fallback automático
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold admin-text-blue mb-2">Múltiplos Formatos</h4>
                <p className="text-sm admin-text-smoke">
                  Suporte a texto, código, tabelas, mídia e resultados de ações
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}