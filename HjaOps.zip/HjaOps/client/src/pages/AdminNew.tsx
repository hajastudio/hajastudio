import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Zap, 
  DollarSign, 
  Activity,
  Server,
  AlertTriangle,
  LogOut,
  User
} from 'lucide-react';
import { StatsCard } from '@/components/admin/StatsCard';
import { AgentsPanel } from '@/components/admin/AgentsPanel';
import { ChartCard } from '@/components/admin/ChartCard';
import { useAuth } from '@/hooks/useAuth';

export default function AdminNew() {
  const { user } = useAuth();
  const [systemStatus, setSystemStatus] = useState<'online' | 'alert'>('online');

  // Mock data for charts and stats
  const userActivityData = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
  const userActivitySeries = [{
    name: 'Usuários Ativos',
    data: [1200, 1900, 3000, 5000, 4300, 5800]
  }];

  const tokensData = ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00'];
  const tokensSeries = [{
    name: 'Tokens Consumidos',
    data: [2400, 1800, 4200, 6100, 7300, 5900]
  }];

  const revenueData = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
  const revenueSeries = [{
    name: 'Receita (R$)',
    data: [12000, 19000, 30000, 45000, 38000, 52000]
  }];

  const latencyData = ['OpenAI', 'Groq', 'HuggingFace', 'Replit'];
  const latencySeries = [{
    name: 'Latência (ms)',
    data: [240, 180, 320, 210]
  }];

  const modelUsageData = ['GPT-5', 'Groq Llama 3.1', 'HuggingFace', 'Local'];
  const modelUsageSeries = [65, 20, 10, 5];

  const logout = () => {
    window.location.href = '/api/logout';
  };

  return (
    <div className="min-h-screen bg-black text-[var(--smoke)] relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-black to-blue-900/20"></div>
      
      {/* Topbar */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
        className="fixed top-0 left-0 right-0 h-16 glass-morphism-strong z-50 gradient-bg"
      >
        <div className="flex items-center justify-between h-full px-6">
          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center space-x-3 cursor-pointer"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl neon-glow flex items-center justify-center relative">
              <Server className="w-6 h-6 text-white" />
              <div className="absolute inset-0 rounded-2xl border-2 border-[var(--blue)]/30 animate-pulse"></div>
            </div>
            <div>
              <h1 className="font-orbitron font-bold text-xl text-white tracking-tight">
                Hja²Ops Admin
              </h1>
              <div className="text-xs text-[var(--smoke)]/70 -mt-1">
                Sistema de Controle
              </div>
            </div>
          </motion.div>

          {/* Center: System Status */}
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-2xl glass-morphism ${
              systemStatus === 'online' 
                ? 'border-green-500/30 bg-green-500/10' 
                : 'border-red-500/30 bg-red-500/10'
            }`}>
              <div className={`w-3 h-3 rounded-full animate-pulse ${
                systemStatus === 'online' ? 'bg-green-400' : 'bg-red-400'
              }`}></div>
              <span className={`text-sm font-medium ${
                systemStatus === 'online' ? 'text-green-400' : 'text-red-400'
              }`}>
                {systemStatus === 'online' ? '🟢 Online' : '🔴 Alerta'}
              </span>
            </div>
          </div>

          {/* User Dropdown */}
          <div className="flex items-center space-x-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center space-x-3 px-4 py-2 rounded-2xl glass-morphism hover:neon-glow transition-all group"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-full flex items-center justify-center">
                <User size={16} className="text-white" />
              </div>
              <div className="hidden sm:block text-left">
                <div className="text-sm font-medium text-white">{user?.email?.split('@')[0] || 'Admin'}</div>
                <div className="text-xs text-[var(--smoke)]/70">Administrador</div>
              </div>
            </motion.button>

            <motion.button
              onClick={logout}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-3 rounded-2xl glass-morphism hover:neon-glow-orange text-[var(--orange)] transition-all"
            >
              <LogOut size={20} />
            </motion.button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="pt-20 p-6 relative z-10">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-4xl font-orbitron font-bold text-white mb-2 text-gradient">
              Dashboard Administrativo
            </h1>
            <p className="text-[var(--smoke)]/80">
              Controle centralizado da plataforma Hja²Ops
            </p>
          </motion.div>

          {/* Section 1: Visão Geral */}
          <section>
            <h2 className="text-2xl font-orbitron font-bold text-white mb-6">Visão Geral</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <StatsCard
                title="Usuários Ativos Hoje"
                value={2847}
                subtitle="Usuários únicos"
                icon={Users}
                trend={{ value: 12.5, isPositive: true }}
              />
              
              <StatsCard
                title="Tokens Consumidos"
                value="125.3K"
                subtitle="Total diário"
                icon={Zap}
                progress={{ value: 125300, max: 200000 }}
              />
              
              <StatsCard
                title="Receita do Mês"
                value="R$ 52.847"
                subtitle="Faturamento mensal"
                icon={DollarSign}
                trend={{ value: 8.3, isPositive: true }}
              />
            </div>
          </section>

          {/* Section 2: Charts */}
          <section>
            <h2 className="text-2xl font-orbitron font-bold text-white mb-6">Análise de Performance</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ChartCard
                title="Atividade de Usuários"
                subtitle="Últimos 6 meses"
                type="area"
                data={userActivityData}
                series={userActivitySeries}
                height={300}
              />
              
              <ChartCard
                title="Consumo de Tokens"
                subtitle="Últimas 24 horas"
                type="line"
                data={tokensData}
                series={tokensSeries}
                height={300}
              />
              
              <ChartCard
                title="Latência por Modelo"
                subtitle="Tempo médio de resposta"
                type="bar"
                data={latencyData}
                series={latencySeries}
                height={300}
              />
              
              <ChartCard
                title="Distribuição de Modelos"
                subtitle="Uso por modelo IA"
                type="donut"
                data={modelUsageData}
                series={modelUsageSeries}
                height={300}
              />
            </div>
          </section>

          {/* Section 3: Agentes & Monitoramento */}
          <section>
            <h2 className="text-2xl font-orbitron font-bold text-white mb-6">Agentes & Monitoramento</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <AgentsPanel />
              
              {/* HVC Core Recommendations */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="glass-morphism-strong rounded-3xl p-6 animated-border"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[var(--orange)] to-red-600 flex items-center justify-center neon-glow-orange">
                    <Activity className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-orbitron font-bold text-white">Recomendações HVC Core</h3>
                    <p className="text-sm text-[var(--smoke)]/70">Algoritmo de otimização autônoma</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-[var(--orange)]/10 border border-[var(--orange)]/30">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-[var(--orange)] mt-0.5" />
                      <div>
                        <h4 className="font-medium text-white mb-1">Otimização de Roteamento</h4>
                        <p className="text-sm text-[var(--smoke)]/80">
                          Detectada alta latência no modelo GPT-5. Recomendamos redistribuir 
                          20% do tráfego para Groq Llama 3.1 durante horário de pico.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-[var(--blue)]/10 border border-[var(--blue)]/30">
                    <div className="flex items-start gap-3">
                      <Zap className="w-5 h-5 text-[var(--blue)] mt-0.5" />
                      <div>
                        <h4 className="font-medium text-white mb-1">Economia de Tokens</h4>
                        <p className="text-sm text-[var(--smoke)]/80">
                          Implementar cache inteligente pode reduzir consumo em 15% 
                          para queries similares de usuários Premium.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/30">
                    <div className="flex items-start gap-3">
                      <Users className="w-5 h-5 text-green-400 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-white mb-1">Crescimento de Usuários</h4>
                        <p className="text-sm text-[var(--smoke)]/80">
                          Padrão de crescimento sustentável detectado. Capacidade atual 
                          suporta mais 40% de usuários sem degradação.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Footer */}
          <footer className="text-center py-8 border-t border-[var(--blue)]/20 glass-morphism rounded-t-3xl mt-8">
            <p className="text-[var(--smoke)]/70 text-sm">
              <span className="font-orbitron font-bold text-gradient">Hja²Ops Core</span> 
              © 2025 — Sistema Autônomo de Orquestração
            </p>
          </footer>
        </div>
      </main>
    </div>
  );
}