import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  DollarSign,
  Target,
  Award,
  Settings,
  Crown,
  BarChart3,
  PieChart,
  Calendar,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import TokenOverview from '@/components/tokens/TokenOverview';
import ForecastSection from '@/components/tokens/ForecastSection';
import SmartDistribution from '@/components/tokens/SmartDistribution';
import RewardsSystem from '@/components/tokens/RewardsSystem';
import AdminControls from '@/components/tokens/AdminControls';
import TokenCharts from '@/components/tokens/TokenCharts';

type ActiveSection = 'overview' | 'forecast' | 'distribution' | 'rewards' | 'admin' | 'charts';

interface TokenData {
  currentBalance: number;
  dailyUsage: number;
  monthlyUsage: number;
  daysRemaining: number;
  estimatedMonthlyCost: number;
  conversionRate: number;
  profitMargin: number;
  totalUsers: number;
  premiumUsers: number;
}

export default function TokenManagement() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('overview');
  const [tokenData, setTokenData] = useState<TokenData>({
    currentBalance: 2847,
    dailyUsage: 156,
    monthlyUsage: 4680,
    daysRemaining: 18,
    estimatedMonthlyCost: 247.50,
    conversionRate: 8.5,
    profitMargin: 87.2,
    totalUsers: 1543,
    premiumUsers: 127
  });

  const sections = [
    { 
      id: 'overview', 
      label: 'Visão Geral', 
      icon: BarChart3, 
      description: 'Dashboard principal com métricas' 
    },
    { 
      id: 'forecast', 
      label: 'Previsão IA', 
      icon: TrendingUp, 
      description: 'Predições e alertas inteligentes' 
    },
    { 
      id: 'distribution', 
      label: 'Distribuição', 
      icon: Target, 
      description: 'Alocação dinâmica por plano' 
    },
    { 
      id: 'rewards', 
      label: 'Recompensas', 
      icon: Award, 
      description: 'Gamificação e incentivos' 
    },
    { 
      id: 'charts', 
      label: 'Analytics', 
      icon: PieChart, 
      description: 'Gráficos e visualizações' 
    },
    { 
      id: 'admin', 
      label: 'Admin Controls', 
      icon: Settings, 
      description: 'Controles administrativos' 
    }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <TokenOverview data={tokenData} />;
      case 'forecast':
        return <ForecastSection data={tokenData} />;
      case 'distribution':
        return <SmartDistribution data={tokenData} />;
      case 'rewards':
        return <RewardsSystem />;
      case 'charts':
        return <TokenCharts data={tokenData} />;
      case 'admin':
        return <AdminControls data={tokenData} />;
      default:
        return <TokenOverview data={tokenData} />;
    }
  };

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header */}
      <header className="admin-sidebar border-b border-blue-500/20 sticky top-0 z-50">
        <div className="flex items-center justify-between px-6 py-4">
          
          {/* Left Section - Logo & Title */}
          <div className="flex items-center gap-4">
            <div className="admin-glow-blue w-12 h-12 rounded-xl flex items-center justify-center admin-pulse">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold admin-text-blue">HVC Core</h1>
              <p className="text-sm admin-text-smoke">Sistema de Gestão Inteligente</p>
            </div>
          </div>

          {/* Center Section - Key Metrics */}
          <div className="hidden lg:flex items-center gap-8">
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">Saldo Atual</p>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 admin-text-blue" />
                <span className="font-bold admin-text-blue">
                  {tokenData.currentBalance.toLocaleString()}
                </span>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">Margem</p>
              <span className="font-bold text-green-400">
                {tokenData.profitMargin.toFixed(1)}%
              </span>
            </div>
            
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">Conversão</p>
              <span className="font-bold admin-text-orange">
                {tokenData.conversionRate.toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Right Section - Quick Actions */}
          <div className="flex items-center gap-4">
            <Badge className={`${
              tokenData.daysRemaining > 14 ? 'bg-green-500' : 
              tokenData.daysRemaining > 7 ? 'admin-bg-orange' : 'bg-red-500'
            } text-white`}>
              {tokenData.daysRemaining} dias restantes
            </Badge>
            
            <Button className="admin-bg-orange hover:opacity-90">
              <DollarSign className="w-4 h-4 mr-2" />
              Comprar Tokens
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        
        {/* Sidebar Navigation */}
        <aside className="admin-sidebar w-80 border-r border-blue-500/20 h-[calc(100vh-80px)] overflow-y-auto">
          <div className="p-6">
            <h2 className="font-bold admin-text-blue mb-4">Módulos HVC</h2>
            <div className="space-y-2">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id as ActiveSection)}
                  className={`w-full text-left p-4 rounded-xl transition-all ${
                    activeSection === section.id
                      ? 'admin-bg-blue text-white'
                      : 'hover:bg-blue-500/10 admin-text-smoke hover:admin-text-blue'
                  }`}
                  data-testid={`section-${section.id}`}
                >
                  <div className="flex items-start gap-3">
                    <section.icon className={`w-5 h-5 mt-0.5 ${
                      activeSection === section.id ? 'text-white' : 'admin-text-blue'
                    }`} />
                    <div>
                      <h3 className="font-semibold">{section.label}</h3>
                      <p className={`text-xs mt-1 ${
                        activeSection === section.id ? 'text-blue-100' : 'admin-text-smoke'
                      }`}>
                        {section.description}
                      </p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Sidebar Stats */}
          <div className="p-6 border-t border-blue-500/20">
            <h3 className="font-bold admin-text-blue mb-4 text-sm">Status do Sistema</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs admin-text-smoke">Usuários Ativos</span>
                <div className="flex items-center gap-2">
                  <Users className="w-3 h-3 admin-text-blue" />
                  <span className="text-sm font-bold admin-text-blue">
                    {tokenData.totalUsers}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs admin-text-smoke">Premium</span>
                <div className="flex items-center gap-2">
                  <Crown className="w-3 h-3 admin-text-orange" />
                  <span className="text-sm font-bold admin-text-orange">
                    {tokenData.premiumUsers}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs admin-text-smoke">Custo/Mês</span>
                <span className="text-sm font-bold text-green-400">
                  R$ {tokenData.estimatedMonthlyCost.toFixed(2)}
                </span>
              </div>
            </div>

            {/* System Health */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs admin-text-smoke">Health Score</span>
                <span className="text-xs font-bold text-green-400">98.5%</span>
              </div>
              <Progress value={98.5} className="h-2" />
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8 overflow-y-auto h-[calc(100vh-80px)]">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderContent()}
          </motion.div>
        </main>
      </div>
    </div>
  );
}