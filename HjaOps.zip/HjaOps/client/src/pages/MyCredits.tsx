import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Zap,
  TrendingUp,
  Calendar,
  Download,
  Eye,
  CreditCard,
  BarChart3,
  Clock,
  DollarSign,
  ArrowUp,
  ArrowDown,
  Filter,
  Search
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import Chart from 'react-apexcharts';
import { ApexOptions } from 'apexcharts';
import { formatPrice, type Transaction, type CreditUsage } from '@/types/pricing';

export default function MyCredits() {
  const [currentCredits, setCurrentCredits] = useState(247);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPeriod, setSelectedPeriod] = useState('7d');

  // Mock data
  const transactions: Transaction[] = [
    {
      id: '1',
      type: 'credit_purchase',
      amount: 69.90,
      credits: 200,
      status: 'approved',
      paymentMethod: 'mercadopago',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      description: 'Pacote Popular - 200 créditos',
      invoice: 'INV-2024-001'
    },
    {
      id: '2',
      type: 'bonus',
      amount: 0,
      credits: 20,
      status: 'approved',
      paymentMethod: 'bonus',
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      description: 'Bônus pacote Popular'
    },
    {
      id: '3',
      type: 'bonus',
      amount: 0,
      credits: 5,
      status: 'approved',
      paymentMethod: 'bonus',
      timestamp: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      description: 'Bônus de boas-vindas'
    }
  ];

  const usage: CreditUsage[] = [
    {
      id: '1',
      agentId: 'roteiro',
      agentName: 'Roteirista IA',
      model: 'gpt-4o',
      credits: 2.5,
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
      details: 'Roteiro publicitário 30s'
    },
    {
      id: '2',
      agentId: 'code',
      agentName: 'Vibe Code',
      model: 'groq',
      credits: 0.8,
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000),
      details: 'Componente React para dashboard'
    },
    {
      id: '3',
      agentId: 'branding',
      agentName: 'Brand Expert',
      model: 'claude-3',
      credits: 1.2,
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
      details: 'Análise de posicionamento'
    }
  ];

  // Usage chart data
  const usageData = Array.from({length: 7}, (_, i) => ({
    day: new Date(Date.now() - (6-i) * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR', { weekday: 'short' }),
    credits: Math.floor(Math.random() * 15) + 5
  }));

  const chartOptions: ApexOptions = {
    chart: {
      type: 'area',
      height: 300,
      background: 'transparent',
      toolbar: { show: false }
    },
    theme: { mode: 'dark' },
    stroke: {
      curve: 'smooth',
      width: 2,
      colors: ['#0055ff']
    },
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.4,
        opacityTo: 0.1,
        stops: [0, 100]
      }
    },
    xaxis: {
      categories: usageData.map(d => d.day),
      labels: { style: { colors: '#c5d1db' } }
    },
    yaxis: {
      title: { text: 'Créditos', style: { color: '#c5d1db' } },
      labels: { style: { colors: '#c5d1db' } }
    },
    grid: { borderColor: '#374151', strokeDashArray: 3 },
    colors: ['#0055ff']
  };

  const chartSeries = [{
    name: 'Créditos usados',
    data: usageData.map(d => d.credits)
  }];

  // Predictions
  const weeklyUsage = usageData.reduce((acc, d) => acc + d.credits, 0);
  const dailyAverage = weeklyUsage / 7;
  const predictedDays = Math.floor(currentCredits / dailyAverage);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-400';
      case 'pending': return 'admin-text-orange';
      case 'rejected': return 'text-red-400';
      default: return 'admin-text-smoke';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-500';
      case 'pending': return 'admin-bg-orange';
      case 'rejected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const filteredTransactions = transactions.filter(t => 
    t.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredUsage = usage.filter(u => 
    u.agentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.details.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header */}
      <header className="admin-sidebar border-b border-blue-500/20 p-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 admin-bg-blue rounded-2xl flex items-center justify-center admin-glow-blue">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold admin-text-blue">Meus Créditos</h1>
                <p className="text-lg admin-text-smoke">Transparência total do seu consumo</p>
              </div>
            </div>

            <Button className="admin-bg-blue hover:opacity-90">
              <CreditCard className="w-4 h-4 mr-2" />
              Comprar Créditos
            </Button>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          {/* Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-500 text-white">Ativo</Badge>
              </div>
              
              <div>
                <p className="text-3xl font-bold admin-text-blue mb-1">{currentCredits}</p>
                <p className="admin-text-smoke text-sm">Créditos disponíveis</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center gap-1">
                  <ArrowUp className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-400">+12%</span>
                </div>
              </div>
              
              <div>
                <p className="text-3xl font-bold admin-text-orange mb-1">{dailyAverage.toFixed(1)}</p>
                <p className="admin-text-smoke text-sm">Média diária (7d)</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
              </div>
              
              <div>
                <p className="text-3xl font-bold text-purple-400 mb-1">{predictedDays}</p>
                <p className="admin-text-smoke text-sm">Dias restantes (previsão)</p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="admin-card p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
              </div>
              
              <div>
                <p className="text-3xl font-bold text-green-400 mb-1">
                  {formatPrice(transactions.filter(t => t.type === 'credit_purchase').reduce((acc, t) => acc + t.amount, 0))}
                </p>
                <p className="admin-text-smoke text-sm">Total investido</p>
              </div>
            </motion.div>
          </div>

          {/* Usage Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="admin-card p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold admin-text-blue">Consumo dos últimos 7 dias</h2>
              
              <div className="flex items-center gap-4">
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className="px-3 py-2 rounded-lg bg-black/50 border border-blue-500/20 admin-text-smoke text-sm"
                >
                  <option value="7d">Últimos 7 dias</option>
                  <option value="30d">Últimos 30 dias</option>
                  <option value="90d">Últimos 3 meses</option>
                </select>
              </div>
            </div>
            
            <Chart
              options={chartOptions}
              series={chartSeries}
              type="area"
              height={300}
            />

            {/* Usage Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
              <div className="text-center p-4 rounded-lg bg-black/30">
                <p className="text-2xl font-bold admin-text-blue">{weeklyUsage}</p>
                <p className="text-sm admin-text-smoke">Total da semana</p>
              </div>
              
              <div className="text-center p-4 rounded-lg bg-black/30">
                <p className="text-2xl font-bold admin-text-orange">{Math.max(...usageData.map(d => d.credits))}</p>
                <p className="text-sm admin-text-smoke">Pico diário</p>
              </div>
              
              <div className="text-center p-4 rounded-lg bg-black/30">
                <p className="text-2xl font-bold text-green-400">{Math.min(...usageData.map(d => d.credits))}</p>
                <p className="text-sm admin-text-smoke">Mínimo diário</p>
              </div>
            </div>
          </motion.div>

          {/* Detailed Tables */}
          <Tabs defaultValue="usage" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-black/30">
              <TabsTrigger value="usage" className="data-[state=active]:admin-text-blue">
                Consumo Detalhado
              </TabsTrigger>
              <TabsTrigger value="transactions" className="data-[state=active]:admin-text-blue">
                Histórico de Compras
              </TabsTrigger>
            </TabsList>

            {/* Usage Tab */}
            <TabsContent value="usage">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="admin-card p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold admin-text-blue">Consumo por Agente</h3>
                  
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke" />
                      <Input
                        placeholder="Buscar..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
                      />
                    </div>
                    
                    <Button variant="outline" size="sm" className="border-blue-500/20 admin-text-blue">
                      <Download className="w-4 h-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  {filteredUsage.map((item) => (
                    <div key={item.id} className="p-4 rounded-lg bg-black/30 border border-blue-500/20">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 admin-bg-blue rounded-lg flex items-center justify-center">
                            <BarChart3 className="w-5 h-5 text-white" />
                          </div>
                          
                          <div>
                            <h4 className="font-semibold admin-text-blue">{item.agentName}</h4>
                            <p className="text-sm admin-text-smoke">{item.details}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="border-blue-500/20 admin-text-blue text-xs">
                                {item.model.toUpperCase()}
                              </Badge>
                              <span className="text-xs admin-text-smoke">
                                {item.timestamp.toLocaleString('pt-BR')}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-lg font-bold admin-text-orange">
                            -{item.credits.toFixed(1)}
                          </p>
                          <p className="text-xs admin-text-smoke">créditos</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </TabsContent>

            {/* Transactions Tab */}
            <TabsContent value="transactions">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="admin-card p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold admin-text-blue">Histórico de Transações</h3>
                  
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 admin-text-smoke" />
                      <Input
                        placeholder="Buscar transações..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 bg-black/50 border-blue-500/20 admin-text-smoke"
                      />
                    </div>
                    
                    <Button variant="outline" size="sm" className="border-blue-500/20 admin-text-blue">
                      <Download className="w-4 h-4 mr-2" />
                      Extrato
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  {filteredTransactions.map((transaction) => (
                    <div key={transaction.id} className="p-4 rounded-lg bg-black/30 border border-blue-500/20">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            transaction.type === 'credit_purchase' ? 'admin-bg-blue' :
                            transaction.type === 'bonus' ? 'admin-bg-orange' :
                            'bg-gray-600'
                          }`}>
                            {transaction.type === 'credit_purchase' ? (
                              <CreditCard className="w-5 h-5 text-white" />
                            ) : (
                              <Zap className="w-5 h-5 text-white" />
                            )}
                          </div>
                          
                          <div>
                            <h4 className="font-semibold admin-text-blue">{transaction.description}</h4>
                            <div className="flex items-center gap-3 mt-1">
                              <Badge className={`${getStatusBadge(transaction.status)} text-white text-xs`}>
                                {transaction.status === 'approved' ? 'Aprovado' :
                                 transaction.status === 'pending' ? 'Pendente' :
                                 transaction.status === 'rejected' ? 'Rejeitado' : transaction.status}
                              </Badge>
                              <span className="text-xs admin-text-smoke">
                                {transaction.timestamp.toLocaleString('pt-BR')}
                              </span>
                              {transaction.invoice && (
                                <Button variant="ghost" size="sm" className="h-auto p-0 text-xs admin-text-blue">
                                  <Eye className="w-3 h-3 mr-1" />
                                  Ver nota
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <div>
                              {transaction.amount > 0 && (
                                <p className="text-lg font-bold text-green-400">
                                  {formatPrice(transaction.amount)}
                                </p>
                              )}
                              <p className="text-sm admin-text-blue">
                                +{transaction.credits} créditos
                              </p>
                            </div>
                            {transaction.type === 'credit_purchase' ? (
                              <ArrowDown className="w-4 h-4 text-green-400" />
                            ) : (
                              <ArrowUp className="w-4 h-4 admin-text-orange" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}