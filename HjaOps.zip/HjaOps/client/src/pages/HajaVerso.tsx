import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import HajaVersoHeader from '@/components/hajaverso/HajaVersoHeader';
import CourseSection from '@/components/hajaverso/CourseSection';
import CommunitySection from '@/components/hajaverso/CommunitySection';
import ResourcesSection from '@/components/hajaverso/ResourcesSection';
import TokensSection from '@/components/hajaverso/TokensSection';

type ActiveTab = 'cursos' | 'comunidade' | 'recursos' | 'tokens';

export default function HajaVerso() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('cursos');
  const [userTokens] = useState(1247); // Mock user tokens data

  const renderContent = () => {
    switch (activeTab) {
      case 'cursos':
        return <CourseSection />;
      case 'comunidade':
        return <CommunitySection />;
      case 'recursos':
        return <ResourcesSection />;
      case 'tokens':
        return <TokensSection />;
      default:
        return <CourseSection />;
    }
  };

  return (
    <div className="min-h-screen admin-theme">
      {/* Header da Área */}
      <HajaVersoHeader 
        activeTab={activeTab}
        onTabChange={setActiveTab}
        userProgress={userTokens}
      />
      
      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}