import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  CreditCard,
  Zap,
  Star,
  Gift,
  Check,
  ArrowRight,
  Shield,
  Clock,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CREDIT_PACKAGES, 
  PLANS, 
  ADDON_PRODUCTS,
  formatPrice, 
  formatCredits,
  type CreditPackage,
  type Plan 
} from '@/types/pricing';

export default function BuyCredits() {
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [processing, setProcessing] = useState(false);

  const handlePurchase = async (productId: string, productType: 'credits' | 'plan') => {
    setSelectedProduct(productId);
    setProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      console.log('Processing payment for:', productId, productType);
      setProcessing(false);
      setSelectedProduct(null);
    }, 2000);
  };

  const applyPromoCode = () => {
    if (promoCode.toLowerCase() === 'welcome10') {
      setPromoApplied(true);
    }
  };

  const calculateDiscountedPrice = (price: number) => {
    return promoApplied ? price * 0.9 : price;
  };

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header */}
      <header className="admin-sidebar border-b border-blue-500/20 p-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="w-16 h-16 admin-bg-blue rounded-2xl flex items-center justify-center admin-glow-blue">
                <CreditCard className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold admin-text-blue">Comprar Créditos</h1>
                <p className="text-lg admin-text-smoke">Escolha o pacote ideal para suas necessidades</p>
              </div>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center justify-center gap-8 mt-6">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-400" />
                <span className="text-sm admin-text-smoke">Pagamento seguro</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 admin-text-blue" />
                <span className="text-sm admin-text-smoke">Créditos instantâneos</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 admin-text-orange" />
                <span className="text-sm admin-text-smoke">Sem mensalidade</span>
              </div>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-8">
        <div className="max-w-6xl mx-auto">
          
          <Tabs defaultValue="credits" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8 bg-black/30">
              <TabsTrigger value="credits" className="data-[state=active]:admin-text-blue">
                Comprar Créditos
              </TabsTrigger>
              <TabsTrigger value="plans" className="data-[state=active]:admin-text-blue">
                Planos Mensais
              </TabsTrigger>
              <TabsTrigger value="addons" className="data-[state=active]:admin-text-blue">
                Add-ons
              </TabsTrigger>
            </TabsList>

            {/* Credits Tab */}
            <TabsContent value="credits">
              <div className="space-y-8">
                
                {/* Promo Code Section */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="admin-card p-6"
                >
                  <h3 className="text-lg font-bold admin-text-blue mb-4">
                    Tem um código promocional?
                  </h3>
                  
                  <div className="flex gap-4">
                    <Input
                      placeholder="Digite seu código aqui..."
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="bg-black/50 border-blue-500/20 admin-text-smoke"
                    />
                    <Button
                      onClick={applyPromoCode}
                      variant="outline"
                      className="border-blue-500/20 admin-text-blue"
                      disabled={promoApplied}
                    >
                      {promoApplied ? 'Aplicado!' : 'Aplicar'}
                    </Button>
                  </div>

                  {promoApplied && (
                    <div className="mt-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-green-400 font-medium">
                          Código aplicado! 10% de desconto em todos os pacotes
                        </span>
                      </div>
                    </div>
                  )}
                </motion.div>

                {/* Credit Packages */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {CREDIT_PACKAGES.map((pkg, index) => (
                    <motion.div
                      key={pkg.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`
                        relative admin-card p-6 hover:border-blue-500/40 transition-all cursor-pointer
                        ${pkg.popular ? 'border-blue-500/50 bg-gradient-to-b from-blue-500/5 to-purple-500/5' : ''}
                      `}
                    >
                      
                      {/* Popular Badge */}
                      {pkg.popular && (
                        <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white">
                          <Star className="w-3 h-3 mr-1" />
                          Mais Popular
                        </Badge>
                      )}

                      {/* Discount Badge */}
                      {pkg.discount && (
                        <Badge className="absolute top-4 right-4 bg-red-500 text-white">
                          -{pkg.discount}%
                        </Badge>
                      )}

                      {/* Package Info */}
                      <div className="text-center mb-6">
                        <h3 className="text-xl font-bold admin-text-blue mb-2">
                          {pkg.name}
                        </h3>
                        <p className="text-sm admin-text-smoke mb-4">
                          {pkg.description}
                        </p>

                        {/* Price */}
                        <div className="mb-4">
                          <div className="flex items-center justify-center gap-2">
                            <span className="text-3xl font-bold admin-text-blue">
                              {formatPrice(calculateDiscountedPrice(pkg.price))}
                            </span>
                            {(pkg.originalPrice || promoApplied) && (
                              <span className="text-lg line-through admin-text-smoke">
                                {formatPrice(pkg.originalPrice || pkg.price)}
                              </span>
                            )}
                          </div>
                          
                          <div className="flex items-center justify-center gap-2 mt-2">
                            <Zap className="w-4 h-4 admin-text-orange" />
                            <span className="text-lg font-bold admin-text-orange">
                              {formatCredits(pkg.credits)} créditos
                            </span>
                          </div>

                          {/* Cost per credit */}
                          <p className="text-xs admin-text-smoke mt-1">
                            {formatPrice(calculateDiscountedPrice(pkg.price) / pkg.credits)}/crédito
                          </p>
                        </div>

                        {/* Bonus */}
                        {pkg.bonus && (
                          <div className="flex items-center justify-center gap-2 mb-4">
                            <Gift className="w-4 h-4 admin-text-orange" />
                            <span className="text-sm font-bold admin-text-orange">
                              +{pkg.bonus} créditos bônus!
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Features */}
                      <div className="space-y-2 mb-6">
                        {pkg.features.map((feature, i) => (
                          <div key={i} className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                            <span className="text-sm admin-text-smoke">{feature}</span>
                          </div>
                        ))}
                      </div>

                      {/* CTA Button */}
                      <Button
                        onClick={() => handlePurchase(pkg.id, 'credits')}
                        className={`w-full ${
                          pkg.popular ? 'admin-bg-blue' : 'admin-bg-blue opacity-80'
                        } hover:opacity-90`}
                        disabled={processing && selectedProduct === pkg.id}
                      >
                        {processing && selectedProduct === pkg.id ? (
                          'Processando...'
                        ) : (
                          <>
                            Comprar agora
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </>
                        )}
                      </Button>
                    </motion.div>
                  ))}
                </div>

                {/* Value Proposition */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="admin-card p-8 text-center"
                >
                  <h3 className="text-2xl font-bold admin-text-blue mb-4">
                    Por que escolher nossos créditos?
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <div className="w-12 h-12 admin-bg-blue rounded-xl flex items-center justify-center mx-auto mb-3">
                        <Zap className="w-6 h-6 text-white" />
                      </div>
                      <h4 className="font-semibold admin-text-blue mb-2">Sem expiração</h4>
                      <p className="text-sm admin-text-smoke">
                        Seus créditos nunca expiram. Use quando quiser.
                      </p>
                    </div>
                    
                    <div>
                      <div className="w-12 h-12 admin-bg-orange rounded-xl flex items-center justify-center mx-auto mb-3">
                        <Shield className="w-6 h-6 text-white" />
                      </div>
                      <h4 className="font-semibold admin-text-blue mb-2">Transparência total</h4>
                      <p className="text-sm admin-text-smoke">
                        Veja exatamente quanto cada ação custa antes de usar.
                      </p>
                    </div>
                    
                    <div>
                      <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-3">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      <h4 className="font-semibold admin-text-blue mb-2">Melhor custo-benefício</h4>
                      <p className="text-sm admin-text-smoke">
                        Pacotes maiores oferecem até 37% de economia.
                      </p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            {/* Plans Tab */}
            <TabsContent value="plans">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {PLANS.map((plan, index) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`
                      relative admin-card p-6 hover:border-blue-500/40 transition-all
                      ${plan.popular ? 'border-blue-500/50 bg-gradient-to-b from-blue-500/5 to-purple-500/5' : ''}
                    `}
                  >
                    
                    {plan.popular && (
                      <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white">
                        <Star className="w-3 h-3 mr-1" />
                        Mais Popular
                      </Badge>
                    )}

                    <div className="text-center mb-6">
                      <h3 className="text-2xl font-bold admin-text-blue mb-2">
                        {plan.name}
                      </h3>
                      <p className="admin-text-smoke mb-4">{plan.description}</p>

                      <div className="mb-4">
                        <span className="text-4xl font-bold admin-text-blue">
                          {formatPrice(plan.price)}
                        </span>
                        <span className="text-sm admin-text-smoke">/mês</span>
                      </div>

                      <div className="flex items-center justify-center gap-2">
                        <Zap className="w-4 h-4 admin-text-orange" />
                        <span className="font-bold admin-text-orange">
                          {plan.credits} créditos/mês
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2 mb-6">
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                          <span className="text-sm admin-text-smoke">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Button
                      onClick={() => handlePurchase(plan.id, 'plan')}
                      className={`w-full ${
                        plan.popular ? 'admin-bg-blue' : 'admin-bg-blue opacity-80'
                      } hover:opacity-90`}
                      disabled={processing && selectedProduct === plan.id}
                    >
                      {processing && selectedProduct === plan.id ? (
                        'Processando...'
                      ) : (
                        'Assinar plano'
                      )}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Add-ons Tab */}
            <TabsContent value="addons">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {ADDON_PRODUCTS.map((addon, index) => (
                  <motion.div
                    key={addon.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="admin-card p-6"
                  >
                    <div className="text-center mb-6">
                      <h3 className="text-xl font-bold admin-text-blue mb-2">
                        {addon.name}
                      </h3>
                      <p className="admin-text-smoke mb-4">{addon.description}</p>

                      <span className="text-3xl font-bold admin-text-blue">
                        {formatPrice(addon.price)}
                      </span>
                    </div>

                    <div className="space-y-2 mb-6">
                      {addon.features.map((feature, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                          <span className="text-sm admin-text-smoke">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <Button
                      onClick={() => handlePurchase(addon.id, 'credits')}
                      className="w-full admin-bg-orange hover:opacity-90"
                      disabled={processing && selectedProduct === addon.id}
                    >
                      {processing && selectedProduct === addon.id ? (
                        'Processando...'
                      ) : (
                        'Adicionar ao plano'
                      )}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}