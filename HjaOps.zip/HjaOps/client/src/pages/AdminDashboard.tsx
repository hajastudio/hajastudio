import { useState } from 'react';
import { motion } from 'framer-motion';
import AdminHeader from '@/components/admin/AdminHeader';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminOverview from '@/components/admin/AdminOverview';
import AdminUsers from '@/components/admin/AdminUsers';
import AdminAgents from '@/components/admin/AdminAgents';
import AdminTransactions from '@/components/admin/AdminTransactions';
import AdminChats from '@/components/admin/AdminChats';
import AdminSettings from '@/components/admin/AdminSettings';
import AdminAffiliates from '@/components/admin/AdminAffiliates';
import ExportReports from '@/components/admin/ExportReports';

type AdminSection = 'overview' | 'chats' | 'agents' | 'users' | 'transactions' | 'affiliates' | 'reports' | 'settings';

export default function AdminDashboard() {
  const [activeSection, setActiveSection] = useState<AdminSection>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <AdminOverview />;
      case 'chats':
        return <AdminChats />;
      case 'agents':
        return <AdminAgents />;
      case 'users':
        return <AdminUsers />;
      case 'transactions':
        return <AdminTransactions />;
      case 'affiliates':
        return <AdminAffiliates />;
      case 'reports':
        return <ExportReports />;
      case 'settings':
        return <AdminSettings />;
      default:
        return <AdminOverview />;
    }
  };

  return (
    <div className="admin-theme min-h-screen">
      {/* Admin Header */}
      <AdminHeader 
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className="flex">
        {/* Admin Sidebar */}
        <AdminSidebar 
          isOpen={sidebarOpen}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
        />
        
        {/* Main Content */}
        <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-16'}`}>
          <motion.div 
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="p-6"
          >
            {renderContent()}
          </motion.div>
        </main>
      </div>
    </div>
  );
}