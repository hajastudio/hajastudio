import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { 
  CreditCard, 
  Search, 
  Filter, 
  Download,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';

interface Transaction {
  id: string;
  type: 'plan' | 'credits';
  amount: string;
  creditsAdded: number;
  status: 'pending' | 'completed' | 'failed';
  provider: string;
  createdAt: string;
  planId?: string;
}

export default function TransactionHistory() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['/api/transactions'],
    enabled: !!user,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'completed': return 'success';
      case 'pending': return 'warning';
      case 'failed': return 'destructive';
      default: return 'default';
    }
  };

  const formatCurrency = (amount: string) => {
    const value = parseFloat(amount) / 100;
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const filteredTransactions = transactions.filter((transaction: Transaction) => {
    const matchesSearch = searchTerm === '' || 
      transaction.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.type.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass border-hairline rounded-lg p-8 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-hja-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="smoke-text">Carregando transações...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-hja-bg py-8 px-4" data-testid="transaction-history-page">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl font-bold font-orbitron smoke-text mb-2">
            Histórico de Transações
          </h1>
          <p className="smoke-text-muted">
            Acompanhe todas as suas compras e transações
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 smoke-text-muted" />
                    <Input
                      placeholder="Buscar por ID ou tipo..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                      data-testid="input-search-transactions"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-3 py-2 border border-hja-border rounded-md bg-hja-surface smoke-text text-sm"
                    data-testid="select-status-filter"
                  >
                    <option value="all">Todos os Status</option>
                    <option value="completed">Concluído</option>
                    <option value="pending">Pendente</option>
                    <option value="failed">Falhou</option>
                  </select>

                  <Button variant="ghost" size="sm" data-testid="button-export">
                    <Download className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Summary Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-hja-primary/10 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-hja-primary" />
                </div>
                <div>
                  <div className="text-2xl font-bold smoke-text">
                    {transactions.length}
                  </div>
                  <div className="text-sm smoke-text-muted">Total de Transações</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <div className="text-2xl font-bold smoke-text">
                    {transactions.filter((t: Transaction) => t.status === 'completed').length}
                  </div>
                  <div className="text-sm smoke-text-muted">Concluídas</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-hja-accent/10 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-hja-accent" />
                </div>
                <div>
                  <div className="text-2xl font-bold smoke-text">
                    {transactions
                      .filter((t: Transaction) => t.status === 'completed')
                      .reduce((total: number, t: Transaction) => total + t.creditsAdded, 0)
                      .toLocaleString()}
                  </div>
                  <div className="text-sm smoke-text-muted">Créditos Adquiridos</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Transactions Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Transações Recentes
              </CardTitle>
              <CardDescription>
                {filteredTransactions.length} de {transactions.length} transações
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredTransactions.length === 0 ? (
                <div className="text-center py-12">
                  <CreditCard className="w-12 h-12 text-hja-muted mx-auto mb-4" />
                  <p className="smoke-text-muted">
                    {searchTerm || statusFilter !== 'all' 
                      ? 'Nenhuma transação encontrada com os filtros aplicados'
                      : 'Você ainda não tem transações'
                    }
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Tipo</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Créditos</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Data</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTransactions.map((transaction: Transaction) => (
                        <TableRow key={transaction.id} data-testid={`transaction-row-${transaction.id}`}>
                          <TableCell className="font-mono text-sm">
                            {transaction.id.slice(0, 8)}...
                          </TableCell>
                          <TableCell>
                            <Badge variant={transaction.type === 'plan' ? 'accent' : 'primary'}>
                              {transaction.type === 'plan' ? 'Plano' : 'Créditos'}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-semibold">
                            {formatCurrency(transaction.amount)}
                          </TableCell>
                          <TableCell>
                            <span className="text-hja-primary font-semibold">
                              +{transaction.creditsAdded.toLocaleString()}
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getStatusIcon(transaction.status)}
                              <Badge variant={getStatusVariant(transaction.status) as any}>
                                {transaction.status === 'completed' ? 'Concluído' :
                                 transaction.status === 'pending' ? 'Pendente' : 'Falhou'}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatDate(transaction.createdAt)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}