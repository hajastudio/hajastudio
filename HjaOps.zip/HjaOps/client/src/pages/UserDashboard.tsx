import { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart3, 
  CreditCard, 
  MessageSquare, 
  Trophy, 
  User,
  Settings,
  Bell,
  Plus,
  TrendingUp,
  Clock,
  Award
} from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/useAuth';
import OverviewSection from '@/components/dashboard/OverviewSection';
import ChatHistorySection from '@/components/dashboard/ChatHistorySection';
import TransactionsSection from '@/components/dashboard/TransactionsSection';
import GamificationSection from '@/components/dashboard/GamificationSection';

type DashboardTab = 'overview' | 'chats' | 'transactions' | 'gamification';

export default function UserDashboard() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');

  // Fetch dashboard data
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ['/api/user/dashboard'],
    enabled: !!user,
  });

  const tabs = [
    {
      id: 'overview' as DashboardTab,
      name: 'Visão Geral',
      icon: BarChart3,
      description: 'Resumo geral da sua conta'
    },
    {
      id: 'chats' as DashboardTab,
      name: 'Histórico',
      icon: MessageSquare,
      description: 'Suas conversas com os agentes'
    },
    {
      id: 'transactions' as DashboardTab,
      name: 'Transações',
      icon: CreditCard,
      description: 'Créditos e planos'
    },
    {
      id: 'gamification' as DashboardTab,
      name: 'Progressão',
      icon: Trophy,
      description: 'Badges e conquistas'
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewSection data={dashboardData} isLoading={isLoading} />;
      case 'chats':
        return <ChatHistorySection data={dashboardData} isLoading={isLoading} />;
      case 'transactions':
        return <TransactionsSection data={dashboardData} isLoading={isLoading} />;
      case 'gamification':
        return <GamificationSection data={dashboardData} isLoading={isLoading} />;
      default:
        return <OverviewSection data={dashboardData} isLoading={isLoading} />;
    }
  };

  return (
    <Layout showSidebar={true}>
      <div className="min-h-screen bg-black">
        {/* Header */}
        <div className="glass-morphism border-b border-[var(--smoke)]/20 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center neon-glow">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-orbitron font-bold text-white">
                  Dashboard Pessoal
                </h1>
                <p className="text-[var(--smoke)]/70">
                  Bem-vindo de volta, {user?.firstName || 'Usuário'}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
                data-testid="notifications-button"
              >
                <Bell className="w-5 h-5" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="p-3 glass-morphism rounded-xl text-[var(--smoke)] hover:text-[var(--blue)] transition-colors"
                data-testid="settings-button"
              >
                <Settings className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="mt-8">
            <div className="flex space-x-1 bg-[var(--smoke)]/5 p-1 rounded-2xl border border-[var(--smoke)]/10">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <motion.button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      relative flex-1 px-6 py-4 rounded-xl font-medium transition-all duration-300
                      ${activeTab === tab.id
                        ? 'text-white shadow-lg'
                        : 'text-[var(--smoke)]/70 hover:text-white'
                      }
                    `}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    data-testid={`tab-${tab.id}`}
                  >
                    {activeTab === tab.id && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute inset-0 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-xl neon-glow"
                        transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                    
                    <div className="relative flex items-center justify-center gap-3">
                      <Icon className="w-5 h-5" />
                      <div className="text-left hidden sm:block">
                        <div className="font-orbitron font-semibold">{tab.name}</div>
                        <div className="text-xs opacity-70">{tab.description}</div>
                      </div>
                      <div className="block sm:hidden font-orbitron font-semibold">
                        {tab.name}
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderTabContent()}
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}