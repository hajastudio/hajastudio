import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Activity, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign,
  Zap,
  Clock,
  Users,
  Target,
  Shield,
  Bell,
  Satellite,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import RealtimeMetrics from '@/components/techwatch/RealtimeMetrics';
import TechWatchFeed from '@/components/techwatch/TechWatchFeed';
import AlertsActions from '@/components/techwatch/AlertsActions';
import EconomyDashboard from '@/components/techwatch/EconomyDashboard';

type ActiveTab = 'metrics' | 'techwatch' | 'alerts' | 'economy';

interface SystemHealth {
  overall: number;
  lastScan: Date;
  activeIncidents: number;
  todayErrors: number;
  avgLatency: number;
  costToday: number;
  tokenUsage: number;
  fallbackRate: number;
}

export default function TechWatch() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('metrics');
  const [systemHealth, setSystemHealth] = useState<SystemHealth>({
    overall: 98.5,
    lastScan: new Date(),
    activeIncidents: 1,
    todayErrors: 12,
    avgLatency: 450,
    costToday: 67.45,
    tokenUsage: 24671,
    fallbackRate: 3.2
  });

  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      if (isLive) {
        setSystemHealth(prev => ({
          ...prev,
          lastScan: new Date(),
          avgLatency: prev.avgLatency + (Math.random() - 0.5) * 50,
          costToday: prev.costToday + Math.random() * 2,
          tokenUsage: prev.tokenUsage + Math.floor(Math.random() * 100),
          fallbackRate: Math.max(0, prev.fallbackRate + (Math.random() - 0.5) * 0.5)
        }));
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [isLive]);

  const tabs = [
    { 
      id: 'metrics', 
      label: 'Métricas RT', 
      icon: Activity, 
      description: 'Monitoramento em tempo real' 
    },
    { 
      id: 'techwatch', 
      label: 'TechWatch', 
      icon: Satellite, 
      description: 'Novidades e atualizações IA' 
    },
    { 
      id: 'alerts', 
      label: 'Alertas & Ações', 
      icon: Bell, 
      description: 'Gerenciamento de incidentes' 
    },
    { 
      id: 'economy', 
      label: 'Economia', 
      icon: DollarSign, 
      description: 'Análise financeira e conversões' 
    }
  ];

  const getHealthColor = (health: number) => {
    if (health >= 98) return 'text-green-400';
    if (health >= 95) return 'admin-text-orange';
    return 'text-red-400';
  };

  const getIncidentColor = (count: number) => {
    if (count === 0) return 'bg-green-500';
    if (count <= 2) return 'admin-bg-orange';
    return 'bg-red-500';
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'metrics':
        return <RealtimeMetrics data={systemHealth} />;
      case 'techwatch':
        return <TechWatchFeed />;
      case 'alerts':
        return <AlertsActions data={systemHealth} />;
      case 'economy':
        return <EconomyDashboard />;
      default:
        return <RealtimeMetrics data={systemHealth} />;
    }
  };

  return (
    <div className="min-h-screen admin-theme">
      
      {/* Header - Command Center Style */}
      <header className="admin-sidebar border-b border-blue-500/20 sticky top-0 z-50">
        <div className="flex items-center justify-between px-6 py-4">
          
          {/* Left Section - HVC TechWatch Branding */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="admin-glow-blue w-12 h-12 rounded-xl flex items-center justify-center admin-pulse">
                <Satellite className="w-6 h-6 text-white" />
              </div>
              {isLive && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold admin-text-blue">HVC TechWatch</h1>
              <div className="flex items-center gap-3">
                <p className="text-sm admin-text-smoke">Centro de Comando • Vigilância 24/7</p>
                <Badge className={`${isLive ? 'bg-red-500' : 'bg-gray-500'} text-white text-xs`}>
                  {isLive ? '🔴 LIVE' : '⏸ PAUSED'}
                </Badge>
              </div>
            </div>
          </div>

          {/* Center Section - Critical Status */}
          <div className="hidden lg:flex items-center gap-8">
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">System Health</p>
              <div className="flex items-center gap-2">
                <Shield className={`w-4 h-4 ${getHealthColor(systemHealth.overall)}`} />
                <span className={`text-lg font-bold ${getHealthColor(systemHealth.overall)}`}>
                  {systemHealth.overall.toFixed(1)}%
                </span>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">Incidentes Ativos</p>
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${getIncidentColor(systemHealth.activeIncidents)}`} />
                <span className={`font-bold ${
                  systemHealth.activeIncidents === 0 ? 'text-green-400' : 
                  systemHealth.activeIncidents <= 2 ? 'admin-text-orange' : 'text-red-400'
                }`}>
                  {systemHealth.activeIncidents}
                </span>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-xs admin-text-smoke mb-1">Último Scan</p>
              <span className="text-sm font-medium admin-text-blue">
                {systemHealth.lastScan.toLocaleTimeString()}
              </span>
            </div>
          </div>

          {/* Right Section - Quick Actions */}
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setIsLive(!isLive)}
              className={`${isLive ? 'admin-bg-orange hover:opacity-90' : 'admin-bg-blue hover:opacity-90'}`}
              data-testid="toggle-live-monitoring"
            >
              {isLive ? 'Pausar' : 'Ativar'} Monitoramento
            </Button>
            
            <Button 
              className="bg-red-600 hover:bg-red-700"
              data-testid="emergency-protocol"
            >
              <AlertTriangle className="w-4 h-4 mr-2" />
              Protocolo Emergência
            </Button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="border-b border-blue-500/20 bg-black/30">
        <div className="flex items-center px-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as ActiveTab)}
              className={`flex items-center gap-3 px-6 py-4 border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-blue-500 admin-text-blue bg-blue-500/10'
                  : 'border-transparent admin-text-smoke hover:admin-text-blue hover:bg-blue-500/5'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <tab.icon className="w-5 h-5" />
              <div className="text-left">
                <div className="font-semibold">{tab.label}</div>
                <div className="text-xs opacity-70">{tab.description}</div>
              </div>
            </button>
          ))}
        </div>
      </nav>

      {/* Quick Status Bar */}
      <div className="bg-black/20 border-b border-blue-500/10">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 admin-text-smoke" />
              <span className="text-sm admin-text-smoke">
                Latência: <span className="font-bold admin-text-blue">{systemHealth.avgLatency.toFixed(0)}ms</span>
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 admin-text-orange" />
              <span className="text-sm admin-text-smoke">
                Tokens: <span className="font-bold admin-text-orange">{systemHealth.tokenUsage.toLocaleString()}</span>
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-400" />
              <span className="text-sm admin-text-smoke">
                Custo: <span className="font-bold text-green-400">R$ {systemHealth.costToday.toFixed(2)}</span>
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 admin-text-blue" />
              <span className="text-sm admin-text-smoke">
                Fallback: <span className="font-bold admin-text-blue">{systemHealth.fallbackRate.toFixed(1)}%</span>
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-xs admin-text-smoke">Todos os sistemas operacionais</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="p-8">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderContent()}
        </motion.div>
      </main>
    </div>
  );
}