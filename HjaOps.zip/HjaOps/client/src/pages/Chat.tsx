import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import ContextHelpButton from '@/components/ContextHelpButton';

interface Agent {
  id: string;
  name: string;
  description: string;
  prompt: string;
  defaultModel: string;
  active: boolean;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  tokensUsed?: number;
}

interface Chat {
  id: string;
  title: string;
  messages: Message[];
  agentId: string;
  modelUsed: string;
  tokens: number;
  createdAt: string;
}

export default function Chat() {
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [currentChat, setCurrentChat] = useState<Chat | null>(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Buscar agentes disponíveis
  const { data: agents = [], isLoading: agentsLoading } = useQuery({
    queryKey: ['/api/agents'],
    queryFn: () => apiRequest('/api/agents').then(res => res.agents),
  });

  // Buscar histórico de chats do usuário
  const { data: chatsData = { chats: [] }, isLoading: chatsLoading } = useQuery({
    queryKey: ['/api/chats'],
    queryFn: () => apiRequest('/api/chats'),
  });

  // Mutação para enviar mensagem
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { message: string; agentId: string }) => {
      const response = await apiRequest('/api/chat', {
        method: 'POST',
        body: JSON.stringify(data),
      });
      return response;
    },
    onSuccess: (data) => {
      // Adicionar mensagem do usuário
      const userMessage: Message = {
        id: `user-${Date.now()}`,
        role: 'user',
        content: message,
        timestamp: new Date().toISOString(),
      };

      // Adicionar resposta do agente
      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.response,
        timestamp: new Date().toISOString(),
        tokensUsed: data.tokensUsed,
      };

      setMessages(prev => [...prev, userMessage, assistantMessage]);
      setMessage('');
      
      toast({
        title: "Mensagem enviada!",
        description: `${data.tokensUsed} tokens utilizados • ${data.creditsUsed} créditos gastos`,
      });

      // Invalidar cache dos chats
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar mensagem",
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!message.trim() || !selectedAgent) return;
    
    sendMessageMutation.mutate({
      message: message.trim(),
      agentId: selectedAgent.id,
    });
  };

  const handleSelectAgent = (agent: Agent) => {
    setSelectedAgent(agent);
    setMessages([]);
    setCurrentChat(null);
  };

  const handleLoadChat = (chat: Chat) => {
    setCurrentChat(chat);
    const selectedAgentForChat = agents.find(a => a.id === chat.agentId);
    if (selectedAgentForChat) {
      setSelectedAgent(selectedAgentForChat);
    }
    
    // Parse das mensagens
    let parsedMessages: Message[] = [];
    try {
      parsedMessages = typeof chat.messages === 'string' 
        ? JSON.parse(chat.messages) 
        : chat.messages;
    } catch (error) {
      console.error('Erro ao parsear mensagens:', error);
    }
    
    setMessages(parsedMessages);
  };

  if (agentsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando agentes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen">
        
        {/* Sidebar - Agentes & Histórico */}
        <div className="w-80 border-r border-border bg-card/50">
          
          {/* Header */}
          <div className="p-6 border-b border-border">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-black font-bold text-sm">H</span>
              </div>
              <h1 className="text-xl font-bold gradient-text">Hja²Ops</h1>
            </div>
            
            <h2 className="text-lg font-semibold mb-2">Selecionar Agente</h2>
            
            {/* Grid de Agentes */}
            <div className="space-y-2">
              {agents.map((agent: Agent) => (
                <Card
                  key={agent.id}
                  className={`p-3 cursor-pointer netflix-card transition-all ${
                    selectedAgent?.id === agent.id ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => handleSelectAgent(agent)}
                  data-testid={`agent-card-${agent.id}`}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-primary text-black text-xs">
                        {agent.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm truncate">{agent.name}</h3>
                      <p className="text-xs text-muted-foreground truncate">{agent.description}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Histórico de Chats */}
          <div className="p-6">
            <h3 className="text-sm font-semibold mb-3 text-muted-foreground">Histórico</h3>
            
            {chatsLoading ? (
              <div className="text-center py-4">
                <div className="animate-spin w-4 h-4 border border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
                <p className="text-xs text-muted-foreground">Carregando...</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {chatsData.chats.map((chat: Chat) => (
                  <Card
                    key={chat.id}
                    className={`p-3 cursor-pointer netflix-card transition-all text-sm ${
                      currentChat?.id === chat.id ? 'ring-1 ring-primary/50' : ''
                    }`}
                    onClick={() => handleLoadChat(chat)}
                    data-testid={`chat-history-${chat.id}`}
                  >
                    <h4 className="font-medium truncate mb-1">{chat.title}</h4>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{new Date(chat.createdAt).toLocaleDateString('pt-BR')}</span>
                      <Badge variant="secondary" className="text-xs">
                        {chat.tokens} tokens
                      </Badge>
                    </div>
                  </Card>
                ))}
                
                {chatsData.chats.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    Nenhum chat ainda
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Área Principal - Chat */}
        <div className="flex-1 flex flex-col">
          
          {/* Header do Chat */}
          {selectedAgent && (
            <div className="p-4 border-b border-border bg-card/30">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-primary text-black">
                    {selectedAgent.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-semibold">{selectedAgent.name}</h2>
                  <p className="text-sm text-muted-foreground">{selectedAgent.description}</p>
                </div>
                <div className="ml-auto">
                  <Badge variant="outline" className="text-xs">
                    {selectedAgent.defaultModel}
                  </Badge>
                </div>
              </div>
            </div>
          )}

          {/* Mensagens */}
          <div className="flex-1 overflow-y-auto p-4">
            {!selectedAgent ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-robot text-2xl text-muted-foreground"></i>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Selecione um Agente</h3>
                  <p className="text-muted-foreground">
                    Escolha um dos agentes especializados para começar a conversar
                  </p>
                </div>
              </div>
            ) : messages.length === 0 ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <Avatar className="w-16 h-16 mx-auto mb-4">
                    <AvatarFallback className="bg-primary text-black text-lg">
                      {selectedAgent.name.split(' ').map(n => n[0]).join('').substring(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-semibold mb-2">Olá! Sou o {selectedAgent.name}</h3>
                  <p className="text-muted-foreground max-w-md">
                    {selectedAgent.description}. Como posso te ajudar hoje?
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-6 max-w-4xl mx-auto">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    {msg.role === 'assistant' && (
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-primary text-black text-xs">
                          AI
                        </AvatarFallback>
                      </Avatar>
                    )}
                    
                    <div className={`max-w-2xl ${msg.role === 'user' ? 'order-last' : ''}`}>
                      <Card className={`p-4 ${
                        msg.role === 'user' 
                          ? 'bg-primary/10 border-primary/20 chat-bubble user' 
                          : 'netflix-card chat-bubble agent'
                      }`}>
                        <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                        
                        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                          <span>{new Date(msg.timestamp).toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', minute: '2-digit' 
                          })}</span>
                          {msg.tokensUsed && (
                            <Badge variant="secondary" className="text-xs">
                              {msg.tokensUsed} tokens
                            </Badge>
                          )}
                        </div>
                      </Card>
                    </div>

                    {msg.role === 'user' && (
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-secondary">
                          U
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Input de Mensagem */}
          {selectedAgent && (
            <div className="p-4 border-t border-border bg-card/30">
              <div className="flex gap-3 max-w-4xl mx-auto">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={`Conversar com ${selectedAgent.name}...`}
                  className="flex-1"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  disabled={sendMessageMutation.isPending}
                  data-testid="input-message"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!message.trim() || sendMessageMutation.isPending}
                  className="neon-glow"
                  data-testid="button-send"
                >
                  {sendMessageMutation.isPending ? (
                    <div className="animate-spin w-4 h-4 border border-current border-t-transparent rounded-full"></div>
                  ) : (
                    <i className="fas fa-paper-plane"></i>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Context Help Button - Chat specific */}
      <ContextHelpButton 
        context="chat" 
        position="bottom-right"
      />
    </div>
  );
}