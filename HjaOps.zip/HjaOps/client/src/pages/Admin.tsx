import { motion } from 'framer-motion';
import { Shield, Users, Activity } from 'lucide-react';
import Layout from '@/components/layout/Layout';
import { useAuth } from '@/hooks/useAuth';

export default function Admin() {
  const { user } = useAuth();

  return (
    <Layout showSidebar={true}>
      <div className="bg-black min-h-screen p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="w-16 h-16 bg-gradient-to-br from-[var(--blue)] to-[var(--orange)] rounded-2xl flex items-center justify-center mx-auto mb-4 neon-glow">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-orbitron font-bold text-white mb-2">
            Admin Dashboard
          </h1>
          <p className="text-[var(--smoke)]/70 mb-6">
            Esta é a versão legacy. 
          </p>
          <motion.a
            href="/admin-new"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[var(--blue)] to-[var(--orange)] rounded-2xl text-white font-medium neon-glow"
          >
            <Activity className="w-5 h-5" />
            Ir para o Novo Dashboard Admin
          </motion.a>
        </motion.div>
      </div>
    </Layout>
  );
}