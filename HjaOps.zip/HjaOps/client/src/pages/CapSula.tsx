import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { User, MessageCircle, TrendingUp, Clock, Pin, Trash2, Image as ImageIcon, Link2, Plus } from 'lucide-react';

interface Capsule {
  id: string;
  userId: string;
  content: string;
  mediaUrl?: string;
  linkUrl?: string;
  reactionsCount: number;
  commentsCount: number;
  isPinned: boolean;
  createdAt: string;
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
}

interface Comment {
  id: string;
  text: string;
  createdAt: string;
  user: {
    id: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
}

interface Reaction {
  type: '🔥' | '❤️' | '👏';
}

const REACTION_TYPES = ['🔥', '❤️', '👏'] as const;

export default function CapSula() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newPost, setNewPost] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'popular'>('recent');
  const [showComments, setShowComments] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [showNewPostForm, setShowNewPostForm] = useState(false);

  // Fetch capsules
  const { data: capsules = [], isLoading } = useQuery({
    queryKey: ['/api/capsules', sortBy],
    queryFn: () => apiRequest(`/api/capsules?sort=${sortBy}&limit=50`),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch comments for active capsule
  const { data: comments = [] } = useQuery({
    queryKey: ['/api/capsules', showComments, 'comments'],
    queryFn: () => showComments ? apiRequest(`/api/capsules/${showComments}/comments`) : [],
    enabled: !!showComments,
  });

  // Create capsule mutation
  const createCapsuleMutation = useMutation({
    mutationFn: (data: { content: string; mediaUrl?: string; linkUrl?: string }) =>
      apiRequest('/api/capsules', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/capsules'] });
      setNewPost('');
      setMediaUrl('');
      setLinkUrl('');
      setShowNewPostForm(false);
      toast({
        title: "Cápsula criada!",
        description: "Sua cápsula foi publicada no feed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: error.message || "Erro ao criar cápsula",
        variant: "destructive",
      });
    },
  });

  // React mutation
  const reactMutation = useMutation({
    mutationFn: ({ capsuleId, type }: { capsuleId: string; type: string }) =>
      apiRequest(`/api/capsules/${capsuleId}/react`, {
        method: 'POST',
        body: JSON.stringify({ type }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/capsules'] });
    },
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: ({ capsuleId, text }: { capsuleId: string; text: string }) =>
      apiRequest(`/api/capsules/${capsuleId}/comment`, {
        method: 'POST',
        body: JSON.stringify({ text }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/capsules'] });
      queryClient.invalidateQueries({ queryKey: ['/api/capsules', showComments, 'comments'] });
      setCommentText('');
      toast({
        title: "Comentário adicionado!",
      });
    },
  });

  const handleCreatePost = () => {
    if (!newPost.trim()) return;
    if (newPost.length > 500) {
      toast({
        title: "Erro",
        description: "Máximo 500 caracteres por cápsula",
        variant: "destructive",
      });
      return;
    }

    createCapsuleMutation.mutate({
      content: newPost,
      mediaUrl: mediaUrl || undefined,
      linkUrl: linkUrl || undefined,
    });
  };

  const handleReact = (capsuleId: string, type: string) => {
    if (!isAuthenticated) {
      toast({
        title: "Login necessário",
        description: "Faça login para reagir",
        variant: "destructive",
      });
      return;
    }
    reactMutation.mutate({ capsuleId, type });
  };

  const handleComment = (capsuleId: string) => {
    if (!commentText.trim()) return;
    if (commentText.length > 300) {
      toast({
        title: "Erro",
        description: "Máximo 300 caracteres por comentário",
        variant: "destructive",
      });
      return;
    }

    commentMutation.mutate({ capsuleId, text: commentText });
  };

  const formatName = (user: Capsule['user']) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user.email.split('@')[0];
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-[#00f3ff] mx-auto mb-4"></div>
          <p className="text-[#00f3ff] text-lg">Carregando feed...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-gray-800 bg-black/90 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-[#00f3ff] to-[#FF740B] bg-clip-text text-transparent">
                CapS'ula
              </h1>
              <Badge variant="outline" className="border-[#00f3ff] text-[#00f3ff]">
                Social Feed
              </Badge>
            </div>
            
            {/* Sort Toggle */}
            <div className="flex gap-2">
              <Button
                variant={sortBy === 'recent' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSortBy('recent')}
                className={`${sortBy === 'recent' 
                  ? 'bg-[#00f3ff] text-black hover:bg-[#00f3ff]/80' 
                  : 'text-white hover:bg-gray-800'
                }`}
                data-testid="button-sort-recent"
              >
                <Clock className="w-4 h-4 mr-1" />
                Recente
              </Button>
              <Button
                variant={sortBy === 'popular' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSortBy('popular')}
                className={`${sortBy === 'popular' 
                  ? 'bg-[#FF740B] text-black hover:bg-[#FF740B]/80' 
                  : 'text-white hover:bg-gray-800'
                }`}
                data-testid="button-sort-popular"
              >
                <TrendingUp className="w-4 h-4 mr-1" />
                Popular
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* New Post Section */}
        {isAuthenticated && (
          <Card className="mb-6 bg-gray-900/50 border-gray-700">
            {!showNewPostForm ? (
              <div className="p-4">
                <Button
                  onClick={() => setShowNewPostForm(true)}
                  className="w-full bg-gradient-to-r from-[#00f3ff] to-[#FF740B] text-black hover:opacity-90 transition-opacity"
                  data-testid="button-new-post"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Criar nova cápsula
                </Button>
              </div>
            ) : (
              <div className="p-4 space-y-4">
                <Textarea
                  placeholder="Compartilhe seus pensamentos... (máx. 500 caracteres)"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="bg-black border-gray-600 text-white resize-none min-h-[100px] focus:border-[#00f3ff]"
                  maxLength={500}
                  data-testid="textarea-new-post"
                />
                
                <div className="flex gap-2">
                  <Input
                    placeholder="URL da imagem (opcional)"
                    value={mediaUrl}
                    onChange={(e) => setMediaUrl(e.target.value)}
                    className="bg-black border-gray-600 text-white flex-1 focus:border-[#00f3ff]"
                    data-testid="input-media-url"
                  />
                  <Input
                    placeholder="Link externo (opcional)"
                    value={linkUrl}
                    onChange={(e) => setLinkUrl(e.target.value)}
                    className="bg-black border-gray-600 text-white flex-1 focus:border-[#00f3ff]"
                    data-testid="input-link-url"
                  />
                </div>

                <div className="flex justify-between items-center">
                  <div className="text-sm text-gray-400">
                    {newPost.length}/500 caracteres
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setShowNewPostForm(false);
                        setNewPost('');
                        setMediaUrl('');
                        setLinkUrl('');
                      }}
                      data-testid="button-cancel-post"
                    >
                      Cancelar
                    </Button>
                    <Button
                      onClick={handleCreatePost}
                      disabled={!newPost.trim() || createCapsuleMutation.isPending}
                      className="bg-[#00f3ff] text-black hover:bg-[#00f3ff]/80"
                      data-testid="button-submit-post"
                    >
                      {createCapsuleMutation.isPending ? 'Publicando...' : 'Publicar'}
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Card>
        )}

        {/* Feed */}
        <div className="space-y-4">
          {capsules.map((capsule: Capsule) => (
            <Card 
              key={capsule.id} 
              className={`bg-gray-900/50 border-gray-700 ${capsule.isPinned ? 'border-[#FF740B] shadow-lg shadow-[#FF740B]/20' : ''}`}
              data-testid={`capsule-${capsule.id}`}
            >
              <div className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#00f3ff] to-[#FF740B] flex items-center justify-center">
                      {capsule.user.profileImageUrl ? (
                        <img 
                          src={capsule.user.profileImageUrl} 
                          alt={formatName(capsule.user)}
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        <User className="w-5 h-5 text-black" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white" data-testid={`text-author-${capsule.id}`}>
                          {formatName(capsule.user)}
                        </span>
                        {capsule.isPinned && (
                          <Pin className="w-4 h-4 text-[#FF740B]" data-testid={`icon-pinned-${capsule.id}`} />
                        )}
                      </div>
                      <span className="text-sm text-gray-400" data-testid={`text-time-${capsule.id}`}>
                        {formatDistanceToNow(new Date(capsule.createdAt), { 
                          addSuffix: true, 
                          locale: ptBR 
                        })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="mb-4">
                  <p className="text-white whitespace-pre-wrap mb-3" data-testid={`text-content-${capsule.id}`}>
                    {capsule.content}
                  </p>
                  
                  {/* Media */}
                  {capsule.mediaUrl && (
                    <div className="mb-3">
                      <img 
                        src={capsule.mediaUrl} 
                        alt="Mídia da cápsula"
                        className="max-w-full h-auto rounded-lg border border-gray-600"
                        data-testid={`img-media-${capsule.id}`}
                      />
                    </div>
                  )}

                  {/* External Link */}
                  {capsule.linkUrl && (
                    <a 
                      href={capsule.linkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-[#00f3ff] hover:underline"
                      data-testid={`link-external-${capsule.id}`}
                    >
                      <Link2 className="w-4 h-4" />
                      {capsule.linkUrl}
                    </a>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-3 border-t border-gray-700">
                  <div className="flex items-center gap-4">
                    {/* Reactions */}
                    <div className="flex items-center gap-2">
                      {REACTION_TYPES.map((reaction) => (
                        <Button
                          key={reaction}
                          variant="ghost"
                          size="sm"
                          onClick={() => handleReact(capsule.id, reaction)}
                          className="text-lg hover:bg-gray-800 p-2"
                          data-testid={`button-react-${reaction}-${capsule.id}`}
                        >
                          {reaction}
                        </Button>
                      ))}
                      <span className="text-sm text-gray-400" data-testid={`text-reactions-count-${capsule.id}`}>
                        {capsule.reactionsCount}
                      </span>
                    </div>

                    {/* Comments */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowComments(showComments === capsule.id ? null : capsule.id)}
                      className="text-gray-400 hover:text-white hover:bg-gray-800"
                      data-testid={`button-comments-${capsule.id}`}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      {capsule.commentsCount}
                    </Button>
                  </div>
                </div>

                {/* Comments Section */}
                {showComments === capsule.id && (
                  <div className="mt-4 pt-4 border-t border-gray-700">
                    {/* New Comment */}
                    {isAuthenticated && (
                      <div className="flex gap-3 mb-4">
                        <Textarea
                          placeholder="Escreva um comentário... (máx. 300 caracteres)"
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          className="bg-black border-gray-600 text-white resize-none min-h-[60px] focus:border-[#00f3ff]"
                          maxLength={300}
                          data-testid={`textarea-comment-${capsule.id}`}
                        />
                        <Button
                          onClick={() => handleComment(capsule.id)}
                          disabled={!commentText.trim() || commentMutation.isPending}
                          className="bg-[#00f3ff] text-black hover:bg-[#00f3ff]/80 whitespace-nowrap"
                          data-testid={`button-submit-comment-${capsule.id}`}
                        >
                          Comentar
                        </Button>
                      </div>
                    )}

                    {/* Comments List */}
                    <div className="space-y-3">
                      {comments.map((comment: Comment) => (
                        <div key={comment.id} className="flex gap-3" data-testid={`comment-${comment.id}`}>
                          <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#00f3ff] to-[#FF740B] flex items-center justify-center flex-shrink-0">
                            {comment.user.profileImageUrl ? (
                              <img 
                                src={comment.user.profileImageUrl} 
                                alt={formatName(comment.user)}
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              <User className="w-4 h-4 text-black" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="bg-gray-800 rounded-lg p-3">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-sm text-white" data-testid={`text-comment-author-${comment.id}`}>
                                  {formatName(comment.user)}
                                </span>
                                <span className="text-xs text-gray-400" data-testid={`text-comment-time-${comment.id}`}>
                                  {formatDistanceToNow(new Date(comment.createdAt), { 
                                    addSuffix: true, 
                                    locale: ptBR 
                                  })}
                                </span>
                              </div>
                              <p className="text-sm text-gray-200" data-testid={`text-comment-content-${comment.id}`}>
                                {comment.text}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {capsules.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-[#00f3ff] to-[#FF740B] flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-8 h-8 text-black" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Nenhuma cápsula ainda</h3>
            <p className="text-gray-400 mb-4">Seja o primeiro a compartilhar algo no feed!</p>
            {isAuthenticated && (
              <Button
                onClick={() => setShowNewPostForm(true)}
                className="bg-gradient-to-r from-[#00f3ff] to-[#FF740B] text-black hover:opacity-90"
                data-testid="button-first-post"
              >
                Criar primeira cápsula
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}