import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Eye, TrendingUp, Award, Star } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/useAuth";
import type { AffiliateProduct } from "@shared/schema";

export default function Vitrine() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const { isAuthenticated } = useAuth();

  const { data: products, isLoading } = useQuery({
    queryKey: ["/api/affiliate/products"],
  });

  const { data: featuredProducts } = useQuery({
    queryKey: ["/api/affiliate/products/featured"],
  });

  const { data: affiliateStats } = useQuery<{
    totalTokensEarned: number;
    clicksToday: number;
  }>({
    queryKey: ["/api/affiliate/stats"],
    enabled: isAuthenticated,
  });

  // Track product impressions when they come into view
  const trackImpression = async (productId: string) => {
    try {
      await fetch(`/api/affiliate/products/${productId}/impression`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      console.error("Error tracking impression:", error);
    }
  };

  // Get unique categories
  const categories = Array.from(new Set((products as AffiliateProduct[])?.map((p: AffiliateProduct) => p.category) || []));

  const handleProductClick = async (product: AffiliateProduct) => {
    try {
      // Track click using the new API
      const response = await fetch(`/api/affiliate/products/${product.id}/click`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Show token notification if earned
        if (data.tokensAwarded > 0) {
          // Create a temporary notification
          const notification = document.createElement('div');
          notification.className = 'fixed top-4 right-4 z-50 bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-6 py-3 rounded-lg shadow-lg animate-bounce';
          notification.innerHTML = `<div class="flex items-center space-x-2"><span>🎉</span><span>+${data.tokensAwarded} Haja® token ganho!</span></div>`;
          document.body.appendChild(notification);
          
          setTimeout(() => {
            notification.remove();
            // Refetch stats to update display
            window.location.reload();
          }, 3000);
        }
        
        if (data.affiliateUrl) {
          window.open(data.affiliateUrl, '_blank');
        }
      }
    } catch (error) {
      console.error("Error tracking click:", error);
      // Still open the link if tracking fails
      window.open(product.affiliateUrl, '_blank');
    }
  };

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(numPrice);
  };

  const ProductCard = ({ product }: { product: AffiliateProduct }) => {
    const cardRef = useRef<HTMLDivElement>(null);
    const [impressionTracked, setImpressionTracked] = useState(false);

    useEffect(() => {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting && !impressionTracked) {
              trackImpression(product.id);
              setImpressionTracked(true);
            }
          });
        },
        { threshold: 0.5 } // Track when 50% of card is visible
      );

      if (cardRef.current) {
        observer.observe(cardRef.current);
      }

      return () => observer.disconnect();
    }, [product.id, impressionTracked]);

    return (
      <Card ref={cardRef}
            className="hv-card-netflix group cursor-pointer bg-black/30 border-[#00CCFF]/30 backdrop-blur-md"
            onClick={() => handleProductClick(product)}
            data-testid={`card-product-${product.id}`}>
      <div className="p-0">
        {/* Image */}
        <div className="relative overflow-hidden rounded-t-lg">
          <img 
            src={product.imageUrl} 
            alt={product.title}
            className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
            data-testid={`img-product-${product.id}`}
          />
          {product.featured && (
            <Badge className="absolute top-2 left-2 bg-gradient-to-r from-[#FF740B] to-red-500 text-white border-0 shadow-lg"
                   data-testid={`badge-featured-${product.id}`}>
              <TrendingUp className="w-3 h-3 mr-1" />
              Destaque
            </Badge>
          )}
          <Badge className="absolute top-2 right-2 bg-black/80 text-[#00CCFF] border-[#00CCFF]/50 backdrop-blur-sm"
                 data-testid={`badge-category-${product.id}`}>
            {product.category}
          </Badge>
          
          {/* Glow effect overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#00CCFF]/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3 bg-gradient-to-b from-black/50 to-black/80 backdrop-blur-sm">
          <h3 className="font-bold text-lg text-white group-hover:text-[#00CCFF] transition-colors line-clamp-2 font-orbitron"
              data-testid={`text-title-${product.id}`}>
            {product.title}
          </h3>
          
          <p className="text-gray-300 text-sm line-clamp-3 hv-text"
             data-testid={`text-description-${product.id}`}>
            {product.description}
          </p>

          {/* Price */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              {product.originalPrice && (
                <span className="text-sm text-gray-400 line-through"
                      data-testid={`text-original-price-${product.id}`}>
                  {formatPrice(product.originalPrice)}
                </span>
              )}
              <div className="text-xl font-bold text-[#FF740B] drop-shadow-lg"
                   data-testid={`text-price-${product.id}`}>
                {formatPrice(product.price)}
              </div>
            </div>

            <Button 
              className="hv-btn-primary text-black font-semibold hover:scale-105 transform transition-all duration-300"
              data-testid={`button-buy-${product.id}`}>
              <ExternalLink className="w-4 h-4 mr-2" />
              Comprar no ML
            </Button>
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {product.tags.map((tag, index) => (
                <Badge 
                  key={index}
                  variant="outline" 
                  className="text-xs border-[#00CCFF]/50 text-[#00CCFF] bg-black/30 backdrop-blur-sm"
                  data-testid={`badge-tag-${product.id}-${index}`}>
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <div className="h-12 bg-gray-700 rounded-lg animate-pulse mx-auto max-w-md"></div>
            <div className="h-6 bg-gray-700 rounded-lg animate-pulse mx-auto max-w-2xl"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-80 bg-gray-700 rounded-lg animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const displayProducts = selectedCategory 
    ? (products as AffiliateProduct[])?.filter((p: AffiliateProduct) => p.category === selectedCategory) 
    : (products as AffiliateProduct[]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center space-y-4 mb-12">
          <h1 className="hv-title text-6xl bg-gradient-to-r from-[#00CCFF] via-[#FF740B] to-[#00CCFF] bg-clip-text text-transparent drop-shadow-lg"
              data-testid="text-title">
            🛒 Vitrine Mercado Livre
          </h1>
          <p className="text-xl hv-text max-w-3xl mx-auto"
             data-testid="text-description">
            Produtos selecionados do <span className="text-[#FF740B] font-semibold">Mercado Livre</span> com{' '}
            <span className="text-[#00CCFF] font-semibold">links de afiliado</span>. 
            Clique e ganhe <span className="text-yellow-400">+1 Haja® token</span> por produto!
          </p>
        </div>

        {/* Gamification Widget */}
        {isAuthenticated && affiliateStats && (
          <div className="mb-8 max-w-md mx-auto">
            <Card className="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border-cyan-500/30 backdrop-blur-sm"
                  data-testid="card-gamification-stats">
              <div className="p-6 text-center">
                <div className="flex items-center justify-center mb-4">
                  <Award className="w-8 h-8 text-yellow-400 mr-2" />
                  <h3 className="text-xl font-bold text-cyan-400">Haja® Tokens</h3>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-400"
                         data-testid="text-total-tokens">
                      {affiliateStats.totalTokensEarned || 0}
                    </div>
                    <div className="text-sm text-gray-300">Total Ganho</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-2xl font-bold text-cyan-400"
                         data-testid="text-clicks-today">
                      {affiliateStats.clicksToday || 0}
                    </div>
                    <div className="text-sm text-gray-300">Cliques Hoje</div>
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-black/30 rounded-lg">
                  <div className="flex items-center justify-center text-sm text-gray-300">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    Ganhe +1 token por produto clicado (1x por dia)
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Featured Products */}
        {featuredProducts && Array.isArray(featuredProducts) && featuredProducts.length > 0 && (
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-white mb-6 flex items-center"
                data-testid="text-featured-title">
              <TrendingUp className="w-8 h-8 mr-3 text-orange-500" />
              Produtos em Destaque
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(featuredProducts as AffiliateProduct[])?.map((product: AffiliateProduct) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}

        {/* Category Filter */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-3 justify-center">
            <Button
              variant={selectedCategory === "" ? "default" : "outline"}
              onClick={() => setSelectedCategory("")}
              className={selectedCategory === "" 
                ? "bg-cyan-600 text-white border-0" 
                : "border-gray-600 text-gray-300 hover:bg-gray-800"}
              data-testid="button-category-all">
              <Eye className="w-4 h-4 mr-2" />
              Todos ({(products as AffiliateProduct[])?.length || 0})
            </Button>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category 
                  ? "bg-cyan-600 text-white border-0" 
                  : "border-gray-600 text-gray-300 hover:bg-gray-800"}
                data-testid={`button-category-${category}`}>
                {category} ({(products as AffiliateProduct[])?.filter((p: AffiliateProduct) => p.category === category).length || 0})
              </Button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {displayProducts?.map((product: AffiliateProduct) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* Empty State */}
        {displayProducts?.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl font-bold text-white mb-2">
              Nenhum produto encontrado
            </h3>
            <p className="text-gray-400">
              Tente selecionar uma categoria diferente
            </p>
          </div>
        )}

        {/* Footer Info */}
        <div className="mt-16 text-center">
          <div className="bg-black/40 backdrop-blur-sm border border-cyan-500/30 rounded-xl p-6 max-w-2xl mx-auto">
            <h3 className="text-xl font-bold text-cyan-400 mb-3">
              💡 Como funciona?
            </h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Ao clicar em "Comprar", você será redirecionado para o Mercado Livre. 
              Nossa plataforma recebe uma pequena comissão que nos ajuda a manter 
              os serviços de IA gratuitos e melhorar constantemente a experiência!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}