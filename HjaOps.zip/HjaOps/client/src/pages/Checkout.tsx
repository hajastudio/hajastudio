import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Check, CreditCard, Zap, Star, Crown } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  price: string;
  creditsIncluded: number;
  perks: string[];
  isActive: boolean;
}

export default function Checkout() {
  const [customCredits, setCustomCredits] = useState(100);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: plans = [], isLoading } = useQuery({
    queryKey: ['/api/plans'],
  });

  const checkoutMutation = useMutation({
    mutationFn: async (data: { planId?: string; creditsAmount?: number }) => {
      const response = await fetch('/api/checkout/session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error('Failed to create checkout session');
      }

      return response.json();
    },
    onSuccess: (data) => {
      // Redirect to Mercado Pago
      window.location.href = data.checkoutUrl;
    },
    onError: (error) => {
      toast({
        title: 'Erro no Checkout',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handlePlanPurchase = (planId: string) => {
    checkoutMutation.mutate({ planId });
  };

  const handleCustomCredits = () => {
    if (customCredits < 10) {
      toast({
        title: 'Quantidade Mínima',
        description: 'Compra mínima de 10 créditos',
        variant: 'destructive',
      });
      return;
    }

    checkoutMutation.mutate({ creditsAmount: customCredits });
  };

  const getPlanIcon = (name: string) => {
    switch (name.toLowerCase()) {
      case 'básico': return <Zap className="w-6 h-6 text-hja-primary" />;
      case 'pro': return <Star className="w-6 h-6 text-hja-accent" />;
      case 'premium': return <Crown className="w-6 h-6 text-hja-warning" />;
      default: return <CreditCard className="w-6 h-6" />;
    }
  };

  const getBadgeVariant = (name: string) => {
    switch (name.toLowerCase()) {
      case 'básico': return 'primary';
      case 'pro': return 'accent';
      case 'premium': return 'warning';
      default: return 'default';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="glass border-hairline rounded-lg p-8 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-hja-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="smoke-text">Carregando planos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-hja-bg py-12 px-4" data-testid="checkout-page">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1 
            className="text-4xl font-bold font-orbitron smoke-text mb-4"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            Escolha Seu Plano
          </motion.h1>
          <motion.p 
            className="text-lg smoke-text-muted max-w-2xl mx-auto"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Desbloqueie todo o potencial dos agentes de IA com nossos planos flexíveis
          </motion.p>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan: Plan, index: number) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card 
                className={`relative overflow-hidden transition-all duration-300 hover:scale-105 hover:glow ${
                  plan.name === 'Pro' ? 'ring-2 ring-hja-accent' : ''
                }`}
                data-testid={`plan-card-${plan.name.toLowerCase()}`}
              >
                {plan.name === 'Pro' && (
                  <div className="absolute top-0 right-0 bg-hja-accent text-white px-3 py-1 text-xs font-bold rounded-bl-lg">
                    POPULAR
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <div className="flex items-center justify-center mb-4">
                    {getPlanIcon(plan.name)}
                  </div>
                  <CardTitle className="text-2xl font-orbitron">
                    {plan.name}
                  </CardTitle>
                  <CardDescription>
                    <div className="text-3xl font-bold smoke-text mt-2">
                      R$ {(parseFloat(plan.price) / 100).toFixed(2).replace('.', ',')}
                      <span className="text-sm font-normal smoke-text-muted">/mês</span>
                    </div>
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="text-center">
                    <Badge variant={getBadgeVariant(plan.name) as any} size="lg">
                      {plan.creditsIncluded.toLocaleString()} créditos mensais
                    </Badge>
                  </div>

                  <ul className="space-y-3">
                    {plan.perks.map((perk, perkIndex) => (
                      <li key={perkIndex} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-hja-primary mt-0.5 flex-shrink-0" />
                        <span className="text-sm smoke-text">{perk}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>

                <CardFooter>
                  <Button
                    variant={plan.name === 'Pro' ? 'accent' : 'primary'}
                    size="lg"
                    className="w-full"
                    onClick={() => handlePlanPurchase(plan.id)}
                    disabled={checkoutMutation.isPending}
                    data-testid={`button-buy-${plan.name.toLowerCase()}`}
                  >
                    {checkoutMutation.isPending ? 'Processando...' : `Assinar ${plan.name}`}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Custom Credits Section */}
        <motion.div
          className="max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <Card data-testid="custom-credits-card">
            <CardHeader className="text-center">
              <CardTitle className="text-xl font-orbitron flex items-center justify-center gap-2">
                <CreditCard className="w-6 h-6 text-hja-primary" />
                Compra Avulsa de Créditos
              </CardTitle>
              <CardDescription>
                Compre apenas os créditos que precisa - R$ 0,10 por crédito
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium smoke-text">
                  Quantidade de Créditos
                </label>
                <Input
                  type="number"
                  value={customCredits}
                  onChange={(e) => setCustomCredits(parseInt(e.target.value) || 0)}
                  min={10}
                  max={10000}
                  className="text-center text-lg"
                  data-testid="input-custom-credits"
                />
              </div>

              <div className="text-center p-4 glass border-hairline rounded-lg">
                <div className="text-2xl font-bold smoke-text">
                  R$ {(customCredits * 0.10).toFixed(2).replace('.', ',')}
                </div>
                <div className="text-sm smoke-text-muted">
                  {customCredits.toLocaleString()} créditos
                </div>
              </div>
            </CardContent>

            <CardFooter>
              <Button
                variant="ghost"
                size="lg"
                className="w-full"
                onClick={handleCustomCredits}
                disabled={checkoutMutation.isPending || customCredits < 10}
                data-testid="button-buy-custom-credits"
              >
                {checkoutMutation.isPending ? 'Processando...' : 'Comprar Créditos'}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>

        {/* FAQ Section */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="glass border-hairline rounded-lg p-8 max-w-4xl mx-auto">
            <h3 className="text-xl font-bold font-orbitron smoke-text mb-4">
              Como Funcionam os Créditos?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
              <div>
                <h4 className="font-semibold smoke-text mb-2">💬 Uso por Mensagem</h4>
                <p className="text-sm smoke-text-muted">
                  Cada mensagem enviada para um agente consome créditos baseado no modelo utilizado
                </p>
              </div>
              <div>
                <h4 className="font-semibold smoke-text mb-2">🔄 Renovação Automática</h4>
                <p className="text-sm smoke-text-muted">
                  Créditos dos planos são renovados automaticamente todo mês
                </p>
              </div>
              <div>
                <h4 className="font-semibold smoke-text mb-2">📊 Transparência Total</h4>
                <p className="text-sm smoke-text-muted">
                  Acompanhe seu uso em tempo real no dashboard
                </p>
              </div>
              <div>
                <h4 className="font-semibold smoke-text mb-2">🎁 Bônus de Boas-vindas</h4>
                <p className="text-sm smoke-text-muted">
                  Novos usuários recebem 100 créditos grátis para experimentar
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}