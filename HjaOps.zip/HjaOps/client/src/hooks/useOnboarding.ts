import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { 
  LearningPath, 
  OnboardingStep, 
  UserOnboardingProgress,
  OnboardingContext,
  OnboardingPreferences 
} from '@/types/onboarding';
import { learningPaths } from '@/data/learningPaths';

// Mock API functions
const mockOnboardingAPI = {
  async getUserProgress(userId: string): Promise<UserOnboardingProgress | null> {
    const stored = localStorage.getItem(`onboarding_${userId}`);
    if (stored) {
      const progress = JSON.parse(stored);
      return {
        ...progress,
        startedAt: new Date(progress.startedAt),
        lastActivity: new Date(progress.lastActivity)
      };
    }
    return null;
  },

  async saveUserProgress(progress: UserOnboardingProgress): Promise<void> {
    localStorage.setItem(`onboarding_${progress.userId}`, JSON.stringify(progress));
  },

  async generateAITooltip(context: OnboardingContext, element: string): Promise<string> {
    // Simulate AI generation delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const aiResponses: Record<string, string> = {
      'chat-section': `Baseado no seu perfil de <strong>${context.userRole}</strong>, o Chat Multiagente é onde a mágica acontece! Aqui você pode conversar com agentes especializados que vão revolucionar seu fluxo de trabalho.`,
      'credits-badge': `Com ${context.timeOnPlatform < 300 ? 'pouco tempo' : 'sua experiência'} na plataforma, o sistema de créditos é simples: mensagens maiores = mais créditos. Seja específico para melhores resultados!`,
      'agent-roteirista': `Para alguém interessado em ${context.featuresUsed.includes('chat') ? 'maximizar o chat' : 'criar conteúdo'}, o Roteirista é perfeito! Ele domina ganchos psicológicos e estruturas que viralizam.`
    };

    return aiResponses[element] || `Esta funcionalidade foi personalizada para seu perfil de <strong>${context.userRole}</strong>. Explore e descubra como pode otimizar seu fluxo de trabalho!`;
  }
};

export function useOnboarding(userId: string, userRole: string = 'user') {
  const [currentStep, setCurrentStep] = useState<OnboardingStep | null>(null);
  const [isTooltipVisible, setIsTooltipVisible] = useState(false);
  const [context, setContext] = useState<OnboardingContext>({
    currentPage: '',
    userRole,
    featuresUsed: [],
    timeOnPlatform: 0,
    lastLogin: new Date(),
    deviceType: 'desktop',
    browserLanguage: navigator.language
  });

  const queryClient = useQueryClient();

  // Load user progress
  const { data: userProgress } = useQuery({
    queryKey: ['onboarding', userId],
    queryFn: () => mockOnboardingAPI.getUserProgress(userId),
    staleTime: 1000 * 60 * 5 // 5 minutes
  });

  // Save progress mutation
  const saveProgressMutation = useMutation({
    mutationFn: mockOnboardingAPI.saveUserProgress,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding', userId] });
    }
  });

  // Get recommended learning path based on user role
  const getRecommendedPath = useCallback((): LearningPath | null => {
    const roleMap: Record<string, string> = {
      'content-creator': 'content-creator-basics',
      'developer': 'developer-onboarding', 
      'business-owner': 'business-owner-growth'
    };

    const pathId = roleMap[userRole] || 'content-creator-basics';
    return learningPaths.find(path => path.id === pathId) || learningPaths[0];
  }, [userRole]);

  // Start onboarding flow
  const startOnboarding = useCallback(async (pathId?: string) => {
    const path = pathId ? 
      learningPaths.find(p => p.id === pathId) : 
      getRecommendedPath();
    
    if (!path || path.steps.length === 0) return;

    const newProgress: UserOnboardingProgress = {
      userId,
      currentPath: path.id,
      currentStep: path.steps[0].id,
      completedSteps: [],
      skippedSteps: [],
      startedAt: new Date(),
      lastActivity: new Date(),
      completionPercentage: 0,
      preferences: {
        showTooltips: true,
        animationSpeed: 'normal',
        interactionStyle: 'guided',
        learningGoals: [],
        skipCompleted: true
      }
    };

    await saveProgressMutation.mutateAsync(newProgress);
    setCurrentStep(path.steps[0]);
    setIsTooltipVisible(true);
  }, [userId, getRecommendedPath, saveProgressMutation]);

  // Handle step action
  const handleStepAction = useCallback(async (actionId: string) => {
    if (!currentStep || !userProgress) return;

    const currentPath = learningPaths.find(p => p.id === userProgress.currentPath);
    if (!currentPath) return;

    const currentStepIndex = currentPath.steps.findIndex(s => s.id === currentStep.id);
    
    switch (actionId) {
      case 'next':
      case 'start-tour':
      case 'continue-tour':
        // Mark current step as completed and move to next
        const nextIndex = currentStepIndex + 1;
        const updatedProgress = {
          ...userProgress,
          completedSteps: [...userProgress.completedSteps, currentStep.id],
          currentStep: nextIndex < currentPath.steps.length ? currentPath.steps[nextIndex].id : undefined,
          lastActivity: new Date(),
          completionPercentage: Math.round(((userProgress.completedSteps.length + 1) / currentPath.steps.length) * 100)
        };

        await saveProgressMutation.mutateAsync(updatedProgress);
        
        if (nextIndex < currentPath.steps.length) {
          setCurrentStep(currentPath.steps[nextIndex]);
          setIsTooltipVisible(true);
        } else {
          // Tour completed
          setCurrentStep(null);
          setIsTooltipVisible(false);
        }
        break;

      case 'skip':
      case 'skip-tour':
        // Mark as skipped and move to next or end
        const skippedProgress = {
          ...userProgress,
          skippedSteps: [...userProgress.skippedSteps, currentStep.id],
          lastActivity: new Date()
        };
        await saveProgressMutation.mutateAsync(skippedProgress);
        setCurrentStep(null);
        setIsTooltipVisible(false);
        break;

      case 'complete':
        // Complete the entire flow
        const completedProgress = {
          ...userProgress,
          completedSteps: [...userProgress.completedSteps, currentStep.id],
          currentStep: undefined,
          lastActivity: new Date(),
          completionPercentage: 100
        };
        await saveProgressMutation.mutateAsync(completedProgress);
        setCurrentStep(null);
        setIsTooltipVisible(false);
        break;

      case 'demo':
        // Trigger demo action (handled by parent component)
        break;

      default:
        // Custom actions
        console.log('Custom action:', actionId);
        break;
    }
  }, [currentStep, userProgress, saveProgressMutation]);

  // Show contextual tooltip
  const showContextualTooltip = useCallback(async (
    element: string, 
    targetRef?: React.RefObject<HTMLElement>
  ) => {
    if (!userProgress?.preferences?.showTooltips) return;

    try {
      const aiContent = await mockOnboardingAPI.generateAITooltip(context, element);
      
      const contextualStep: OnboardingStep = {
        id: `contextual-${element}-${Date.now()}`,
        title: 'Dica Personalizada',
        content: aiContent,
        position: 'bottom',
        type: 'tooltip',
        interactive: true,
        priority: 999,
        aiGenerated: true,
        actions: [
          {
            id: 'got-it',
            label: 'Entendi',
            type: 'complete',
            style: 'primary'
          },
          {
            id: 'learn-more',
            label: 'Saber Mais',
            type: 'custom',
            style: 'secondary'
          }
        ]
      };

      setCurrentStep(contextualStep);
      setIsTooltipVisible(true);
    } catch (error) {
      console.error('Failed to generate AI tooltip:', error);
    }
  }, [context, userProgress]);

  // Close tooltip
  const closeTooltip = useCallback(() => {
    setIsTooltipVisible(false);
    setCurrentStep(null);
  }, []);

  // Update context
  const updateContext = useCallback((updates: Partial<OnboardingContext>) => {
    setContext(prev => ({ ...prev, ...updates }));
  }, []);

  // Check if user should see onboarding
  const shouldShowOnboarding = useCallback(() => {
    if (!userProgress) return true; // New user
    if (userProgress.completionPercentage >= 100) return false; // Completed
    if (userProgress.skippedSteps.length > 0 && !userProgress.currentStep) return false; // Skipped
    return true;
  }, [userProgress]);

  // Auto-start onboarding for new users
  useEffect(() => {
    if (userId && !userProgress && shouldShowOnboarding()) {
      // Small delay to ensure UI is ready
      setTimeout(() => {
        startOnboarding();
      }, 1000);
    }
  }, [userId, userProgress, shouldShowOnboarding, startOnboarding]);

  return {
    // State
    currentStep,
    isTooltipVisible,
    userProgress,
    context,
    availablePaths: learningPaths,
    
    // Actions
    startOnboarding,
    handleStepAction,
    showContextualTooltip,
    closeTooltip,
    updateContext,
    
    // Computed
    shouldShowOnboarding: shouldShowOnboarding(),
    currentProgress: userProgress ? {
      current: userProgress.completedSteps.length,
      total: learningPaths.find(p => p.id === userProgress.currentPath)?.steps.length || 0
    } : null,
    
    // Utils
    isLoading: saveProgressMutation.isPending
  };
}