import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { ChatMessage, ChatRequest, ChatResponse } from '@/types/agents';

// Mock API functions
const mockChatAPI = {
  async sendMessage(request: ChatRequest): Promise<ChatResponse> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    // Simulate potential errors
    if (Math.random() < 0.1) {
      throw new Error('Falha temporária do servidor');
    }
    
    // Simulate insufficient credits (402 error)
    if (Math.random() < 0.05) {
      const error = new Error('Créditos insuficientes') as any;
      error.status = 402;
      throw error;
    }
    
    const mockResponse: ChatResponse = {
      id: `chat_${Date.now()}`,
      model: 'hf:mistral-7b',
      usage: {
        inputTokens: Math.floor(Math.random() * 200) + 50,
        outputTokens: Math.floor(Math.random() * 300) + 100,
        creditsCharged: Math.floor(Math.random() * 3) + 1
      },
      messages: [
        {
          id: `msg_${Date.now()}`,
          role: 'assistant',
          content: generateMockResponse(request.agentId, request.messages[request.messages.length - 1].content),
          timestamp: new Date(),
          agentId: request.agentId,
          metadata: {
            model: 'hf:mistral-7b',
            tokens: Math.floor(Math.random() * 300) + 100,
            latency: Math.floor(Math.random() * 2000) + 800,
            provider: 'huggingface'
          }
        }
      ],
      meta: {
        provider: 'huggingface',
        latencyMs: Math.floor(Math.random() * 2000) + 800
      }
    };
    
    return mockResponse;
  },

  async getMessages(threadId: string): Promise<ChatMessage[]> {
    // Mock messages for demo
    return [];
  }
};

function generateMockResponse(agentId: string, userMessage: string): string {
  const responses = {
    'design-matrix': [
      'Vou ajudar você a criar uma interface que converte! Baseado no que você descreveu, sugiro focar em:\n\n**1. Hierarquia Visual Clara**\n- Título impactante com valor único\n- CTA principal em destaque\n- Benefícios escaneáveis\n\n**2. Prova Social**\n- Depoimentos de clientes\n- Números de resultado\n- Logos de empresas\n\n**3. Redução de Fricção**\n- Formulário simples\n- Menos campos possível\n- Garantia/teste grátis\n\nQuer que eu detalhe algum desses pontos específicos?',
      
      'Perfeito! Para otimizar a conversão, vamos aplicar princípios de psicologia cognitiva:\n\n```html\n<section class="hero-section">\n  <h1>Transforme Visitantes em Clientes</h1>\n  <p>Sistema comprovado que aumenta conversão em 340%</p>\n  <button class="cta-primary">Começar Agora</button>\n</section>\n```\n\nEssa estrutura usa o princípio da especificidade (340%) e urgência ("Agora"). Quer que eu refine mais algum elemento?'
    ],
    
    'vibe-code': [
      'Analisando seu código... Identifiquei algumas oportunidades de melhoria:\n\n**Arquitetura:**\n```typescript\n// ❌ Evite\nfunction processData(data: any) {\n  // lógica complexa aqui\n}\n\n// ✅ Melhor\nclass DataProcessor {\n  private validator: DataValidator;\n  private transformer: DataTransformer;\n  \n  process(data: ProcessableData): ProcessedData {\n    const validated = this.validator.validate(data);\n    return this.transformer.transform(validated);\n  }\n}\n```\n\n**Benefícios:**\n- Separação de responsabilidades\n- Fácil teste unitário\n- Manutenção simplificada\n\nPrecisa que eu refatore alguma parte específica?',
      
      'Excelente pergunta! Para React performático, seguimos essa hierarquia:\n\n**1. Otimização de Re-renders:**\n```tsx\nconst OptimizedComponent = memo(({ data }) => {\n  const memoizedValue = useMemo(() => \n    expensiveCalculation(data), [data]\n  );\n  \n  return <div>{memoizedValue}</div>;\n});\n```\n\n**2. State Management:**\n- Use Zustand para estado global\n- useState para estado local\n- useReducer para lógica complexa\n\n**3. Lazy Loading:**\n```tsx\nconst LazyComponent = lazy(() => import(\'./Component\'));\n```\n\nQual dessas otimizações quer implementar primeiro?'
    ],
    
    'roteirista': [
      'Vou criar um roteiro viral para você! 🎬\n\n**GANCHO (0-3s):**\n"Você está perdendo R$ 50 mil por mês e nem sabe..."\n\n**DESENVOLVIMENTO (3-25s):**\n- Problema: 90% das pessoas fazem isso errado\n- Agitação: Conte uma história pessoal\n- Solução: 3 passos simples\n\n**CTA (25-30s):**\n"Comenta \'QUERO\' que eu mando o passo a passo completo"\n\n**ELEMENTOS VIRAIS:**\n✅ Gancho com número específico\n✅ Promise gap (curiosidade)\n✅ Story telling pessoal\n✅ CTA de engajamento\n\nQuer que eu adapte para seu nicho específico?',
      
      'Perfeito! Vamos criar um roteiro que PARA o scroll:\n\n**ESTRUTURA VIRAL COMPROVADA:**\n\n**GANCHO (Primeira frase):**\n"Se você faz isso no seu negócio, está perdendo R$ 10 mil por mês"\n\n**STORY ARC:**\n- **Problema:** "Eu fazia isso também..."\n- **Jornada:** "Até descobrir que..."\n- **Transformação:** "E em 30 dias..."\n- **Resultado:** "Hoje faturamos..."\n\n**CALL TO ACTION:**\n"Salva esse post e comenta \'FÓRMULA\' que eu ensino"\n\n**PSICOLOGIA POR TRÁS:**\n- Especificidade: R$ 10 mil\n- FOMO: "você está perdendo"\n- Prova social: resultado pessoal\n- Reciprocidade: "eu ensino"\n\nQuer que eu personalize para seu produto/serviço?'
    ],
    
    'youtube-analyst': [
      'Analisando o vídeo que você enviou! 📊\n\n**MÉTRICAS IDENTIFICADAS:**\n- CTR: ~8.2% (Acima da média!)\n- Retenção: Queda em 15s e 45s\n- Engagement: 4.1% (Bom)\n\n**PONTOS FORTES:**\n✅ Thumbnail com contraste alto\n✅ Título com número específico\n✅ Gancho forte nos primeiros 3s\n\n**OPORTUNIDADES:**\n⚠️ **15s:** Muita informação de uma vez\n⚠️ **45s:** Transição muito lenta\n⚠️ **Título:** Pode ser mais específico\n\n**RECOMENDAÇÕES:**\n1. Adicione preview do resultado em 15s\n2. Corte 10s da transição\n3. Teste: "Como ganhar R$ 5.000" → "5 passos para ganhar R$ 5.000 em 30 dias"\n\nQuer que eu analise algum concorrente para comparação?',
      
      'Análise completa da performance! 🎯\n\n**ALGORITMO YOUTUBE (Atual):**\n- **Primeiros 24h:** CTR + Retenção determinam alcance\n- **Longo prazo:** Session time (tempo de sessão)\n- **Descoberta:** Títulos + thumbnails otimizados\n\n**SEU DESEMPENHO:**\n```\nCTR: 6.8% (Meta: 8%+)\nRetenção 30s: 72% (Ótimo!)\nDuration média: 3:24 (Meta: 4:00+)\nComments/Views: 2.1% (Excelente)\n```\n\n**PLANO DE OTIMIZAÇÃO:**\n1. **Thumbnail:** Teste A/B com cores mais contrastantes\n2. **Título:** Adicione urgência/especificidade\n3. **Intro:** Corte 5s, entre direto no valor\n4. **Estrutura:** Use "pattern interrupt" a cada 30s\n\n**PRÓXIMOS VÍDEOS:**\n- Replique elementos dos vídeos com 80%+ retenção\n- Teste formatos: lista, tutorial, storytelling\n\nQual métrica quer focar primeiro?'
    ],
    
    'branding-social': [
      'Vou desenvolver uma estratégia de marca consistente para você! 🎨\n\n**TOM DE VOZ DEFINIDO:**\n- **Personalidade:** Confiante, didático, próximo\n- **Linguagem:** Informal mas autoritative\n- **Valores:** Transparência, resultados, evolução\n\n**PILARES DE CONTEÚDO:**\n1. **Educação (40%):** Tutoriais, dicas, insights\n2. **Inspiração (30%):** Cases, jornadas, transformações\n3. **Entretenimento (20%):** Bastidores, pessoal, trends\n4. **Conversão (10%):** Produtos, serviços, calls\n\n**CALENDÁRIO SEMANAL:**\n- **Segunda:** Motivação + planejamento semana\n- **Terça:** Tutorial/educativo\n- **Quarta:** Case de sucesso\n- **Quinta:** Tendência/novidade\n- **Sexta:** Bastidores/pessoal\n- **Sábado:** Inspiração weekend\n- **Domingo:** Reflexão/recap\n\nQuer que eu detalhe algum pilar específico?',
      
      'Estratégia de marca 360° criada! 🚀\n\n**IDENTIDADE CORE:**\n```\nMissão: Transformar conhecimento em resultado\nVisão: Ser referência em [seu nicho]\nValores: Autenticidade • Evolução • Impacto\n```\n\n**POSITIONING STATEMENT:**\n"Para [seu público] que quer [resultado], somos [categoria] que [diferencial único] porque [proof points]"\n\n**VOICE & TONE:**\n- **Inspirador sem ser motivacional fake**\n- **Didático sem ser condescendente** \n- **Confiante sem ser arrogante**\n- **Próximo sem ser invasivo**\n\n**CONTENT FRAMEWORK:**\n```\n70% Value-first (educar, inspirar)\n20% Behind-scenes (conectar)\n10% Pitch (converter)\n```\n\n**COPY GUIDELINES:**\n- Use "você" e "seu/sua"\n- Números específicos sempre\n- CTAs claros e diretos\n- Storytelling pessoal\n\nQuer que eu crie templates de post para cada pilar?'
    ],
    
    'viral-agent': [
      'Vou criar conteúdo que EXPLODE nas redes! 💥\n\n**FÓRMULA VIRAL IDENTIFICADA:**\n\n**GANCHO PSICOLÓGICO:**\n"POV: Você descobriu o segredo que 1% usa para..."\n\n**ESTRUTURA ADDICTIVA:**\n1. **Problem Agitation:** "Todo mundo faz assim (errado)"\n2. **Pattern Interrupt:** "Mas eu descobri que..."\n3. **Revelation:** "A verdade é que..."\n4. **Social Proof:** "Em 30 dias consegui..."\n5. **CTA Irresistível:** "Quem quer saber como?"\n\n**ELEMENTOS VIRAIS:**\n✅ Contraste (1% vs 99%)\n✅ Curiosity gap (segredo)\n✅ FOMO (descobriu)\n✅ Especificidade (30 dias)\n✅ Reciprocidade (vou ensinar)\n\n**TRENDS ATUAIS:**\n- "POV:" + situação específica\n- "Red flags em..." (nicho)\n- "Coisas que mudaram minha vida"\n- Before & After transformações\n\nQual formato quer explorar primeiro?',
      
      'CONTEÚDO VIRAL DECODIFICADO! 🧬\n\n**ANATOMIA DE UM POST VIRAL:**\n\n**LINHA 1 (GANCHO):**\n"Isso vai mudar como você vê [tópico]"\n\n**DESENVOLVIMENTO:**\n```\nProblema: "A maioria das pessoas faz X"\nAgitação: "Resultado: perdem Y"\nSolução: "Mas existe uma forma melhor"\nProva: "Testei por Z tempo"\nResultado: "E consegui [resultado específico]"\n```\n\n**CALL TO ACTION:**\n"Salva esse post e marca quem precisa ver ✨"\n\n**FATORES VIRAIS:**\n- **Emoção forte:** Raiva, surpresa, alegria\n- **Utilidade prática:** "Vou usar isso"\n- **Identidade tribal:** "Isso é tão eu"\n- **Shareability:** "Preciso mostrar isso"\n\n**TIMING ESTRATÉGICO:**\n- Segunda 7h: Motivação semana\n- Quarta 12h: Dica rápida almoço\n- Sexta 18h: Inspiração weekend\n\n**HASHTAG STRATEGY:**\n3 nichos + 3 populares + 3 específicas\n\nQuer que eu crie 5 variações desse template?'
    ]
  };

  const agentResponses = responses[agentId] || [
    'Olá! Sou um agente IA especializado. Como posso ajudar você hoje?',
    'Entendi sua solicitação. Vou analisar e fornecer uma resposta detalhada.'
  ];

  // Return a random response from the agent's pool
  return agentResponses[Math.floor(Math.random() * agentResponses.length)];
}

export function useChatMessages(threadId?: string, agentId?: string) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  // Load messages for thread
  const { data: threadMessages } = useQuery({
    queryKey: ['chatMessages', threadId],
    queryFn: () => threadId ? mockChatAPI.getMessages(threadId) : Promise.resolve([]),
    enabled: !!threadId
  });

  // Update local messages when thread changes
  React.useEffect(() => {
    if (threadMessages) {
      setMessages(threadMessages);
    } else {
      setMessages([]);
    }
  }, [threadMessages]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, attachments = [] }: { content: string; attachments?: any[] }) => {
      if (!agentId) throw new Error('Nenhum agente selecionado');

      const userMessage: ChatMessage = {
        id: `msg_user_${Date.now()}`,
        role: 'user',
        content,
        timestamp: new Date(),
        attachments,
        status: 'sending'
      };

      // Add user message immediately
      setMessages(prev => [...prev, userMessage]);

      const request: ChatRequest = {
        userId: 'current_user',
        agentId,
        messages: [...messages, userMessage].map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        options: {
          stream: false,
          attachments,
          toolHints: []
        }
      };

      return mockChatAPI.sendMessage(request);
    },
    onSuccess: (response) => {
      // Update user message status
      setMessages(prev => prev.map(msg => 
        msg.status === 'sending' ? { ...msg, status: 'sent' } : msg
      ));

      // Add assistant response
      if (response.messages.length > 0) {
        setMessages(prev => [...prev, ...response.messages]);
      }
      
      setError(null);
    },
    onError: (error: any) => {
      // Update user message status to error
      setMessages(prev => prev.map(msg => 
        msg.status === 'sending' ? { ...msg, status: 'error' } : msg
      ));
      
      setError(error.message);
    }
  });

  const sendMessage = useCallback(async (content: string, attachments: any[] = []) => {
    setError(null);
    setIsLoading(true);
    
    try {
      await sendMessageMutation.mutateAsync({ content, attachments });
    } catch (error) {
      // Error handling is done in onError
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [sendMessageMutation]);

  const retryLastMessage = useCallback(() => {
    const lastUserMessage = [...messages].reverse().find(msg => msg.role === 'user');
    if (lastUserMessage) {
      // Remove error message and retry
      setMessages(prev => prev.filter(msg => msg.status !== 'error'));
      sendMessage(lastUserMessage.content, lastUserMessage.attachments || []);
    }
  }, [messages, sendMessage]);

  return {
    messages,
    sendMessage,
    isLoading: isLoading || sendMessageMutation.isPending,
    error,
    retryLastMessage
  };
}