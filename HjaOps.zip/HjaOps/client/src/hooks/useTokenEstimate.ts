import { useState, useCallback } from 'react';
import { useMutation } from '@tanstack/react-query';
import type { CreditEstimate } from '@/types/agents';

// Mock token estimation
const estimateTokens = async (agentId: string, text: string): Promise<CreditEstimate> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Simple token estimation (rough approximation)
  const wordCount = text.trim().split(/\s+/).length;
  const charCount = text.length;
  
  // Estimate tokens (1 token ≈ 0.75 words or 4 characters)
  const estimatedTokens = Math.max(
    Math.ceil(wordCount / 0.75),
    Math.ceil(charCount / 4)
  );
  
  // Different agents have different costs
  const agentMultipliers = {
    'design-matrix': 1.0,
    'vibe-code': 1.2,
    'roteirista': 0.8,
    'youtube-analyst': 1.1,
    'branding-social': 0.9,
    'viral-agent': 0.9
  };
  
  const multiplier = agentMultipliers[agentId] || 1.0;
  const adjustedTokens = Math.ceil(estimatedTokens * multiplier);
  
  // Convert tokens to credits (roughly 150-200 tokens per credit)
  const estimatedCredits = Math.max(1, Math.ceil(adjustedTokens / 175));
  
  return {
    estimatedTokens: adjustedTokens,
    estimatedCredits
  };
};

export function useTokenEstimate(agentId?: string) {
  const [estimatedCost, setEstimatedCost] = useState<number | null>(null);
  
  const estimateMutation = useMutation({
    mutationFn: ({ agentId, text }: { agentId: string; text: string }) => 
      estimateTokens(agentId, text),
    onSuccess: (data) => {
      setEstimatedCost(data.estimatedCredits);
    },
    onError: () => {
      setEstimatedCost(null);
    }
  });

  const estimateTokensForText = useCallback(async (text: string) => {
    if (!agentId || !text.trim()) {
      setEstimatedCost(null);
      return;
    }

    try {
      await estimateMutation.mutateAsync({ agentId, text });
    } catch (error) {
      console.error('Token estimation failed:', error);
    }
  }, [agentId, estimateMutation]);

  return {
    estimateTokens: estimateTokensForText,
    estimatedCost,
    isEstimating: estimateMutation.isPending
  };
}