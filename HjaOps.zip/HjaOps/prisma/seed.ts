import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Usuário inicial
  const user = await prisma.user.create({
    data: {
      email: "demo@haja.app",
      credits: 50,
      plan: "pro",
    },
  });

  console.log("✅ Usuário criado:", user.email);

  // Agentes iniciais
  const agents = await prisma.agent.createMany({
    data: [
      {
        id: "roteirista",
        name: "Roteirista",
        description: "Criação de roteiros criativos para vídeos.",
        prompt: "Você é um roteirista especializado em vídeos virais.",
        defaultModel: "groq/llama-3.1-70b",
      },
      {
        id: "vibe-code",
        name: "Vibe Code",
        description: "Assistente de programação criativa.",
        prompt: "Você escreve código moderno com explicações claras.",
        defaultModel: "replit/replit-code-v1-3b",
      },
      {
        id: "agente-viral",
        name: "Agente Viral",
        description: "Focado em ideias de alto engajamento.",
        prompt: "Você cria ganchos curtos e poderosos para redes sociais.",
        defaultModel: "groq/deepseek-r1",
      },
    ],
  });

  console.log("✅ Agentes iniciais criados:", agents.count);
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error("❌ Erro no seed:", e);
    await prisma.$disconnect();
    process.exit(1);
  });
