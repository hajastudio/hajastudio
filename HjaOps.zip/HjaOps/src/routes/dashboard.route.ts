import { Router } from "express";
import { db } from "../db";
import { users, chats } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const router = Router();

// Dados gerais do usuário
router.get("/:userId", async (req, res) => {
  const { userId } = req.params;

  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  const userChats = await db.select().from(chats).where(eq(chats.userId, userId));

  const dashboard = {
    profile: user[0],
    totalChats: userChats.length,
    tokensUsed: userChats.reduce((sum, c) => sum + (c.tokens || 0), 0),
    lastChat: userChats[userChats.length - 1] || null
  };

  res.json(dashboard);
});

export default router;