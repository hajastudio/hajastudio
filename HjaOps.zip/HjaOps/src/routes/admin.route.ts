import { Router } from "express";
import { db } from "../db";
import { users, agents } from "../../drizzle/schema";

const router = Router();

// 📌 Lista todos usuários
router.get("/users", async (_, res) => {
  const allUsers = await db.select().from(users);
  res.json(allUsers);
});

// 📌 Lista todos agentes
router.get("/agents", async (_, res) => {
  const allAgents = await db.select().from(agents);
  res.json(allAgents);
});

// 📌 Cria novo agente
router.post("/agents", async (req, res) => {
  const { name, description, prompt } = req.body;
  const newAgent = await db.insert(agents).values({
    name, description, prompt, active: true
  }).returning();
  res.json(newAgent[0]);
});

export default router;