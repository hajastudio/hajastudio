import { Router } from "express";
import { db } from "../db";
import { chats, users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const router = Router();

// Enviar mensagem no chat
router.post("/", async (req, res) => {
  const { userId, agentId, message } = req.body;

  // 🔹 Valida créditos
  const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user[0] || (user[0].credits || 0) <= 0) {
    return res.status(402).json({ error: "Créditos insuficientes" });
  }

  // 🔹 Simula resposta IA (futuramente: orquestrador de modelos)
  const response = `🤖 Agente ${agentId} respondeu: "${message.toUpperCase()}"`;

  // 🔹 Salva chat
  const newChat = await db.insert(chats).values({
    userId,
    agentId,
    title: "Sessão Chat",
    messages: [
      { role: "user", content: message, timestamp: new Date().toISOString() },
      { role: "assistant", content: response, timestamp: new Date().toISOString() }
    ],
    modelUsed: "demo-model",
    tokens: message.length,
  }).returning();

  // 🔹 Desconta créditos
  await db.update(users)
    .set({ credits: (user[0].credits || 0) - 1 })
    .where(eq(users.id, userId));

  res.json(newChat[0]);
});

export default router;
