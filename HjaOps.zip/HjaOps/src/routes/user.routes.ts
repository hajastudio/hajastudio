import { Router } from "express";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const router = Router();

router.post("/", async (req, res) => {
  const { email } = req.body;
  const user = await prisma.user.create({ data: { email } });
  res.json(user);
});

router.get("/", async (_, res) => {
  const users = await prisma.user.findMany();
  res.json(users);
});

export default router;
