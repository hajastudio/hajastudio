import { Router } from "express";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const router = Router();

router.post("/", async (req, res) => {
  const { userId, type, amount, creditsAdded, provider } = req.body;
  const transaction = await prisma.transaction.create({
    data: { userId, type, amount, creditsAdded, provider },
  });
  await prisma.user.update({
    where: { id: userId },
    data: { credits: { increment: creditsAdded } },
  });
  res.json(transaction);
});

export default router;
