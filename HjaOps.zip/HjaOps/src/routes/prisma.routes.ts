import express from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticateUser, requireAdmin } from '../middleware/auth.middleware';
import { checkCredits, deductCredits } from '../middleware/credits.middleware';
import { z } from 'zod';

const router = express.Router();
const prisma = new PrismaClient();

// Schemas de validação
const chatRequestSchema = z.object({
  agentId: z.string(),
  message: z.string().min(1),
  temperature: z.number().min(0).max(2).optional()
});

const agentSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  prompt: z.string().min(1),
  defaultModel: z.string().optional(),
  tags: z.array(z.string()).optional(),
  active: z.boolean().optional()
});

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        role: string;
      };
    }
  }
}

// Mock de função de IA (substitua pela integração real)
const generateAIResponse = async (prompt: string, userMessage: string, model: string = "gpt-5") => {
  // Simular resposta da IA
  const responses = [
    "Esta é uma resposta simulada do agente de IA.",
    "Interessante pergunta! Vou elaborar uma resposta detalhada para você.",
    "Baseado no seu contexto, posso sugerir as seguintes abordagens..."
  ];
  
  const randomResponse = responses[Math.floor(Math.random() * responses.length)];
  const estimatedTokens = Math.floor(userMessage.length / 4) + Math.floor(randomResponse.length / 4);
  
  return {
    content: randomResponse,
    tokensUsed: estimatedTokens
  };
};

// POST /chat - Iniciar conversa com agente
router.post('/chat', authenticateUser, checkCredits(5), async (req: express.Request, res: express.Response) => {
  try {
    const validatedData = chatRequestSchema.parse(req.body);
    const userId = req.user!.id;

    // Verificar se o agente existe e está ativo
    const agent = await prisma.agent.findFirst({
      where: { 
        id: validatedData.agentId,
        active: true 
      }
    });

    if (!agent) {
      return res.status(404).json({ message: 'Agente não encontrado ou inativo' });
    }

    // Gerar resposta da IA (mock)
    const aiResponse = await generateAIResponse(
      agent.prompt, 
      validatedData.message, 
      agent.defaultModel
    );

    // Deduzir créditos baseado nos tokens usados
    const creditsToDeduct = Math.ceil(aiResponse.tokensUsed / 100); // 1 crédito por 100 tokens
    const creditsDeducted = await deductCredits(userId, creditsToDeduct);

    if (!creditsDeducted) {
      return res.status(403).json({ message: 'Erro ao deduzir créditos' });
    }

    // Criar o chat no banco
    const messages = [
      {
        role: 'user' as const,
        content: validatedData.message,
        timestamp: new Date().toISOString()
      },
      {
        role: 'assistant' as const,
        content: aiResponse.content,
        timestamp: new Date().toISOString(),
        tokensUsed: aiResponse.tokensUsed
      }
    ];

    const chat = await prisma.chat.create({
      data: {
        userId,
        agentId: validatedData.agentId,
        title: validatedData.message.substring(0, 50),
        messages: JSON.stringify(messages),
        modelUsed: agent.defaultModel,
        tokens: aiResponse.tokensUsed
      }
    });

    res.json({
      chatId: chat.id,
      response: aiResponse.content,
      tokensUsed: aiResponse.tokensUsed,
      creditsDeducted
    });

  } catch (error) {
    console.error('Erro no chat:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Dados inválidos', errors: error.errors });
    }
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /dashboard/:userId - Retornar dados do dashboard
router.get('/dashboard/:userId', authenticateUser, async (req: express.Request, res: express.Response) => {
  try {
    const userId = req.params.userId;

    // Verificar se o usuário pode acessar este dashboard
    if (req.user!.id !== userId && req.user!.role !== 'admin') {
      return res.status(403).json({ message: 'Acesso negado' });
    }

    // Buscar dados do usuário
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }

    // Buscar últimos chats
    const recentChats = await prisma.chat.findMany({
      where: { userId },
      include: {
        agent: {
          select: { name: true, description: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });

    // Estatísticas do usuário
    const totalChats = await prisma.chat.count({
      where: { userId }
    });

    const totalTokensUsed = await prisma.chat.aggregate({
      where: { userId },
      _sum: { tokens: true }
    });

    res.json({
      user: {
        id: user.id,
        email: user.email,
        credits: user.credits,
        plan: user.plan,
        createdAt: user.createdAt
      },
      stats: {
        totalChats,
        totalTokensUsed: totalTokensUsed._sum.tokens || 0
      },
      recentChats: recentChats.map(chat => ({
        id: chat.id,
        title: chat.title,
        agentName: chat.agent.name,
        tokensUsed: chat.tokens,
        createdAt: chat.createdAt
      }))
    });

  } catch (error) {
    console.error('Erro no dashboard:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// POST /admin/agent - Criar novo agente (apenas admin)
router.post('/admin/agent', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const validatedData = agentSchema.parse(req.body);

    const agent = await prisma.agent.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        prompt: validatedData.prompt,
        defaultModel: validatedData.defaultModel || 'gpt-5',
        tags: validatedData.tags || [],
        active: validatedData.active ?? true
      }
    });

    res.status(201).json(agent);

  } catch (error) {
    console.error('Erro ao criar agente:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Dados inválidos', errors: error.errors });
    }
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /admin/usage - Estatísticas de uso (apenas admin)
router.get('/admin/usage', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    // Últimas 50 interações
    const recentInteractions = await prisma.chat.findMany({
      include: {
        user: {
          select: { email: true }
        },
        agent: {
          select: { name: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    // Total de tokens usados
    const totalTokensUsed = await prisma.chat.aggregate({
      _sum: { tokens: true }
    });

    // Agentes mais usados
    const agentUsage = await prisma.chat.groupBy({
      by: ['agentId'],
      _count: { agentId: true },
      _sum: { tokens: true },
      orderBy: { _count: { agentId: 'desc' } },
      take: 10
    });

    // Buscar nomes dos agentes
    const agentIds = agentUsage.map(usage => usage.agentId);
    const agents = await prisma.agent.findMany({
      where: { id: { in: agentIds } },
      select: { id: true, name: true }
    });

    const agentMap = agents.reduce((acc, agent) => {
      acc[agent.id] = agent.name;
      return acc;
    }, {} as Record<string, string>);

    const topAgents = agentUsage.map(usage => ({
      agentId: usage.agentId,
      agentName: agentMap[usage.agentId] || 'Agente Desconhecido',
      totalChats: usage._count.agentId,
      totalTokens: usage._sum.tokens || 0
    }));

    // Usuários mais ativos
    const activeUsers = await prisma.chat.groupBy({
      by: ['userId'],
      _count: { userId: true },
      _sum: { tokens: true },
      orderBy: { _count: { userId: 'desc' } },
      take: 10
    });

    res.json({
      recentInteractions: recentInteractions.map(chat => ({
        id: chat.id,
        userEmail: chat.user.email,
        agentName: chat.agent.name,
        tokensUsed: chat.tokens,
        createdAt: chat.createdAt
      })),
      totalTokensUsed: totalTokensUsed._sum.tokens || 0,
      topAgents,
      totalUsers: activeUsers.length,
      totalChats: recentInteractions.length
    });

  } catch (error) {
    console.error('Erro nas estatísticas de uso:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

export default router;