import express from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticateUser } from '../middleware/auth.middleware';
import { checkCredits, deductCredits } from '../middleware/credits.middleware';
import { z } from 'zod';

const router = express.Router();
const prisma = new PrismaClient();

// Schema de validação para chat
const chatRequestSchema = z.object({
  agentId: z.string(),
  message: z.string().min(1),
  temperature: z.number().min(0).max(2).optional()
});

// Mock de função de IA (substitua pela integração real)
const generateAIResponse = async (prompt: string, userMessage: string, model: string = "gpt-5") => {
  const responses = [
    "Esta é uma resposta simulada do agente de IA.",
    "Interessante pergunta! Vou elaborar uma resposta detalhada para você.",
    "Baseado no seu contexto, posso sugerir as seguintes abordagens...",
    "Entendo sua solicitação. Aqui está minha análise e sugestões."
  ];
  
  const randomResponse = responses[Math.floor(Math.random() * responses.length)];
  const estimatedTokens = Math.floor(userMessage.length / 4) + Math.floor(randomResponse.length / 4);
  
  return {
    content: randomResponse,
    tokensUsed: estimatedTokens
  };
};

// POST /api/chat - Iniciar conversa com agente
router.post('/', authenticateUser, checkCredits(5), async (req: express.Request, res: express.Response) => {
  try {
    const validatedData = chatRequestSchema.parse(req.body);
    const userId = req.user!.id;

    // Verificar se o agente existe e está ativo
    const agent = await prisma.agent.findFirst({
      where: { 
        id: validatedData.agentId,
        active: true 
      }
    });

    if (!agent) {
      return res.status(404).json({ message: 'Agente não encontrado ou inativo' });
    }

    // Gerar resposta da IA (mock)
    const aiResponse = await generateAIResponse(
      agent.prompt, 
      validatedData.message, 
      agent.defaultModel
    );

    // Deduzir créditos baseado nos tokens usados
    const creditsToDeduct = Math.ceil(aiResponse.tokensUsed / 100); // 1 crédito por 100 tokens
    const creditsDeducted = await deductCredits(userId, creditsToDeduct);

    if (!creditsDeducted) {
      return res.status(403).json({ message: 'Erro ao deduzir créditos' });
    }

    // Criar o chat no banco
    const messages = [
      {
        role: 'user' as const,
        content: validatedData.message,
        timestamp: new Date().toISOString()
      },
      {
        role: 'assistant' as const,
        content: aiResponse.content,
        timestamp: new Date().toISOString(),
        tokensUsed: aiResponse.tokensUsed
      }
    ];

    const chat = await prisma.chat.create({
      data: {
        userId,
        agentId: validatedData.agentId,
        title: validatedData.message.substring(0, 50),
        messages: JSON.stringify(messages),
        modelUsed: agent.defaultModel,
        tokens: aiResponse.tokensUsed
      }
    });

    res.json({
      chatId: chat.id,
      response: aiResponse.content,
      tokensUsed: aiResponse.tokensUsed,
      creditsDeducted
    });

  } catch (error) {
    console.error('Erro no chat:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Dados inválidos', errors: error.errors });
    }
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /api/chat/:chatId - Buscar chat específico
router.get('/:chatId', authenticateUser, async (req: express.Request, res: express.Response) => {
  try {
    const { chatId } = req.params;
    const userId = req.user!.id;

    const chat = await prisma.chat.findFirst({
      where: {
        id: chatId,
        userId
      },
      include: {
        agent: {
          select: { name: true, description: true }
        }
      }
    });

    if (!chat) {
      return res.status(404).json({ message: 'Chat não encontrado' });
    }

    res.json(chat);

  } catch (error) {
    console.error('Erro ao buscar chat:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

export default router;