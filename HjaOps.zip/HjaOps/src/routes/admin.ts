import express from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticateUser, requireAdmin } from '../middleware/auth.middleware';
import { z } from 'zod';

const router = express.Router();
const prisma = new PrismaClient();

// Schema de validação para agente
const agentSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  prompt: z.string().min(1),
  defaultModel: z.string().optional(),
  tags: z.array(z.string()).optional(),
  active: z.boolean().optional()
});

// POST /api/admin/agent - Criar novo agente (apenas admin)
router.post('/agent', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const validatedData = agentSchema.parse(req.body);

    const agent = await prisma.agent.create({
      data: {
        name: validatedData.name,
        description: validatedData.description,
        prompt: validatedData.prompt,
        defaultModel: validatedData.defaultModel || 'gpt-5',
        tags: validatedData.tags || [],
        active: validatedData.active ?? true
      }
    });

    res.status(201).json(agent);

  } catch (error) {
    console.error('Erro ao criar agente:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Dados inválidos', errors: error.errors });
    }
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /api/admin/usage - Estatísticas de uso (apenas admin)
router.get('/usage', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    // Últimas 50 interações
    const recentInteractions = await prisma.chat.findMany({
      include: {
        user: {
          select: { email: true }
        },
        agent: {
          select: { name: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    // Total de tokens usados
    const totalTokensUsed = await prisma.chat.aggregate({
      _sum: { tokens: true }
    });

    // Agentes mais usados
    const agentUsage = await prisma.chat.groupBy({
      by: ['agentId'],
      _count: { agentId: true },
      _sum: { tokens: true },
      orderBy: { _count: { agentId: 'desc' } },
      take: 10
    });

    // Buscar nomes dos agentes
    const agentIds = agentUsage.map(usage => usage.agentId);
    const agents = await prisma.agent.findMany({
      where: { id: { in: agentIds } },
      select: { id: true, name: true }
    });

    const agentMap = agents.reduce((acc, agent) => {
      acc[agent.id] = agent.name;
      return acc;
    }, {} as Record<string, string>);

    const topAgents = agentUsage.map(usage => ({
      agentId: usage.agentId,
      agentName: agentMap[usage.agentId] || 'Agente Desconhecido',
      totalChats: usage._count.agentId,
      totalTokens: usage._sum.tokens || 0
    }));

    // Usuários mais ativos
    const activeUsers = await prisma.chat.groupBy({
      by: ['userId'],
      _count: { userId: true },
      _sum: { tokens: true },
      orderBy: { _count: { userId: 'desc' } },
      take: 10
    });

    res.json({
      recentInteractions: recentInteractions.map(chat => ({
        id: chat.id,
        userEmail: chat.user.email,
        agentName: chat.agent.name,
        tokensUsed: chat.tokens,
        createdAt: chat.createdAt
      })),
      totalTokensUsed: totalTokensUsed._sum.tokens || 0,
      topAgents,
      totalUsers: activeUsers.length,
      totalChats: recentInteractions.length
    });

  } catch (error) {
    console.error('Erro nas estatísticas de uso:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /api/admin/agents - Listar todos os agentes (apenas admin)
router.get('/agents', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const agents = await prisma.agent.findMany({
      orderBy: { createdAt: 'desc' }
    });

    res.json(agents);

  } catch (error) {
    console.error('Erro ao buscar agentes:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// PUT /api/admin/agent/:id - Atualizar agente (apenas admin)
router.put('/agent/:id', authenticateUser, requireAdmin, async (req: express.Request, res: express.Response) => {
  try {
    const { id } = req.params;
    const validatedData = agentSchema.parse(req.body);

    const agent = await prisma.agent.update({
      where: { id },
      data: {
        name: validatedData.name,
        description: validatedData.description,
        prompt: validatedData.prompt,
        defaultModel: validatedData.defaultModel || 'gpt-5',
        tags: validatedData.tags || [],
        active: validatedData.active ?? true
      }
    });

    res.json(agent);

  } catch (error) {
    console.error('Erro ao atualizar agente:', error);
    if (error instanceof z.ZodError) {
      return res.status(400).json({ message: 'Dados inválidos', errors: error.errors });
    }
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

export default router;