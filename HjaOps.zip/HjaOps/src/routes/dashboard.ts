import express from 'express';
import { PrismaClient } from '@prisma/client';
import { authenticateUser } from '../middleware/auth.middleware';

const router = express.Router();
const prisma = new PrismaClient();

// GET /api/dashboard/:userId - Retornar dados do dashboard
router.get('/:userId', authenticateUser, async (req: express.Request, res: express.Response) => {
  try {
    const userId = req.params.userId;

    // Verificar se o usuário pode acessar este dashboard
    if (req.user!.id !== userId && req.user!.role !== 'admin') {
      return res.status(403).json({ message: 'Acesso negado' });
    }

    // Buscar dados do usuário
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }

    // Buscar últimos chats
    const recentChats = await prisma.chat.findMany({
      where: { userId },
      include: {
        agent: {
          select: { name: true, description: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    });

    // Estatísticas do usuário
    const totalChats = await prisma.chat.count({
      where: { userId }
    });

    const totalTokensUsed = await prisma.chat.aggregate({
      where: { userId },
      _sum: { tokens: true }
    });

    res.json({
      user: {
        id: user.id,
        email: user.email,
        credits: user.credits,
        plan: user.plan,
        createdAt: user.createdAt
      },
      stats: {
        totalChats,
        totalTokensUsed: totalTokensUsed._sum.tokens || 0
      },
      recentChats: recentChats.map(chat => ({
        id: chat.id,
        title: chat.title,
        agentName: chat.agent.name,
        tokensUsed: chat.tokens,
        createdAt: chat.createdAt
      }))
    });

  } catch (error) {
    console.error('Erro no dashboard:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

// GET /api/dashboard/stats/:userId - Estatísticas detalhadas
router.get('/stats/:userId', authenticateUser, async (req: express.Request, res: express.Response) => {
  try {
    const userId = req.params.userId;

    if (req.user!.id !== userId && req.user!.role !== 'admin') {
      return res.status(403).json({ message: 'Acesso negado' });
    }

    // Agentes mais usados pelo usuário
    const agentUsage = await prisma.chat.groupBy({
      by: ['agentId'],
      where: { userId },
      _count: { agentId: true },
      _sum: { tokens: true },
      orderBy: { _count: { agentId: 'desc' } },
      take: 5
    });

    // Buscar nomes dos agentes
    const agentIds = agentUsage.map(usage => usage.agentId);
    const agents = await prisma.agent.findMany({
      where: { id: { in: agentIds } },
      select: { id: true, name: true }
    });

    const agentMap = agents.reduce((acc, agent) => {
      acc[agent.id] = agent.name;
      return acc;
    }, {} as Record<string, string>);

    const topAgents = agentUsage.map(usage => ({
      agentId: usage.agentId,
      agentName: agentMap[usage.agentId] || 'Agente Desconhecido',
      totalChats: usage._count.agentId,
      totalTokens: usage._sum.tokens || 0
    }));

    res.json({
      topAgents,
      totalAgentsUsed: agentUsage.length
    });

  } catch (error) {
    console.error('Erro nas estatísticas:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
});

export default router;