import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        role: string;
      };
    }
  }
}

export const authenticateUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Simular autenticação por token (você pode implementar JWT aqui)
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Token de autorização não fornecido' });
    }

    const token = authHeader.substring(7); // Remove 'Bearer '
    
    // Por enquanto, vamos simular validação do token
    // Aqui você implementaria a verificação real do JWT
    if (!token || token === 'invalid') {
      return res.status(401).json({ message: 'Token inválido' });
    }

    // Mock: extrair userId do token (implementar JWT decode depois)
    const userId = token; // Por enquanto, o token é o próprio userId
    
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, email: true, plan: true }
    });

    if (!user) {
      return res.status(401).json({ message: 'Usuário não encontrado' });
    }

    req.user = {
      id: user.id,
      email: user.email,
      role: user.plan === 'admin' ? 'admin' : 'user'
    };

    next();
  } catch (error) {
    console.error('Erro na autenticação:', error);
    res.status(500).json({ message: 'Erro interno do servidor' });
  }
};

export const requireAdmin = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  if (!req.user) {
    return res.status(401).json({ message: 'Autenticação necessária' });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Acesso negado. Permissão de administrador necessária' });
  }

  next();
};