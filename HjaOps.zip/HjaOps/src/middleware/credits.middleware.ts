import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const checkCredits = (minimumCredits: number = 1) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: 'Autenticação necessária' });
      }

      const user = await prisma.user.findUnique({
        where: { id: req.user.id },
        select: { credits: true, plan: true }
      });

      if (!user) {
        return res.status(404).json({ message: 'Usuário não encontrado' });
      }

      if (user.credits < minimumCredits) {
        return res.status(403).json({ 
          message: 'Créditos insuficientes para realizar esta ação',
          currentCredits: user.credits,
          requiredCredits: minimumCredits
        });
      }

      next();
    } catch (error) {
      console.error('Erro ao verificar créditos:', error);
      res.status(500).json({ message: 'Erro interno do servidor' });
    }
  };
};

export const deductCredits = async (userId: string, amount: number): Promise<boolean> => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { credits: true }
    });

    if (!user || user.credits < amount) {
      return false;
    }

    await prisma.user.update({
      where: { id: userId },
      data: { credits: user.credits - amount }
    });

    return true;
  } catch (error) {
    console.error('Erro ao deduzir créditos:', error);
    return false;
  }
};

export const addCredits = async (userId: string, amount: number): Promise<boolean> => {
  try {
    await prisma.user.update({
      where: { id: userId },
      data: { credits: { increment: amount } }
    });

    return true;
  } catch (error) {
    console.error('Erro ao adicionar créditos:', error);
    return false;
  }
};