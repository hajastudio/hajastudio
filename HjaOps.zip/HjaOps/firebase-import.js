import admin from "firebase-admin";
import fs from "fs";

// 🔑 Inicia Firebase com chave de serviço
const serviceAccount = JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON);

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Função para importar
async function importData() {
  const rawData = fs.readFileSync("firestore.json");
  const data = JSON.parse(rawData);

  for (const [collectionName, documents] of Object.entries(data)) {
    const collectionRef = db.collection(collectionName);

    for (const [docId, docData] of Object.entries(documents)) {
      console.log(`📥 Importando ${collectionName}/${docId}...`);
      await collectionRef.doc(docId).set(docData, { merge: true });
    }
  }

  console.log("✅ Importação concluída!");
}

importData().catch((err) => {
  console.error("❌ Erro ao importar:", err);
  process.exit(1);
});