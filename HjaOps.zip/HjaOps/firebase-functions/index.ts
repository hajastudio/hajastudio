import { onRequest, onCall, onSchedule } from "firebase-functions/v2/https";
import { onDocumentCreated, onDocumentUpdated } from "firebase-functions/v2/firestore";
import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { logger } from "firebase-functions";
import * as cors from "cors";

// 🚀 Inicializa Firebase Admin
initializeApp();
const db = getFirestore();

// 🔧 CORS setup
const corsHandler = cors({ origin: true });

// 🎯 HVC Core - Orquestrador de IA
class HVCOrchestrator {
  private providers = {
    groq: { endpoint: process.env.GROQ_API_URL, key: process.env.GROQ_API_KEY, priority: 1 },
    huggingface: { endpoint: process.env.HF_API_URL, key: process.env.HF_API_KEY, priority: 2 },
    replit: { endpoint: process.env.REPLIT_API_URL, key: process.env.REPLIT_API_KEY, priority: 3 }
  };

  async makeRequest(model: string, prompt: string, userId: string): Promise<any> {
    const provider = this.getProviderFromModel(model);
    
    try {
      // Tenta provider principal
      const response = await this.callProvider(provider, model, prompt);
      
      // Registra sucesso
      await this.logUsage(userId, model, provider, response.tokens, true);
      
      return response;
    } catch (error) {
      logger.error(`Falha no ${provider}:`, error);
      
      // Ativa fallback automático
      return await this.fallbackRequest(model, prompt, userId, provider);
    }
  }

  private async fallbackRequest(model: string, prompt: string, userId: string, failedProvider: string): Promise<any> {
    const fallbacks = this.getFallbackProviders(failedProvider);
    
    for (const fallback of fallbacks) {
      try {
        logger.info(`🔄 Fallback: tentando ${fallback}`);
        const response = await this.callProvider(fallback, model, prompt);
        
        // Registra fallback
        await this.logUsage(userId, model, fallback, response.tokens, true, { fallback: true, originalProvider: failedProvider });
        
        return response;
      } catch (error) {
        logger.error(`Fallback ${fallback} falhou:`, error);
      }
    }
    
    throw new Error("Todos os provedores falharam");
  }

  private getProviderFromModel(model: string): string {
    if (model.includes("groq")) return "groq";
    if (model.includes("huggingface")) return "huggingface";
    if (model.includes("replit")) return "replit";
    return "groq"; // default
  }

  private getFallbackProviders(failed: string): string[] {
    const order = ["groq", "huggingface", "replit"];
    return order.filter(p => p !== failed);
  }

  private async callProvider(provider: string, model: string, prompt: string): Promise<any> {
    // Mock implementation - substituir por chamadas reais
    const mockResponses = {
      groq: { message: "Resposta do Groq", tokens: 180, cost: 0.036 },
      huggingface: { message: "Resposta do HuggingFace", tokens: 165, cost: 0.028 },
      replit: { message: "Resposta do Replit", tokens: 140, cost: 0.024 }
    };
    
    return mockResponses[provider] || mockResponses.groq;
  }

  private async logUsage(userId: string, model: string, provider: string, tokens: number, success: boolean, metadata: any = {}): Promise<void> {
    const usage = {
      userId,
      model,
      provider,
      tokens,
      success,
      timestamp: new Date(),
      ...metadata
    };
    
    await db.collection('usage-logs').add(usage);
  }
}

// 📋 1. onUserCreate → cria perfil inicial
export const onUserCreate = onDocumentCreated("users/{userId}", async (event) => {
  const { userId } = event.params;
  const userData = event.data?.data();
  
  logger.info(`🆕 Novo usuário criado: ${userId}`);
  
  try {
    // Perfil inicial com créditos de boas-vindas
    const initialProfile = {
      profile: {
        interesses: {},
        estiloPreferido: "neutro",
        agentesUsados: {}
      },
      credits: 50, // Bônus inicial
      plan: "free",
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    };
    
    // Atualiza documento do usuário
    await db.collection('users').doc(userId).update(initialProfile);
    
    // Cria primeira transação (créditos de boas-vindas)
    await db.collection('transactions').add({
      userId,
      type: "bonus",
      amount: 0,
      creditsAdded: 50,
      provider: "sistema",
      description: "Bônus de boas-vindas",
      timestamp: new Date().toISOString()
    });
    
    logger.info(`✅ Perfil inicial criado para ${userId}`);
  } catch (error) {
    logger.error("Erro ao criar perfil inicial:", error);
  }
});

// 💬 2. onChatSubmit → valida créditos, chama orquestrador, salva resposta
export const onChatSubmit = onCall({ cors: corsHandler }, async (request) => {
  const { userId, agentId, message, chatId } = request.data;
  
  if (!userId || !agentId || !message) {
    throw new Error("Dados obrigatórios: userId, agentId, message");
  }
  
  try {
    // 1. Verifica créditos do usuário
    const userDoc = await db.collection('users').doc(userId).get();
    const userData = userDoc.data();
    
    if (!userData || userData.credits < 1) {
      throw new Error("Créditos insuficientes");
    }
    
    // 2. Busca configuração do agente
    const agentDoc = await db.collection('agents').doc(agentId).get();
    const agentData = agentDoc.data();
    
    if (!agentData || !agentData.active) {
      throw new Error("Agente não disponível");
    }
    
    // 3. Faz chamada para HVC Core
    const hvc = new HVCOrchestrator();
    const response = await hvc.makeRequest(agentData.defaultModel, `${agentData.prompt}\n\nUsuário: ${message}`, userId);
    
    // 4. Calcula créditos a debitar
    const creditsToCharge = Math.ceil(response.tokens / 100);
    
    // 5. Cria ou atualiza chat
    let chatDocId = chatId;
    if (!chatId) {
      // Novo chat
      const newChat = await db.collection('chats').add({
        userId,
        agentId,
        title: message.substring(0, 50) + (message.length > 50 ? '...' : ''),
        messages: [],
        modelUsed: agentData.defaultModel,
        tokens: 0,
        createdAt: new Date().toISOString()
      });
      chatDocId = newChat.id;
    }
    
    // 6. Adiciona mensagens ao chat
    const chatRef = db.collection('chats').doc(chatDocId);
    const chatDoc = await chatRef.get();
    const chatData = chatDoc.data();
    
    const updatedMessages = [
      ...(chatData?.messages || []),
      {
        role: "user",
        content: message,
        timestamp: new Date().toISOString()
      },
      {
        role: "assistant", 
        content: response.message,
        timestamp: new Date().toISOString()
      }
    ];
    
    await chatRef.update({
      messages: updatedMessages,
      tokens: (chatData?.tokens || 0) + response.tokens,
      lastUpdated: new Date().toISOString()
    });
    
    // 7. Debita créditos do usuário
    await db.collection('users').doc(userId).update({
      credits: userData.credits - creditsToCharge,
      lastLogin: new Date().toISOString()
    });
    
    // 8. Registra transação
    await db.collection('transactions').add({
      userId,
      type: "uso",
      amount: 0,
      creditsUsed: creditsToCharge,
      provider: "hvc-core",
      chatId: chatDocId,
      timestamp: new Date().toISOString()
    });
    
    logger.info(`✅ Chat processado: ${creditsToCharge} créditos debitados de ${userId}`);
    
    return {
      success: true,
      chatId: chatDocId,
      message: response.message,
      usage: {
        tokens: response.tokens,
        creditsCharged: creditsToCharge,
        cost: response.cost
      }
    };
    
  } catch (error) {
    logger.error("Erro no chat submit:", error);
    throw new Error(error.message);
  }
});

// 💰 3. onTransactionApproved → adiciona créditos após webhook Mercado Pago
export const onTransactionApproved = onRequest({ cors: corsHandler }, async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).send('Method Not Allowed');
    return;
  }
  
  try {
    const { type, data } = req.body;
    
    // Verifica se é notificação do Mercado Pago
    if (type !== 'payment') {
      res.status(200).send('OK');
      return;
    }
    
    logger.info(`💰 Webhook Mercado Pago recebido: ${data.id}`);
    
    // Busca detalhes do pagamento (mock)
    const paymentData = {
      id: data.id,
      status: 'approved',
      external_reference: 'user001_plan_pro', // userId_tipo_plano
      transaction_amount: 59.90
    };
    
    if (paymentData.status === 'approved') {
      const [userId, tipo, plano] = paymentData.external_reference.split('_');
      
      let creditsToAdd = 0;
      let newPlan = null;
      
      // Define créditos baseado no valor pago
      if (paymentData.transaction_amount >= 99.90) {
        creditsToAdd = 1000;
        newPlan = 'premium';
      } else if (paymentData.transaction_amount >= 59.90) {
        creditsToAdd = 500;
        newPlan = 'pro';
      } else if (paymentData.transaction_amount >= 29.90) {
        creditsToAdd = 300;
        newPlan = 'basic';
      }
      
      // Atualiza usuário
      const userRef = db.collection('users').doc(userId);
      const userDoc = await userRef.get();
      const userData = userDoc.data();
      
      const updates: any = {
        credits: (userData?.credits || 0) + creditsToAdd,
        lastTransaction: new Date().toISOString()
      };
      
      if (newPlan && tipo === 'plano') {
        updates.plan = newPlan;
      }
      
      await userRef.update(updates);
      
      // Registra transação
      await db.collection('transactions').add({
        userId,
        type: tipo === 'plano' ? 'plano' : 'creditos',
        amount: paymentData.transaction_amount,
        creditsAdded: creditsToAdd,
        plan: newPlan,
        provider: 'mercadopago',
        paymentId: paymentData.id,
        status: 'approved',
        timestamp: new Date().toISOString()
      });
      
      logger.info(`✅ Pagamento processado: ${creditsToAdd} créditos adicionados para ${userId}`);
    }
    
    res.status(200).send('OK');
  } catch (error) {
    logger.error('Erro no webhook:', error);
    res.status(500).send('Error');
  }
});

// 🔍 4. dailyTechScan → cron diário, busca novidades em IA
export const dailyTechScan = onSchedule("0 6 * * *", async () => {
  logger.info("🔍 Iniciando scan diário de tecnologias...");
  
  try {
    // Mock de scan - em produção usaria APIs reais ou web scraping
    const mockTrends = [
      {
        nome: "Claude 4.0 Release",
        tipo: "modelo",
        descricao: "Anthropic lança Claude 4.0 com capacidades multimodais avançadas",
        link: "https://anthropic.com/claude-4",
        impacto: "alto",
        relevanciaHja: 0.8
      },
      {
        nome: "Groq Rate Limit Increase",
        tipo: "api",
        descricao: "Groq dobra rate limits gratuitos para desenvolvedores",
        link: "https://groq.com/news",
        impacto: "medio", 
        relevanciaHja: 0.9
      }
    ];
    
    const today = new Date().toISOString().split('T')[0];
    
    // Salva trends do dia
    await db.collection('tech-trends').doc(today).set({
      date: today,
      trends: mockTrends,
      priority: "alto",
      actionRequired: true,
      summary: `${mockTrends.length} novidades detectadas`,
      nextScan: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      scannedAt: new Date().toISOString()
    }, { merge: true });
    
    // Gera alertas para trends de alto impacto
    const highImpactTrends = mockTrends.filter(t => t.impacto === "alto");
    
    for (const trend of highImpactTrends) {
      await db.collection('alerts').add({
        type: "newTechnology",
        level: "info",
        title: `Nova Tecnologia: ${trend.nome}`,
        message: trend.descricao,
        link: trend.link,
        timestamp: new Date().toISOString(),
        resolved: false,
        priority: "medium"
      });
    }
    
    logger.info(`✅ Tech scan concluído: ${mockTrends.length} trends encontradas`);
  } catch (error) {
    logger.error("Erro no tech scan:", error);
  }
});

// 👍 5. hvcFeedbackProcessor → ajusta agente/perfil baseado em feedback
export const hvcFeedbackProcessor = onDocumentCreated("feedback/{feedbackId}", async (event) => {
  const feedbackData = event.data?.data();
  
  if (!feedbackData) return;
  
  const { userId, agentId, rating, type } = feedbackData;
  
  logger.info(`📊 Processando feedback: ${rating}/5 para agente ${agentId}`);
  
  try {
    // Atualiza perfil do usuário baseado no feedback
    const userRef = db.collection('users').doc(userId);
    const userDoc = await userRef.get();
    const userData = userDoc.data();
    
    if (userData?.profile) {
      const currentInterest = userData.profile.interesses[agentId] || 0.5;
      
      // Ajusta interesse baseado na nota (1-5 → -0.2 a +0.2)
      const adjustment = (rating - 3) * 0.1;
      const newInterest = Math.max(0, Math.min(1, currentInterest + adjustment));
      
      await userRef.update({
        [`profile.interesses.${agentId}`]: newInterest,
        lastFeedback: new Date().toISOString()
      });
      
      // Se feedback muito positivo (5), dá bônus
      if (rating === 5) {
        await userRef.update({
          credits: (userData.credits || 0) + 10
        });
        
        await db.collection('transactions').add({
          userId,
          type: "bonus",
          amount: 0,
          creditsAdded: 10,
          provider: "feedback",
          description: `Bônus por feedback 5 estrelas (${agentId})`,
          timestamp: new Date().toISOString()
        });
      }
    }
    
    logger.info(`✅ Feedback processado para usuário ${userId}`);
  } catch (error) {
    logger.error("Erro ao processar feedback:", error);
  }
});

// 📊 6. Função auxiliar para analytics em tempo real
export const getHVCAnalytics = onCall({ cors: corsHandler }, async (request) => {
  const { userId } = request.auth || {};
  
  // Verifica se é admin
  if (!userId) {
    throw new Error("Usuário não autenticado");
  }
  
  const userDoc = await db.collection('users').doc(userId).get();
  const userData = userDoc.data();
  
  if (!userData?.isAdmin) {
    throw new Error("Acesso negado - apenas admins");
  }
  
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Analytics do dia
    const analyticsDoc = await db.collection('hvc-analytics').doc(`daily-${today}`).get();
    const analytics = analyticsDoc.data();
    
    // Alertas ativos
    const alertsSnapshot = await db.collection('alerts')
      .where('resolved', '==', false)
      .orderBy('timestamp', 'desc')
      .limit(10)
      .get();
    
    const activeAlerts = alertsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    // Tech trends recentes
    const trendsSnapshot = await db.collection('tech-trends')
      .orderBy('date', 'desc')
      .limit(3)
      .get();
    
    const recentTrends = trendsSnapshot.docs.map(doc => doc.data());
    
    return {
      success: true,
      data: {
        analytics: analytics || {},
        activeAlerts,
        recentTrends,
        lastUpdated: new Date().toISOString()
      }
    };
    
  } catch (error) {
    logger.error("Erro ao buscar analytics:", error);
    throw new Error("Erro interno do servidor");
  }
});