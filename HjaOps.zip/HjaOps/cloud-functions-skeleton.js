/**
 * Hja²Ops - Cloud Functions
 * Firebase Functions com integração IA e sistema de créditos
 */

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

// Initialize Firebase Admin
admin.initializeApp();

// onUserCreate - Cria perfil inicial do usuário
exports.onUserCreate = functions.auth.user().onCreate((user) => {
  return admin.firestore().collection("users").doc(user.uid).set({
    email: user.email,
    credits: 50, // Créditos iniciais do plano free
    plan: "free",
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    lastLogin: admin.firestore.FieldValue.serverTimestamp(),
    profile: { 
      interesses: {}, 
      estiloPreferido: "futurista", 
      agentesUsados: {} 
    },
    billing: {
      creditsUsedMonth: 0,
      nextBillingDate: null,
      autoRenewal: false
    },
    security: {
      isAdmin: false,
      lastIpAddress: "",
      anomalyFlags: []
    }
  });
});

// onChatSubmit - Orquestrador principal de IA
exports.onChatSubmit = functions.https.onCall(async (data, context) => {
  // Validar autenticação
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be authenticated');
  }

  const { userId, agentId, message, chatId } = data;
  
  try {
    // 1. Buscar dados do usuário e agente
    const [userDoc, agentDoc] = await Promise.all([
      admin.firestore().collection('users').doc(userId).get(),
      admin.firestore().collection('agents').doc(agentId).get()
    ]);

    if (!userDoc.exists) {
      throw new functions.https.HttpsError('not-found', 'User not found');
    }
    
    if (!agentDoc.exists || !agentDoc.data().metadata.active) {
      throw new functions.https.HttpsError('not-found', 'Agent not available');
    }

    const userData = userDoc.data();
    const agentData = agentDoc.data();

    // 2. Validar créditos (estimativa baseada no agente)
    const estimatedCost = agentData.analytics.avgTokensPerChat * agentData.config.costPerToken || 0.1;
    
    if (userData.credits < estimatedCost) {
      throw new functions.https.HttpsError('resource-exhausted', 'Insufficient credits', {
        required: estimatedCost,
        available: userData.credits
      });
    }

    // 3. Chamar orquestrador de IA
    const aiResponse = await processWithAI(agentData, message);

    // 4. Calcular custo real e descontar créditos
    const realCost = aiResponse.tokens * agentData.config.costPerToken;
    
    await admin.firestore().collection('users').doc(userId).update({
      credits: admin.firestore.FieldValue.increment(-realCost),
      'billing.creditsUsedMonth': admin.firestore.FieldValue.increment(realCost),
      [`profile.agentesUsados.${agentId}`]: admin.firestore.FieldValue.increment(1),
      lastLogin: admin.firestore.FieldValue.serverTimestamp()
    });

    // 5. Registrar chat
    const chatRef = chatId ? 
      admin.firestore().collection('chats').doc(chatId) : 
      admin.firestore().collection('chats').doc();
    
    await chatRef.set({
      userId: userId,
      agentId: agentId,
      metadata: {
        title: message.substring(0, 50) + "...",
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        lastActivity: admin.firestore.FieldValue.serverTimestamp(),
        totalMessages: admin.firestore.FieldValue.increment(2), // user + assistant
        status: "active"
      },
      messages: admin.firestore.FieldValue.arrayUnion(
        {
          id: `user_${Date.now()}`,
          role: "user",
          content: message,
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        },
        {
          id: `assistant_${Date.now()}`,
          role: "assistant", 
          content: aiResponse.content,
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        }
      ),
      usage: {
        modelUsed: aiResponse.modelUsed,
        totalTokens: aiResponse.tokens,
        costInCredits: realCost,
        fallbackUsed: aiResponse.fallbackUsed
      }
    }, { merge: true });

    // 6. Criar transação de uso
    await admin.firestore().collection('transactions').add({
      userId: userId,
      type: 'credit_usage',
      details: {
        amount: -realCost,
        creditsAdded: -realCost,
        chatId: chatRef.id,
        agentId: agentId,
        model: aiResponse.modelUsed
      },
      payment: {
        provider: 'system',
        status: 'approved'
      },
      metadata: {
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        completedAt: admin.firestore.FieldValue.serverTimestamp()
      }
    });

    return {
      success: true,
      message: aiResponse.content,
      usage: {
        tokens: aiResponse.tokens,
        cost: realCost,
        model: aiResponse.modelUsed
      },
      chatId: chatRef.id
    };

  } catch (error) {
    console.error('Chat processing error:', error);
    throw new functions.https.HttpsError('internal', error.message);
  }
});

// Orquestrador de IA com fallback
async function processWithAI(agentData, message) {
  const models = [
    agentData.config.defaultModel,
    ...(agentData.config.fallbackModels || [])
  ];
  
  for (const modelName of models) {
    try {
      const result = await callAIProvider(modelName, agentData.prompt, message);
      return {
        content: result.content,
        tokens: result.tokens,
        modelUsed: modelName,
        fallbackUsed: modelName !== agentData.config.defaultModel
      };
    } catch (error) {
      console.error(`Model ${modelName} failed:`, error);
      continue;
    }
  }
  
  throw new Error('All AI providers failed');
}

// Chamadas para APIs de IA
async function callAIProvider(modelName, systemPrompt, userMessage) {
  if (modelName.startsWith('groq-')) {
    return await callGroqAPI(modelName, systemPrompt, userMessage);
  } else if (modelName.startsWith('hf-')) {
    return await callHuggingFaceAPI(modelName, systemPrompt, userMessage);
  } else if (modelName.startsWith('replit-')) {
    return await callReplitAPI(modelName, systemPrompt, userMessage);
  }
  throw new Error(`Unknown model provider: ${modelName}`);
}

async function callGroqAPI(model, systemPrompt, userMessage) {
  const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
    model: model.replace('groq-', ''),
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage }
    ]
  }, {
    headers: {
      'Authorization': `Bearer ${functions.config().groq.api_key}`,
      'Content-Type': 'application/json'
    }
  });
  
  return {
    content: response.data.choices[0].message.content,
    tokens: response.data.usage.total_tokens
  };
}

async function callHuggingFaceAPI(model, systemPrompt, userMessage) {
  // Implementar API HuggingFace
  const response = await axios.post(`https://api-inference.huggingface.co/models/${model}`, {
    inputs: `${systemPrompt}\n\nUser: ${userMessage}\nAssistant:`
  }, {
    headers: {
      'Authorization': `Bearer ${functions.config().huggingface.api_key}`,
      'Content-Type': 'application/json'
    }
  });
  
  return {
    content: response.data[0].generated_text,
    tokens: response.data[0].generated_text.length / 4 // Aproximação
  };
}

async function callReplitAPI(model, systemPrompt, userMessage) {
  // Implementar API Replit 
  // Similar structure to other APIs
  throw new Error('Replit API not implemented yet');
}

// onTransactionApproved - Webhook do Mercado Pago
exports.onTransactionApproved = functions.https.onRequest(async (req, res) => {
  try {
    const { userId, creditsAdded, amount, externalId } = req.body;
    
    // Atualizar créditos do usuário
    await admin.firestore().collection("users").doc(userId).update({
      credits: admin.firestore.FieldValue.increment(creditsAdded)
    });
    
    // Registrar transação
    await admin.firestore().collection("transactions").add({
      userId, 
      type: 'credit_purchase',
      details: {
        amount: amount,
        creditsAdded: creditsAdded
      },
      payment: {
        provider: "mercadopago",
        externalId: externalId,
        status: 'approved'
      },
      metadata: {
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        completedAt: admin.firestore.FieldValue.serverTimestamp()
      }
    });

    console.log(`Credits added: ${creditsAdded} for user ${userId}`);
    res.sendStatus(200);
  } catch (error) {
    console.error('Transaction error:', error);
    res.status(500).send('Error processing transaction');
  }
});

// dailyForecast - Análise diária de uso
exports.dailyForecast = functions.pubsub.schedule("every 24 hours").onRun(async () => {
  try {
    const usersSnapshot = await admin.firestore().collection('users').get();
    
    for (const userDoc of usersSnapshot.docs) {
      const userData = userDoc.data();
      const userId = userDoc.id;
      
      // Análise simples: se créditos < 10, criar alerta
      if (userData.credits < 10) {
        await admin.firestore().collection('alerts').add({
          type: 'lowCredits',
          severity: 'warning',
          title: 'Créditos Baixos',
          message: `Usuário ${userId} com ${userData.credits} créditos`,
          details: { userId: userId, credits: userData.credits },
          status: 'active',
          metadata: {
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            autoGenerated: true
          }
        });
      }
    }
    
    console.log('Daily forecast completed');
  } catch (error) {
    console.error('Daily forecast error:', error);
  }
});

// techScan - Scanner de tendências IA
exports.techScan = functions.pubsub.schedule("every 12 hours").onRun(async () => {
  try {
    // Simular busca de tendências (implementar APIs reais depois)
    const trends = [
      {
        nome: "GPT-5 Release",
        tipo: "new_model",
        impacto: "high",
        descricao: "OpenAI lança GPT-5 com melhor performance",
        relevanciaHja: 0.9
      }
    ];

    await admin.firestore().collection('tech-trends').add({
      date: admin.firestore.FieldValue.serverTimestamp(),
      trends: trends,
      priority: 'medium',
      summary: 'Novas tendências detectadas em IA'
    });

    console.log('Tech scan completed');
  } catch (error) {
    console.error('Tech scan error:', error);
  }
});